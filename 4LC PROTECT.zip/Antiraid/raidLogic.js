export const defaults = Object.freeze({ enabled: 1, count: 8, window_ms: 10000, duration_ms: 600000, action: 'kick' });
const waves = new Map();
export function observeJoin(guildId, memberId, settings, now = Date.now()) {
    let state = waves.get(guildId);
    if (!state) waves.set(guildId, state = { joins: [], until: 0 });
    state.joins = state.joins.filter(item => now - item.at < settings.window_ms);
    state.joins.push({ id: memberId, at: now });
    const triggered = now >= state.until && state.joins.length >= settings.count;
    if (triggered) state.until = now + settings.duration_ms;
    const ids = triggered ? [...new Set(state.joins.map(item => item.id))] : now < state.until ? [memberId] : [];
    if (state.joins.length > 500) state.joins = state.joins.slice(-500);
    return { triggered, active: now < state.until, ids, count: state.joins.length, until: state.until };
}
export function resetGuild(guildId) { waves.delete(guildId); }
