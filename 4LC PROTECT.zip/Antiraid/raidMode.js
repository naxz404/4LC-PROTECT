import { allowedGuilds } from '../ServerScope.js';
import { BrandedEmbedBuilder } from '../BrandedEmbedBuilder.js';
import { EmbedBuilder } from 'discord.js';
import db from '../Events/loadDatabase.js';
import sendLog from '../Events/sendlog.js';
import config from '../config.json' with { type: 'json' };
import { defaults, observeJoin } from './raidLogic.js';

const states = new Map();
const timers = new Map();
const query = (sql, values) => new Promise((resolve, reject) => db.get(sql, values, (err, row) => err ? reject(err) : resolve(row)));
const run = (sql, values) => new Promise((resolve, reject) => db.run(sql, values, err => err ? reject(err) : resolve()));
export async function settings(guildId) {
    const row = await query('SELECT * FROM raidmode WHERE guild = ?', [guildId]);
    return { ...defaults, ...row };
}
async function log(guild, description) {
    sendLog(guild, new BrandedEmbedBuilder().setTitle('4LC-PROTECT • Auto RaidMode').setDescription(description).setColor(config.color).setFooter({ text: 'By 4LC' }).setTimestamp(), 'raidlog');
}
async function restoreVerification(guild) {
    const row = await query('SELECT * FROM raidmode WHERE guild = ?', [guild.id]);
    if (!row?.verification_until) return;
    if (Date.now() < row.verification_until) return scheduleRestore(guild, row.verification_until);
    if (guild.verificationLevel === 4 && row.previous_verification !== null && row.previous_verification !== 4) {
        try { await guild.setVerificationLevel(row.previous_verification, 'Fin Auto RaidMode'); }
        catch (error) { console.error('[RaidMode] Restauration vérification:', error); return scheduleRestore(guild, Date.now() + 30000); }
    }
    await run('UPDATE raidmode SET previous_verification = NULL, verification_until = 0 WHERE guild = ?', [guild.id]);
}
function scheduleRestore(guild, until) {
    if (timers.has(guild.id)) clearTimeout(timers.get(guild.id));
    const timer = setTimeout(() => { timers.delete(guild.id); restoreVerification(guild).catch(console.error); }, Math.max(100, until - Date.now() + 100));
    timer.unref?.(); timers.set(guild.id, timer);
}
export async function resumeVerification(bot) {
    for (const guild of allowedGuilds(bot)) {
        const row = await query('SELECT verification_until FROM raidmode WHERE guild = ?', [guild.id]).catch(() => null);
        if (row?.verification_until) scheduleRestore(guild, Math.max(Date.now(), row.verification_until));
    }
}
async function raiseVerification(guild, until) {
    await run(`INSERT INTO raidmode (guild, previous_verification, verification_until) VALUES (?, ?, ?)
        ON CONFLICT(guild) DO UPDATE SET previous_verification = CASE WHEN verification_until > 0 THEN previous_verification ELSE excluded.previous_verification END,
        verification_until = excluded.verification_until`, [guild.id, guild.verificationLevel, until]);
    scheduleRestore(guild, until);
    if (guild.verificationLevel !== 4) await guild.setVerificationLevel(4, 'Auto RaidMode : arrivées massives');
}
async function process(guild, ids, action) {
    const unique = [...new Set(ids)].filter(id => id !== guild.ownerId && id !== guild.client.user.id);
    const members = unique.map(id => guild.members.cache.get(id)).filter(m => m && !m.user.bot);
    if (action === 'ban' && typeof guild.bans.bulkCreate === 'function') {
        for (let n = 0; n < members.length; n += 200) {
            const batch = members.slice(n, n + 200).filter(m => m.bannable).map(m => m.id);
            if (batch.length) await guild.bans.bulkCreate(batch, { reason: '4LC-PROTECT : raid' }).catch(console.error);
        }
    } else {
        let n = 0;
        await Promise.all(Array.from({ length: Math.min(3, members.length) }, async () => {
            while (n < members.length) {
                const m = members[n++];
                if (action === 'ban' && m.bannable) await m.ban({ reason: '4LC-PROTECT : raid' }).catch(console.error);
                else if (action === 'kick' && m.kickable) await m.kick('4LC-PROTECT : raid').catch(console.error);
            }
        }));
    }
}
export async function checkJoin(member) {
    if (member.user.bot) return false;
    const cfg = await settings(member.guild.id);
    if (!cfg.enabled) return false;
    const result = observeJoin(member.guild.id, member.id, cfg);
    if (!result.active) return false;
    let state = states.get(member.guild.id);
    if (!state) states.set(member.guild.id, state = { ids: new Set(), timer: null });
    for (const id of result.ids) state.ids.add(id);
    if (result.triggered) {
        void raiseVerification(member.guild, result.until).catch(error => console.error('[RaidMode] Vérification:', error));
        void log(member.guild, `${result.count} arrivées en ${cfg.window_ms / 1000} s. Mode raid activé pour ${Math.round(cfg.duration_ms / 60000)} min. Action : ${cfg.action}.`);
    }
    if (!state.timer) state.timer = setTimeout(() => {
        states.delete(member.guild.id);
        void process(member.guild, [...state.ids], cfg.action).catch(console.error);
    }, 150);
    return true;
}
