import { isGlobalOwner } from '../Owners.js';
import db from '../Events/loadDatabase.js';
import config from '../config.json' with { type: 'json' };
const recent = new Set();
export async function findEntry(guild, type, targetId) {
    for (const delay of [0, 100, 250, 500]) {
        if (delay) await new Promise(resolve => setTimeout(resolve, delay));
        const logs = await guild.fetchAuditLogs({ type, limit: 10 }).catch(() => null);
        const entry = logs?.entries.find(e => e.target?.id === targetId && Date.now() - e.createdTimestamp < 7000 && e.executor?.id);
        if (entry) return entry;
    }
    return null;
}
const row = (sql, args) => new Promise(resolve => db.get(sql, args, (err, value) => resolve(err ? null : value)));
export async function isTrusted(guild, executor) {
    if (!executor || executor.id === guild.ownerId || executor.id === guild.client.user.id || isGlobalOwner(executor.id)) return true;
    return Boolean(await row('SELECT id FROM owner WHERE id = ?', [executor.id]) || await row('SELECT id FROM whitelist WHERE id = ?', [executor.id]));
}
export async function punishExecutor(guild, executor, module, auditId) {
    if (await isTrusted(guild, executor)) return;
    const key = `${guild.id}:${auditId}`;
    if (recent.has(key)) return;
    recent.add(key);
    const timer = setTimeout(() => recent.delete(key), 10000); timer.unref?.();
    const member = guild.members.cache.get(executor.id) || await guild.members.fetch(executor.id).catch(() => null);
    if (!member) return;
    const setting = await row('SELECT punition FROM punish WHERE guild = ? AND module = ?', [guild.id, module]);
    const action = setting?.punition || 'derank';
    try {
        if (action === 'ban' && member.bannable) await member.ban({ reason: module });
        else if (action === 'kick' && member.kickable) await member.kick(module);
        else if (action === 'derank' && member.manageable) await member.roles.set([], module);
        else if (action === 'timeout' && member.moderatable) await member.timeout(60000, module);
    } catch (error) { console.error(`[${module}] Sanction impossible:`, error); }
}
