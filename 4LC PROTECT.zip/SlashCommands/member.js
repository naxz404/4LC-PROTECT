import { ApplicationCommandOptionType, PermissionFlagsBits } from 'discord.js';
import { memberPanelPayload } from '../Features/staffPanel.js';
import { canOpenStaff } from '../Features/staffPanel.js';
export const command = {
  name: 'member', description: 'Ouvrir le panel complet de gestion d’un membre', dm_permission: false, default_member_permissions: null,
  options: [{ name:'membre', description:'Membre à gérer', type:ApplicationCommandOptionType.User, required:true }],
  run: async (_bot, interaction) => {
    if (!canOpenStaff(interaction.member)) return interaction.reply({content:'⛔ Permission insuffisante.',ephemeral:true});
    const user=interaction.options.getUser('membre',true); const member=await interaction.guild.members.fetch(user.id).catch(()=>null);
    if(!member) return interaction.reply({content:'Membre introuvable.',ephemeral:true});
    return interaction.reply({...memberPanelPayload(member),ephemeral:true});
  }
};
