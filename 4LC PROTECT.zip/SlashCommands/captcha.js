import { ApplicationCommandOptionType, MessageFlags, PermissionFlagsBits } from 'discord.js';
import definition from '../ProtectModules/Commands/captcha/captcha.js';
import { runModule } from '../ProtectModules/integration.js';
export const command = {
    name: 'captcha', description: 'Configurer le captcha et afficher son panneau', dm_permission: false,
    default_member_permissions: String(PermissionFlagsBits.ManageGuild),
    options: [{ type: ApplicationCommandOptionType.Boolean, name: 'activer', description: 'Activer ou désactiver le captcha' }],
    run: async (client, interaction) => {
        await interaction.deferReply({ flags: MessageFlags.Ephemeral });
        const enabled = interaction.options.getBoolean('activer');
        const message = {
            guild: interaction.guild, member: interaction.member, author: interaction.user,
            reply: data => interaction.editReply({ ...data, flags: (data.flags || 0) & ~MessageFlags.Ephemeral }),
        };
        return runModule(definition, client, message, enabled === null ? [] : [enabled ? 'on' : 'off']);
    },
};
