import { PermissionFlagsBits } from 'discord.js';
import { handleSlash } from '../ProtectCore/slash/handlers.js';
export const command = {
    name: 'config',
    description: 'Ouvrir le panneau complet de configuration 4LC-PROTECT',
    dm_permission: false,
    default_member_permissions: String(PermissionFlagsBits.Administrator),
    options: [],
    run: async (client, interaction) => handleSlash(interaction),
};
