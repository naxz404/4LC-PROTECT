import { PermissionFlagsBits } from 'discord.js';
import { staffPanelPayload } from '../Features/staffPanel.js';
import { canOpenStaff } from '../Features/staffPanel.js';
export const command = {
  name: 'panel', description: 'Ouvrir le panel staff 4LC-PROTECT', dm_permission: false,
  default_member_permissions: null, options: [],
  run: async (bot, interaction) => {
    if (!canOpenStaff(interaction.member)) return interaction.reply({ content: '⛔ Permission insuffisante.', ephemeral: true });
    return interaction.reply(staffPanelPayload());
  },
};
