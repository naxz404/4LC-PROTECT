import { allowedGuilds } from '../ServerScope.js';
import { getGuildConfig, saveGuildConfig } from './storage.js';
import { ActionRowBuilder, ButtonBuilder, ButtonStyle, EmbedBuilder } from 'discord.js';
import { tr } from './i18n.js';

export async function sendTempBanNotice(user, guild, durationMs, reason, cfg = getGuildConfig(guild.id)) {
    const expiresAt = Date.now() + durationMs;
    const embed = new EmbedBuilder().setColor(0x000000).setTitle(tr(cfg, '⏳ Bannissement temporaire', '⏳ Temporary ban')).setDescription(
        `${tr(cfg, 'Serveur', 'Server')} : **${guild.name}**\n` +
        `${tr(cfg, 'Raison', 'Reason')} : **${reason}**\n` +
        `${tr(cfg, 'Fin prévue', 'Expected end')} : <t:${Math.floor(expiresAt / 1000)}:F> (<t:${Math.floor(expiresAt / 1000)}:R>)`,
    ).setFooter({ text: '4LC-PROTECT • Modération' });
    const payload = { embeds: [embed] };
    if (cfg.appealUrl && /^https?:\/\//i.test(cfg.appealUrl)) payload.components = [new ActionRowBuilder().addComponents(new ButtonBuilder().setStyle(ButtonStyle.Link).setURL(cfg.appealUrl).setLabel(tr(cfg, 'Faire appel', 'Appeal')).setEmoji('📨'))];
    return user.send(payload).then(() => true).catch(() => false);
}

export async function processExpiredBans(client, now = Date.now()) {
    for (const guild of allowedGuilds(client)) {
        const cfg = getGuildConfig(guild.id);
        if (!cfg.tempBans?.length) continue;
        const remaining = [];
        for (const ban of cfg.tempBans) {
            if (ban.expiresAt > now) { remaining.push(ban); continue; }
            try {
                let current;
                try { current = await guild.bans.fetch(ban.userId); }
                catch (error) { if (error.code === 10026) current = null; else throw error; }
                if (current) await guild.members.unban(ban.userId, 'Bannissement temporaire expiré');
            } catch (error) {
                console.error(`Tempban ${guild.id}/${ban.userId} :`, error);
                remaining.push(ban);
            }
        }
        if (remaining.length !== cfg.tempBans.length) { cfg.tempBans = remaining; saveGuildConfig(guild.id, cfg); }
    }
}
