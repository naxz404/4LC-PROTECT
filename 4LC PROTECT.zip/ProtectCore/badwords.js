import { AutoModerationActionType, AutoModerationRuleEventType, AutoModerationRuleTriggerType, PermissionFlagsBits } from 'discord.js';
import { getGuildConfig, saveGuildConfig } from './storage.js';
import { invalidateSettings } from './antiraid/runtime.js';

export function parseBadwords(input) {
    const words = String(input || '').split(/[,\n]+/).map((word) => word.trim().toLowerCase()).filter(Boolean);
    if (words.length > 100 || words.some((word) => word.length > 60 || /[\r\n*]/.test(word))) throw Error('Maximum 100 mots ou expressions, 60 caractères chacun, sans astérisque.');
    return [...new Set(words)];
}

export function blockedWord(content, cfg, channelId) {
    if (!cfg.badwords?.enabled || cfg.badwords.exemptChannels?.includes(channelId)) return null;
    const value = String(content || '').normalize('NFKC').toLocaleLowerCase();
    return (cfg.badwords.words || []).find((word) => {
        const needle = word.normalize('NFKC').toLocaleLowerCase();
        let pos = value.indexOf(needle);
        while (pos >= 0) {
            const before = pos ? value[pos - 1] : '';
            const after = value[pos + needle.length] || '';
            if ((!before || !/[\p{L}\p{N}]/u.test(before)) && (!after || !/[\p{L}\p{N}]/u.test(after))) return true;
            pos = value.indexOf(needle, pos + 1);
        }
        return false;
    }) || null;
}

// Ne modifier que la règle dont l'identifiant a été créé et conservé par ce bot.
export async function syncBadwordsRule(guild, cfg = getGuildConfig(guild.id)) {
    const words = cfg.badwords?.words || [];
    const shouldExist = Boolean(cfg.badwords?.enabled && words.length);
    if (!shouldExist && !cfg.badwords?.ruleId) return { active: false };
    const me = guild.members.me || await guild.members.fetchMe().catch(() => null);
    if (!me?.permissions.has(PermissionFlagsBits.ManageGuild)) throw Error('Permission « Gérer le serveur » manquante pour AutoMod. Le filtre du bot reste actif après publication.');
    let rule = cfg.badwords.ruleId ? await guild.autoModerationRules.fetch(cfg.badwords.ruleId).catch(() => null) : null;
    if (!shouldExist) {
        if (rule) await rule.delete('4LC-PROTECT : désactivation du filtre de mots');
        cfg.badwords.ruleId = null; saveGuildConfig(guild.id, cfg); invalidateSettings(guild.id);
        return { active: false };
    }
    const options = {
        name: '4LC-PROTECT · Mots interdits',
        eventType: AutoModerationRuleEventType.MessageSend,
        triggerType: AutoModerationRuleTriggerType.Keyword,
        triggerMetadata: { keywordFilter: words },
        actions: [
            { type: AutoModerationActionType.BlockMessage, metadata: { customMessage: 'Ce message contient un mot interdit sur ce serveur.' } },
            ...(cfg.badwords.sanction === 'timeout' ? [{ type: AutoModerationActionType.Timeout, metadata: { durationSeconds: cfg.badwords.timeoutSeconds || 60 } }] : []),
        ],
        exemptChannels: (cfg.badwords.exemptChannels || []).filter((id) => guild.channels.cache.has(id)).slice(0, 50),
        enabled: true,
        reason: '4LC-PROTECT : synchroniser les mots interdits',
    };
    if (cfg.badwords.sanction === 'timeout' && !me.permissions.has(PermissionFlagsBits.ModerateMembers)) throw Error('Permission « Exclure temporairement des membres » manquante pour le timeout AutoMod.');
    if (rule) await rule.edit(options);
    else {
        rule = await guild.autoModerationRules.create(options);
        cfg.badwords.ruleId = rule.id; saveGuildConfig(guild.id, cfg); invalidateSettings(guild.id);
    }
    return { active: true, ruleId: rule.id };
}
