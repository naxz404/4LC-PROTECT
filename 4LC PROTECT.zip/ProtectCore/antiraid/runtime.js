// Inspiré de Handler/antiraid/runtime.js de 4LC-PROTECT : cache de config par
// serveur, file de sanctions à concurrence limitée avec déduplication, et
// cache des entrées d'audit-log avec nouvelles tentatives (l'entrée d'audit
// arrive parfois après l'événement Discord).
import config from '../config.js';
import { getGuildConfig } from '../storage.js';

const SETTINGS_TTL = 30_000;
const MAX_SANCTION_CONCURRENCY = 3;
const SANCTION_DEDUPE_MS = 5000;
const AUDIT_TTL = 2_000;
// Une entrée reçue par guildAuditLogEntryCreate est utilisée sans requête.
// En secours, ce délai très court évite qu'un cache vieux de deux secondes
// retarde la contention pendant une rafale de suppressions.
const AUDIT_FETCH_COOLDOWN_MS = 125;

const settingsCache = new Map();
const sanctionQueues = new Map();
const sanctionActive = new Map();
const sanctionRecent = new Map();
const auditEntryCache = new Map();
const auditFetches = new Map();
const auditLastFetch = new Map();

/** Config anti-raid mise en cache 30s ; invalidée immédiatement par les commandes. */
export function getSettings(guildId) {
    const cached = settingsCache.get(guildId);
    if (cached && cached.expiresAt > Date.now()) return cached.value;
    const value = getGuildConfig(guildId);
    settingsCache.set(guildId, { value, expiresAt: Date.now() + SETTINGS_TTL });
    return value;
}

export function invalidateSettings(guildId) {
    settingsCache.delete(guildId);
}

/** Bypass = owner du bot ou whitelist du serveur. */
export function isBypassed(userId, guildId, ...trustedIds) {
    if (trustedIds.filter(Boolean).includes(userId)) return true;
    if (config.ownerIds.includes(userId)) return true;
    const settings = getSettings(guildId);
    return settings.whitelistedUsers.includes(userId) || (settings.whitelistEntries || []).some((entry) => entry.userId === userId && entry.module === 'all' && (!entry.expiresAt || entry.expiresAt > Date.now()));
}

/** Exemption globale ou limitée à une protection, avec expiration facultative. */
export function isModuleBypassed(userId, guildId, module, ...trustedIds) {
    if (trustedIds.filter(Boolean).includes(userId) || config.ownerIds.includes(userId)) return true;
    const settings = getSettings(guildId);
    if (settings.whitelistedUsers.includes(userId)) return true;
    return (settings.whitelistEntries || []).some((entry) => entry.userId === userId && (entry.module === 'all' || entry.module === module) && (!entry.expiresAt || entry.expiresAt > Date.now()));
}

function drain(guildId) {
    const queue = sanctionQueues.get(guildId);
    if (!queue) return;
    let active = sanctionActive.get(guildId) ?? 0;
    while (active < MAX_SANCTION_CONCURRENCY && queue.length) {
        const job = queue.shift();
        if (!job) break;
        active++;
        sanctionActive.set(guildId, active);
        Promise.resolve()
            .then(job.task)
            .catch((error) => console.error(`[AntiRaid] Sanction ${job.key} échouée:`, error))
            .finally(() => {
                sanctionActive.set(guildId, Math.max(0, (sanctionActive.get(guildId) ?? 1) - 1));
                drain(guildId);
            });
    }
    if (!queue.length && active === 0) {
        sanctionQueues.delete(guildId);
        sanctionActive.delete(guildId);
    }
}

/** File de sanctions par serveur (concurrence limitée) + déduplication 5s
 * pour éviter de sanctionner deux fois la même cible pour le même événement. */
export function queueSanction(guildId, key, task) {
    const now = Date.now();
    const dedupeKey = `${guildId}:${key}`;
    const last = sanctionRecent.get(dedupeKey) ?? 0;
    if (now - last < SANCTION_DEDUPE_MS) return false;
    sanctionRecent.set(dedupeKey, now);
    if (sanctionRecent.size > 10_000) {
        for (const [k, ts] of sanctionRecent) {
            if (now - ts > SANCTION_DEDUPE_MS) sanctionRecent.delete(k);
        }
    }
    if (!sanctionQueues.has(guildId)) sanctionQueues.set(guildId, []);
    sanctionQueues.get(guildId).push({ key, task });
    drain(guildId);
    return true;
}

async function fetchAuditEntries(guild, type, force = false) {
    const key = `${guild.id}:${type}`;
    const cached = auditEntryCache.get(key);
    if (!force && cached && cached.expiresAt > Date.now()) return cached.entries;
    const lastFetch = auditLastFetch.get(key) ?? 0;
    if (!force && Date.now() - lastFetch < AUDIT_FETCH_COOLDOWN_MS) return cached?.entries ?? [];
    if (auditFetches.has(key)) return auditFetches.get(key);
    auditLastFetch.set(key, Date.now());
    const request = (async () => {
        try {
            const logs = await guild.fetchAuditLogs({ limit: 50, type });
            const liveEntries = auditEntryCache.get(key)?.entries ?? [];
            const fetched = [...logs.entries.values()];
            const entries = [...new Map([...liveEntries, ...fetched].map((e) => [e.id, e])).values()]
                .sort((a, b) => b.createdTimestamp - a.createdTimestamp)
                .slice(0, 50);
            auditEntryCache.set(key, { entries, expiresAt: Date.now() + AUDIT_TTL });
            return entries;
        } catch (error) {
            console.error(`[AntiRaid] Audit Log indisponible (${guild.id}/${type}):`, error);
            return auditEntryCache.get(key)?.entries ?? [];
        } finally {
            auditFetches.delete(key);
        }
    })();
    auditFetches.set(key, request);
    return request;
}

/** Enregistre immédiatement une entrée reçue via guildAuditLogEntryCreate. */
export function recordAuditEntry(guild, entry) {
    if (!guild?.id || !entry?.action || !entry?.id) return;
    const key = `${guild.id}:${entry.action}`;
    const current = auditEntryCache.get(key)?.entries ?? [];
    const entries = [entry, ...current.filter((item) => item.id !== entry.id)]
        .sort((a, b) => b.createdTimestamp - a.createdTimestamp)
        .slice(0, 50);
    auditEntryCache.set(key, { entries, expiresAt: Date.now() + AUDIT_TTL });
}

/** Entrée d'audit-log la plus récente pour une cible donnée (fenêtre maxAge ms).
 * Retente plusieurs fois : l'entrée d'audit peut arriver après l'événement gateway. */
export async function findRecentAuditEntry(guild, type, targetId = null, maxAge = 5000) {
    const retryDelays = targetId == null ? [0, 60, 180, 450, 900] : [0, 40, 120, 300, 700];
    for (let attempt = 0; attempt < retryDelays.length; attempt++) {
        const delay = retryDelays[attempt];
        if (delay) await new Promise((r) => setTimeout(r, delay));
        let entries = auditEntryCache.get(`${guild.id}:${type}`)?.entries ?? [];
        let now = Date.now();
        let matches = entries
            .filter((e) => e.executor && now - e.createdTimestamp >= 0 && now - e.createdTimestamp <= maxAge)
            .filter((e) => targetId == null || e.target?.id === targetId)
            .sort((a, b) => b.createdTimestamp - a.createdTimestamp);
        if (matches[0]) return matches[0];
        entries = await fetchAuditEntries(guild, type, attempt > 0);
        now = Date.now();
        matches = entries
            .filter((e) => e.executor && now - e.createdTimestamp >= 0 && now - e.createdTimestamp <= maxAge)
            .filter((e) => targetId == null || e.target?.id === targetId)
            .sort((a, b) => b.createdTimestamp - a.createdTimestamp);
        if (matches[0]) return matches[0];
    }
    return null;
}

export function clearGuildRuntime(guildId) {
    settingsCache.delete(guildId);
    sanctionQueues.delete(guildId);
    sanctionActive.delete(guildId);
    for (const key of auditEntryCache.keys()) if (key.startsWith(`${guildId}:`)) auditEntryCache.delete(key);
    for (const key of auditFetches.keys()) if (key.startsWith(`${guildId}:`)) auditFetches.delete(key);
    for (const key of auditLastFetch.keys()) if (key.startsWith(`${guildId}:`)) auditLastFetch.delete(key);
}
