// Adapté de Handler/antiraid/logs.js de 4LC-PROTECT.
import { AttachmentBuilder, EmbedBuilder } from 'discord.js';
import { fileURLToPath } from 'node:url';
import { colors } from '../config.js';
import { getSettings } from './runtime.js';
import { getGuildConfig, saveGuildConfig } from '../storage.js';
import { invalidateSettings } from './runtime.js';
import { emojiText } from '../appEmojis.js';

const ALERT_GIF_NAME = 'alertastaff2000.gif';
const ALERT_GIF_PATH = fileURLToPath(new URL(`../assets/${ALERT_GIF_NAME}`, import.meta.url));
const urgentTitle = (title) => /(?:🚨|Anti-Nuke|Urgence|Emergency|Restauration incomplète|Restore failed|Phishing détecté|Phishing detected)/i.test(title);

export function buildAntiRaidEmbed(title, desc, color = colors.prime) {
    const urgent = urgentTitle(title);
    const embed = new EmbedBuilder()
        .setTitle(`${emojiText(urgent ? 'alert' : 'role', urgent ? '🚨' : '🛡️')} ${title}`)
        .setDescription(desc)
        .setColor(color)
        .setFooter({ text: '4LC-PROTECT • Protection en temps réel' })
        .setTimestamp();
    if (urgent) embed.setThumbnail(`attachment://${ALERT_GIF_NAME}`);
    return embed;
}

async function sendNow(client, guildId, embed, components = []) {
    try {
        let settings = getSettings(guildId);
        const guild = client.guilds?.cache?.get(guildId) || null;
        if (!settings.logChannel && guild) {
            const fallback = guild.channels.cache.find((item) => item.name === '4lcprotect-logs' && item.isTextBased?.() && item.isSendable?.());
            if (fallback) {
                const cfg = getGuildConfig(guildId); cfg.logChannel = fallback.id; saveGuildConfig(guildId, cfg); invalidateSettings(guildId); settings = cfg;
            }
        }
        if (!settings.logChannel) return false;
        let channel = client.channels.cache.get(settings.logChannel);
        if (!channel) channel = await client.channels.fetch(settings.logChannel).catch(() => null);
        if (!channel || !channel.isTextBased() || channel.isDMBased() || !channel.isSendable()) return false;
        if (channel.guildId !== guildId) return false; // le salon sauvegardé a été supprimé/remplacé
        const files = [];
        if (embed.toJSON().thumbnail?.url === `attachment://${ALERT_GIF_NAME}`) files.push(new AttachmentBuilder(ALERT_GIF_PATH, { name: ALERT_GIF_NAME }));
        await channel.send({ embeds: [embed], components, files });
        return true;
    } catch (error) {
        console.error(`[AntiRaid] Échec de l'envoi du log dans ${guildId}:`, error);
        return false;
    }
}

// Les logs ordinaires attendent derrière les alertes critiques. La protection
// ne doit jamais attendre une longue file d'envois d'images Discord.
const queues = new Map();
const delivery = new Map();
export function logDeliveryMetrics(guildId) {
    return { ...(delivery.get(guildId) || { lastAt: null, lastDurationMs: null, lastSuccess: null }), queued: queues.get(guildId)?.entries.length || 0 };
}
export function sendLog(client, guildId, embed, priority = 'normal', components = []) {
    return new Promise((resolve) => {
        const state = queues.get(guildId) || { busy: false, entries: [] };
        queues.set(guildId, state);
        if (state.entries.length >= 50 && priority !== 'critical') {
            delivery.set(guildId, { lastAt: Date.now(), lastDurationMs: null, lastSuccess: false });
            return resolve(false);
        }
        const item = { client, guildId, embed, components, resolve };
        if (priority === 'critical') state.entries.unshift(item);
        else state.entries.push(item);
        if (!state.busy) void drain(guildId, state);
    });
}

async function drain(guildId, state) {
    state.busy = true;
    while (state.entries.length) {
        const item = state.entries.shift();
        const start = Date.now();
        const success = await sendNow(item.client, item.guildId, item.embed, item.components);
        delivery.set(guildId, { lastAt: Date.now(), lastDurationMs: Date.now() - start, lastSuccess: success });
        item.resolve(success);
    }
    state.busy = false;
    queues.delete(guildId);
}
