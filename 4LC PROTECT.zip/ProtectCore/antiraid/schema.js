// Modules et sanctions anti-raid, directement inspirés de la config
// antiraid de 4LC-PROTECT (Handler/antiraid/schema.js), simplifiés pour un
// stockage JSON plat plutôt que Mongo.

export const PUNISHMENTS = ['timeout', 'kick', 'ban', 'derank', 'jail'];
export const PUNISHMENT_LABELS = {
    timeout: 'TimeMute / Timeout',
    kick: 'Expulsion',
    ban: 'Bannissement',
    derank: 'Retrait des rôles',
    jail: 'Quarantaine',
    none: 'Aucune sanction',
};
export const PUNISHMENT_LABELS_EN = {
    timeout: 'TimeMute / Timeout', kick: 'Kick', ban: 'Ban', derank: 'Remove roles', jail: 'Quarantine', none: 'No punishment',
};
export const PUNISHMENT_PAST_LABELS = {
    ban: 'banni',
    kick: 'expulsé',
    derank: 'dérank',
    timeout: 'mis en timeout',
    jail: 'placé en quarantaine',
    none: 'non sanctionné',
};
export const PUNISHMENT_PAST_LABELS_EN = {
    ban: 'banned', kick: 'kicked', derank: 'roles removed', timeout: 'timed out', jail: 'quarantined', none: 'not punished',
};

export const MODULES = [
    'antispam',
    'antilink',
    'antichannel',
    'antirole',
    'antiupdate',
    'antivanity',
    'antiwebhook',
    'antiban',
    'antieveryone',
    'antibot',
    'antitoken',
    'antiuserapps',
];

export const MODULE_LABELS = {
    antispam: 'Anti-Spam',
    antilink: 'Anti-Lien',
    antichannel: 'Anti-Salon',
    antirole: 'Anti-Rôle',
    antiupdate: 'Anti-Modification serveur',
    antivanity: 'Anti-Vanity URL',
    antiwebhook: 'Anti-Webhook',
    antiban: 'Anti-Ban',
    antieveryone: 'Anti-@everyone/@here',
    antibot: 'Anti-Bot',
    antitoken: 'Anti-Compte récent',
    antiuserapps: 'Anti-App externe',
};
export const MODULE_LABELS_EN = {
    antispam: 'Anti-Spam', antilink: 'Anti-Link', antichannel: 'Anti-Channel', antirole: 'Anti-Role',
    antiupdate: 'Anti-Server Update', antivanity: 'Anti-Vanity URL', antiwebhook: 'Anti-Webhook',
    antiban: 'Anti-Ban', antieveryone: 'Anti-@everyone/@here', antibot: 'Anti-Bot', antitoken: 'Anti-New Account',
    antiuserapps: 'Anti-External-App',
};

export const MODULE_DESCRIPTIONS = {
    antispam: "Sanctionne les membres qui envoient trop de messages en peu de temps.",
    antilink: "Supprime les liens (ou uniquement les invitations Discord) envoyés par les membres.",
    antichannel: "Supprime les salons créés sans autorisation et sanctionne la suppression de salon non autorisée.",
    antirole: "Sanctionne la création/suppression de rôles, et les attributions de rôles Administrateur non autorisées.",
    antiupdate: "Restaure les paramètres du serveur modifiés sans autorisation (nom, icône, salons, filtres).",
    antivanity: "Restaure automatiquement l'URL personnalisée (vanity) du serveur.",
    antiwebhook: "Sanctionne la création/suppression de webhooks non autorisée.",
    antiban: "Alerte et sanctionne l'auteur d'un bannissement non autorisé.",
    antieveryone: "Supprime les mentions @everyone/@here envoyées par des membres non autorisés.",
    antibot: "Expulse les bots non autorisés et bloque les réponses des applications installées sur un compte membre.",
    antitoken: "Expulse les comptes trop récents à leur arrivée sur le serveur.",
    antiuserapps: "Supprime les réponses des applications non ajoutées au serveur (installées seulement sur un compte membre) et sanctionne le membre qui les a utilisées.",
};
export const MODULE_DESCRIPTIONS_EN = {
    antispam: 'Punishes members who send too many messages in a short time.',
    antilink: 'Deletes links, or Discord invitations only, sent by members.',
    antichannel: 'Deletes unauthorized channels and punishes unauthorized channel deletion.',
    antirole: 'Punishes unauthorized role changes and Administrator role grants.',
    antiupdate: 'Restores unauthorized server setting changes including name, icon and filters.',
    antivanity: 'Automatically restores the server custom invite URL.',
    antiwebhook: 'Punishes unauthorized webhook creation or deletion.',
    antiban: 'Logs and punishes unauthorized bans.',
    antieveryone: 'Deletes unauthorized @everyone and @here mentions.',
    antibot: 'Kicks unauthorized bots and blocks responses from user-installed apps.',
    antitoken: 'Kicks accounts that are too new when they join the server.',
    antiuserapps: "Deletes responses from applications not added to the server (installed only on a member's account) and punishes the member who used them.",
};

export const moduleLabel = (name, cfg) => (cfg?.language === 'en' ? MODULE_LABELS_EN : MODULE_LABELS)[name] || name;
export const moduleDescription = (name, cfg) => (cfg?.language === 'en' ? MODULE_DESCRIPTIONS_EN : MODULE_DESCRIPTIONS)[name] || name;
export const punishmentLabel = (name, cfg) => (cfg?.language === 'en' ? PUNISHMENT_LABELS_EN : PUNISHMENT_LABELS)[name] || name;
export const punishmentPastLabel = (name, cfg) => (cfg?.language === 'en' ? PUNISHMENT_PAST_LABELS_EN : PUNISHMENT_PAST_LABELS)[name] || name;

const DAY = 24 * 60 * 60 * 1000;
const MIN = 60 * 1000;

export const DEFAULT_PUNISHMENT = 'timeout';

// Profil strict 4LC-PROTECT.
// Les actions administratives destructrices sont bannies immédiatement,
// tandis que les infractions de messagerie utilisent des timeouts sévères
// afin de limiter les faux positifs irréversibles.
export const DEFAULT_PUNISHMENTS = {
    antispam: 'timeout',
    antilink: 'timeout',
    antichannel: 'ban',
    antirole: 'ban',
    antiupdate: 'ban',
    antivanity: 'ban',
    antiwebhook: 'ban',
    antiban: 'ban',
    antieveryone: 'timeout',
    antibot: 'ban',
    antitoken: 'kick',
    antiuserapps: 'timeout',
};

export const DEFAULT_PUNISHMENT_DURATIONS = {
    antispam: 30 * MIN,
    antilink: 2 * 60 * MIN,
    antichannel: 10 * MIN,
    antirole: 10 * MIN,
    antiupdate: 10 * MIN,
    antivanity: 10 * MIN,
    antiwebhook: 10 * MIN,
    antiban: 10 * MIN,
    antieveryone: 2 * 60 * MIN,
    antibot: 10 * MIN,
    antitoken: 10 * MIN,
    antiuserapps: 2 * 60 * MIN,
};

export function applyStrictDefaultPunishments(cfg) {
    cfg.punishments = { ...(cfg.punishments || {}), ...DEFAULT_PUNISHMENTS };
    cfg.punishmentDurations = { ...(cfg.punishmentDurations || {}), ...DEFAULT_PUNISHMENT_DURATIONS };
    cfg.raidAction = 'ban';
    if (cfg.honeypot) cfg.honeypot.punishment = 'ban';
    if (cfg.antiNuke) cfg.antiNuke.action = 'derank';
    return cfg;
}

export function punishmentDuration(cfg, module, fallback = MIN) {
    const value = Number(cfg?.punishmentDurations?.[module]);
    return Number.isFinite(value) && value >= 1_000 ? Math.min(value, 28 * DAY) : fallback;
}

export function durationLabel(ms, cfg = {}) {
    const minutes = Math.max(1, Math.round(Number(ms || MIN) / MIN));
    if (minutes % 1440 === 0) return `${minutes / 1440} ${cfg.language === 'en' ? 'day(s)' : 'jour(s)'}`;
    if (minutes % 60 === 0) return `${minutes / 60} ${cfg.language === 'en' ? 'hour(s)' : 'heure(s)'}`;
    return `${minutes} minute(s)`;
}

export const DEFAULT_CONFIG = {
    prefix: null,
    language: 'fr',
    tagRoleId: null,
    logChannel: null,
    installed: false,
    legacyProtectionMigrated: false,
    localizedMessages: [],
    whitelistedUsers: [],
    secureUsers: [],
    userAppsWhitelist: [],
    externalAppPermissionSnapshot: [],
    externalAppOverwriteSnapshot: [],
    whitelistEntries: [],
    whitelistHistory: [],
    punishments: { ...DEFAULT_PUNISHMENTS },
    punishmentDurations: { ...DEFAULT_PUNISHMENT_DURATIONS },
    enabled: Object.fromEntries(MODULES.map((m) => [m, false])),
    antispam: { count: 5, windowMs: 10_000, timeoutMs: MIN },
    antilink: { type: 'invite' }, // 'invite' | 'all'
    badwords: { enabled: false, words: [], exemptChannels: [], ruleId: null, sanction: 'none', timeoutSeconds: 60 },
    antitoken: { minAccountAgeMs: 7 * DAY },
    autoRaid: { enabled: false, count: 10, windowMs: 10_000, durationMs: 10 * MIN },
    protectionLevel: 'custom',
    automaticEmergency: null,
    joinLock: false,
    raidAction: 'kick',
    simulationMode: false,
    reportChannel: null,
    verification: { enabled: false, roleId: null, verifiedRoleId: null, channelId: null, captchaEnabled: true, timeoutMs: 5 * MIN, maxAttempts: 3, kickOnFail: true, ignoreBots: true },
    honeypot: { enabled: false, channelId: null, punishment: 'softban', timeoutMs: DAY, ignoredUsers: [], ignoredRoles: [] },
    jail: { roleId: null, channelId: null, quarantines: [] },
    antiAlt: { enabled: true, threshold: 45, burstCount: 5, burstWindowMs: 15000, burstPoints: 30 },
    fullLockdown: { active: false, snapshots: {} },
    antiNuke: { enabled: false, count: 3, windowMs: 10_000, action: 'derank', restoreAfterMs: 10 * MIN, immediateDestructive: true, automaticRestore: true },
    lockSnapshot: null,
    lockCaseSequence: 0,
    lockHistory: [],
    lockIcon: false,
    mentionLimit: 0,
    suspiciousTextFilter: false,
    phishing: { enabled: true, quarantine: true },
    ghostPing: { enabled: true, maxAgeMs: 30_000 },
    warningSystem: { enabled: true, mutePoints: 3, kickPoints: 5, tempBanPoints: 999, banPoints: 7, tempBanMs: DAY },
    raidHistory: [],
    raidVerification: null,
    appealUrl: null,
    tempBans: [],
};

export function isModule(name) {
    return MODULES.includes(name);
}
