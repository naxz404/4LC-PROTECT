// Adapté de Handler/antiraid/punish.js de 4LC-PROTECT.
import { quarantineMember } from '../quarantine.js';
import { addIncident, getGuildConfig } from '../storage.js';
import { announceIncident } from '../incidentActions.js';

/** Un membre ne peut pas être sanctionné : propriétaire du serveur, ou rôle >= rôle du bot. */
export function canSanction(guild, member) {
    if (member.id === guild.ownerId) return false;
    const me = guild.members.me;
    if (!me) return false;
    if (member.roles.highest.position >= me.roles.highest.position) return false;
    return true;
}

/**
 * Applique une punition (ban/kick/timeout/derank/none) à un membre, en
 * respectant la hiérarchie des rôles. Ne lève jamais — retourne un résultat
 * indiquant si l'action a pu être appliquée.
 * `durationMs` sert de durée de timeout (ignoré pour les autres sanctions).
 */
async function applyPunishment(member, punishment, durationMs, reason) {
    if (punishment === 'none') return { applied: false, note: 'aucune sanction configurée' };
    if (getGuildConfig(member.guild.id).simulationMode) return { applied: false, simulated: true, note: `Simulation : ${punishment} aurait été appliqué (${reason})` };
    if (punishment === 'jail') return quarantineMember(member.client, member, reason.split(':')[0] || 'protection', reason);
    const guild = member.guild;
    if (!canSanction(guild, member)) {
        return { applied: false, note: 'hiérarchie des rôles insuffisante ou propriétaire du serveur' };
    }
    try {
        // Un compte bot est toujours expulsé, quelle que soit la sanction
        // configurée. Les membres humains conservent la sanction choisie.
        if (member.user?.bot) {
            if (!member.kickable) return { applied: false, note: 'bot non expulsable (vérifier la hiérarchie des rôles)' };
            await member.kick(`${reason} — sanction anti-raid automatique pour un bot`);
            return { applied: true, effectivePunishment: 'kick' };
        }
        switch (punishment) {
            case 'ban':
                if (!member.bannable) return { applied: false, note: 'membre non bannissable' };
                await member.ban({ reason });
                return { applied: true, effectivePunishment: 'ban' };
            case 'kick':
                if (!member.kickable) return { applied: false, note: 'membre non expulsable' };
                await member.kick(reason);
                return { applied: true, effectivePunishment: 'kick' };
            case 'derank':
                if (!member.manageable) return { applied: false, note: 'rôles non gérables' };
                await member.roles.set([], reason);
                return { applied: true, effectivePunishment: 'derank' };
            case 'timeout':
            default: {
                if (!member.moderatable) return { applied: false, note: 'membre non modérable' };
                const ms = durationMs > 0 ? Math.min(durationMs, 28 * 24 * 60 * 60 * 1000) : 60_000;
                await member.timeout(ms, reason);
                return { applied: true, effectivePunishment: 'timeout' };
            }
        }
    } catch (error) {
        console.error(`[AntiRaid] Échec de la sanction (${punishment}) sur ${member.id} dans ${guild.id}:`, error);
        return { applied: false, note: 'erreur Discord lors de l\'application de la sanction' };
    }
}

export async function punishMember(member, punishment, durationMs, reason) {
    const result = await applyPunishment(member, punishment, durationMs, reason);
    if (result.simulated) {
        const { buildAntiRaidEmbed, sendLog } = await import('./logs.js');
        await sendLog(member.client || member.guild.client, member.guild.id, buildAntiRaidEmbed('🧪 Simulation', `<@${member.id}> · ${result.note}`)).catch(() => {});
    }
    if (result.applied) {
        try {
            const incident = addIncident(member.guild.id, { userId: member.id, action: result.effectivePunishment || punishment,
                reason, expectedUntil: (result.effectivePunishment || punishment) === 'timeout' ? member.communicationDisabledUntilTimestamp || null : null });
            result.incidentId = incident.id;
            void announceIncident(member.client || member.guild.client, member.guild.id, incident).catch(console.error);
        } catch (error) { console.error('[Incident] Écriture impossible après sanction :', error); }
    }
    return result;
}
