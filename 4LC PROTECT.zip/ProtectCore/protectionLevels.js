import { MODULES } from './antiraid/schema.js';

export const PROTECTION_LEVELS = {
    faible: { modules: ['antispam', 'antilink', 'antieveryone'], spam: [8, 12], joins: [15, 10], punishment: 'timeout', antiNuke: false, linkType: 'invite' },
    normal: { modules: ['antispam', 'antilink', 'antieveryone', 'antitoken', 'antibot'], spam: [6, 10], joins: [10, 10], punishment: 'timeout', antiNuke: true, linkType: 'invite' },
    eleve: { modules: ['antispam', 'antilink', 'antieveryone', 'antitoken', 'antibot', 'antichannel', 'antirole', 'antiwebhook', 'antiban'], spam: [5, 8], joins: [7, 10], punishment: 'jail', antiNuke: true, linkType: 'all' },
    urgence: { modules: [...MODULES], spam: [4, 6], joins: [5, 8], punishment: 'jail', antiNuke: true, linkType: 'all', joinLock: true },
};

export const normalizeLevel = (value) => ({ low: 'faible', normal: 'normal', high: 'eleve', élevé: 'eleve', eleve: 'eleve', emergency: 'urgence', urgence: 'urgence', faible: 'faible' })[String(value || '').toLowerCase()] || null;

export function applyProtectionLevel(cfg, requested) {
    const level = normalizeLevel(requested);
    if (!level) return null;
    const preset = PROTECTION_LEVELS[level];
    for (const module of MODULES) cfg.enabled[module] = preset.modules.includes(module);
    for (const module of MODULES) cfg.punishments[module] = preset.punishment;
    cfg.antispam.count = preset.spam[0]; cfg.antispam.windowMs = preset.spam[1] * 1000;
    cfg.antilink.type = preset.linkType;
    cfg.autoRaid.enabled = true; cfg.autoRaid.count = preset.joins[0]; cfg.autoRaid.windowMs = preset.joins[1] * 1000;
    cfg.antiNuke.enabled = preset.antiNuke;
    cfg.joinLock = Boolean(preset.joinLock);
    cfg.protectionLevel = level;
    return level;
}
