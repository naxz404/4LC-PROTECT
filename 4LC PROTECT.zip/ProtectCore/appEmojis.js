// Les emojis de l'application sont chargés depuis Discord au démarrage.
// Aucun identifiant de serveur n'est codé en dur : ils restent utilisables
// sur le serveur où l'application est utilisée.
const aliases = {
    alert: ['alertastaff2000', 'alertastaff', 'warning'],
    warning: ['warning', 'iconroleyellow'],
    accept: ['accept', 'win11checkicon', 'verified'],
    blocked: ['blocked', 'cancel', 'iconrolered'],
    cancel: ['cancel', 'win11erroicon'],
    role: ['roleicon', 'iconrolegreen', 'staffpurple'],
    verified: ['verified', 'accept'],
    ticket: ['ticket', 'communitymanager'],
    admin: ['admin', 'admingreen', 'moderador'],
    member: ['member', 'online'],
    arrow: ['bluearrow', 'accept'],
};

const normalize = (name) => String(name || '').toLowerCase().replace(/^\d+[_-]?/, '').replace(/[^a-z0-9]/g, '');
let available = new Map();

export function setApplicationEmojis(emojis) {
    available = new Map([...emojis.values()].map((emoji) => [normalize(emoji.name), emoji]));
}

export async function loadApplicationEmojis(client) {
    try {
        const emojis = await client.application.emojis.fetch();
        setApplicationEmojis(emojis);
        console.log(`[Emojis] ${emojis.size} emoji(s) d'application disponibles.`);
        return emojis.size;
    } catch (error) {
        console.warn(`[Emojis] Chargement impossible : ${error.message}. Emojis standards utilisés.`);
        return 0;
    }
}

function resolveEmoji(key) {
    const names = aliases[key] || [];
    for (const name of names) if (available.has(name)) return available.get(name);
    for (const name of names) {
        const match = [...available].find(([candidate]) => candidate.endsWith(name) || candidate.startsWith(name));
        if (match) return match[1];
    }
    return null;
}

export function emojiText(key, fallback) {
    const emoji = resolveEmoji(key);
    return emoji ? `<${emoji.animated ? 'a' : ''}:${emoji.name}:${emoji.id}>` : fallback;
}

export function emojiComponent(key, fallback) {
    const emoji = resolveEmoji(key);
    return emoji ? { id: emoji.id, name: emoji.name, animated: Boolean(emoji.animated) } : fallback;
}
