import { isGlobalOwner } from '../Owners.js';
import { PermissionFlagsBits } from 'discord.js';

export function clearConfirmation(userId, count, cfg = {}) {
    return { content: cfg.language === 'en' ? `<@${userId}> deleted ${count} messages.` : `<@${userId}> a supprimé ${count} messages.`, allowedMentions: { parse: [] } };
}
export function deleteAfterTwoSeconds(remove) {
    const timer = setTimeout(() => { Promise.resolve().then(remove).catch(() => {}); }, 2000);
    timer.unref?.();
    return timer;
}
export async function clearRecentMessages(channel, count, before, actor, bot) {
    if (!Number.isInteger(count) || count < 1 || count > 100) throw new Error('Indique un nombre entier entre 1 et 100.');
    if (!channel?.bulkDelete || !channel.messages?.fetch) throw new Error('Commande réservée aux salons textuels du serveur.');
    if (!isGlobalOwner(actor.id) && !channel.permissionsFor(actor)?.has(PermissionFlagsBits.ManageMessages)) throw new Error('Permission Gérer les messages requise dans ce salon.');
    if (!channel.permissionsFor(bot)?.has([PermissionFlagsBits.ViewChannel, PermissionFlagsBits.ReadMessageHistory, PermissionFlagsBits.ManageMessages])) throw new Error('Le bot doit pouvoir voir le salon, lire son historique et gérer les messages.');
    const messages = await channel.messages.fetch({ limit: count, before });
    const deleted = await channel.bulkDelete(messages, true);
    return deleted.size;
}
