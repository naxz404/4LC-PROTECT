import { AuditLogEvent, PermissionFlagsBits } from 'discord.js';
import { getSettings, invalidateSettings, isModuleBypassed } from './antiraid/runtime.js';
import { buildAntiRaidEmbed, sendLog } from './antiraid/logs.js';
import { tr } from './i18n.js';
import { restoreServerBackup, snapshotGuild } from './serverBackup.js';
import { getGuildConfig, saveGuildConfig } from './storage.js';
import { activateAutomaticEmergency, recordEmergencyResult } from './emergencyMode.js';

const tracked = new Set([
    AuditLogEvent.ChannelCreate, AuditLogEvent.ChannelDelete, AuditLogEvent.ChannelUpdate,
    AuditLogEvent.RoleCreate, AuditLogEvent.RoleDelete, AuditLogEvent.RoleUpdate,
    AuditLogEvent.MemberBanAdd, AuditLogEvent.WebhookCreate, AuditLogEvent.WebhookDelete, AuditLogEvent.WebhookUpdate,
    AuditLogEvent.GuildUpdate, AuditLogEvent.MemberRoleUpdate,
]);

// Ces actions peuvent détruire le serveur dès la première occurrence.
// En mode immédiat, toute action d'administration suivie déclenche la
// contention dès le premier événement d'audit. Les compteurs restent utiles
// quand l'option immédiate est explicitement désactivée.
const immediateDestructive = new Set(tracked);

const windows = new Map();
const emergencySignals = new Map();
const cooldown = new Map();
const baselines = new Map();
const refreshTimers = new Map();
const activeResponses = new Map();
const dangerous = [PermissionFlagsBits.Administrator, PermissionFlagsBits.ManageGuild, PermissionFlagsBits.ManageRoles, PermissionFlagsBits.ManageChannels, PermissionFlagsBits.BanMembers, PermissionFlagsBits.ManageWebhooks];

export function isDestructiveAntiNukeAction(action) { return immediateDestructive.has(action); }
export function antiNukeTriggerThreshold(cfg, action) { return cfg?.antiNuke?.immediateDestructive !== false && isDestructiveAntiNukeAction(action) ? 1 : Math.max(2, Number(cfg?.antiNuke?.count) || 3); }

export function primeAntiNukeGuild(guild) {
    const record = { code: `AUTO-${Date.now().toString(36).toUpperCase()}`, ownerId: guild.ownerId, sourceGuildId: guild.id, snapshot: snapshotGuild(guild) };
    baselines.set(guild.id, record);
    return record;
}

function scheduleTrustedBaseline(guild) {
    clearTimeout(refreshTimers.get(guild.id));
    const timer = setTimeout(() => {
        if (activeResponses.has(guild.id)) return scheduleTrustedBaseline(guild);
        try { primeAntiNukeGuild(guild); } catch { /* prochaine action retentera */ }
    }, 3_000);
    timer.unref?.(); refreshTimers.set(guild.id, timer);
}

async function containExecutor(guild, member, cfg) {
    if (!member) return { removed: [], terminal: 'membre introuvable' };
    // Pour un bot, l’expulsion est l’unique requête la plus rapide : elle
    // coupe immédiatement toutes ses prochaines actions sur le serveur.
    if (member.user?.bot && member.kickable) {
        const kicked = await member.kick('Anti-Nuke : bot compromis').then(() => true).catch(() => false);
        if (kicked) return { removed: [], terminal: 'bot expulsé immédiatement' };
    }
    const roles = member.roles.cache.filter((role) => role.editable && dangerous.some((permission) => role.permissions.has(permission)));
    const removed = [...roles.values()];
    const rolesRemoved = removed.length ? await member.roles.remove(removed, 'Anti-Nuke : contention immédiate').then(() => true).catch(() => false) : false;

    // Un bot compromis peut avoir des requêtes déjà mises en file. On le
    // retire après avoir coupé ses permissions pour interrompre la rafale.
    if (cfg.antiNuke.action === 'ban' && member.bannable) {
        const banned = await member.ban({ reason: 'Anti-Nuke : destruction rapide détectée' }).then(() => true).catch(() => false);
        if (banned) return { removed: rolesRemoved ? removed : [], terminal: 'banni' };
    }
    if (cfg.antiNuke.action === 'kick' && member.kickable) {
        const kicked = await member.kick('Anti-Nuke : destruction rapide détectée').then(() => true).catch(() => false);
        if (kicked) return { removed: rolesRemoved ? removed : [], terminal: 'expulsé' };
    }
    return { removed: rolesRemoved ? removed : [], terminal: rolesRemoved ? 'permissions dangereuses retirées' : 'contention impossible — hiérarchie ou permissions insuffisantes' };
}

export async function handleAntiNukeAudit(client, guild, entry) {
    const cfg = getSettings(guild.id); const executorId = entry.executor?.id;
    if (!cfg.antiNuke?.enabled || !executorId || !tracked.has(entry.action)) return false;
    if (isModuleBypassed(executorId, guild.id, 'antinuke', client.user.id, guild.ownerId)) {
        scheduleTrustedBaseline(guild);
        return false;
    }

    const key = `${guild.id}:${executorId}`; const now = Date.now();
    const list = (windows.get(key) || []).filter((time) => now - time < cfg.antiNuke.windowMs); list.push(now); windows.set(key, list);
    const signals = (emergencySignals.get(guild.id) || []).filter((time) => now - time < cfg.antiNuke.windowMs);
    signals.push(now); emergencySignals.set(guild.id, signals);
    if (signals.length === 2 && !cfg.simulationMode) activateAutomaticEmergency(guild.id, 'actions administratives suspectes');
    if (!baselines.has(guild.id)) primeAntiNukeGuild(guild);
    const threshold = antiNukeTriggerThreshold(cfg, entry.action);
    if (list.length < threshold) return false;
    if (cfg.simulationMode) {
        await sendLog(client, guild.id, buildAntiRaidEmbed('🧪 Simulation Anti-Nuke', `<@${executorId}> · ${list.length} action(s) sensible(s). Contention et restauration auraient été déclenchées.`));
        windows.set(key, []);
        return true;
    }

    // La contention passe avant le journal et la restauration.
    const member = guild.members.cache.get(executorId) || await guild.members.fetch(executorId).catch(() => null);
    const containment = await containExecutor(guild, member, cfg);
    if ((cooldown.get(key) || 0) > now) return true;
    cooldown.set(key, now + Math.max(10_000, cfg.antiNuke.restoreAfterMs || 0)); windows.set(key, []);

    const persistent = getGuildConfig(guild.id); persistent.raidHistory ||= [];
    persistent.raidHistory.push({ at: now, type: 'antinuke', executorId, actions: list.length, windowMs: cfg.antiNuke.windowMs, action: containment.terminal, immediate: isDestructiveAntiNukeAction(entry.action) });
    persistent.raidHistory = persistent.raidHistory.slice(-100); saveGuildConfig(guild.id, persistent); invalidateSettings(guild.id);

    const backup = baselines.get(guild.id);
    let restore = null;
    if (cfg.antiNuke.automaticRestore !== false && backup && !activeResponses.has(guild.id)) {
        // Laisse quelques centaines de millisecondes aux restaurations ciblées
        // (clone exact du salon/rôle) avant le contrôle global de la baseline.
        const response = (async () => {
            await new Promise((resolve) => setTimeout(resolve, 350));
            return restoreServerBackup(guild, backup, client.user.id);
        })().catch((error) => ({ error: error.message }));
        activeResponses.set(guild.id, response);
        restore = await response;
        activeResponses.delete(guild.id);
    }
    const restoreText = restore?.error ? `échec (${restore.error})` : restore ? `${restore.channelsCreated} salon(s), ${restore.rolesCreated} rôle(s) recréé(s)` : 'déjà en cours ou indisponible';
    recordEmergencyResult(guild.id, { blocked: containment.terminal.startsWith('contention impossible') ? 0 : 1,
        restored: (restore?.channelsCreated || 0) + (restore?.rolesCreated || 0), failed: (restore?.error ? 1 : 0) + (restore?.failures?.length || 0) });
    await sendLog(client, guild.id, buildAntiRaidEmbed(tr(cfg, '🚨 Anti-Nuke immédiat', '🚨 Immediate Anti-Nuke'), tr(cfg,
        `<@${executorId}> · ${list.length} action(s) sensible(s).\nContention : **${containment.terminal}**.\nRôles dangereux retirés : **${containment.removed.map((role) => role.name).join(', ') || 'aucun'}**.\nRestauration automatique : **${restoreText}**.\nLes rôles retirés ne seront pas rendus automatiquement.`,
        `<@${executorId}> · ${list.length} sensitive action(s).\nContainment: **${containment.terminal}**.\nDangerous roles removed: **${containment.removed.map((role) => role.name).join(', ') || 'none'}**.\nAutomatic restore: **${restoreText}**.\nRemoved roles will not be restored automatically.`)), 'critical');
    if (restore?.error || restore?.failures?.length) await sendLog(client, guild.id, buildAntiRaidEmbed('⚠️ Restauration incomplète / Partial restore', `${restore.error || restore.failures.slice(0, 5).join('\n')} · vérifiez les permissions et la sauvegarde.`), 'critical');
    return true;
}

export function clearAntiNukeGuild(guildId) {
    baselines.delete(guildId); activeResponses.delete(guildId); clearTimeout(refreshTimers.get(guildId)); refreshTimers.delete(guildId);
    for (const key of windows.keys()) if (key.startsWith(`${guildId}:`)) windows.delete(key);
    emergencySignals.delete(guildId);
    for (const key of cooldown.keys()) if (key.startsWith(`${guildId}:`)) cooldown.delete(key);
}
