import { PermissionFlagsBits } from 'discord.js';
import { getGuildConfig, saveGuildConfig } from './storage.js';
import { invalidateSettings } from './antiraid/runtime.js';
import { helpPayload } from './helpEmbed.js';
import { panelPayload } from './ui.js';
import { welcomePayload } from './welcome.js';
import { honeypotWarning } from './honeypot.js';

const MAX_TRACKED = 100;

function componentData(message) {
    return (message.components || []).flatMap((row) => row.components || []).map((component) => component.toJSON?.() || component.data || component);
}

export function localizedMessageInfo(message) {
    const components = componentData(message);
    if (components.some((component) => component.custom_id === 'sar:panel:toggle')) return { type: 'config' };
    if (components.some((component) => component.custom_id === 'sar:welcome:setup')) return { type: 'welcome' };
    const help = components.find((component) => String(component.custom_id || '').startsWith('sar:help:'));
    if (!help) return null;
    return {
        type: 'help',
        ownerId: String(help.custom_id).slice('sar:help:'.length),
        category: help.options?.find((option) => option.default)?.value || '__home__',
    };
}

export function rememberLocalizedMessage(guildId, message, type = null) {
    if (!guildId || !message?.id || !message.channelId) return;
    const detected = localizedMessageInfo(message);
    const info = type ? { ...(detected || {}), type } : detected;
    if (!info) return;
    const cfg = getGuildConfig(guildId);
    const previous = Array.isArray(cfg.localizedMessages) ? cfg.localizedMessages : [];
    cfg.localizedMessages = [
        ...previous.filter((entry) => entry.messageId !== message.id),
        { channelId: message.channelId, messageId: message.id, ...info },
    ].slice(-MAX_TRACKED);
    saveGuildConfig(guildId, cfg);
    invalidateSettings(guildId);
}

function payload(cfg, info) {
    if (info.type === 'config') return panelPayload(cfg);
    if (info.type === 'welcome') return welcomePayload(cfg);
    if (info.type === 'honeypot') return { embeds: [honeypotWarning(cfg)] };
    if (info.type === 'help') {
        const actor = info.ownerId && info.ownerId !== 'public' ? { id: info.ownerId } : null;
        return helpPayload(cfg, actor, null, info.category || '__home__');
    }
    return null;
}

async function editIfLocalized(message, cfg, forcedInfo = null) {
    const info = forcedInfo || localizedMessageInfo(message);
    const next = info && payload(cfg, info);
    if (!next) return false;
    await message.edit(next);
    return true;
}

/**
 * Ré-édite immédiatement le(s) panneau(x) de configuration publics déjà
 * envoyés sur le serveur, sans scanner l'historique des salons (contrairement
 * à refreshLocalizedMessages). Pensée pour être appelée après chaque
 * modification de réglage afin que le panneau reste toujours à jour tout
 * seul, sans clic sur « Actualiser ». Best-effort : ne lève jamais.
 */
export async function refreshConfigPanelOnly(guild) {
    if (!guild) return;
    try {
        const cfg = getGuildConfig(guild.id);
        const tracked = Array.isArray(cfg.localizedMessages) ? cfg.localizedMessages : [];
        for (const entry of tracked) {
            if (entry.type !== 'config') continue;
            const channel = guild.channels.cache.get(entry.channelId) || await guild.channels.fetch(entry.channelId).catch(() => null);
            if (!channel?.messages) continue;
            const message = channel.messages.cache.get(entry.messageId) || await channel.messages.fetch(entry.messageId).catch(() => null);
            if (!message || message.author?.id !== guild.client.user.id) continue;
            await message.edit(panelPayload(cfg)).catch(() => {});
        }
    } catch { /* best-effort : ne doit jamais interrompre l'action qui vient de sauvegarder la config */ }
}

/** Réédite les panneaux persistants déjà envoyés et retrouve aussi les anciens messages récents non suivis. */
export async function refreshLocalizedMessages(guild) {
    const cfg = getGuildConfig(guild.id);
    const tracked = Array.isArray(cfg.localizedMessages) ? cfg.localizedMessages : [];
    const refreshed = new Set();
    const kept = [];

    for (const entry of tracked) {
        const channel = await guild.channels.fetch(entry.channelId).catch(() => null);
        const message = channel?.messages ? await channel.messages.fetch(entry.messageId).catch(() => null) : null;
        if (!message || message.author.id !== guild.client.user.id) continue;
        const currentInfo = localizedMessageInfo(message) || entry;
        if (await editIfLocalized(message, cfg, currentInfo).catch(() => false)) {
            refreshed.add(message.id);
            kept.push({ channelId: entry.channelId, messageId: entry.messageId, ...currentInfo });
        }
    }

    const me = guild.members.me || await guild.members.fetchMe().catch(() => null);
    const channels = guild.channels.cache.filter((channel) => channel.isTextBased?.() && !channel.isDMBased?.() && channel.messages && (!me || channel.permissionsFor(me)?.has([PermissionFlagsBits.ViewChannel, PermissionFlagsBits.ReadMessageHistory]))).first(30);
    for (const channel of channels) {
        const messages = await channel.messages.fetch({ limit: 50 }).catch(() => null);
        if (!messages) continue;
        for (const message of messages.values()) {
            if (refreshed.has(message.id) || message.author.id !== guild.client.user.id) continue;
            const info = localizedMessageInfo(message);
            if (!info) continue;
            if (await editIfLocalized(message, cfg, info).catch(() => false)) {
                refreshed.add(message.id);
                kept.push({ channelId: channel.id, messageId: message.id, ...info });
            }
        }
    }

    cfg.localizedMessages = kept.slice(-MAX_TRACKED);
    saveGuildConfig(guild.id, cfg);
    invalidateSettings(guild.id);
    return refreshed.size;
}
