import { ActionRowBuilder, AttachmentBuilder, ButtonBuilder, ButtonStyle, EmbedBuilder, MessageFlags } from 'discord.js';
import { fileURLToPath } from 'node:url';
import { getGuildConfig } from './storage.js';
import { isEnglish, tr } from './i18n.js';
import { emojiText, emojiComponent } from './appEmojis.js';

export const CHANGELOG_PAGES = [
    {
        version: 'v2.1.0', date: '28 septembre 2026', dateEn: 'September 28, 2026', emoji: '✨',
        title: '4LC-PROTECT — Sécurité et interface enrichies', titleEn: '4LC-PROTECT — Security and interface update',
        fr: ['Messages édités et webhooks filtrés contre le phishing et les mentions.', 'Détection des liens raccourcis, domaines trompeurs, réactions et pièces jointes répétées.', 'Mode urgence temporaire, sauvegardes automatiques et alertes de restauration.', 'Boutons de révision des sanctions et inventaire des webhooks avec `+webhooks`.', 'Emojis de l’application dans les panneaux et GIF d’alerte dans les logs critiques.', 'Bans groupés, diagnostic des 429, snapshots réessayables et commande simulation.'],
        en: ['Edited messages and webhook messages are checked for phishing and mentions.', 'Short links, deceptive domains, reaction floods and repeated attachments are detected.', 'Temporary emergency mode, automatic backups and restore alerts.', 'Action review buttons and webhook inventory with `+webhooks`.', 'Application emojis decorate panels and an alert GIF appears in critical logs.', 'Bulk bans, rate-limit diagnostics, retryable permission snapshots and a simulation command.'],
    },
    {
        version: 'v2.0.0', date: '19 septembre 2026', dateEn: 'September 19, 2026', emoji: '⚡',
        title: '4LC-PROTECT — Protection instantanée', titleEn: '4LC-PROTECT — Instant protection',
        fr: ['Nouveau nom : 4LC-PROTECT.', 'Anti-Nuke déclenché dès la première action sensible non autorisée.', 'Expulsion prioritaire des bots compromis et retrait immédiat des permissions dangereuses.', 'Recréation automatique des salons et rôles supprimés avec leur nom, position et permissions.', 'Annulation des modifications non autorisées de salons, rôles et paramètres serveur.', 'Détection Anti-Spam renforcée pour les rafales, doublons, fichiers et attaques multi-salons.', 'Nouvelle commande Renew pour recréer proprement un salon et supprimer son historique.', 'Nouveaux suivis Case pour les verrouillages et déverrouillages.', 'Nouvelle identité visuelle ajoutée à tous les journaux de sécurité.'],
        en: ['New name: 4LC-PROTECT.', 'Anti-Nuke now triggers on the first unauthorized sensitive action.', 'Compromised bots are kicked first and dangerous permissions are removed immediately.', 'Deleted channels and roles are automatically recreated with their name, position and permissions.', 'Unauthorized channel, role and server-setting changes are reverted.', 'Stronger Anti-Spam detection for bursts, duplicates, files and cross-channel attacks.', 'New Renew command to recreate a channel and clear its history.', 'New Case tracking for channel locks and unlocks.', 'New visual identity added to every security log.'],
    },
    {
        version: 'v1.9.0', date: 'septembre 2026', dateEn: 'September 2026', emoji: '🚨',
        title: 'Anti-Nuke et sanctions', titleEn: 'Anti-Nuke and punishments',
        fr: ['Contention immédiate lors d’une destruction de salon ou de rôle.', 'Restauration automatique de la structure du serveur après une attaque.', 'Les permissions dangereuses retirées ne sont jamais rendues automatiquement.', 'Durée TimeMute personnalisable depuis le panneau Sanctions.'],
        en: ['Immediate containment when a channel or role is destroyed.', 'Automatic server-structure recovery after an attack.', 'Removed dangerous permissions are never restored automatically.', 'Custom TimeMute duration from the Punishments panel.'],
    },
    {
        version: 'v1.8.0', date: 'septembre 2026', dateEn: 'September 2026', emoji: '⚡',
        title: 'Moteur de protection adaptatif', titleEn: 'Adaptive protection engine',
        fr: ['Défis CAPTCHA individuels.', 'Anti-Spam adaptatif contre les rafales, doublons, fichiers et attaques multi-salons.', 'Sanctions progressives en cas de récidive.', 'Anti-Raid capable de traiter toute une vague détectée et de renforcer automatiquement l’Anti-Spam.'],
        en: ['Personal CAPTCHA challenges.', 'Adaptive Anti-Spam against bursts, duplicates, files and cross-channel attacks.', 'Progressive punishments for repeat offences.', 'Anti-Raid handles a detected wave and automatically tightens Anti-Spam.'],
    },
    {
        version: 'v1.7.0', date: 'septembre 2026', dateEn: 'September 2026', emoji: '💾',
        title: 'Sauvegardes et modération avancée', titleEn: 'Backups and advanced moderation',
        fr: ['Sauvegarde des rôles, salons, permissions et emojis.', 'Comparaison et restauration contrôlée de la structure du serveur.', 'Panneau CAPTCHA complet avec délai, essais et action en cas d’échec.', 'Blacklist partageable et historique des attaques.', 'Avertissements progressifs : timeout, expulsion, bannissement temporaire et bannissement.', 'Détection du phishing, quarantaine, ghost ping et abus de webhooks.', 'Avis de bannissement temporaire envoyé en message direct avec lien d’appel.'],
        en: ['Backups for roles, channels, permissions and emojis.', 'Controlled comparison and recovery of the server structure.', 'Complete CAPTCHA panel with time limit, attempts and failure action.', 'Shareable blacklist and attack history.', 'Progressive warnings: timeout, kick, temporary ban and ban.', 'Phishing, quarantine, ghost-ping and webhook-abuse detection.', 'Temporary-ban notice sent by DM with an appeal link.'],
    },
    {
        version: 'v1.6.0', date: 'septembre 2026', dateEn: 'September 2026', emoji: '🧩',
        title: 'CAPTCHA et panneaux dynamiques', titleEn: 'CAPTCHA and dynamic panels',
        fr: ['Menu CAPTCHA complet : activer, réparer, désactiver et publier.', 'Création automatique du rôle Unverified et du salon de vérification.', 'Restrictions Unverified appliquées aux salons existants et futurs.', 'Les panneaux Aide et Configuration se mettent à jour après un changement de langue.'],
        en: ['Complete CAPTCHA menu: enable, repair, disable and publish.', 'Automatic Unverified role and verification-channel creation.', 'Unverified restrictions applied to existing and future channels.', 'Help and Settings panels refresh after a language change.'],
    },
    {
        version: 'v1.5.0', date: 'septembre 2026', dateEn: 'September 2026', emoji: '🚨',
        title: 'Urgence, sauvegardes et quarantaine', titleEn: 'Emergency, backups and quarantine',
        fr: ['Niveaux Faible, Normal, Élevé et Urgence.', 'Panneau Panic avec verrouillage et restauration.', 'Sauvegardes et restauration dédiées à ce serveur.', 'Exemptions temporaires, globales ou propres à une protection avec historique.', 'Quarantaine intelligente avec les décisions Autoriser, Expulser ou Bannir.'],
        en: ['Low, Normal, High and Emergency levels.', 'Panic panel with lockdown and recovery.', 'Backups and restoration dedicated to this server.', 'Temporary, global or per-protection exemptions with history.', 'Smart quarantine with Allow, Kick or Ban decisions.'],
    },
    {
        version: 'v1.4.0', date: 'septembre 2026', dateEn: 'September 2026', emoji: '🛡️',
        title: 'Commandes sécurité, CAPTCHA et HoneyPot', titleEn: 'Security commands, CAPTCHA and HoneyPot',
        fr: ['Commandes slash et préfixées pour chaque protection.', 'CAPTCHA limité dans le temps avant validation du membre.', 'HoneyPot configurable avec Softban, bannissement, expulsion ou timeout.', 'Whitelist globale, par protection, temporaire ou permanente.', 'Ajout de Panic, Protection Test, Security Scan et Trust Score.'],
        en: ['Slash and prefix commands for each protection.', 'Time-limited CAPTCHA before member verification.', 'Configurable HoneyPot with softban, ban, kick or timeout.', 'Global, per-protection, temporary or permanent whitelist.', 'Added Panic, Protection Test, Security Scan and Trust Score.'],
    },
    {
        version: 'v1.3.0', date: 'septembre 2026', dateEn: 'September 2026', emoji: '✨',
        title: 'Interface, langues et arrivée du bot', titleEn: 'Interface, languages and bot onboarding',
        fr: ['Changelog interactif avec navigation par pages.', 'Page À propos simplifiée avec les actions utiles.', 'Création automatique du salon `4lcprotect-logs` à l’arrivée du bot.', 'Nouveau message de bienvenue et configuration rapide.', 'Interface complète en français ou en anglais.'],
        en: ['Interactive paginated changelog.', 'Simplified About page with useful actions.', 'Automatic `4lcprotect-logs` channel creation when the bot joins.', 'New welcome message and quick setup.', 'Complete French and English interface.'],
    },
    {
        version: 'v1.2.0', date: '18 septembre 2026', dateEn: 'September 18, 2026', emoji: '🛡️',
        title: 'Aide, protection et modération', titleEn: 'Help, protection and moderation',
        fr: ['Menu d’aide interactif et détails pour chaque commande.', 'Protections anti-raid et sanctions automatiques.', 'Panneau de configuration interactif.', 'Commandes de modération, verrouillage et signalement.'],
        en: ['Interactive help menu and details for each command.', 'Anti-raid protections and automatic punishments.', 'Interactive settings panel.', 'Moderation, lockdown and reporting commands.'],
    },
];

function clamp(page) { return Math.max(0, Math.min(Number(page) || 0, CHANGELOG_PAGES.length - 1)); }

export function changelogPayload(cfg = {}, actorId = 'public', page = 0) {
    const index = clamp(page);
    const item = CHANGELOG_PAGES[index];
    const en = isEnglish(cfg);
    const bullets = (en ? item.en : item.fr).map((line) => `• ${line}`).join('\n');
    const embed = new EmbedBuilder().setColor(0x6495ed).setTitle(`${emojiText('verified', item.emoji)} ${en ? item.titleEn : item.title}`)
        .setDescription(bullets).setFooter({ text: `${item.version} — ${en ? item.dateEn : item.date}` });
    const button = (action, emoji, disabled = false) => new ButtonBuilder().setCustomId(`sar:changelog:${actorId}:${action}:${index}`).setEmoji(emoji).setStyle(ButtonStyle.Secondary).setDisabled(disabled);
    const count = new ButtonBuilder().setCustomId(`sar:changelog:${actorId}:count:${index}`).setLabel(`${index + 1}/${CHANGELOG_PAGES.length}`).setStyle(ButtonStyle.Secondary).setDisabled(true);
    return { embeds: [embed], components: [new ActionRowBuilder().addComponents(
        button('first', '⏮️', index === 0), button('prev', '◀️', index === 0), count,
        button('next', emojiComponent('arrow', '▶️'), index === CHANGELOG_PAGES.length - 1), button('last', '⏭️', index === CHANGELOG_PAGES.length - 1),
    )] };
}

export async function handleChangelogInteraction(interaction) {
    if (!interaction.isButton() || !interaction.customId.startsWith('sar:changelog:')) return false;
    const [, , ownerId, action, rawPage] = interaction.customId.split(':');
    const cfg = getGuildConfig(interaction.guildId);
    if (ownerId !== 'public' && ownerId !== interaction.user.id) {
        await interaction.reply({ content: tr(cfg, 'Ce changelog est réservé à son auteur.', 'This changelog belongs to its original user.'), flags: MessageFlags.Ephemeral });
        return true;
    }
    let page = clamp(rawPage);
    if (action === 'first') page = 0;
    if (action === 'prev') page--;
    if (action === 'next') page++;
    if (action === 'last') page = CHANGELOG_PAGES.length - 1;
    await interaction.update({ ...changelogPayload(cfg, interaction.user.id, page), attachments: [] });
    return true;
}
