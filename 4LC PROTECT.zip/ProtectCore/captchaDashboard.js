import { ActionRowBuilder, ButtonStyle, ChannelSelectMenuBuilder, ChannelType, ContainerBuilder, MessageFlags, ModalBuilder, PermissionFlagsBits, RoleSelectMenuBuilder, TextInputBuilder, TextInputStyle } from 'discord.js';
import { getGuildConfig, saveGuildConfig } from './storage.js';
import { invalidateSettings } from './antiraid/runtime.js';
import { disableVerificationEnvironment, enableVerificationEnvironment } from './onboarding.js';
import { tr } from './i18n.js';

const MIN_TIMEOUT = 30_000;
const MAX_TIMEOUT = 24 * 60 * 60_000;
const MIN_ATTEMPTS = 1;
const MAX_ATTEMPTS = 10;
const save = (guildId, cfg) => { saveGuildConfig(guildId, cfg); invalidateSettings(guildId); };
const duration = (ms) => ms % 3_600_000 === 0 ? `${ms / 3_600_000}h` : ms % 60_000 === 0 ? `${ms / 60_000}m` : `${Math.round(ms / 1000)}s`;
const parseDuration = (value) => { const match = String(value).trim().toLowerCase().match(/^(\d+)\s*(s|m|h)$/); if (!match) return null; return Number(match[1]) * ({ s: 1000, m: 60_000, h: 3_600_000 }[match[2]]); };

export function captchaSettingsComponents(cfg) {
    const en = cfg.language === 'en'; const v = cfg.verification;
    const yes = (value) => value ? '✅ Oui' : '❌ Non';
    const state = v.enabled ? '⚡ Activé' : '⛔ Désactivé';
    const container = new ContainerBuilder().setAccentColor(0x000000);
    container.addTextDisplayComponents((text) => text.setContent(`# ✅ 〃 Captcha`));
    container.addSeparatorComponents((separator) => separator.setDivider(true));
    container.addTextDisplayComponents((text) => text.setContent(
        `${state} · ${en ? 'Channel' : 'Salon'} ${v.channelId ? `<#${v.channelId}>` : '—'} · ${en ? 'Role' : 'Rôle'} ${v.verifiedRoleId ? `<@&${v.verifiedRoleId}>` : '—'}\n` +
        `${en ? 'Delay' : 'Délai'} **${duration(v.timeoutMs || 300_000)}** · ${en ? 'Attempts' : 'Essais'} **${v.maxAttempts || 3}** · ${en ? 'Kick' : 'Expulsion'} ${yes(v.kickOnFail !== false)} · Bots ${yes(v.ignoreBots !== false)}`,
    ));
    container.addSeparatorComponents((separator) => separator.setDivider(true));
    container.addSectionComponents((section) => section.addTextDisplayComponents((text) => text.setContent(`${en ? 'Protection' : 'Protection'} · ${state}`)).setButtonAccessory((button) => button.setCustomId('sar:cp:toggle').setEmoji({ name: '⚡' }).setStyle(v.enabled ? ButtonStyle.Danger : ButtonStyle.Success)));
    container.addSeparatorComponents((separator) => separator.setDivider(true));
    container.addTextDisplayComponents((text) => text.setContent(`📁 **${en ? 'Verification channel' : 'Salon de vérification'}**`));
    container.addActionRowComponents((row) => row.setComponents(new ChannelSelectMenuBuilder().setCustomId('sar:cp:channel').setPlaceholder(en ? 'Choose a channel...' : 'Choisir le salon...').setChannelTypes(ChannelType.GuildText, ChannelType.GuildAnnouncement)));
    container.addSectionComponents((section) => section.addTextDisplayComponents((text) => text.setContent(`**${en ? 'Remove channel' : 'Retirer le salon'}**`)).setButtonAccessory((button) => button.setCustomId('sar:cp:channel-clear').setEmoji({ name: '❌' }).setStyle(ButtonStyle.Danger).setDisabled(!v.channelId)));
    container.addSeparatorComponents((separator) => separator.setDivider(true));
    container.addTextDisplayComponents((text) => text.setContent(`👥 **${en ? 'Verified role' : 'Rôle vérifié'}**`));
    container.addActionRowComponents((row) => row.setComponents(new RoleSelectMenuBuilder().setCustomId('sar:cp:role').setPlaceholder(en ? 'Choose a role...' : 'Choisir le rôle...')));
    container.addSectionComponents((section) => section.addTextDisplayComponents((text) => text.setContent(`**${en ? 'Remove role' : 'Retirer le rôle'}**`)).setButtonAccessory((button) => button.setCustomId('sar:cp:role-clear').setEmoji({ name: '❌' }).setStyle(ButtonStyle.Danger).setDisabled(!v.verifiedRoleId)));
    container.addSeparatorComponents((separator) => separator.setDivider(true));
    container.addSectionComponents((section) => section.addTextDisplayComponents((text) => text.setContent(`${en ? 'Delay' : 'Délai'} · \`${duration(v.timeoutMs || 300_000)}\``)).setButtonAccessory((button) => button.setCustomId('sar:cp:timeout').setEmoji({ name: '⚙️' }).setStyle(ButtonStyle.Secondary)));
    container.addSectionComponents((section) => section.addTextDisplayComponents((text) => text.setContent(`${en ? 'Attempts' : 'Essais'} · \`${v.maxAttempts || 3}\``)).setButtonAccessory((button) => button.setCustomId('sar:cp:attempts').setEmoji({ name: '⚙️' }).setStyle(ButtonStyle.Secondary)));
    container.addSectionComponents((section) => section.addTextDisplayComponents((text) => text.setContent(`**${en ? 'Kick on failure' : "Expulsion en cas d’échec"}**\n> ${yes(v.kickOnFail !== false)}`)).setButtonAccessory((button) => button.setCustomId('sar:cp:kick').setEmoji({ name: '⚡' }).setStyle(v.kickOnFail !== false ? ButtonStyle.Success : ButtonStyle.Danger)));
    container.addSectionComponents((section) => section.addTextDisplayComponents((text) => text.setContent(`**${en ? 'Ignore bots' : 'Ignorer les bots'}**\n> ${yes(v.ignoreBots !== false)}`)).setButtonAccessory((button) => button.setCustomId('sar:cp:bots').setEmoji({ name: '⚡' }).setStyle(v.ignoreBots !== false ? ButtonStyle.Success : ButtonStyle.Danger)));
    return [container];
}

export function captchaSettingsPayload(cfg) { return { components: captchaSettingsComponents(cfg), flags: MessageFlags.Ephemeral | MessageFlags.IsComponentsV2 }; }
const refresh = (i) => i.update({ components: captchaSettingsComponents(getGuildConfig(i.guildId)) });
function modal(id, title, inputId, label, value) { return new ModalBuilder().setCustomId(id).setTitle(title).addComponents(new ActionRowBuilder().addComponents(new TextInputBuilder().setCustomId(inputId).setLabel(label).setStyle(TextInputStyle.Short).setRequired(true).setValue(value))); }

export async function handleCaptchaSettingsInteraction(i) {
    if (!i.guildId || !i.customId?.startsWith('sar:cp:')) return false;
    const cfg = getGuildConfig(i.guildId);
    if (!i.memberPermissions?.has(PermissionFlagsBits.ManageGuild)) { await i.reply({ content: tr(cfg, '⛔ Permission Gérer le serveur requise.', '⛔ Manage Server permission required.'), flags: MessageFlags.Ephemeral }); return true; }
    const id = i.customId;
    if (i.isButton() && id === 'sar:cp:timeout') { await i.showModal(modal('sar:cp:modal-timeout', 'Délai du captcha', 'value', 'Délai (30s, 5m, 1h…)', duration(cfg.verification.timeoutMs || 300_000))); return true; }
    if (i.isButton() && id === 'sar:cp:attempts') { await i.showModal(modal('sar:cp:modal-attempts', 'Essais du captcha', 'value', 'Nombre d’essais (1–10)', String(cfg.verification.maxAttempts || 3))); return true; }
    if (i.isModalSubmit() && id === 'sar:cp:modal-timeout') { const ms = parseDuration(i.fields.getTextInputValue('value')); if (!ms || ms < MIN_TIMEOUT || ms > MAX_TIMEOUT) { await i.reply({ content: 'Durée invalide : entre `30s` et `24h`.', flags: MessageFlags.Ephemeral }); return true; } cfg.verification.timeoutMs = ms; save(i.guildId, cfg); await i.update({ components: captchaSettingsComponents(cfg) }); return true; }
    if (i.isModalSubmit() && id === 'sar:cp:modal-attempts') { const n = Number(i.fields.getTextInputValue('value')); if (!Number.isInteger(n) || n < MIN_ATTEMPTS || n > MAX_ATTEMPTS) { await i.reply({ content: 'Nombre invalide : entre 1 et 10.', flags: MessageFlags.Ephemeral }); return true; } cfg.verification.maxAttempts = n; save(i.guildId, cfg); await i.update({ components: captchaSettingsComponents(cfg) }); return true; }
    if (i.isButton() && id === 'sar:cp:toggle') { await i.deferUpdate(); if (cfg.verification.enabled) await disableVerificationEnvironment(i.guild); else await enableVerificationEnvironment(i.guild); await i.editReply({ components: captchaSettingsComponents(getGuildConfig(i.guildId)) }); return true; }
    if (i.isChannelSelectMenu() && id === 'sar:cp:channel') { cfg.verification.channelId = i.values[0]; save(i.guildId, cfg); if (cfg.verification.enabled) { await i.deferUpdate(); await enableVerificationEnvironment(i.guild); await i.editReply({ components: captchaSettingsComponents(getGuildConfig(i.guildId)) }); } else await refresh(i); return true; }
    if (i.isRoleSelectMenu() && id === 'sar:cp:role') { const role = i.guild.roles.cache.get(i.values[0]); const me = i.guild.members.me || await i.guild.members.fetchMe(); if (!role || role.managed || role.position >= me.roles.highest.position || role.permissions.has(PermissionFlagsBits.Administrator)) { await i.reply({ content: 'Choisissez un rôle ordinaire, sans Administrateur et sous le rôle du bot.', flags: MessageFlags.Ephemeral }); return true; } cfg.verification.verifiedRoleId = role.id; save(i.guildId, cfg); await refresh(i); return true; }
    if (i.isButton() && id === 'sar:cp:channel-clear') { cfg.verification.channelId = null; save(i.guildId, cfg); await refresh(i); return true; }
    if (i.isButton() && id === 'sar:cp:role-clear') { cfg.verification.verifiedRoleId = null; save(i.guildId, cfg); await refresh(i); return true; }
    if (i.isButton() && id === 'sar:cp:kick') { cfg.verification.kickOnFail = cfg.verification.kickOnFail === false; save(i.guildId, cfg); await refresh(i); return true; }
    if (i.isButton() && id === 'sar:cp:bots') { cfg.verification.ignoreBots = cfg.verification.ignoreBots === false; save(i.guildId, cfg); await refresh(i); return true; }
    return false;
}
