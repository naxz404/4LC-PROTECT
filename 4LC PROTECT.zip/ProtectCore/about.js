import { ActionRowBuilder, ButtonBuilder, ButtonStyle, EmbedBuilder } from 'discord.js';
import { tr } from './i18n.js';

export function aboutPayload(cfg, clientId, actorId = '4lcprotect') {
    const embed = new EmbedBuilder().setColor(0x6495ed).setTitle(tr(cfg, 'À propos de 4LC-PROTECT', 'About 4LC-PROTECT')).setDescription(
        tr(cfg,
            '**4LC-PROTECT** — Bot de protection, de modération et de gestion conçu pour ce serveur.\n\n' +
            '### Fonctionnement\n' +
            '- **Protection en temps réel :** raids, spam, liens, mentions abusives et actions dangereuses.\n' +
            '- **Gestion complète :** sanctions, quarantaine, verrouillage, tickets, sauvegardes et restauration.\n' +
            '- **Configuration dédiée :** les réglages sont pensés pour l’administration de ce serveur.\n' +
            '- **Accès contrôlé :** gestion réservée aux owners, secures et membres autorisés.',
            '**4LC-PROTECT** — Protection, moderation and management bot dedicated to this server.\n\n' +
            '### Operation\n' +
            '- **Real-time protection:** raids, spam, links, abusive mentions and dangerous actions.\n' +
            '- **Complete management:** punishments, quarantine, lockdowns, tickets, backups and restoration.\n' +
            '- **Dedicated configuration:** settings are designed for this server.\n' +
            '- **Controlled access:** management is reserved for owners, secure members and authorized staff.',
        ),
    );
    const changelog = new ButtonBuilder().setCustomId(`sar:about:changelog:${actorId}`).setStyle(ButtonStyle.Primary).setLabel('Changelog').setEmoji('📋');
    return { embeds: [embed], components: [new ActionRowBuilder().addComponents(changelog)] };
}
