import { protectionDataDir } from '../DataPaths.js';
import { readFileSync, writeFileSync, mkdirSync, renameSync } from 'node:fs';
import { resolve } from 'node:path';

const dataDir = protectionDataDir;
const cacheFile = resolve(dataDir, 'phishing-domains.json');
const interval = 15 * 60_000;
let domains = new Set();
let lastFetch = 0;
let pending = null;

function parseFeed(value) {
    const list = Array.isArray(value) ? value : value?.domains;
    if (!Array.isArray(list) || list.length > 50_000) throw Error('Liste de domaines invalide');
    return new Set(list.map((item) => String(item).trim().toLowerCase().replace(/^\.+|\.+$/g, ''))
        .filter((host) => host.length <= 253 && /^[a-z0-9-]+(?:\.[a-z0-9-]+)+$/.test(host)));
}
try { domains = parseFeed(JSON.parse(readFileSync(cacheFile, 'utf8'))); } catch { /* premier démarrage */ }

export function isRemotePhishingDomain(host) {
    const normalized = String(host).toLowerCase().replace(/\.$/, '');
    for (const domain of domains) if (normalized === domain || normalized.endsWith(`.${domain}`)) return true;
    return false;
}
export function remoteDomainCount() { return domains.size; }

export async function refreshPhishingDomains(force = false) {
    const url = process.env.PHISHING_DOMAINS_URL;
    if (!url) return false;
    if (!/^https:\/\//i.test(url)) throw Error('PHISHING_DOMAINS_URL doit être HTTPS');
    if (pending) return pending;
    if (!force && Date.now() - lastFetch < interval) return false;
    lastFetch = Date.now();
    pending = (async () => {
        const response = await fetch(url, { signal: AbortSignal.timeout(8_000), headers: { accept: 'application/json' } });
        if (!response.ok || Number(response.headers.get('content-length')) > 2_000_000) throw Error(`Flux de phishing indisponible (${response.status})`);
        const raw = await response.text();
        if (raw.length > 2_000_000) throw Error('Flux de phishing trop volumineux');
        const next = parseFeed(JSON.parse(raw));
        if (!next.size) throw Error('Liste de phishing vide : ancienne liste conservée');
        mkdirSync(dataDir, { recursive: true });
        const temporary = `${cacheFile}.${process.pid}.tmp`;
        writeFileSync(temporary, JSON.stringify({ domains: [...next] }));
        // Le cache est remplacé seulement après validation complète du flux.
        renameSync(temporary, cacheFile);
        domains = next;
        return true;
    })().finally(() => { pending = null; });
    return pending;
}

export function startPhishingDomainRefresh() {
    void refreshPhishingDomains(true).catch((error) => console.warn('[Phishing] Dernière liste valide conservée :', error.message));
    const timer = setInterval(() => void refreshPhishingDomains().catch((error) => console.warn('[Phishing]', error.message)), interval);
    timer.unref?.();
}
