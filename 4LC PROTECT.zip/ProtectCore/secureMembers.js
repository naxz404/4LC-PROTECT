import { getGuildConfig, saveGuildConfig } from './storage.js';
import { isGuildOwner, accessDenied } from './protectionAccess.js';
import { invalidateSettings } from './antiraid/runtime.js';

export async function updateSecureMember(guild, actorId, userId, remove = false) {
    if (!isGuildOwner(guild, actorId)) throw new Error(accessDenied('owner'));
    if (!/^\d{17,20}$/.test(userId || '')) throw new Error('Mentionne un membre ou indique son identifiant Discord.');
    if (userId === guild.ownerId) throw new Error('Le propriétaire du serveur possède déjà tous les accès.');
    if (!remove) {
        const member = await guild.members.fetch(userId).catch(() => null);
        if (!member || member.user.bot) throw new Error('Choisis un membre humain présent sur ce serveur.');
    }
    // Relire après la requête pour ne pas écraser une autre modification du serveur.
    if (!isGuildOwner(guild, actorId)) throw new Error(accessDenied('owner'));
    const cfg = getGuildConfig(guild.id);
    cfg.secureUsers = remove ? cfg.secureUsers.filter((id) => id !== userId) : [...new Set([...cfg.secureUsers, userId])];
    saveGuildConfig(guild.id, cfg); invalidateSettings(guild.id);
    return cfg;
}
