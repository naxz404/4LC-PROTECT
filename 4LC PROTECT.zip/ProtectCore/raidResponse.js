import { getGuildConfig, saveGuildConfig } from './storage.js';
import { isModuleBypassed } from './antiraid/runtime.js';
import { buildAntiRaidEmbed, sendLog } from './antiraid/logs.js';

const pending = new Map();
const timers = new Map();
const REASON = 'Auto RaidMode : vague d’arrivées suspecte';

export async function raiseRaidVerification(guild, durationMs) {
    const cfg = getGuildConfig(guild.id), until = Date.now() + durationMs;
    if (!cfg.raidVerification?.until) {
        cfg.raidVerification = { previous: guild.verificationLevel, until };
        saveGuildConfig(guild.id, cfg);
        if (guild.verificationLevel !== 4) await guild.setVerificationLevel(4, REASON);
    } else if (until > cfg.raidVerification.until) {
        cfg.raidVerification.until = until;
        saveGuildConfig(guild.id, cfg);
    }
    scheduleVerificationRestore(guild);
}
export async function restoreRaidVerification(guild) {
    const cfg = getGuildConfig(guild.id), saved = cfg.raidVerification;
    if (!saved) return;
    if (saved.until > Date.now()) { scheduleVerificationRestore(guild); return; }
    if (guild.verificationLevel === 4 && saved.previous !== 4) {
        try { await guild.setVerificationLevel(saved.previous, 'Fin Auto RaidMode'); }
        catch { scheduleVerificationRestore(guild, 30_000); return; }
    }
    delete cfg.raidVerification;
    saveGuildConfig(guild.id, cfg);
}
function scheduleVerificationRestore(guild, retryMs = null) {
    if (timers.has(guild.id)) clearTimeout(timers.get(guild.id));
    const until = getGuildConfig(guild.id).raidVerification?.until;
    if (!until) return;
    const delay = retryMs ?? Math.max(1, until - Date.now() + 100);
    const timer = setTimeout(() => { timers.delete(guild.id); void restoreRaidVerification(guild); }, delay);
    timer.unref?.(); timers.set(guild.id, timer);
}

export function queueRaidMembers(client, guild, ids, action, delayMs = 250) {
    let state = pending.get(guild.id);
    if (!state) { state = { client, guild, action, ids: new Set(), promises: [] }; pending.set(guild.id, state); }
    for (const id of ids) state.ids.add(id);
    const promise = new Promise((resolve) => state.promises.push(resolve));
    if (!state.timer) {
        state.timer = setTimeout(() => {
            pending.delete(guild.id);
            void flushRaidMembers(state).catch((error) => {
                console.error('[RaidMode] Traitement impossible :', error);
                for (const resolve of state.promises) resolve({ candidateCount: state.ids.size, handled: 0, failed: state.ids.size, restCalls: 0 });
            });
        }, delayMs);
    }
    return promise;
}
async function flushRaidMembers(state) {
    const { client, guild, action } = state;
    const cfg = getGuildConfig(guild.id), ids = [...state.ids].filter((id) =>
        !isModuleBypassed(id, guild.id, 'antijoin', client.user.id, guild.ownerId) && id !== client.user.id);
    const targets = [], uncachedBanIds = [];
    for (const id of ids) {
        const cached = guild.members.cache.get(id);
        if (action === 'ban' && !cached) { uncachedBanIds.push(id); continue; }
        const member = cached || await guild.members.fetch(id).catch(() => null);
        if (member && !member.user.bot) targets.push(member);
    }
    const eligible = targets.filter((member) => action === 'ban' ? member.bannable : member.kickable);
    const banIds = [...eligible.map((member) => member.id), ...uncachedBanIds];
    let handled = 0, failed = 0, restCalls = 0;
    if (cfg.simulationMode) {
        await sendLog(client, guild.id, buildAntiRaidEmbed('🧪 Simulation Auto RaidMode', `${action === 'ban' ? banIds.length : eligible.length} membre(s) auraient été ${action === 'ban' ? 'bannis' : 'expulsés'}. Aucune sanction appliquée.`));
    } else if (action === 'ban' && typeof guild.bans?.bulkCreate === 'function') {
        for (let index = 0; index < banIds.length; index += 200) {
            const batch = banIds.slice(index, index + 200);
            try {
                const result = await guild.bans.bulkCreate(batch, { reason: REASON }); restCalls++;
                handled += result.bannedUsers?.length ?? 0; failed += result.failedUsers?.length ?? 0;
            } catch { restCalls++; failed += batch.length; }
        }
    } else {
        let next = 0;
        await Promise.all(Array.from({ length: Math.min(3, eligible.length) }, async () => {
            while (next < eligible.length) {
                const member = eligible[next++]; restCalls++;
                try {
                    if (action === 'ban') await member.ban({ reason: REASON });
                    else await member.kick(REASON);
                    handled++;
                } catch { failed++; }
            }
        }));
    }
    const outcome = { candidateCount: ids.length, handled, failed, restCalls, simulated: Boolean(cfg.simulationMode) };
    for (const resolve of state.promises) resolve(outcome);
}
