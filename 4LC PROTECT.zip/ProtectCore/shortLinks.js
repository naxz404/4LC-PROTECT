import { lookup } from 'node:dns/promises';
import { isIP } from 'node:net';
import { request as httpRequest } from 'node:http';
import { request as httpsRequest } from 'node:https';

const SHORTENERS = new Set(['bit.ly', 'tinyurl.com', 't.co', 'is.gd', 'cutt.ly', 'shorturl.at', 'ow.ly', 'buff.ly', 'rebrand.ly', 'rb.gy']);
const cache = new Map();
export function isShortLink(raw) { try { return SHORTENERS.has(new URL(raw).hostname.toLowerCase()); } catch { return false; } }
const nonPublicIp = (ip) => {
    if (isIP(ip) === 4) {
        const [a, b] = ip.split('.').map(Number);
        return a === 0 || a === 10 || a === 127 || a >= 224 || (a === 169 && b === 254) || (a === 172 && b >= 16 && b <= 31) || (a === 192 && b === 168) || (a === 100 && b >= 64 && b <= 127);
    }
    return !ip || ip === '::1' || ip === '::' || /^(fc|fd|fe[89ab])/i.test(ip) || ip.toLowerCase().startsWith('::ffff:');
};

async function publicAddress(url) {
    if (!['http:', 'https:'].includes(url.protocol) || url.username || url.password || url.port || isIP(url.hostname)) return null;
    const addresses = await lookup(url.hostname, { all: true }).catch(() => []);
    if (!addresses.length || addresses.some((entry) => nonPublicIp(entry.address))) return null;
    return addresses[0];
}

async function nextLocation(url) {
    const address = await publicAddress(url);
    if (!address) return null;
    return new Promise((resolve) => {
        const request = (url.protocol === 'https:' ? httpsRequest : httpRequest)(url, {
            method: 'HEAD', timeout: 1_500,
            lookup: (_hostname, _options, callback) => callback(null, address.address, address.family),
            headers: { 'user-agent': '4LC-PROTECT/1.0', accept: '*/*' },
        }, (response) => {
            response.resume();
            try { resolve(response.statusCode >= 300 && response.statusCode < 400 && response.headers.location ? new URL(response.headers.location, url) : null); }
            catch { resolve(null); }
        });
        request.on('timeout', () => request.destroy());
        request.on('error', () => resolve(null));
        request.end();
    });
}

export async function expandShortLink(raw) {
    let url; try { url = new URL(raw); } catch { return null; }
    if (!SHORTENERS.has(url.hostname.toLowerCase())) return null;
    const cached = cache.get(url.toString());
    if (cached && cached.until > Date.now()) return cached.value;
    const original = url.toString();
    for (let redirects = 0; redirects < 2; redirects++) {
        const next = await nextLocation(url);
        if (!next || !await publicAddress(next)) {
            cache.set(original, { value: null, until: Date.now() + 30_000 });
            return null;
        }
        url = next;
        if (!SHORTENERS.has(url.hostname.toLowerCase())) {
            if (cache.size > 5_000) cache.clear();
            cache.set(original, { value: url.toString(), until: Date.now() + 10 * 60_000 });
            return url.toString();
        }
    }
    cache.set(original, { value: null, until: Date.now() + 30_000 });
    return null;
}
