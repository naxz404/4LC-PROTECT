import { AuditLogEvent, PermissionFlagsBits } from 'discord.js';
import { getSettings, isModuleBypassed, findRecentAuditEntry, queueSanction } from '../antiraid/runtime.js';
import { punishMember } from '../antiraid/punish.js';
import { buildAntiRaidEmbed, sendLog } from '../antiraid/logs.js';
import { punishmentDuration, punishmentPastLabel } from '../antiraid/schema.js';
import { tr } from '../i18n.js';

export default {
    name: 'roleUpdate',
    async execute(client, previous, current) {
        const guild = current.guild; const settings = getSettings(guild.id);
        if (settings.antiNuke.enabled || !settings.enabled.antirole || current.managed) return;
        const changed = previous.name !== current.name || previous.color !== current.color || previous.hoist !== current.hoist || previous.mentionable !== current.mentionable || !previous.permissions.equals(current.permissions) || previous.position !== current.position;
        if (!changed) return;
        const adminEscalation = !previous.permissions.has(PermissionFlagsBits.Administrator) && current.permissions.has(PermissionFlagsBits.Administrator);
        const criticalEscalation = adminEscalation && (current.id === guild.id || current.position <= 2);
        const entry = await findRecentAuditEntry(guild, AuditLogEvent.RoleUpdate, current.id);
        const executorId = entry?.executor?.id;
        if (executorId && isModuleBypassed(executorId, guild.id, 'antirole', client.user.id, guild.ownerId)) return;
        if (!executorId && !criticalEscalation) return;
        const me = guild.members.me || await guild.members.fetchMe().catch(() => null);
        const restored = (current.editable || current.id === guild.id) && me ? await current.edit({ name: previous.name, color: previous.color, hoist: previous.hoist, mentionable: previous.mentionable, permissions: previous.permissions.bitfield & me.permissions.bitfield, reason: 'Anti-Rôle : annulation prioritaire 4LC-PROTECT' }).then(async (role) => { if (current.id !== guild.id) await role.setPosition(Math.min(previous.position, Math.max(1, me.roles.highest.position - 1))).catch(() => {}); return true; }).catch(() => false) : false;
        if (!executorId) {
            await sendLog(client, guild.id, buildAntiRaidEmbed('Administrator ajouté à un rôle', `Rôle **${previous.name}** · auteur inconnu · restauration ${restored ? 'réussie' : 'échouée'}.`));
            return;
        }
        queueSanction(guild.id, `antirole-update:${executorId}`, async () => {
            const member = guild.members.cache?.get(executorId) || await guild.members.fetch(executorId).catch(() => null);
            const result = member ? await punishMember(member, settings.punishments.antirole, punishmentDuration(settings, 'antirole', 10 * 60_000), 'Anti-Rôle : modification non autorisée') : { applied: false, note: 'membre introuvable' };
            const label = result.applied ? punishmentPastLabel(result.effectivePunishment, settings) : tr(settings, `non sanctionné (${result.note})`, `not punished (${result.note})`);
            await sendLog(client, guild.id, buildAntiRaidEmbed(tr(settings, criticalEscalation ? 'Élévation Administrator bloquée' : 'Modification de rôle annulée', criticalEscalation ? 'Administrator escalation blocked' : 'Role update reverted'), tr(settings, `<@${executorId}> a modifié **${previous.name}** sans autorisation.\nRestauration : **${restored ? 'réussie' : 'échec'}**.\nRésultat : **${label}**.`, `<@${executorId}> changed **${previous.name}** without authorization.\nRestore: **${restored ? 'successful' : 'failed'}**.\nResult: **${label}**.`)));
        });
    },
};
