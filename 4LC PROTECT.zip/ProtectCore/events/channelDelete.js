import { AuditLogEvent } from 'discord.js';
import { getSettings, isModuleBypassed, findRecentAuditEntry, queueSanction } from '../antiraid/runtime.js';
import { punishMember } from '../antiraid/punish.js';
import { buildAntiRaidEmbed, sendLog } from '../antiraid/logs.js';
import { punishmentDuration, punishmentPastLabel } from '../antiraid/schema.js';
import { tr } from '../i18n.js';
import { recordEmergencyResult } from '../emergencyMode.js';

export default {
    name: 'channelDelete',
    async execute(client, channel) {
        const guild = channel.guild;
        if (!guild) return;
        const settings = getSettings(guild.id);
        if (settings.antiNuke.enabled || !settings.enabled.antichannel) return;

        const entry = await findRecentAuditEntry(guild, AuditLogEvent.ChannelDelete, channel.id);
        const executorId = entry?.executor?.id;
        if (!executorId || isModuleBypassed(executorId, guild.id, 'antichannel', client.user.id, guild.ownerId)) return;

        // La restauration ne doit jamais attendre la file de sanctions. Chaque
        // salon supprimé est recréé, même si le même attaquant en supprime 20.
        const restored = typeof channel.clone === 'function'
            ? await channel.clone({ reason: 'Anti-Salon : restauration prioritaire 4LC-PROTECT' }).then(async (copy) => {
                await copy.setPosition(channel.rawPosition).catch(() => {});
                if (channel.parentId && guild.channels.cache.has(channel.parentId) && typeof copy.setParent === 'function') await copy.setParent(channel.parentId, { lockPermissions: false, reason: 'Restauration de la catégorie' }).catch(() => {});
                return copy;
            }).catch(() => null)
            : null;
        recordEmergencyResult(guild.id, { damage: 1, restored: restored ? 1 : 0, failed: restored ? 0 : 1 });

        queueSanction(guild.id, `antichannel-del:${executorId}`, async () => {
            const member = guild.members.cache?.get(executorId) || await guild.members.fetch(executorId).catch(() => null);
            let label = tr(settings, 'membre introuvable', 'member not found');
            if (member) {
                const result = await punishMember(member, settings.punishments.antichannel, punishmentDuration(settings, 'antichannel', 5 * 60_000), 'Anti-Salon : suppression non autorisée');
                label = result.applied ? punishmentPastLabel(result.effectivePunishment, settings) : tr(settings, `non sanctionné (${result.note})`, `not punished (${result.note})`);
            }
            await sendLog(client, guild.id, buildAntiRaidEmbed(tr(settings, 'Anti-Salon déclenché', 'Anti-Channel triggered'), tr(settings, `<@${executorId}> a supprimé **${channel.name}** sans autorisation.\nRestauration : **${restored ? `oui (${restored})` : 'échec'}** (l’historique Discord ne peut pas être récupéré).\nRésultat : **${label}**.`, `<@${executorId}> deleted **${channel.name}** without authorization.\nRestored: **${restored ? `yes (${restored})` : 'failed'}** (Discord message history cannot be recovered).\nResult: **${label}**.`)));
        });
    },
};
