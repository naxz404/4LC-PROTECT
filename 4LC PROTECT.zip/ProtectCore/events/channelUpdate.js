import { AuditLogEvent } from 'discord.js';
import { getSettings, isModuleBypassed, findRecentAuditEntry, queueSanction } from '../antiraid/runtime.js';
import { punishMember } from '../antiraid/punish.js';
import { buildAntiRaidEmbed, sendLog } from '../antiraid/logs.js';
import { punishmentDuration, punishmentPastLabel } from '../antiraid/schema.js';
import { tr } from '../i18n.js';

export default {
    name: 'channelUpdate',
    async execute(client, previous, current) {
        const guild = current.guild; if (!guild) return;
        const settings = getSettings(guild.id); if (settings.antiNuke.enabled || !settings.enabled.antichannel) return;
        const oldOverwrites = JSON.stringify(previous.permissionOverwrites.cache.map((row) => [row.id, row.allow.bitfield.toString(), row.deny.bitfield.toString()]));
        const newOverwrites = JSON.stringify(current.permissionOverwrites.cache.map((row) => [row.id, row.allow.bitfield.toString(), row.deny.bitfield.toString()]));
        const changed = previous.name !== current.name || previous.parentId !== current.parentId || previous.rawPosition !== current.rawPosition || previous.topic !== current.topic || previous.nsfw !== current.nsfw || previous.rateLimitPerUser !== current.rateLimitPerUser || oldOverwrites !== newOverwrites;
        if (!changed) return;
        const entry = await findRecentAuditEntry(guild, AuditLogEvent.ChannelUpdate, current.id);
        const executorId = entry?.executor?.id;
        if (!executorId || isModuleBypassed(executorId, guild.id, 'antichannel', client.user.id, guild.ownerId)) return;
        const options = { name: previous.name, position: previous.rawPosition, parent: previous.parentId || null, reason: 'Anti-Salon : annulation prioritaire 4LC-PROTECT' };
        if ('topic' in previous) options.topic = previous.topic || null;
        if ('nsfw' in previous) options.nsfw = Boolean(previous.nsfw);
        if ('rateLimitPerUser' in previous) options.rateLimitPerUser = previous.rateLimitPerUser || 0;
        const restored = await current.edit(options).then(async () => { await current.permissionOverwrites.set([...previous.permissionOverwrites.cache.values()].map((row) => ({ id: row.id, type: row.type, allow: row.allow.bitfield, deny: row.deny.bitfield })), 'Anti-Salon : permissions restaurées').catch(() => {}); return true; }).catch(() => false);
        queueSanction(guild.id, `antichannel-update:${executorId}`, async () => {
            const member = guild.members.cache?.get(executorId) || await guild.members.fetch(executorId).catch(() => null);
            const result = member ? await punishMember(member, settings.punishments.antichannel, punishmentDuration(settings, 'antichannel', 5 * 60_000), 'Anti-Salon : modification non autorisée') : { applied: false, note: 'membre introuvable' };
            const label = result.applied ? punishmentPastLabel(result.effectivePunishment, settings) : tr(settings, `non sanctionné (${result.note})`, `not punished (${result.note})`);
            await sendLog(client, guild.id, buildAntiRaidEmbed(tr(settings, 'Modification de salon annulée', 'Channel update reverted'), tr(settings, `<@${executorId}> a modifié **${previous.name}** sans autorisation.\nRestauration : **${restored ? 'réussie' : 'échec'}**.\nRésultat : **${label}**.`, `<@${executorId}> changed **${previous.name}** without authorization.\nRestore: **${restored ? 'successful' : 'failed'}**.\nResult: **${label}**.`)));
        });
    },
};
