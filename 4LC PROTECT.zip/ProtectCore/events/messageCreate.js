import { getSettings, isBypassed, isModuleBypassed, queueSanction } from '../antiraid/runtime.js';
import { punishMember } from '../antiraid/punish.js';
import { buildAntiRaidEmbed, sendLog } from '../antiraid/logs.js';
import { punishmentDuration, punishmentPastLabel } from '../antiraid/schema.js';
import { tr } from '../i18n.js';
import { handleHoneypotMessage } from '../honeypot.js';
import { markModeratedDeletion, rememberGhostPingCandidate } from '../ghostPing.js';
import { quarantineMember } from '../quarantine.js';
import { applyProgressiveWarning } from '../warningSystem.js';
import { findGlobalBlacklist } from '../storage.js';
import { inspectSpamMessage, inspectDistributedMentions, nextSpamStep } from '../adaptiveSecurity.js';
import { hashAttachments } from '../attachmentHash.js';
import { isRemotePhishingDomain } from '../phishingDomains.js';
import { expandShortLink, isShortLink } from '../shortLinks.js';
import { blockedWord } from '../badwords.js';

const INVITE_RE = /(discord\.gg|discord(?:app)?\.com\/invite)\/[a-z0-9-]+/i;
const LINK_RE = /https?:\/\/[^\s]+/i;
const URL_RE = /https?:\/\/[^\s<>()]+/gi;
const OFFICIAL_DISCORD = new Set(['discord.com', 'discord.gg', 'discordapp.com', 'support.discord.com', 'status.discord.com', 'cdn.discordapp.com', 'media.discordapp.net']);
const PHISHING_HINT = /(dlscord|disc0rd|discord-app|discordgift|discord-nitro|nitro.?free|steamcornmunity|stearncommunity|steancommunity|airdrop|wallet.?connect|claim.?gift)/i;

function editDistance(a, b) {
    let row = Array.from({ length: b.length + 1 }, (_, index) => index);
    for (let i = 1; i <= a.length; i++) {
        const next = [i];
        for (let j = 1; j <= b.length; j++) next[j] = Math.min(next[j - 1] + 1, row[j] + 1, row[j - 1] + (a[i - 1] === b[j - 1] ? 0 : 1));
        row = next;
    }
    return row[b.length];
}

function hostRisk(host) {
    if (isRemotePhishingDomain(host) || PHISHING_HINT.test(host) || (host.includes('discord') && !OFFICIAL_DISCORD.has(host))) return `domaine suspect : ${host}`;
    const root = host.split('.').at(-2) || '';
    if (root.length >= 5 && root.length <= 16 && editDistance(root, 'discord') <= 2 && !OFFICIAL_DISCORD.has(host)) return `domaine Discord trompeur : ${host}`;
    if (root.length >= 11 && root.length <= 16 && editDistance(root, 'steamcommunity') <= 2 && host !== 'steamcommunity.com' && !host.endsWith('.steamcommunity.com')) return `domaine Steam trompeur : ${host}`;
    return null;
}

export function suspiciousPhishingReason(message) {
    for (const raw of message.content.match(URL_RE) || []) {
        try { const host = new URL(raw).hostname.toLowerCase().replace(/^www\./, ''); const risk = hostRisk(host); if (risk) return risk; } catch { /* URL invalide */ }
    }
    for (const attachment of message.attachments?.values?.() || []) {
        const name = `${attachment.name || ''} ${attachment.description || ''}`;
        if (PHISHING_HINT.test(name) || (/image\//i.test(attachment.contentType || '') && /(qr|nitro|gift|airdrop|crypto|wallet)/i.test(name))) return `image/fichier suspect : ${attachment.name || 'sans nom'}`;
    }
    return null;
}

async function handlePhishing(message, settings) {
    if (settings.phishing?.enabled === false || (!message.webhookId && isBypassed(message.author.id, message.guild.id, message.client.user.id, message.guild.ownerId))) return false;
    let reason = suspiciousPhishingReason(message);
    if (!reason) for (const raw of (message.content.match(URL_RE) || []).slice(0, 2)) {
        const expanded = await expandShortLink(raw);
        if (expanded) { reason = hostRisk(new URL(expanded).hostname.toLowerCase().replace(/^www\./, '')); if (reason) { reason += ' (lien raccourci)'; break; } }
        else if (isShortLink(raw)) { reason = 'lien raccourci non vérifiable'; break; }
    }
    if (!reason) return false;
    markModeratedDeletion(message.id); await message.delete().catch(() => {});
    let result = null; if (!message.webhookId && settings.phishing?.quarantine !== false && message.member) result = await quarantineMember(message.client, message.member, 'phishing', reason).catch(() => null);
    await sendLog(message.client, message.guild.id, buildAntiRaidEmbed(tr(settings, 'Phishing détecté', 'Phishing detected'), `${message.author} · ${reason}\n${tr(settings, 'Message supprimé', 'Message deleted')}.${result?.applied ? ` ${tr(settings, 'Compte placé en quarantaine.', 'Account quarantined.')}` : ''}`));
    return true;
}

async function handleAntiSpam(message, settings) {
    const mentionDetection = inspectDistributedMentions(message);
    const mentionTriggered = settings.enabled.antieveryone && mentionDetection.triggered;
    if (!settings.enabled.antispam && !mentionTriggered) return false;
    const module = mentionTriggered ? 'antieveryone' : 'antispam';
    if (isModuleBypassed(message.author.id, message.guild.id, module, message.client.user.id, message.guild.ownerId)) return false;
    message.securityAttachmentHashes = await hashAttachments(message);
    const detection = settings.enabled.antispam ? inspectSpamMessage(message, settings.antispam) : { triggered: false, reason: null, messageIds: [], raidMode: false };
    if (mentionTriggered) {
        detection.triggered = true;
        detection.reason = `${mentionDetection.count} mentions réparties sur plusieurs messages`;
        detection.messageIds = mentionDetection.messageIds;
    }
    if (!detection.triggered) return false;

    queueSanction(message.guild.id, `${module}:${message.author.id}`, async () => {
        const member = message.webhookId ? null : message.member;
        if (!member) return;
        const step = nextSpamStep(message.guild.id, message.author.id);
        const reason = mentionTriggered
            ? tr(settings, `Anti-Mass Mention : ${detection.reason}`, `Anti-Mass Mention: ${detection.reason}`)
            : tr(settings, `Anti-Spam adaptatif : ${detection.reason}`, `Adaptive Anti-Spam: ${detection.reason}`);
        const progressive = settings.warningSystem?.enabled !== false ? await applyProgressiveWarning(message.client, member, reason, message.client.user.id, 1, module) : null;
        const configuredDuration = punishmentDuration(settings, module, settings.antispam.timeoutMs);
        const duration = step === 1 ? Math.min(configuredDuration, 30_000) : step === 2 ? configuredDuration : Math.max(configuredDuration, 5 * 60_000);
        const result = progressive ? null : await punishMember(member, settings.punishments[module], duration, reason);
        const label = progressive ? `${progressive.total} point(s) · ${progressive.action}` : result.applied ? punishmentPastLabel(result.effectivePunishment, settings) : tr(settings, `non sanctionné (${result.note})`, `not punished (${result.note})`);
        await sendLog(message.client, message.guild.id, buildAntiRaidEmbed(
            tr(settings, mentionTriggered ? 'Anti-Mass Mention déclenché' : 'Anti-Spam adaptatif déclenché', mentionTriggered ? 'Anti-Mass Mention triggered' : 'Adaptive Anti-Spam triggered'),
            tr(settings, `${member} · ${detection.reason}${detection.raidMode ? ' · seuil renforcé pendant le raid' : ''}.
Récidive : **niveau ${step}** · Résultat : **${label}**.`, `${member} · ${detection.reason}${detection.raidMode ? ' · stricter raid threshold' : ''}.
Repeat level: **${step}** · Result: **${label}**.`)
        ));
    });
    const ids = detection.messageIds;
    if (ids?.length && typeof message.channel.bulkDelete === 'function') await message.channel.bulkDelete(ids, true).catch(() => {});
    else await message.delete().catch(() => {});
    return true;
}

async function handleAntiLink(message, settings) {
    if (!settings.enabled.antilink) return false;
    if (!message.webhookId && isModuleBypassed(message.author.id, message.guild.id, 'antilink', message.client.user.id, message.guild.ownerId)) return false;
    const matchesInvite = INVITE_RE.test(message.content);
    const matchesLink = settings.antilink.type === 'all' && LINK_RE.test(message.content);
    if (!matchesInvite && !matchesLink) return false;

    markModeratedDeletion(message.id); await message.delete().catch(() => {});
    if (message.webhookId) {
        await sendLog(message.client, message.guild.id, buildAntiRaidEmbed(tr(settings, 'Lien webhook bloqué', 'Webhook link blocked'), `Webhook \`${message.webhookId}\` · ${message.channel}`));
        return true;
    }
    queueSanction(message.guild.id, `antilink:${message.author.id}:${message.id}`, async () => {
        const member = message.webhookId ? null : message.member;
        if (!member) return;
        const result = await punishMember(member, settings.punishments.antilink, punishmentDuration(settings, 'antilink', 5 * 60_000), tr(settings, 'Anti-Lien : lien non autorisé', 'Anti-Link: unauthorized link'));
        const label = result.applied ? punishmentPastLabel(result.effectivePunishment, settings) : tr(settings, `non sanctionné (${result.note})`, `not punished (${result.note})`);
        await sendLog(message.client, message.guild.id, buildAntiRaidEmbed(tr(settings, 'Anti-Lien déclenché', 'Anti-Link triggered'), tr(settings, `${member} a envoyé un lien non autorisé dans ${message.channel}.\nRésultat : **${label}**.`, `${member} sent an unauthorized link in ${message.channel}.\nResult: **${label}**.`)));
    });
    return true;
}

async function handleAntiEveryone(message, settings) {
    if (!settings.enabled.antieveryone) return false;
    if (isModuleBypassed(message.author.id, message.guild.id, 'antieveryone', message.client.user.id, message.guild.ownerId)) return false;
    if (!message.mentions?.everyone && !/(^|[^\w])@(everyone|here)\b/i.test(message.content)) return false;
    if (!message.webhookId && isModuleBypassed(message.author.id, message.guild.id, 'antieveryone', message.client.user.id, message.guild.ownerId)) return false;
    if (!message.webhookId && message.member?.permissions.has('MentionEveryone')) return false;

    markModeratedDeletion(message.id); await message.delete().catch(() => {});
    if (message.webhookId) {
        await sendLog(message.client, message.guild.id, buildAntiRaidEmbed(tr(settings, 'Mention webhook bloquée', 'Webhook mention blocked'), `Webhook \`${message.webhookId}\` · ${message.channel}`));
        return true;
    }
    queueSanction(message.guild.id, `antieveryone:${message.author.id}:${message.id}`, async () => {
        const member = message.webhookId ? null : message.member;
        if (!member) return;
        const result = await punishMember(member, settings.punishments.antieveryone, punishmentDuration(settings, 'antieveryone', 5 * 60_000), tr(settings, 'Anti-@everyone : mention de masse non autorisée', 'Anti-@everyone: unauthorized mass mention'));
        const label = result.applied ? punishmentPastLabel(result.effectivePunishment, settings) : tr(settings, `non sanctionné (${result.note})`, `not punished (${result.note})`);
        await sendLog(message.client, message.guild.id, buildAntiRaidEmbed(tr(settings, 'Anti-@everyone déclenché', 'Anti-@everyone triggered'), tr(settings, `${member} a mentionné @everyone/@here dans ${message.channel}.\nRésultat : **${label}**.`, `${member} mentioned @everyone/@here in ${message.channel}.\nResult: **${label}**.`)));
    });
    return true;
}

/**
 * Détecte les messages produits par une application "installée sur le compte
 * d'un membre" (User Apps Discord) et jamais ajoutée au serveur en tant que
 * bot. Une réponse de commande peut avoir `webhookId`, même si ce n'est
 * pas un webhook ordinaire. L'origine de l'installation indiquée dans
 * interactionMetadata permet de distinguer installation utilisateur et serveur.
 */
export async function handleExternalApp(message, settings) {
    const module = settings.enabled.antiuserapps ? 'antiuserapps' : settings.enabled.antibot ? 'antibot' : null;
    if (!module) return false;
    const interactionInfo = message.interactionMetadata || message.interaction;
    if (!interactionInfo) return false; // pas une réponse à une commande d'application
    const appId = message.applicationId || message.author.id;
    if (appId === message.client.user.id) return false;
    const owners = interactionInfo.authorizingIntegrationOwners;
    if (owners?.guildId === message.guild.id || owners?.['0'] === message.guild.id) return false;
    const userInstalled = Boolean(owners?.userId || owners?.['1']);
    if (!userInstalled && (message.member || !message.author?.bot)) return false;
    // Sans contexte d'installation, les bots membres du serveur ne sont pas
    // considérés comme des applications externes.
    if (!userInstalled && message.guild.members.cache.has(appId)) return false;
    if ((settings.userAppsWhitelist || []).includes(appId)) return false;

    markModeratedDeletion(message.id);
    const deleted = await message.delete().then(() => true).catch(() => false);

    const actor = interactionInfo.user || null;
    let label = tr(settings, 'membre introuvable', 'member not found');
    if (actor) {
        const member = message.guild.members.cache.get(actor.id) || await message.guild.members.fetch(actor.id).catch(() => null);
        if (member) {
            if (isModuleBypassed(actor.id, message.guild.id, module, message.client.user.id, message.guild.ownerId)) {
                label = tr(settings, 'non sanctionné (exempté)', 'not punished (exempted)');
            } else {
                const result = await punishMember(member, settings.punishments[module], punishmentDuration(settings, module, 5 * 60_000), tr(settings, 'Anti-App externe : commande d’une application non ajoutée au serveur', 'Anti-External-App: command from an app not added to the server'));
                label = result.applied ? punishmentPastLabel(result.effectivePunishment, settings) : tr(settings, `non sanctionné (${result.note})`, `not punished (${result.note})`);
            }
        }
    }
    await sendLog(message.client, message.guild.id, buildAntiRaidEmbed(
        tr(settings, 'Application externe bloquée', 'External app blocked'),
        tr(settings,
            `Une application non ajoutée au serveur (\`${appId}\`) a répondu dans ${message.channel}.${actor ? ` Membre à l'origine de la commande : <@${actor.id}>.` : ''}\n${deleted ? 'Message supprimé' : 'Suppression impossible (permissions à vérifier)'} · Résultat : **${label}**.`,
            `An application not added to the server (\`${appId}\`) responded in ${message.channel}.${actor ? ` Member who triggered the command: <@${actor.id}>.` : ''}\n${deleted ? 'Message removed' : 'Could not delete (check permissions)'} · Result: **${label}**.`),
    ));
    return true;
}

async function handleContentFilter(message, settings) {
    if (!message.webhookId && isBypassed(message.author.id, message.guild.id, message.client.user.id, message.guild.ownerId)) return false;
    const mentions = (message.mentions?.users?.size || 0) + (message.mentions?.roles?.size || 0);
    const tooManyMentions = settings.mentionLimit > 0 && mentions >= settings.mentionLimit;
    const marks = message.content.match(/\p{M}/gu)?.length || 0;
    const invisibles = message.content.match(/[\u200B-\u200F\u2060\uFEFF]/gu)?.length || 0;
    const suspicious = settings.suspiciousTextFilter && (marks > 12 || invisibles > 4);
    if (!tooManyMentions && !suspicious) return false;
    markModeratedDeletion(message.id); const deleted = await message.delete().then(() => true).catch(() => false);
    if (deleted) await sendLog(message.client, message.guild.id, buildAntiRaidEmbed(tr(settings, 'Filtre de contenu', 'Content filter'), tr(settings, `${message.author} : message retiré (${tooManyMentions ? 'mentions en masse' : 'texte perturbant'}).`, `${message.author}: message removed (${tooManyMentions ? 'mass mentions' : 'disruptive text'}).`)));
    return deleted;
}

/** Vérifications communes à la création et à l'édition, sans comptabiliser l'édition comme du spam. */
export async function filterMessageContent(message, settings = getSettings(message.guild.id)) {
    const word = blockedWord(message.content, settings, message.channelId);
    if (word && (message.webhookId || !isBypassed(message.author.id, message.guild.id, message.client.user.id, message.guild.ownerId))) {
        markModeratedDeletion(message.id);
        await message.delete().catch(() => {});
        await sendLog(message.client, message.guild.id, buildAntiRaidEmbed(tr(settings, 'Mot interdit', 'Blocked word'), `${message.author} · ${message.channel} · ${tr(settings, 'Message retiré', 'Message removed')} (${word.replace(/`/g, 'ˋ')}).`));
        return true;
    }
    if (await handlePhishing(message, settings)) return true;
    if (await handleAntiLink(message, settings)) return true;
    if (await handleAntiEveryone(message, settings)) return true;
    return handleContentFilter(message, settings);
}

export default {
    name: 'messageCreate',
    async execute(client, message) {
        if (!message.guild || message.author?.id === client.user.id) return false;
        const settings = getSettings(message.guild.id);
        if (await handleExternalApp(message, settings)) return true;
        if (message.webhookId) { await filterMessageContent(message, settings); return; }
        if (message.author?.bot) {
            if (message.member) await filterMessageContent(message, settings);
            return;
        }
        const blacklisted = findGlobalBlacklist(message.author.id);
        if (blacklisted) {
            markModeratedDeletion(message.id); await message.delete().catch(() => {});
            if (message.member?.bannable) await message.member.ban({ reason: `Blacklist globale : ${blacklisted.reason}` }).catch(() => {});
            else if (message.member?.kickable) await message.member.kick(`Blacklist globale : ${blacklisted.reason}`).catch(() => {});
            await sendLog(client, message.guild.id, buildAntiRaidEmbed('Blacklist globale', `${message.author} bloqué pendant une activité sur le serveur.\nRaison : **${blacklisted.reason}**.`)); return true;
        }
        rememberGhostPingCandidate(message);
        if (await handleHoneypotMessage(message, settings)) return true;
        if (await filterMessageContent(message, settings)) return true;
        if (await handleAntiSpam(message, settings)) return true;
    },
};
