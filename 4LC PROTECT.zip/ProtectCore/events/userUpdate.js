import { allowedGuilds } from '../../ServerScope.js';
import { syncTagRole } from '../tagRole.js';

export default {
    name: 'userUpdate',
    async execute(client, oldUser, newUser) {
        const before = oldUser.primaryGuild;
        const after = newUser.primaryGuild;
        if (before?.identityGuildId === after?.identityGuildId && before?.identityEnabled === after?.identityEnabled) return;
        for (const guild of allowedGuilds(client)) {
            const member = guild.members.cache.get(newUser.id);
            if (member) await syncTagRole(member, newUser);
        }
    },
};
