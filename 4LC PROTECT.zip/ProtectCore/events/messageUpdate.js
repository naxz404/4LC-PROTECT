import { filterMessageContent, handleExternalApp } from './messageCreate.js';
import { getSettings } from '../antiraid/runtime.js';

export default {
    name: 'messageUpdate',
    async execute(_client, previous, current) {
        if (!current.guild || !current.author) {
            if (current.partial) current = await current.fetch().catch(() => null);
        }
        if (!current?.guild || !current.author) return;
        if (await handleExternalApp(current, getSettings(current.guild.id))) return;
        if (current.author.bot && !current.webhookId) return;
        // Les embeds et compteurs de réactions déclenchent aussi messageUpdate.
        if (!previous.partial && previous.content === current.content &&
            previous.attachments?.size === current.attachments?.size) return;
        await filterMessageContent(current);
    },
};
