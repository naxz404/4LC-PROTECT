import { getSettings, invalidateSettings, isBypassed, isModuleBypassed } from '../antiraid/runtime.js';
import { buildAntiRaidEmbed, sendLog } from '../antiraid/logs.js';
import { syncTagRole } from '../tagRole.js';
import { tr } from '../i18n.js';
import { findGlobalBlacklist, getGuildConfig, saveGuildConfig } from '../storage.js';
import { quarantineMember } from '../quarantine.js';
import { startCaptchaChallenge } from '../captcha.js';
import { recordJoin } from '../adaptiveSecurity.js';
import { scoreJoinRisk } from '../joinRisk.js';
import { trackMemberInvite } from '../inviteTracker.js';
import { activateAutomaticEmergency } from '../emergencyMode.js';
import { primeAntiNukeGuild } from '../antinuke.js';
import { queueRaidMembers, raiseRaidVerification } from '../raidResponse.js';

export default {
    name: 'guildMemberAdd',
    async execute(client, member) {
        const settings = getSettings(member.guild.id);
        if (isBypassed(member.id, member.guild.id, client.user.id, member.guild.ownerId)) return;
        const accountRisk = member.user.bot ? { score: 0, indicators: [] } : scoreJoinRisk(member.user);
        if (!member.user.bot) void trackMemberInvite(client, member, accountRisk).catch(console.error);
        const blacklisted = findGlobalBlacklist(member.id);
        if (blacklisted) {
            if (!settings.simulationMode) {
                if (member.bannable) await member.ban({ reason: `Blacklist globale : ${blacklisted.reason}` }).catch(() => {});
                else if (member.kickable) await member.kick(`Blacklist globale : ${blacklisted.reason}`).catch(() => {});
            }
            await sendLog(client, member.guild.id, buildAntiRaidEmbed(settings.simulationMode ? '🧪 Simulation Blacklist' : 'Blacklist globale', `${member.user.tag} (\`${member.id}\`) ${settings.simulationMode ? 'aurait été bloqué' : 'bloqué'} à l’arrivée.\nRaison : **${blacklisted.reason}**.`));
            return true;
        }

        if (settings.joinLock && !member.user.bot && !isModuleBypassed(member.id, member.guild.id, 'antijoin', client.user.id, member.guild.ownerId)) {
            if (settings.simulationMode) await sendLog(client, member.guild.id, buildAntiRaidEmbed('🧪 Simulation Join-Lock', `<@${member.id}> aurait été expulsé.`));
            else if (member.kickable) await member.kick('Join-Lock activé').catch(() => {});
            return true;
        }

        // Les contrôles d'expulsion passent avant le CAPTCHA, les rôles et
        // toute autre requête afin de réduire au minimum le temps de présence.
        if (settings.enabled.antibot && member.user.bot && !isModuleBypassed(member.id, member.guild.id, 'antibot', client.user.id, member.guild.ownerId)) {
            const kicked = !settings.simulationMode && member.kickable ? await member.kick('Anti-Bot : bot non autorisé').then(() => true).catch(() => false) : false;
            await sendLog(client, member.guild.id, buildAntiRaidEmbed(settings.simulationMode ? '🧪 Simulation Anti-Bot' : tr(settings, 'Anti-Bot déclenché', 'Anti-Bot triggered'), settings.simulationMode ? `${member} (bot) aurait été expulsé.` : tr(settings, `${member} (bot) : ${kicked ? 'expulsé à son arrivée' : 'expulsion impossible (permissions ou hiérarchie)'}.`, `${member} (bot): ${kicked ? 'kicked on join' : 'could not be kicked (permissions or hierarchy)'}.`)));
            return true;
        }

        if (settings.enabled.antitoken && !member.user.bot && !isModuleBypassed(member.id, member.guild.id, 'antitoken', client.user.id, member.guild.ownerId)) {
            const age = Date.now() - member.user.createdTimestamp;
            if (age < settings.antitoken.minAccountAgeMs) {
                const kicked = !settings.simulationMode && member.kickable ? await member.kick('Anti-Compte récent : compte trop jeune').then(() => true).catch(() => false) : false;
                await sendLog(client, member.guild.id, buildAntiRaidEmbed(settings.simulationMode ? '🧪 Simulation Anti-Compte récent' : tr(settings, 'Anti-Compte récent déclenché', 'Anti-New Account triggered'), settings.simulationMode ? `${member} aurait été expulsé (compte de ${Math.round(age / 60000)} min).` : tr(settings, `${member} : ${kicked ? 'expulsé' : 'expulsion impossible'} (compte créé il y a ${Math.round(age / 60000)} min, minimum requis : ${Math.round(settings.antitoken.minAccountAgeMs / 60000)} min).`, `${member}: ${kicked ? 'kicked' : 'could not be kicked'} (account created ${Math.round(age / 60000)} min ago, required minimum: ${Math.round(settings.antitoken.minAccountAgeMs / 60000)} min).`)));
                return true;
            }
        }

        if (settings.autoRaid?.enabled && !member.user.bot && !isModuleBypassed(member.id, member.guild.id, 'antijoin', client.user.id, member.guild.ownerId)) {
            const now = Date.now();
            const joins = recordJoin(member.guild.id, member.id, settings.autoRaid.count, settings.autoRaid.windowMs, settings.autoRaid.durationMs);
            if (joins.crossed) {
                if (!settings.simulationMode) activateAutomaticEmergency(member.guild.id, 'arrivées massives');
                primeAntiNukeGuild(member.guild);
                const persistent = getGuildConfig(member.guild.id); persistent.raidHistory ||= []; persistent.raidHistory.push({ at: now, joins: joins.count, windowMs: settings.autoRaid.windowMs, action: settings.raidAction }); persistent.raidHistory = persistent.raidHistory.slice(-100); saveGuildConfig(member.guild.id, persistent); invalidateSettings(member.guild.id);
                if (!persistent.simulationMode) void raiseRaidVerification(member.guild, settings.autoRaid.durationMs).catch(console.error);
                void queueRaidMembers(client, member.guild, joins.memberIds, settings.raidAction);
                void sendLog(client, member.guild.id, buildAntiRaidEmbed(tr(settings, 'Auto RaidMode adaptatif activé', 'Adaptive Auto RaidMode enabled'), tr(settings, `${joins.count} arrivées en ${settings.autoRaid.windowMs / 1000} secondes. La vague détectée et les nouvelles arrivées seront traitées pendant ${settings.autoRaid.durationMs / 60000} minutes; l’Anti-Spam passe automatiquement sur un seuil renforcé.`, `${joins.count} joins in ${settings.autoRaid.windowMs / 1000} seconds. The detected wave and new joins will be handled for ${settings.autoRaid.durationMs / 60000} minutes; Anti-Spam automatically switches to a stricter threshold.`)));
                return true;
            }
            if (joins.active) {
                await queueRaidMembers(client, member.guild, [member.id], settings.raidAction);
                return true;
            }
        }

        await syncTagRole(member);
    },
};
