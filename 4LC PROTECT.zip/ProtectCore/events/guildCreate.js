import { syncGuildCommands } from '../slash/sync.js';
import { ChannelType, PermissionFlagsBits } from 'discord.js';
import { getGuildConfig, saveGuildConfig } from '../storage.js';
import { definitionsForLanguage } from '../slash/definitions.js';
import { invalidateSettings } from '../antiraid/runtime.js';
import { ensureUnverifiedRole } from '../onboarding.js';
import { rememberLocalizedMessage } from '../localizedMessages.js';
import { welcomePayload } from '../welcome.js';
import { primeGuildInvites } from '../inviteTracker.js';
import { createPeriodicServerBackup } from '../serverBackup.js';

export { welcomePayload, welcomeLanguageSelect } from '../welcome.js';

export async function ensureDefaultLogChannel(client, guild) {
    const cfg = getGuildConfig(guild.id);
    const me = guild.members.me || await guild.members.fetchMe().catch(() => null);
    let channel = cfg.logChannel ? await guild.channels.fetch(cfg.logChannel).catch(() => null) : null;
    if (!channel?.isTextBased()) channel = guild.channels.cache.find((item) => item.type === ChannelType.GuildText && item.name === '4lcprotect-logs') || null;
    if (!channel && me?.permissions.has(PermissionFlagsBits.ManageChannels)) {
        channel = await guild.channels.create({
            name: '4lcprotect-logs', type: ChannelType.GuildText,
            reason: 'Salon de logs par défaut de 4LC-PROTECT',
            permissionOverwrites: [
                { id: guild.roles.everyone.id, deny: [PermissionFlagsBits.ViewChannel] },
                { id: client.user.id, allow: [PermissionFlagsBits.ViewChannel, PermissionFlagsBits.SendMessages, PermissionFlagsBits.EmbedLinks, PermissionFlagsBits.ReadMessageHistory] },
            ],
        }).catch(() => null);
    }
    if (channel?.isTextBased()) {
        cfg.logChannel = channel.id;
        saveGuildConfig(guild.id, cfg);
        invalidateSettings(guild.id);
        if (channel.isSendable()) {
            const sent = await channel.send(welcomePayload(cfg)).catch(() => null);
            if (sent) rememberLocalizedMessage(guild.id, sent, 'welcome');
        }
        return channel;
    }
    const fallback = guild.systemChannel?.isSendable() ? guild.systemChannel : guild.channels.cache.find((item) => item.isTextBased?.() && item.isSendable?.() && me && item.permissionsFor(me)?.has(PermissionFlagsBits.SendMessages));
    if (fallback) {
        const sent = await fallback.send(welcomePayload(cfg)).catch(() => null);
        if (sent) rememberLocalizedMessage(guild.id, sent, 'welcome');
    }
    return null;
}

export default {
    name: 'guildCreate',
    async execute(client, guild) {
        void primeGuildInvites(guild);
        try { createPeriodicServerBackup(guild); } catch (error) { console.error(`[Backup] ${guild.id}:`, error); }
        await ensureUnverifiedRole(guild);
        await ensureDefaultLogChannel(client, guild);
        if (process.env.AUTO_REGISTER_SLASH === 'false') return;
        try {
            const result = await syncGuildCommands(guild, definitionsForLanguage(getGuildConfig(guild.id).language));
            console.log(`Commandes / enregistrées sur ${guild.name} (${guild.id}) : ${result.created} créées, ${result.updated} actualisées, ${result.removed} anciennes retirées.`);
        } catch (error) {
            console.error(`❌ Enregistrement des commandes / sur ${guild.name} (${guild.id}) : ${error.message}. Vérifiez l'installation du bot et le scope applications.commands.`);
        }
    },
};
