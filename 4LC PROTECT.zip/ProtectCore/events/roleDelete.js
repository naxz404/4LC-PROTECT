import { AuditLogEvent } from 'discord.js';
import { getSettings, isModuleBypassed, findRecentAuditEntry, queueSanction } from '../antiraid/runtime.js';
import { punishMember } from '../antiraid/punish.js';
import { buildAntiRaidEmbed, sendLog } from '../antiraid/logs.js';
import { punishmentDuration, punishmentPastLabel } from '../antiraid/schema.js';
import { tr } from '../i18n.js';
import { recordEmergencyResult } from '../emergencyMode.js';

export default {
    name: 'roleDelete',
    async execute(client, role) {
        const guild = role.guild;
        const settings = getSettings(guild.id);
        if (settings.antiNuke.enabled || !settings.enabled.antirole) return;

        const entry = await findRecentAuditEntry(guild, AuditLogEvent.RoleDelete, role.id);
        const executorId = entry?.executor?.id;
        if (!executorId || isModuleBypassed(executorId, guild.id, 'antirole', client.user.id, guild.ownerId)) return;

        const me = guild.members.me || await guild.members.fetchMe().catch(() => null);
        const restored = !role.managed && me?.permissions.has('ManageRoles')
            ? await guild.roles.create({
                name: role.name, color: role.color, hoist: role.hoist, mentionable: role.mentionable,
                permissions: role.permissions.bitfield & me.permissions.bitfield,
                reason: 'Anti-Rôle : restauration prioritaire 4LC-PROTECT',
            }).then(async (copy) => { await copy.setPosition(Math.min(role.position, Math.max(1, me.roles.highest.position - 1))).catch(() => {}); return copy; }).catch(() => null)
            : null;
        recordEmergencyResult(guild.id, { damage: 1, restored: restored ? 1 : 0, failed: restored ? 0 : 1 });

        queueSanction(guild.id, `antirole-del:${executorId}`, async () => {
            const member = guild.members.cache?.get(executorId) || await guild.members.fetch(executorId).catch(() => null);
            let label = tr(settings, 'membre introuvable', 'member not found');
            if (member) {
                const result = await punishMember(member, settings.punishments.antirole, punishmentDuration(settings, 'antirole', 10 * 60_000), 'Anti-Rôle : suppression non autorisée');
                label = result.applied ? punishmentPastLabel(result.effectivePunishment, settings) : tr(settings, `non sanctionné (${result.note})`, `not punished (${result.note})`);
            }
            await sendLog(client, guild.id, buildAntiRaidEmbed(tr(settings, 'Anti-Rôle déclenché', 'Anti-Role triggered'), tr(settings, `<@${executorId}> a supprimé le rôle **${role.name}** sans autorisation.\nRestauration : **${restored ? `oui (${restored})` : 'échec'}**.\nRésultat : **${label}**.`, `<@${executorId}> deleted role **${role.name}** without authorization.\nRestored: **${restored ? `yes (${restored})` : 'failed'}**.\nResult: **${label}**.`)));
        });
    },
};
