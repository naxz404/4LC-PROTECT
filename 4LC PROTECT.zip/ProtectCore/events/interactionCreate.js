import { isGuildOwner } from '../protectionAccess.js';
import { componentProtectionAccess, accessAllowed, accessDenied } from '../protectionAccess.js';
import { ActionRowBuilder, ButtonBuilder, ButtonStyle, ChannelSelectMenuBuilder, ChannelType, EmbedBuilder, MessageFlags, ModalBuilder, PermissionFlagsBits, RoleSelectMenuBuilder, StringSelectMenuBuilder, TextInputBuilder, TextInputStyle } from 'discord.js';
import { getGuildConfig, saveGuildConfig, deleteMemberData } from '../storage.js';
import { invalidateSettings } from '../antiraid/runtime.js';
import { MODULES, durationLabel, moduleLabel, punishmentLabel } from '../antiraid/schema.js';
import { BLUE, badwordsPayload, categoryPayload, panelPayload, setupPayload, summaryPayload, whitelistPayload } from '../ui.js';
import { handleSlash } from '../slash/handlers.js';
import { handleCaptcha } from '../captcha.js';
import { handleHelpInteraction } from '../helpEmbed.js';
import { handleChangelogInteraction, changelogPayload } from '../changelog.js';
import { tr } from '../i18n.js';
import { syncTagRole } from '../tagRole.js';
import config from '../config.js';
import { installErrorNormalizer } from '../errors/errorEmbed.js';
import { syncGuildCommands } from '../slash/sync.js';
import { definitionsForLanguage } from '../slash/definitions.js';
import { captureError } from '../errors/observability.js';
import { syncHoneypotLanguage } from '../honeypot.js';
import { applyProtectionLevel } from '../protectionLevels.js';
import { resolveBackup, restoreServerBackup } from '../serverBackup.js';
import { resolveQuarantine } from '../quarantine.js';
import { lockChannels, unlockChannels } from '../lockdown.js';
import { refreshConfigPanelOnly, refreshLocalizedMessages, rememberLocalizedMessage } from '../localizedMessages.js';
import { captchaSettingsPayload, handleCaptchaSettingsInteraction } from '../captchaDashboard.js';
import { honeypotSettingsPayload, handleHoneypotSettingsInteraction } from '../honeypotDashboard.js';
import { primeAntiNukeGuild } from '../antinuke.js';
import { welcomePayload } from '../welcome.js';
import { throttleInteraction } from '../interactionCooldown.js';
import { syncExternalAppPermissions } from '../externalAppPermissions.js';
import { handleIncidentInteraction } from '../incidentActions.js';
import { buildAntiRaidEmbed, sendLog } from '../antiraid/logs.js';
import { parseBadwords, syncBadwordsRule } from '../badwords.js';
import { ensureCentralLogChannel } from '../../Features/centralLogs.js';

const pending = new Map();
const key = (interaction) => `${interaction.guildId}:${interaction.user.id}`;
const note = (text) => ({ content: text, flags: MessageFlags.Ephemeral });
function save(interaction, cfg) { saveGuildConfig(interaction.guildId, cfg); invalidateSettings(interaction.guildId); refreshConfigPanelOnly(interaction.guild).catch(() => {}); }
function modal(id, title, fields) {
    const m = new ModalBuilder().setCustomId(id).setTitle(title);
    for (const [fieldId, label, value] of fields) m.addComponents(new ActionRowBuilder().addComponents(new TextInputBuilder().setCustomId(fieldId).setLabel(label).setValue(String(value)).setStyle(TextInputStyle.Short).setRequired(true)));
    return m;
}
function linkSettingsPayload(cfg) {
    const en = cfg.language === 'en';
    const scope = cfg.antilink.type === 'all' ? (en ? 'All links' : 'Tous les liens') : (en ? 'Discord invites' : 'Invitations Discord');
    const embed = new EmbedBuilder().setColor(BLUE).setTitle(en ? '🔗 Anti-link' : '🔗 Anti-lien')
        .setDescription(`${cfg.enabled.antilink ? '🟢' : '⚪'} ${en ? 'Protection' : 'Protection'} · **${scope}**`);
    const menu = new StringSelectMenuBuilder().setCustomId('sar:links').setPlaceholder(en ? 'Blocked links' : 'Liens bloqués').addOptions(
        { label: en ? 'Discord invites' : 'Invitations Discord', value: 'invite', default: cfg.antilink.type !== 'all' },
        { label: en ? 'All links' : 'Tous les liens', value: 'all', default: cfg.antilink.type === 'all' },
    );
    const toggle = new ButtonBuilder().setCustomId('sar:links:toggle').setLabel(cfg.enabled.antilink ? (en ? 'Disable' : 'Désactiver') : (en ? 'Enable' : 'Activer')).setStyle(cfg.enabled.antilink ? ButtonStyle.Danger : ButtonStyle.Success);
    return { embeds: [embed], components: [new ActionRowBuilder().addComponents(menu), new ActionRowBuilder().addComponents(toggle)] };
}

export default {
    name: 'interactionCreate',
    async execute(client, i) {
        installErrorNormalizer(i);
        try {
        if (await throttleInteraction(i)) return;
        if (await handleIncidentInteraction(i)) return;
        if (await handleSlash(i)) return;
        if (await handleCaptcha(i)) return;
        if (await handleCaptchaSettingsInteraction(i)) return;
        if (await handleHoneypotSettingsInteraction(i)) return;
        if (await handleHelpInteraction(i)) return;
        if (await handleChangelogInteraction(i)) return;
        if (!i.guildId || !i.customId?.startsWith('sar:')) return;
        if (i.isButton() && i.customId.startsWith('sar:privacy:delete:')) {
            const userId = i.customId.slice('sar:privacy:delete:'.length);
            if (userId !== i.user.id) return i.reply(note('Cette demande appartient à un autre membre.'));
            const result = deleteMemberData(i.guildId, userId);
            invalidateSettings(i.guildId);
            return i.update({ content: `✅ Données supprimées : ${result.deletedSanctions} sanction(s), ${result.deletedJoins} arrivée(s).${result.globalBlacklistRetained ? ' Une entrée de blacklist globale reste conservée.' : ''}`, components: [] });
        }
        if (i.isButton() && i.customId.startsWith('sar:about:changelog:')) {
            const cfg = getGuildConfig(i.guildId);
            const ownerId = i.customId.slice('sar:about:changelog:'.length);
            if (ownerId !== 'public' && ownerId !== i.user.id) return i.reply(note(tr(cfg, 'Ce menu est réservé à son auteur.', 'This menu belongs to its original user.')));
            return i.update(changelogPayload(cfg, i.user.id));
        }
        if (i.isButton() && i.customId.startsWith('sar:quarantine:')) {
            const [, , action, userId] = i.customId.split(':'); const cfg = getGuildConfig(i.guildId);
            if (!i.memberPermissions?.has(PermissionFlagsBits.ModerateMembers)) return i.reply(note(tr(cfg, 'Permission Modérer les membres requise.', 'Moderate Members permission required.')));
            const result = await resolveQuarantine(i.guild, userId, action, i.user.id);
            return i.update({ content: result.ok ? `✅ ${tr(cfg, 'Décision appliquée', 'Decision applied')} : **${action}**.` : `❌ ${tr(cfg, 'Action impossible', 'Action failed')} : ${result.note}.`, embeds: [], components: [] });
        }
        if (i.isButton() && i.customId.startsWith('sar:backup:restore:')) {
            const [, , , code, ownerId] = i.customId.split(':'); const cfg = getGuildConfig(i.guildId);
            if (i.user.id !== ownerId || !isGuildOwner(i.guild, i.user.id)) return i.reply(note(tr(cfg, 'Seul le propriétaire ayant demandé cette restauration peut confirmer.', 'Only the owner who requested this restore can confirm.')));
            const record = resolveBackup(code, i.user.id); if (!record) return i.reply(note(tr(cfg, 'Sauvegarde introuvable.', 'Backup not found.')));
            await i.deferUpdate();
            let result;
            try { result = await restoreServerBackup(i.guild, record, i.user.id); }
            catch (error) {
                await sendLog(client, i.guildId, buildAntiRaidEmbed('⚠️ Restauration échouée', String(error.message || error).slice(0, 1500)), 'critical');
                return i.editReply({ content: `❌ Restauration interrompue : ${String(error.message || error).slice(0, 300)}`, components: [], embeds: [] });
            }
            if (result.failures.length) await sendLog(client, i.guildId, buildAntiRaidEmbed('⚠️ Restauration partielle', result.failures.slice(0, 5).join('\n')), 'critical');
            return i.editReply({ content: `${result.failures.length ? '⚠️' : '✅'} ${tr(cfg, 'Restauration terminée', 'Restore complete')} · rôles +${result.rolesCreated}/${result.rolesUpdated} · salons +${result.channelsCreated}/${result.channelsUpdated} · emojis +${result.emojisCreated} (${result.emojisSkipped} ignorés) · échecs : ${result.failures.length}.`, components: [], embeds: [] });
        }
        const cfg = getGuildConfig(i.guildId);
        const access = componentProtectionAccess(i.customId, i.values);
        if (!accessAllowed(access, i.guild, i.user.id, cfg)) return i.reply(note(accessDenied(access, cfg)));
        const id = i.customId;
        if (i.isButton() && (id === 'sar:panic:on' || id === 'sar:panic:off')) {
            await i.deferUpdate();
            if (id.endsWith(':on')) { applyProtectionLevel(cfg, 'urgence'); save(i, cfg); const permissions = await syncExternalAppPermissions(i.guild); primeAntiNukeGuild(i.guild); const result = await lockChannels(i.guild, i.guild.channels.cache.values(), i.user.id); return i.editReply({ content: `🔒 ${result.locked} salon(s) verrouillé(s) · niveau Urgence actif.${permissions.failed.length ? ` ⚠️ Applications externes : ${permissions.failed.slice(0, 3).join(', ')}.` : ''}`, embeds: [], components: [] }); }
            const result = await unlockChannels(i.guild, null, i.user.id); cfg.joinLock = false; save(i, cfg); return i.editReply({ content: `🔓 ${result.restored}/${result.requested} salon(s) restauré(s) · Join-Lock désactivé.`, embeds: [], components: [] });
        }
        if (i.isButton() && id === 'sar:panel:level') {
            const menu = new StringSelectMenuBuilder().setCustomId('sar:level:set').setPlaceholder(tr(cfg, 'Choisir le niveau de protection', 'Choose protection level')).addOptions(
                { label: 'Faible', value: 'faible' }, { label: 'Normal', value: 'normal' }, { label: 'Élevé', value: 'eleve' }, { label: 'Urgence', value: 'urgence' },
                { label: 'Anti-Nuke ON', value: 'antinuke:on' }, { label: 'Anti-Nuke OFF', value: 'antinuke:off' },
            );
            return i.reply({ content: tr(cfg, 'Chaque niveau ajuste Anti-Spam, Anti-Join, Anti-Lien, les sanctions et Anti-Nuke.', 'Each level adjusts Anti-Spam, Anti-Join, Anti-Link, punishments and Anti-Nuke.'), components: [new ActionRowBuilder().addComponents(menu)], flags: MessageFlags.Ephemeral });
        }
        if (i.isStringSelectMenu() && id === 'sar:level:set') {
            if (i.values[0].startsWith('antinuke:')) { cfg.antiNuke.enabled = i.values[0].endsWith(':on'); save(i, cfg); if (cfg.antiNuke.enabled) primeAntiNukeGuild(i.guild); return i.update({ content: `✅ Anti-Nuke ${cfg.antiNuke.enabled ? 'ON' : 'OFF'}.`, components: [] }); }
            await i.deferUpdate(); applyProtectionLevel(cfg, i.values[0]); save(i, cfg); const permissions = await syncExternalAppPermissions(i.guild); if (cfg.antiNuke.enabled) primeAntiNukeGuild(i.guild); return i.editReply({ content: `✅ ${tr(cfg, 'Niveau appliqué', 'Level applied')} : **${cfg.protectionLevel}**.${permissions.failed.length ? ` ⚠️ ${permissions.failed.slice(0, 3).join(', ')}.` : ''}`, components: [] });
        }
        if (i.isButton() && id === 'sar:welcome:setup') return i.reply({ ...setupPayload(cfg), flags: MessageFlags.Ephemeral });
        if (i.isButton() && id === 'sar:welcome:logs') {
            const select = new ChannelSelectMenuBuilder().setCustomId('sar:welcome:logs:set').setPlaceholder(tr(cfg, 'Choisir le nouveau salon de logs', 'Choose the new log channel')).addChannelTypes(ChannelType.GuildText);
            return i.reply({ content: tr(cfg, 'Choisissez le salon qui recevra les alertes de sécurité.', 'Choose the channel that will receive security alerts.'), components: [new ActionRowBuilder().addComponents(select)], flags: MessageFlags.Ephemeral });
        }
        if (i.isChannelSelectMenu() && id === 'sar:welcome:logs:set') {
            cfg.logChannel = i.values[0]; save(i, cfg);
            return i.update({ content: tr(cfg, `✅ Le salon <#${cfg.logChannel}> recevra maintenant les logs.`, `✅ <#${cfg.logChannel}> will now receive security logs.`), components: [] });
        }
        if (i.isStringSelectMenu() && id === 'sar:welcome:language:set') {
            if (!['fr', 'en'].includes(i.values[0])) return i.reply(note(tr(cfg, 'Langue inconnue.', 'Unknown language.')));
            cfg.language = i.values[0]; save(i, cfg);
            await i.update(welcomePayload(cfg));
            await syncGuildCommands(i.guild, definitionsForLanguage(cfg.language));
            await syncHoneypotLanguage(i.guild, cfg);
            const refreshed = await refreshLocalizedMessages(i.guild);
            return i.followUp(note(cfg.language === 'en'
                ? `✅ 4LC-PROTECT is now fully displayed in English on this server.${refreshed ? ` (${refreshed} panel(s) updated.)` : ''}`
                : `✅ 4LC-PROTECT est maintenant entièrement affiché en français sur ce serveur.${refreshed ? ` (${refreshed} panneau(x) actualisé(s).)` : ''}`));
        }
        if (i.isStringSelectMenu() && id === 'sar:setup:modules') {
            const now = Date.now();
            for (const [pendingKey, state] of pending) if (state.expiresAt <= now) pending.delete(pendingKey);
            pending.set(key(i), { values: i.values, expiresAt: now + 15 * 60_000 });
            const preview = structuredClone(cfg);
            for (const m of MODULES) preview.enabled[m] = i.values.includes(m);
            return i.update(setupPayload(preview));
        }
        if (i.isButton() && id === 'sar:setup:cancel') { pending.delete(key(i)); return i.update({ content: tr(cfg, 'Installation annulée.', 'Setup cancelled.'), embeds: [], components: [] }); }
        if (i.isButton() && id === 'sar:setup:confirm') {
            const state = pending.get(key(i));
            const selected = state?.expiresAt > Date.now() ? state.values : null;
            if (!selected) { pending.delete(key(i)); return i.reply(note(tr(cfg, 'Choisissez d’abord les modules dans le menu, même si vous souhaitez les désactiver tous.', 'Select the modules in the menu first, even if you want to disable them all.'))); }
            await i.deferUpdate();
            for (const m of MODULES) cfg.enabled[m] = selected.includes(m);
            cfg.installed = true; save(i, cfg); pending.delete(key(i)); const permissions = await syncExternalAppPermissions(i.guild);
            await i.editReply(summaryPayload(cfg));
            if (permissions.failed.length) await i.followUp(note(`⚠️ Applications externes : ${permissions.failed.slice(0, 3).join(', ')}.`));
            return;
        }
        if (i.isButton() && id === 'sar:send') {
            const sent = await i.channel.send(panelPayload(cfg)); rememberLocalizedMessage(i.guildId, sent, 'config');
            return i.reply(note(tr(cfg, '✅ Panneau envoyé dans ce salon.', '✅ Panel sent in this channel.')));
        }
        if (i.isButton() && id === 'sar:panel') return i.reply({ ...panelPayload(cfg), flags: MessageFlags.Ephemeral });
        if (i.isButton() && id === 'sar:panel:send') {
            const sent = await i.channel.send(panelPayload(cfg)); rememberLocalizedMessage(i.guildId, sent, 'config');
            return i.reply(note(tr(cfg, '✅ Nouveau panneau envoyé dans ce salon.', '✅ New panel sent in this channel.')));
        }
        if (i.isButton() && id === 'sar:panel:refresh') return i.update(panelPayload(cfg));
        if (i.isButton() && id === 'sar:panel:lockicon') {
            cfg.lockIcon = !cfg.lockIcon; save(i, cfg);
            return i.update(panelPayload(cfg));
        }
        if (i.isButton() && id === 'sar:panel:join') {
            return i.reply({ content: cfg.joinLock ? tr(cfg, 'Désactiver le blocage des arrivées ?', 'Disable join blocking?') : tr(cfg, '⚠️ Activer le Join-Lock ? Toute nouvelle personne pourra être expulsée.', '⚠️ Enable Join-Lock? Every new member may be kicked.'), components: [new ActionRowBuilder().addComponents(new ButtonBuilder().setCustomId(`sar:panel:join:confirm:${cfg.joinLock ? 'off' : 'on'}`).setLabel(tr(cfg, 'Confirmer', 'Confirm')).setStyle(ButtonStyle.Danger))], flags: MessageFlags.Ephemeral });
        }
        if (i.isButton() && id.startsWith('sar:panel:join:confirm:')) {
            cfg.joinLock = id.endsWith(':on'); save(i, cfg);
            return i.update({ content: tr(cfg, `Join-Lock ${cfg.joinLock ? 'activé' : 'désactivé'}. Actualisez le panneau pour voir son état.`, `Join-Lock ${cfg.joinLock ? 'enabled' : 'disabled'}. Refresh the panel to see its status.`), components: [] });
        }
        if (i.isButton() && id === 'sar:panel:verification') {
            return i.reply(captchaSettingsPayload(cfg));
        }
        if (i.isButton() && id === 'sar:panel:honeypot') return i.reply(honeypotSettingsPayload(cfg));
        if (i.isButton() && id === 'sar:panel:reports') return i.reply(note(tr(cfg, 'Salon des signalements : /logs signalements:#salon. Un membre peut signaler avec /report.', 'Report channel: /logs signalements:#channel. Members can report with /report.')));
        if (i.isButton() && id === 'sar:panel:language') {
            const select = new StringSelectMenuBuilder().setCustomId('sar:language:set').setPlaceholder('🌐 Langue / Language').addOptions({ label: 'Français', value: 'fr', emoji: '🇫🇷' }, { label: 'English', value: 'en', emoji: '🇬🇧' });
            return i.reply({ content: tr(cfg, 'Choisissez la langue de tout le bot pour ce serveur :', 'Choose the language for the entire bot on this server:'), components: [new ActionRowBuilder().addComponents(select)], flags: MessageFlags.Ephemeral });
        }
        if (i.isStringSelectMenu() && id === 'sar:language:set') {
            if (!['fr', 'en'].includes(i.values[0])) return i.reply(note(tr(cfg, 'Langue inconnue.', 'Unknown language.')));
            cfg.language = i.values[0]; save(i, cfg);
            await i.update({ content: cfg.language === 'en' ? '✅ 4LC-PROTECT is now fully displayed in English on this server.' : '✅ 4LC-PROTECT est maintenant entièrement affiché en français sur ce serveur.', components: [] });
            await syncGuildCommands(i.guild, definitionsForLanguage(cfg.language));
            await syncHoneypotLanguage(i.guild, cfg);
            const refreshed = await refreshLocalizedMessages(i.guild);
            return i.followUp({ content: cfg.language === 'en' ? `🔄 ${refreshed} existing help/settings panel(s) refreshed.` : `🔄 ${refreshed} panneau(x) d’aide/configuration existant(s) actualisé(s).`, flags: MessageFlags.Ephemeral });
        }
        if (i.isButton() && id === 'sar:panel:prefix') return i.showModal(modal('sar:modal:prefix', tr(cfg, 'Préfixe', 'Prefix'), [['value', tr(cfg, '1 à 3 caractères sans espace', '1 to 3 characters without spaces'), cfg.prefix || config.prefix]]));
        if (i.isButton() && id === 'sar:panel:recreatelogs') {
            await i.deferReply({ flags: MessageFlags.Ephemeral });
            const channel = await ensureCentralLogChannel(i.guild, { recreate: true });
            if (!channel) return i.editReply('❌ Impossible de recréer le salon de logs. Vérifie les permissions du bot.');
            return i.editReply(`✅ Salon de logs recréé : ${channel}. Tous les logs 4LC-PROTECT sont redirigés ici.`);
        }
        if (i.isButton() && id === 'sar:panel:warnings') return i.showModal(modal('sar:modal:warnings', 'Auto-sanctions progressives', [['timeout', 'Warns avant timeout', cfg.warningSystem.mutePoints || 3], ['kick', 'Warns avant kick', cfg.warningSystem.kickPoints || 5], ['ban', 'Warns avant ban', cfg.warningSystem.banPoints || 7]]));
        if (i.isModalSubmit() && id === 'sar:modal:prefix') {
            const value = i.fields.getTextInputValue('value');
            if (!/^[^\s@/`]{1,3}$/.test(value)) return i.reply(note(tr(cfg, 'Préfixe invalide : 1 à 3 caractères sans espace, @, / ni accent grave.', 'Invalid prefix: 1 to 3 characters without spaces, @, / or backticks.')));
            cfg.prefix = value; save(i, cfg);
            return i.reply(note(tr(cfg, `✅ Nouveau préfixe : \`${value}\`. Actualisez le panneau.`, `✅ New prefix: \`${value}\`. Refresh the panel.`)));
        }
        if (i.isButton() && id === 'sar:panel:tag') {
            const embed = new EmbedBuilder().setColor(BLUE).setTitle(tr(cfg, 'Configuration du Rôle de Tag', 'Server Tag Role Settings'))
                .setDescription(tr(cfg, 'Attribue un rôle aux membres qui affichent **le tag de ce serveur** dans leur profil Discord. Quand ils retirent ce tag, le bot retire le rôle lors de la prochaine synchronisation. Les mises à jour de profil ne sont pas toujours signalées instantanément : utilisez « Actualiser mon rôle ».', 'Assigns a role to members displaying **this server tag** on their Discord profile. The role is removed on the next sync if the tag disappears. Profile updates are not always instant, so use “Refresh my role”.'))
                .addFields({ name: tr(cfg, 'Rôle de Tag', 'Tag role'), value: cfg.tagRoleId ? `<@&${cfg.tagRoleId}>` : tr(cfg, 'Aucun', 'None') });
            const select = new RoleSelectMenuBuilder().setCustomId('sar:tag:role').setPlaceholder(tr(cfg, 'Choisir un rôle existant', 'Choose an existing role'));
            return i.reply({ embeds: [embed], components: [new ActionRowBuilder().addComponents(select), new ActionRowBuilder().addComponents(new ButtonBuilder().setCustomId('sar:tag:create').setLabel(tr(cfg, 'En créer un pour moi', 'Create one for me')).setStyle(ButtonStyle.Primary), new ButtonBuilder().setCustomId('sar:tag:reset').setLabel(tr(cfg, 'Réinitialiser', 'Reset')).setStyle(ButtonStyle.Danger), new ButtonBuilder().setCustomId('sar:tag:sync').setLabel(tr(cfg, 'Actualiser mon rôle', 'Refresh my role')).setStyle(ButtonStyle.Primary))], flags: MessageFlags.Ephemeral });
        }
        if (i.isRoleSelectMenu() && id === 'sar:tag:role') {
            const role = i.guild.roles.cache.get(i.values[0]);
            const bot = await i.guild.members.fetchMe();
            if (!role || role.id === i.guildId || role.managed || role.position >= bot.roles.highest.position || role.permissions.has(PermissionFlagsBits.Administrator)) return i.reply(note(tr(cfg, 'Choisissez un rôle ordinaire sans Administrateur, situé sous celui du bot.', 'Choose a regular non-Administrator role below the bot role.')));
            cfg.tagRoleId = role.id; save(i, cfg);
            return i.update({ content: tr(cfg, `✅ Rôle de tag défini sur ${role}.`, `✅ Tag role set to ${role}.`), embeds: [], components: [] });
        }
        if (i.isButton() && id === 'sar:tag:create') {
            const bot = await i.guild.members.fetchMe();
            if (!bot.permissions.has(PermissionFlagsBits.ManageRoles)) return i.reply(note(tr(cfg, 'Le bot doit avoir la permission Gérer les rôles.', 'The bot needs the Manage Roles permission.')));
            const role = await i.guild.roles.create({ name: 'Tag', color: BLUE, reason: `Rôle de tag créé par ${i.user.id}` });
            cfg.tagRoleId = role.id; save(i, cfg);
            return i.update({ content: tr(cfg, `✅ Rôle ${role} créé. Placez-le sous le rôle du bot si nécessaire.`, `✅ Role ${role} created. Place it below the bot role if needed.`), embeds: [], components: [] });
        }
        if (i.isButton() && id === 'sar:tag:reset') {
            cfg.tagRoleId = null; save(i, cfg);
            return i.update({ content: tr(cfg, 'Rôle de tag désactivé. Les rôles déjà attribués ne sont pas retirés automatiquement.', 'Tag role disabled. Previously assigned roles are not removed automatically.'), embeds: [], components: [] });
        }
        if (i.isButton() && id === 'sar:tag:sync') {
            const member = await i.guild.members.fetch(i.user.id);
            const result = await syncTagRole(member);
            return i.reply(note(tr(cfg, `Synchronisation : ${result}.`, `Sync result: ${result}.`)));
        }
        if (i.isStringSelectMenu() && id === 'sar:panel:nav') {
            return i.reply({ ...(i.values[0] === 'whitelist' ? whitelistPayload(cfg) : categoryPayload(cfg, i.values[0])), flags: MessageFlags.Ephemeral });
        }
        if (i.isButton() && id === 'sar:panel:back') {
            return i.update(panelPayload(cfg));
        }
        if (i.isButton() && id === 'sar:panel:badwords') return i.reply({ ...badwordsPayload(cfg), flags: MessageFlags.Ephemeral });
        if (i.isButton() && id === 'sar:badwords:edit') {
            const field = new TextInputBuilder().setCustomId('words').setLabel(tr(cfg, 'Mots séparés par des virgules ou lignes', 'Words separated by commas or lines')).setStyle(TextInputStyle.Paragraph).setRequired(false).setMaxLength(4000).setValue((cfg.badwords.words || []).join(', '));
            return i.showModal(new ModalBuilder().setCustomId('sar:badwords:save').setTitle(tr(cfg, 'Mots interdits', 'Blocked words')).addComponents(new ActionRowBuilder().addComponents(field)));
        }
        if (i.isButton() && id === 'sar:badwords:sanction') {
            return i.showModal(modal('sar:badwords:sanction-save', tr(cfg, 'Sanction mots interdits', 'Blocked words punishment'), [['mode', tr(cfg, 'none ou timeout', 'none or timeout'), cfg.badwords.sanction], ['seconds', tr(cfg, 'Durée timeout en secondes (1 à 2419200)', 'Timeout seconds (1 to 2419200)'), cfg.badwords.timeoutSeconds || 60]]));
        }
        if (i.isModalSubmit() && id === 'sar:badwords:sanction-save') {
            const mode = i.fields.getTextInputValue('mode').trim().toLowerCase(); const seconds = Number(i.fields.getTextInputValue('seconds'));
            if (!['none', 'timeout'].includes(mode) || !Number.isInteger(seconds) || seconds < 1 || seconds > 2419200) return i.reply(note(tr(cfg, 'Entrez none ou timeout et une durée de 1 à 2419200 secondes.', 'Enter none or timeout and 1 to 2419200 seconds.')));
            cfg.badwords.sanction = mode; cfg.badwords.timeoutSeconds = seconds; save(i, cfg); await i.deferReply({ flags: MessageFlags.Ephemeral });
            try { await syncBadwordsRule(i.guild, cfg); return i.editReply(badwordsPayload(cfg)); }
            catch (error) { return i.editReply({ content: `⚠️ ${error.message}`, ...badwordsPayload(cfg) }); }
        }
        if (i.isModalSubmit() && id === 'sar:badwords:save') {
            try { cfg.badwords.words = parseBadwords(i.fields.getTextInputValue('words')); }
            catch (error) { return i.reply(note(`❌ ${error.message}`)); }
            save(i, cfg); await i.deferReply({ flags: MessageFlags.Ephemeral });
            try { await syncBadwordsRule(i.guild, cfg); await i.editReply(badwordsPayload(cfg)); }
            catch (error) { await i.editReply({ content: `⚠️ ${error.message}`, ...badwordsPayload(cfg) }); }
            return;
        }
        if (i.isButton() && id === 'sar:badwords:toggle') {
            if (!cfg.badwords.enabled && !cfg.badwords.words.length) return i.reply(note(tr(cfg, 'Ajoutez au moins un mot avant d’activer.', 'Add at least one word before enabling.')));
            cfg.badwords.enabled = !cfg.badwords.enabled; save(i, cfg); await i.deferUpdate();
            try { await syncBadwordsRule(i.guild, cfg); return i.editReply(badwordsPayload(cfg)); }
            catch (error) { return i.editReply({ content: `⚠️ ${error.message}`, ...badwordsPayload(cfg) }); }
        }
        if (i.isChannelSelectMenu() && id === 'sar:badwords:channel') {
            const channelId = i.values[0]; const channels = cfg.badwords.exemptChannels;
            if (channels.includes(channelId)) cfg.badwords.exemptChannels = channels.filter((v) => v !== channelId);
            else if (channels.length < 50) channels.push(channelId);
            else return i.reply(note(tr(cfg, 'Maximum 50 salons exemptés.', 'Maximum 50 exempt channels.')));
            save(i, cfg); await i.deferUpdate();
            try { await syncBadwordsRule(i.guild, cfg); return i.editReply(badwordsPayload(cfg)); }
            catch (error) { return i.editReply({ content: `⚠️ ${error.message}`, ...badwordsPayload(cfg) }); }
        }
        if (i.isStringSelectMenu() && id === 'sar:panel:toggle') {
            const m = i.values[0];
            if (MODULES.includes(m)) cfg.enabled[m] = !cfg.enabled[m];
            else if (m === 'phishing') cfg.phishing.enabled = cfg.phishing.enabled === false;
            else if (m === 'ghostping') cfg.ghostPing.enabled = cfg.ghostPing.enabled === false;
            else if (m === 'warnings') cfg.warningSystem.enabled = cfg.warningSystem.enabled === false;
            else return i.reply(note(tr(cfg, 'Module inconnu.', 'Unknown module.')));
            save(i, cfg);
            if (m === 'antibot' || m === 'antiuserapps') {
                await i.deferUpdate();
                const result = await syncExternalAppPermissions(i.guild);
                await i.editReply(panelPayload(getGuildConfig(i.guildId)));
                if (!result.complete) await i.followUp(note(tr(cfg, `⚠️ Blocage préventif partiel : ${result.failed.slice(0, 3).join(', ')}.`, `⚠️ Partial preemptive block: ${result.failed.slice(0, 3).join(', ')}.`)));
                return;
            }
            return i.update(panelPayload(cfg));
        }
        if (i.isChannelSelectMenu() && id === 'sar:panel:logs') {
            cfg.logChannel = i.values[0]; save(i, cfg);
            return i.update(panelPayload(cfg));
        }
        if (i.isButton() && id === 'sar:panel:spam') return i.showModal(modal('sar:modal:spam', tr(cfg, 'Réglages anti-spam', 'Anti-spam settings'), [['count', tr(cfg, 'Nombre de messages (2 à 100)', 'Message count (2 to 100)'), cfg.antispam.count], ['seconds', tr(cfg, 'Fenêtre en secondes (2 à 3600)', 'Window in seconds (2 to 3600)'), cfg.antispam.windowMs / 1000]]));
        if (i.isButton() && id === 'sar:panel:age') return i.showModal(modal('sar:modal:age', tr(cfg, 'Âge minimum du compte', 'Minimum account age'), [['minutes', tr(cfg, 'Âge en minutes (0 à 525600)', 'Age in minutes (0 to 525600)'), Math.round(cfg.antitoken.minAccountAgeMs / 60000)]]));
        if (i.isButton() && id === 'sar:panel:raid') return i.showModal(modal('sar:modal:raid', 'Auto RaidMode', [['enabled', tr(cfg, 'Activer ? oui ou non', 'Enable? yes or no'), cfg.autoRaid.enabled ? tr(cfg, 'oui', 'yes') : tr(cfg, 'non', 'no')], ['count', tr(cfg, 'Nombre d’arrivées (2 à 100)', 'Join count (2 to 100)'), cfg.autoRaid.count], ['seconds', tr(cfg, 'Fenêtre en secondes (2 à 3600)', 'Window in seconds (2 to 3600)'), cfg.autoRaid.windowMs / 1000], ['duration', tr(cfg, 'Protection en minutes (1 à 1440)', 'Protection in minutes (1 to 1440)'), cfg.autoRaid.durationMs / 60000]]));
        if (i.isButton() && id === 'sar:panel:links') {
            return i.reply({ ...linkSettingsPayload(cfg), flags: MessageFlags.Ephemeral });
        }
        if (i.isStringSelectMenu() && id === 'sar:links') { cfg.antilink.type = i.values[0]; save(i, cfg); return i.update(linkSettingsPayload(cfg)); }
        if (i.isButton() && id === 'sar:links:toggle') { cfg.enabled.antilink = !cfg.enabled.antilink; save(i, cfg); return i.update(linkSettingsPayload(cfg)); }
        if (i.isButton() && id === 'sar:panel:punish') {
            const menu = new StringSelectMenuBuilder().setCustomId('sar:punish:module').setPlaceholder(tr(cfg, 'Choisir un module', 'Choose a module')).addOptions(MODULES.map((m) => ({ label: moduleLabel(m, cfg), value: m })));
            return i.reply({ content: tr(cfg, 'Choisissez le module à configurer :', 'Choose the module to configure:'), components: [new ActionRowBuilder().addComponents(menu)], flags: MessageFlags.Ephemeral });
        }
        if (i.isStringSelectMenu() && id === 'sar:punish:module') {
            const m = i.values[0]; if (!MODULES.includes(m)) return i.reply(note(tr(cfg, 'Module inconnu.', 'Unknown module.')));
            const menu = new StringSelectMenuBuilder().setCustomId(`sar:punish:set:${m}`).setPlaceholder(tr(cfg, 'Choisir la sanction', 'Choose the punishment')).addOptions(['timeout', 'kick', 'ban', 'derank', 'jail', 'none'].map((v) => ({ label: punishmentLabel(v, cfg), value: v })));
            return i.update({ content: tr(cfg, `Sanction pour ${moduleLabel(m, cfg)} :`, `Punishment for ${moduleLabel(m, cfg)}:`), components: [new ActionRowBuilder().addComponents(menu)] });
        }
        if (i.isStringSelectMenu() && id.startsWith('sar:punish:set:')) {
            const m = id.split(':')[3]; if (!MODULES.includes(m)) return i.reply(note(tr(cfg, 'Module inconnu.', 'Unknown module.')));
            const punishment = i.values[0]; cfg.punishments[m] = punishment;
            if (punishment !== 'timeout') { save(i, cfg); return i.update({ content: `✅ ${moduleLabel(m, cfg)} : ${punishmentLabel(punishment, cfg)}.`, components: [] }); }
            save(i, cfg);
            const durations = new StringSelectMenuBuilder().setCustomId(`sar:punish:duration:${m}`).setPlaceholder(tr(cfg, 'Choisir la durée du TimeMute', 'Choose the TimeMute duration')).addOptions(
                { label: tr(cfg, '1 minute', '1 minute'), value: '1' },
                { label: tr(cfg, '5 minutes', '5 minutes'), value: '5' },
                { label: tr(cfg, '10 minutes', '10 minutes'), value: '10' },
                { label: tr(cfg, '1 heure', '1 hour'), value: '60' },
                { label: tr(cfg, '1 jour', '1 day'), value: '1440' },
                { label: tr(cfg, '7 jours', '7 days'), value: '10080' },
            );
            const custom = new ButtonBuilder().setCustomId(`sar:punish:duration-custom:${m}`).setLabel(tr(cfg, 'Durée personnalisée', 'Custom duration')).setEmoji('⏱️').setStyle(ButtonStyle.Secondary);
            return i.update({ content: tr(cfg, `Sanction **TimeMute** choisie pour ${moduleLabel(m, cfg)}. Sélectionnez maintenant sa durée :`, `**TimeMute** selected for ${moduleLabel(m, cfg)}. Now choose its duration:`), components: [new ActionRowBuilder().addComponents(durations), new ActionRowBuilder().addComponents(custom)] });
        }
        if (i.isStringSelectMenu() && id.startsWith('sar:punish:duration:')) {
            const m = id.split(':')[3]; if (!MODULES.includes(m)) return i.reply(note(tr(cfg, 'Module inconnu.', 'Unknown module.')));
            const minutes = Number(i.values[0]); if (!Number.isInteger(minutes) || minutes < 1 || minutes > 40320) return i.reply(note(tr(cfg, 'Durée invalide.', 'Invalid duration.')));
            cfg.punishments[m] = 'timeout'; cfg.punishmentDurations[m] = minutes * 60_000; save(i, cfg);
            return i.update({ content: `✅ ${moduleLabel(m, cfg)} : **${punishmentLabel('timeout', cfg)} · ${durationLabel(cfg.punishmentDurations[m], cfg)}**.`, components: [] });
        }
        if (i.isButton() && id.startsWith('sar:punish:duration-custom:')) {
            const m = id.split(':')[3]; if (!MODULES.includes(m)) return i.reply(note(tr(cfg, 'Module inconnu.', 'Unknown module.')));
            return i.showModal(modal(`sar:punish:duration-modal:${m}`, tr(cfg, 'Durée du TimeMute', 'TimeMute duration'), [['minutes', tr(cfg, 'Durée en minutes (1 à 40320)', 'Duration in minutes (1 to 40320)'), Math.round((cfg.punishmentDurations[m] || 300_000) / 60_000)]]));
        }
        if (i.isModalSubmit() && id.startsWith('sar:punish:duration-modal:')) {
            const m = id.split(':')[3]; if (!MODULES.includes(m)) return i.reply(note(tr(cfg, 'Module inconnu.', 'Unknown module.')));
            const minutes = Number(i.fields.getTextInputValue('minutes'));
            if (!Number.isInteger(minutes) || minutes < 1 || minutes > 40320) return i.reply(note(tr(cfg, 'Entrez un nombre entier entre 1 et 40320 minutes.', 'Enter a whole number between 1 and 40320 minutes.')));
            cfg.punishments[m] = 'timeout'; cfg.punishmentDurations[m] = minutes * 60_000; save(i, cfg);
            return i.reply(note(`✅ ${moduleLabel(m, cfg)} : **${punishmentLabel('timeout', cfg)} · ${durationLabel(cfg.punishmentDurations[m], cfg)}**.`));
        }
        if (i.isButton() && id === 'sar:panel:whitelist') return i.reply({ embeds: [new EmbedBuilder().setColor(BLUE).setTitle(tr(cfg, 'Exemptions', 'Exemptions')).setDescription(cfg.whitelistedUsers.length ? cfg.whitelistedUsers.map((u) => `<@${u}>`).join(', ') : tr(cfg, 'Aucun membre exempté.', 'No exempted members.')).setFooter({ text: `${tr(cfg, 'Ajout / retrait', 'Add / remove')}: ${cfg.prefix || config.prefix}protect whitelist add|remove @member` })], flags: MessageFlags.Ephemeral });
        if (i.isModalSubmit() && id === 'sar:modal:warnings') {
            const t=Number(i.fields.getTextInputValue('timeout')); const k=Number(i.fields.getTextInputValue('kick')); const b=Number(i.fields.getTextInputValue('ban'));
            if (![t,k,b].every(Number.isInteger) || t < 1 || k <= t || b <= k || b > 100) return i.reply(note('Utilise 3 seuils croissants, par exemple 3 / 5 / 7.'));
            cfg.warningSystem = { ...cfg.warningSystem, enabled: true, mutePoints: t, kickPoints: k, tempBanPoints: 999, banPoints: b }; save(i,cfg);
            return i.reply(note(`✅ Auto-sanctions : ${t} warns = timeout · ${k} = kick · ${b} = ban.`));
        }
        if (i.isModalSubmit() && id === 'sar:modal:spam') {
            const count = Number(i.fields.getTextInputValue('count')); const seconds = Number(i.fields.getTextInputValue('seconds'));
            if (!Number.isInteger(count) || count < 2 || count > 100 || !Number.isInteger(seconds) || seconds < 2 || seconds > 3600) return i.reply(note(tr(cfg, 'Valeurs invalides : 2–100 messages et 2–3600 secondes.', 'Invalid values: 2–100 messages and 2–3600 seconds.')));
            cfg.antispam.count = count; cfg.antispam.windowMs = seconds * 1000; save(i, cfg); return i.reply(note(tr(cfg, `✅ Anti-spam : ${count} messages / ${seconds} secondes.`, `✅ Anti-spam: ${count} messages / ${seconds} seconds.`)));
        }
        if (i.isModalSubmit() && id === 'sar:modal:age') {
            const minutes = Number(i.fields.getTextInputValue('minutes'));
            if (!Number.isInteger(minutes) || minutes < 0 || minutes > 525600) return i.reply(note(tr(cfg, 'Entrez un nombre entier entre 0 et 525600.', 'Enter a whole number between 0 and 525600.')));
            cfg.antitoken.minAccountAgeMs = minutes * 60000; save(i, cfg); return i.reply(note(tr(cfg, `✅ Âge minimum : ${minutes} minutes.`, `✅ Minimum age: ${minutes} minutes.`)));
        }
        if (i.isModalSubmit() && id === 'sar:modal:raid') {
            const enabled = i.fields.getTextInputValue('enabled').trim().toLowerCase();
            const count = Number(i.fields.getTextInputValue('count'));
            const seconds = Number(i.fields.getTextInputValue('seconds'));
            const duration = Number(i.fields.getTextInputValue('duration'));
            const enabledValues = cfg.language === 'en' ? ['yes', 'no'] : ['oui', 'non'];
            if (!enabledValues.includes(enabled) || !Number.isInteger(count) || count < 2 || count > 100 || !Number.isInteger(seconds) || seconds < 2 || seconds > 3600 || !Number.isInteger(duration) || duration < 1 || duration > 1440) return i.reply(note(tr(cfg, 'Valeurs invalides : oui/non, 2–100 arrivées, 2–3600 secondes et 1–1440 minutes.', 'Invalid values: yes/no, 2–100 joins, 2–3600 seconds and 1–1440 minutes.')));
            cfg.autoRaid = { enabled: enabledValues.indexOf(enabled) === 0, count, windowMs: seconds * 1000, durationMs: duration * 60000 }; save(i, cfg);
            return i.reply(note(tr(cfg, `✅ Auto RaidMode ${cfg.autoRaid.enabled ? 'activé' : 'désactivé'} : ${count} arrivées / ${seconds}s.`, `✅ Auto RaidMode ${cfg.autoRaid.enabled ? 'enabled' : 'disabled'}: ${count} joins / ${seconds}s.`)));
        }
        } catch (error) {
            const diagnosticId = captureError(error, 'interaction', i.guildId || null);
            console.warn(`[${diagnosticId}] Interaction 4LC-PROTECT échouée.`);
            const fallbackCfg = i.guildId ? getGuildConfig(i.guildId) : {};
            const response = note(tr(fallbackCfg, `Action impossible : vérifiez les permissions du bot et la hiérarchie des rôles. Diagnostic : ${diagnosticId}`, `Action failed: check the bot permissions and role hierarchy. Diagnostic: ${diagnosticId}`));
            if (i.deferred || i.replied) await i.followUp(response).catch(() => {});
            else await i.reply(response).catch(() => {});
        }
    },
};
