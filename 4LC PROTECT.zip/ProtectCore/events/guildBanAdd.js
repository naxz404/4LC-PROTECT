import { AuditLogEvent } from 'discord.js';
import { getSettings, isModuleBypassed, findRecentAuditEntry, queueSanction } from '../antiraid/runtime.js';
import { punishMember } from '../antiraid/punish.js';
import { buildAntiRaidEmbed, sendLog } from '../antiraid/logs.js';
import { punishmentDuration, punishmentPastLabel } from '../antiraid/schema.js';
import { tr } from '../i18n.js';

export default {
    name: 'guildBanAdd',
    async execute(client, ban) {
        const guild = ban.guild;
        const settings = getSettings(guild.id);
        if (settings.antiNuke.enabled || !settings.enabled.antiban) return;

        const entry = await findRecentAuditEntry(guild, AuditLogEvent.MemberBanAdd, ban.user.id);
        const executorId = entry?.executor?.id;
        if (!executorId || isModuleBypassed(executorId, guild.id, 'antiban', client.user.id, guild.ownerId)) return;

        // Annuler le bannissement avant toute sanction ou journalisation.
        const restored = await guild.members.unban(ban.user.id, 'Anti-Ban : annulation prioritaire 4LC-PROTECT').then(() => true).catch(() => false);

        queueSanction(guild.id, `antiban:${executorId}:${ban.user.id}`, async () => {
            const member = guild.members.cache?.get(executorId) || await guild.members.fetch(executorId).catch(() => null);
            let label = tr(settings, 'membre introuvable', 'member not found');
            if (member) {
                const result = await punishMember(member, settings.punishments.antiban, punishmentDuration(settings, 'antiban', 10 * 60_000), 'Anti-Ban : bannissement non autorisé');
                label = result.applied ? punishmentPastLabel(result.effectivePunishment, settings) : tr(settings, `non sanctionné (${result.note})`, `not punished (${result.note})`);
            }
            await sendLog(
                client,
                guild.id,
                buildAntiRaidEmbed(
                    tr(settings, 'Anti-Ban déclenché', 'Anti-Ban triggered'),
                    tr(settings, `<@${executorId}> a banni ${ban.user.tag} (\`${ban.user.id}\`) sans autorisation.\nBannissement annulé : **${restored ? 'oui' : 'échec'}**.\nRésultat sur l'auteur : **${label}**.`, `<@${executorId}> banned ${ban.user.tag} (\`${ban.user.id}\`) without authorization.\nBan reverted: **${restored ? 'yes' : 'failed'}**.\nExecutor result: **${label}**.`),
                ),
            );
        });
    },
};
