import { allowedGuilds } from '../../ServerScope.js';
import { processExpiredBans } from '../tempBans.js';
import { ensureUnverifiedRole, removeLegacyVerificationPanels } from '../onboarding.js';
import { getGuildConfig } from '../storage.js';
import { primeAntiNukeGuild } from '../antinuke.js';
import { startPhishingDomainRefresh } from '../phishingDomains.js';
import { primeGuildInvites } from '../inviteTracker.js';
import { createPeriodicServerBackup } from '../serverBackup.js';
import { finishExpiredEmergencies } from '../emergencyMode.js';
import { loadApplicationEmojis } from '../appEmojis.js';
import { syncExternalAppPermissions } from '../externalAppPermissions.js';
import { syncBadwordsRule } from '../badwords.js';
import { restoreRaidVerification } from '../raidResponse.js';

export default {
    name: 'clientReady',
    once: true,
    async execute(client) {
        console.log(`✅ 4LC-PROTECT connecté en tant que ${client.user.tag} (${allowedGuilds(client).length} serveur(s))`);
        startPhishingDomainRefresh();
        await loadApplicationEmojis(client);
        // La présence reste gérée par 4LC-PROTECT.
        await processExpiredBans(client);
        setInterval(() => processExpiredBans(client).catch(console.error), 60_000).unref();
        for (const guild of allowedGuilds(client)) {
            void restoreRaidVerification(guild).catch(console.error);
            const protection = getGuildConfig(guild.id);
            if (protection.badwords?.enabled || protection.badwords?.ruleId) {
                void syncBadwordsRule(guild, protection).catch((error) => console.warn(`[Badwords] ${guild.id}: ${error.message}`));
            }
            if (protection.enabled.antibot || protection.enabled.antiuserapps || protection.externalAppPermissionSnapshot?.length) {
                void syncExternalAppPermissions(guild).then((result) => {
                    if (result.failed.length) console.warn(`[ExternalApps] ${guild.id}: blocage partiel (${result.failed.join(', ')})`);
                }).catch((error) => console.error(`[ExternalApps] ${guild.id}:`, error));
            }
            void primeGuildInvites(guild);
            await ensureUnverifiedRole(guild).catch(() => {});
            await removeLegacyVerificationPanels(guild).catch(() => {});
            if (getGuildConfig(guild.id).antiNuke?.enabled) primeAntiNukeGuild(guild);
            try { createPeriodicServerBackup(guild); } catch (error) { console.error(`[Backup] ${guild.id}:`, error); }
        }
        setInterval(() => {
            for (const guild of allowedGuilds(client)) {
                try { createPeriodicServerBackup(guild); } catch (error) { console.error(`[Backup] ${guild.id}:`, error); }
            }
        }, 60 * 60_000).unref();
        await finishExpiredEmergencies(client);
        setInterval(() => finishExpiredEmergencies(client).catch(console.error), 30_000).unref();
    },
};
