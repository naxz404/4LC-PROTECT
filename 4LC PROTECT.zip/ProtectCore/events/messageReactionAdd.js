import { getSettings, isModuleBypassed, queueSanction } from '../antiraid/runtime.js';
import { punishMember } from '../antiraid/punish.js';
import { buildAntiRaidEmbed, sendLog } from '../antiraid/logs.js';
import { punishmentDuration } from '../antiraid/schema.js';
import { tr } from '../i18n.js';

const windows = new Map();
const WINDOW_MS = 8_000;
const LIMIT = 12;

export default {
    name: 'messageReactionAdd',
    async execute(client, reaction, user) {
        if (!user || user.bot) return;
        if (reaction.partial) reaction = await reaction.fetch().catch(() => null);
        const guild = reaction?.message?.guild;
        if (!guild) return;
        const settings = getSettings(guild.id);
        if (!settings.enabled.antispam || isModuleBypassed(user.id, guild.id, 'antispam', client.user.id, guild.ownerId)) return;
        const key = `${guild.id}:${user.id}`;
        const now = Date.now();
        const old = windows.get(key) || [];
        const recent = old.filter((entry) => now - entry.at < WINDOW_MS);
        recent.push({ at: now, reaction });
        if (windows.size > 10_000) for (const [id, entries] of windows) if (now - entries.at(-1)?.at > WINDOW_MS) windows.delete(id);
        if (recent.length < LIMIT) { windows.set(key, recent); return; }
        windows.delete(key);
        queueSanction(guild.id, `reaction-spam:${user.id}`, async () => {
            const member = await guild.members.fetch(user.id).catch(() => null);
            if (member) await punishMember(member, settings.punishments.antispam, punishmentDuration(settings, 'antispam', 5 * 60_000), 'Anti-Spam : réactions en masse');
            await Promise.allSettled(recent.map(({ reaction: item }) => item.users.remove(user.id)));
            await sendLog(client, guild.id, buildAntiRaidEmbed(tr(settings, 'Spam de réactions', 'Reaction spam'), `<@${user.id}> · ${recent.length} réactions en ${WINDOW_MS / 1000} s.`));
        });
    },
};
