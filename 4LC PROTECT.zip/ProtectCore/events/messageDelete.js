import { handleGhostPingDelete } from '../ghostPing.js';

export default {
    name: 'messageDelete',
    async execute(client, message) { await handleGhostPingDelete(client, message); },
};
