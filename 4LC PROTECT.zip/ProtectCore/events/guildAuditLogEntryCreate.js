import { recordAuditEntry } from '../antiraid/runtime.js';
import { handleAntiNukeAudit } from '../antinuke.js';
import { buildAntiRaidEmbed, sendLog } from '../antiraid/logs.js';

export default {
    name: 'guildAuditLogEntryCreate',
    async execute(client, entry, guild) {
        recordAuditEntry(guild, entry);
        await handleAntiNukeAudit(client, guild, entry);
    },
};
