import { AuditLogEvent, PermissionFlagsBits } from 'discord.js';
import { getGuildConfig } from '../storage.js';
import { getSettings, isModuleBypassed, findRecentAuditEntry, queueSanction } from '../antiraid/runtime.js';
import { punishMember } from '../antiraid/punish.js';
import { buildAntiRaidEmbed, sendLog } from '../antiraid/logs.js';
import { punishmentDuration, punishmentPastLabel } from '../antiraid/schema.js';
import { syncTagRole } from '../tagRole.js';
import { tr } from '../i18n.js';

export default {
    name: 'guildMemberUpdate',
    async execute(client, previous, current) {
        const guild = current.guild;
        const settings = getSettings(guild.id);
        if (settings.enabled.antirole) {
            const addedDangerous = current.roles.cache.filter((role) => !previous.roles.cache.has(role.id) && role.permissions.has(PermissionFlagsBits.Administrator));
            if (addedDangerous.size) {
                const entry = await findRecentAuditEntry(guild, AuditLogEvent.MemberRoleUpdate, current.id);
                const executorId = entry?.executor?.id;
                if (executorId && !isModuleBypassed(executorId, guild.id, 'antirole', client.user.id, guild.ownerId)) {
                    const removed = [];
                    for (const role of addedDangerous.values()) {
                        if (role.editable) {
                            const ok = await current.roles.remove(role, 'Anti-Rôle : rôle Administrateur attribué sans autorisation').then(() => true).catch(() => false);
                            if (ok) removed.push(role.name);
                        }
                    }
                    queueSanction(guild.id, `antirole-grant:${executorId}:${current.id}`, async () => {
                        const executor = guild.members.cache?.get(executorId) || await guild.members.fetch(executorId).catch(() => null);
                        let label = tr(settings, 'membre introuvable', 'member not found');
                        if (executor) {
                            const result = await punishMember(executor, settings.punishments.antirole, punishmentDuration(settings, 'antirole', 10 * 60_000), 'Anti-Rôle : attribution Administrateur non autorisée');
                            label = result.applied ? punishmentPastLabel(result.effectivePunishment, settings) : tr(settings, `non sanctionné (${result.note})`, `not punished (${result.note})`);
                        }
                        await sendLog(client, guild.id, buildAntiRaidEmbed(tr(settings, 'Anti-Rôle déclenché', 'Anti-Role triggered'), tr(settings, `<@${executorId}> a attribué un rôle Administrateur à ${current}.\nRôles retirés : **${removed.join(', ') || 'aucun (hiérarchie insuffisante)'}**.\nRésultat sur l'auteur : **${label}**.`, `<@${executorId}> granted an Administrator role to ${current}.\nRemoved roles: **${removed.join(', ') || 'none (insufficient hierarchy)'}**.\nResult for the executor: **${label}**.`)));
                    });
                }
            }
        }

        const roleId = getGuildConfig(guild.id).tagRoleId;
        if (roleId) {
            const before = previous.user.primaryGuild;
            const after = current.user.primaryGuild;
            if (before?.identityGuildId !== after?.identityGuildId || before?.identityEnabled !== after?.identityEnabled || previous.roles.cache.has(roleId) !== current.roles.cache.has(roleId)) await syncTagRole(current);
        }
    },
};
