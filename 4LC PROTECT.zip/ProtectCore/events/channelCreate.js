import { AuditLogEvent } from 'discord.js';
import { getSettings, isModuleBypassed, findRecentAuditEntry, queueSanction } from '../antiraid/runtime.js';
import { punishMember } from '../antiraid/punish.js';
import { buildAntiRaidEmbed, sendLog } from '../antiraid/logs.js';
import { punishmentDuration, punishmentPastLabel } from '../antiraid/schema.js';
import { tr } from '../i18n.js';
import { protectChannelForVerification } from '../onboarding.js';

export default {
    name: 'channelCreate',
    async execute(client, channel) {
        const guild = channel.guild;
        if (!guild) return;
        await protectChannelForVerification(channel).catch(() => {});
        const settings = getSettings(guild.id);
        if (settings.antiNuke.enabled || !settings.enabled.antichannel) return;

        const entry = await findRecentAuditEntry(guild, AuditLogEvent.ChannelCreate, channel.id);
        const executorId = entry?.executor?.id;
        if (!executorId || isModuleBypassed(executorId, guild.id, 'antichannel', client.user.id, guild.ownerId)) return;

        await channel.delete('Anti-Salon : création non autorisée').catch(() => {});
        queueSanction(guild.id, `antichannel:${executorId}`, async () => {
            const member = guild.members.cache?.get(executorId) || await guild.members.fetch(executorId).catch(() => null);
            let label = tr(settings, 'membre introuvable', 'member not found');
            if (member) {
                const result = await punishMember(member, settings.punishments.antichannel, punishmentDuration(settings, 'antichannel', 5 * 60_000), 'Anti-Salon : création non autorisée');
                label = result.applied ? punishmentPastLabel(result.effectivePunishment, settings) : tr(settings, `non sanctionné (${result.note})`, `not punished (${result.note})`);
            }
            await sendLog(client, guild.id, buildAntiRaidEmbed(tr(settings, 'Anti-Salon déclenché', 'Anti-Channel triggered'), tr(settings, `<@${executorId}> a créé le salon **${channel.name}** sans autorisation — salon supprimé.\nRésultat : **${label}**.`, `<@${executorId}> created **${channel.name}** without authorization — channel deleted.\nResult: **${label}**.`)));
        });
    },
};
