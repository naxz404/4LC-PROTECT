import { AuditLogEvent, Routes } from 'discord.js';
import { getSettings, isModuleBypassed, findRecentAuditEntry, queueSanction } from '../antiraid/runtime.js';
import { buildAntiRaidEmbed, sendLog } from '../antiraid/logs.js';
import { punishMember } from '../antiraid/punish.js';
import { punishmentDuration, punishmentPastLabel } from '../antiraid/schema.js';
import { tr } from '../i18n.js';

const WATCHED_FIELDS = [
    { key: 'name', fr: 'Nom du serveur', en: 'Server name' },
    { key: 'icon', fr: 'Icône', en: 'Icon' },
    { key: 'afkChannelId', fr: 'Salon AFK', en: 'AFK channel' },
    { key: 'systemChannelId', fr: 'Salon système', en: 'System channel' },
    { key: 'verificationLevel', fr: 'Niveau de vérification', en: 'Verification level' },
    { key: 'explicitContentFilter', fr: 'Filtre de contenu explicite', en: 'Explicit content filter' },
];

export default {
    name: 'guildUpdate',
    async execute(client, oldGuild, newGuild) {
        const settings = getSettings(newGuild.id);
        if (settings.antiNuke.enabled || !settings.enabled.antiupdate && !settings.enabled.antivanity) return;

        const entry = await findRecentAuditEntry(newGuild, AuditLogEvent.GuildUpdate);
        const executorId = entry?.executor?.id;
        const vanityBypassed = executorId && isModuleBypassed(executorId, newGuild.id, 'antivanity', client.user.id, newGuild.ownerId);
        const updateBypassed = executorId && isModuleBypassed(executorId, newGuild.id, 'antiupdate', client.user.id, newGuild.ownerId);

        if (settings.enabled.antivanity && oldGuild.vanityURLCode !== newGuild.vanityURLCode) {
            if (!vanityBypassed) {
                await client.rest.patch(Routes.guildVanityUrl(newGuild.id), { body: { code: oldGuild.vanityURLCode } }).catch((error) => console.error(`[AntiRaid] Restauration vanity impossible (${newGuild.id}) :`, error));
                await sendLog(
                    client,
                    newGuild.id,
                    buildAntiRaidEmbed(tr(settings, 'Anti-Vanity déclenché', 'Anti-Vanity triggered'), tr(settings, `L'URL personnalisée a été modifiée${executorId ? ` par <@${executorId}>` : ''} — restauration tentée vers \`${oldGuild.vanityURLCode || 'aucune'}\`.`, `The custom URL was changed${executorId ? ` by <@${executorId}>` : ''} — attempted restoration to \`${oldGuild.vanityURLCode || 'none'}\`.`)),
                );
            }
        }

        if (settings.enabled.antiupdate && !updateBypassed) {
            const changes = WATCHED_FIELDS.filter((f) => oldGuild[f.key] !== newGuild[f.key]);
            if (changes.length) {
                const restore = {};
                if (changes.some((f) => f.key === 'name')) restore.name = oldGuild.name;
                if (changes.some((f) => f.key === 'icon')) restore.icon = oldGuild.iconURL({ extension: 'png', size: 1024 }) || null;
                if (changes.some((f) => f.key === 'afkChannelId')) restore.afkChannel = oldGuild.afkChannelId;
                if (changes.some((f) => f.key === 'systemChannelId')) restore.systemChannel = oldGuild.systemChannelId;
                if (changes.some((f) => f.key === 'verificationLevel')) restore.verificationLevel = oldGuild.verificationLevel;
                if (changes.some((f) => f.key === 'explicitContentFilter')) restore.explicitContentFilter = oldGuild.explicitContentFilter;
                // Sans entrée d'audit, limiter la restauration aux éléments visibles du raid.
                const attemptedRestore = executorId ? restore : Object.fromEntries(Object.entries(restore).filter(([key]) => key === 'name' || key === 'icon'));
                const restored = Object.keys(attemptedRestore).length ? await newGuild.edit({ ...attemptedRestore, reason: 'Anti-Modification : annulation prioritaire 4LC-PROTECT' }).then(() => true).catch(() => false) : false;
                queueSanction(newGuild.id, `antiupdate:${executorId || entry?.id || Date.now()}`, async () => {
                    const member = executorId ? newGuild.members.cache?.get(executorId) || await newGuild.members.fetch(executorId).catch(() => null) : null;
                    const result = member ? await punishMember(member, settings.punishments.antiupdate, punishmentDuration(settings, 'antiupdate', 10 * 60_000), 'Anti-Modification : paramètres serveur modifiés') : { applied: false, note: 'membre introuvable' };
                    const label = result.applied ? punishmentPastLabel(result.effectivePunishment, settings) : tr(settings, `non sanctionné (${result.note})`, `not punished (${result.note})`);
                    const desc = changes.map((f) => tr(settings, `**${f.fr}** modifié${executorId ? ` par <@${executorId}>` : ''}.`, `**${f.en}** changed${executorId ? ` by <@${executorId}>` : ''}.`)).join('\n');
                    await sendLog(client, newGuild.id, buildAntiRaidEmbed(tr(settings, 'Anti-Modification serveur', 'Anti-Server Update'), `${desc}\n${tr(settings, 'Restauration', 'Restore')} : **${restored ? tr(settings, 'réussie', 'successful') : tr(settings, 'échec', 'failed')}**.\n${tr(settings, 'Résultat', 'Result')} : **${label}**.`));
                });
            }
        }
    },
};
