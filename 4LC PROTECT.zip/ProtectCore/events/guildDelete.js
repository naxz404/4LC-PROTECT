import { clearGuildRuntime } from '../antiraid/runtime.js';
import { clearAntiNukeGuild } from '../antinuke.js';

export default {
    name: 'guildDelete',
    async execute(client, guild) {
        clearGuildRuntime(guild.id);
        clearAntiNukeGuild(guild.id);
    },
};
