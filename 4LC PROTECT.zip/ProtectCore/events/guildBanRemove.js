import { getGuildConfig, saveGuildConfig } from '../storage.js';

export default {
    name: 'guildBanRemove',
    async execute(client, ban) {
        const cfg = getGuildConfig(ban.guild.id);
        if (!cfg.tempBans?.some((entry) => entry.userId === ban.user.id)) return;
        cfg.tempBans = cfg.tempBans.filter((entry) => entry.userId !== ban.user.id);
        saveGuildConfig(ban.guild.id, cfg);
    },
};
