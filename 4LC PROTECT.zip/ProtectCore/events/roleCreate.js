import { AuditLogEvent, PermissionFlagsBits } from 'discord.js';
import { getSettings, isModuleBypassed, findRecentAuditEntry, queueSanction } from '../antiraid/runtime.js';
import { punishMember } from '../antiraid/punish.js';
import { buildAntiRaidEmbed, sendLog } from '../antiraid/logs.js';
import { punishmentDuration, punishmentPastLabel } from '../antiraid/schema.js';
import { tr } from '../i18n.js';

export default {
    name: 'roleCreate',
    async execute(client, role) {
        const guild = role.guild;
        const settings = getSettings(guild.id);
        if (settings.antiNuke.enabled || !settings.enabled.antirole) return;
        // On ne cible que les rôles dangereux (Administrateur) pour éviter les faux positifs sur des rôles cosmétiques.
        if (!role.permissions.has(PermissionFlagsBits.Administrator)) return;

        const entry = await findRecentAuditEntry(guild, AuditLogEvent.RoleCreate, role.id);
        const executorId = entry?.executor?.id;
        if (!executorId || isModuleBypassed(executorId, guild.id, 'antirole', client.user.id, guild.ownerId)) return;

        await role.delete('Anti-Rôle : rôle Administrateur créé sans autorisation').catch(() => {});
        queueSanction(guild.id, `antirole-create:${executorId}`, async () => {
            const member = guild.members.cache?.get(executorId) || await guild.members.fetch(executorId).catch(() => null);
            let label = tr(settings, 'membre introuvable', 'member not found');
            if (member) {
                const result = await punishMember(member, settings.punishments.antirole, punishmentDuration(settings, 'antirole', 10 * 60_000), 'Anti-Rôle : rôle Administrateur non autorisé');
                label = result.applied ? punishmentPastLabel(result.effectivePunishment, settings) : tr(settings, `non sanctionné (${result.note})`, `not punished (${result.note})`);
            }
            await sendLog(client, guild.id, buildAntiRaidEmbed(tr(settings, 'Anti-Rôle déclenché', 'Anti-Role triggered'), tr(settings, `<@${executorId}> a créé le rôle Administrateur **${role.name}** — rôle supprimé.\nRésultat : **${label}**.`, `<@${executorId}> created Administrator role **${role.name}** — role deleted.\nResult: **${label}**.`)));
        });
    },
};
