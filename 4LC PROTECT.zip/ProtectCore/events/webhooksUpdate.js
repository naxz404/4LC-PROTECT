import { AuditLogEvent, PermissionFlagsBits } from 'discord.js';
import { getSettings, isModuleBypassed, findRecentAuditEntry, queueSanction } from '../antiraid/runtime.js';
import { punishMember } from '../antiraid/punish.js';
import { buildAntiRaidEmbed, sendLog } from '../antiraid/logs.js';
import { punishmentDuration, punishmentPastLabel } from '../antiraid/schema.js';
import { tr } from '../i18n.js';
import { addIncident } from '../storage.js';

const webhookWindows = new Map();
const reportedAudits = new Map();

export default {
    name: 'webhooksUpdate',
    async execute(client, channel) {
        const guild = channel.guild;
        if (!guild) return;
        const settings = getSettings(guild.id);
        if (settings.antiNuke.enabled || !settings.enabled.antiwebhook) return;

        // L'événement ne précise pas le changement : croiser les trois actions du journal d'audit.
        const [created, deleted, updated] = await Promise.all([
            findRecentAuditEntry(guild, AuditLogEvent.WebhookCreate),
            findRecentAuditEntry(guild, AuditLogEvent.WebhookDelete),
            findRecentAuditEntry(guild, AuditLogEvent.WebhookUpdate),
        ]);
        const belongsToChannel = (audit) => audit?.target?.channelId === channel.id || audit?.extra?.channel?.id === channel.id || audit?.extra?.channelId === channel.id;
        const entry = [created, deleted, updated].filter(belongsToChannel).sort((a, b) => b.createdTimestamp - a.createdTimestamp)[0];
        const executorId = entry?.executor?.id;
        if (!entry || reportedAudits.has(entry.id)) return;
        reportedAudits.set(entry.id, Date.now());
        if (reportedAudits.size > 5_000) for (const [id, at] of reportedAudits) if (Date.now() - at > 60_000) reportedAudits.delete(id);

        const action = entry === created ? tr(settings, 'création', 'creation') : entry === updated ? tr(settings, 'modification', 'update') : tr(settings, 'suppression', 'deletion');
        addIncident(guild.id, { type: 'webhook', userId: executorId || 'inconnu', action, reason: `Webhook ${entry.target?.id || '?'} dans #${channel.name}`, webhookId: entry.target?.id || null, channelId: channel.id, auditId: entry.id });
        if (!executorId || isModuleBypassed(executorId, guild.id, 'antiwebhook', client.user.id, guild.ownerId)) {
            if (entry === updated) await sendLog(client, guild.id, buildAntiRaidEmbed(tr(settings, 'Webhook modifié', 'Webhook updated'), `${channel} · ${entry.target?.id || '?'} · ${executorId ? `<@${executorId}>` : 'auteur inconnu / unknown actor'}`));
            return;
        }
        const key = `${guild.id}:${executorId}`; const now = Date.now();
        const actions = (webhookWindows.get(key) || []).filter((item) => now - item.at < (settings.antiNuke?.windowMs || 10_000));
        actions.push({ at: now, webhookId: entry.target?.id || null }); webhookWindows.set(key, actions);
        if (entry === created) {
            const webhooks = await guild.fetchWebhooks().catch(() => null); const target = webhooks?.get(entry.target?.id);
            if (target) await target.delete('Anti-Webhook : création non autorisée').catch(() => {});
        }
        if (actions.length >= (settings.antiNuke?.count || 3)) {
            const member = guild.members.cache?.get(executorId) || await guild.members.fetch(executorId).catch(() => null);
            const dangerous = member?.roles.cache.filter((role) => role.editable && (role.permissions.has(PermissionFlagsBits.ManageWebhooks) || role.permissions.has(PermissionFlagsBits.Administrator)));
            if (dangerous?.size) await member.roles.remove([...dangerous.values()], 'Anti-Webhook : créations massives').catch(() => {});
            webhookWindows.set(key, []);
        }
        queueSanction(guild.id, `antiwebhook:${executorId}:${entry.id}`, async () => {
            const member = guild.members.cache?.get(executorId) || await guild.members.fetch(executorId).catch(() => null);
            let label = tr(settings, 'membre introuvable', 'member not found');
            if (member) {
                const result = await punishMember(member, settings.punishments.antiwebhook, punishmentDuration(settings, 'antiwebhook', 10 * 60_000), `Anti-Webhook : ${action} non autorisée`);
                label = result.applied ? punishmentPastLabel(result.effectivePunishment, settings) : tr(settings, `non sanctionné (${result.note})`, `not punished (${result.note})`);
            }
            await sendLog(client, guild.id, buildAntiRaidEmbed(tr(settings, 'Anti-Webhook déclenché', 'Anti-Webhook triggered'), tr(settings, `<@${executorId}> a effectué une ${action} de webhook dans ${channel} sans autorisation.\nRésultat : **${label}**.`, `<@${executorId}> performed an unauthorized webhook ${action} in ${channel}.\nResult: **${label}**.`)));
        });
    },
};
