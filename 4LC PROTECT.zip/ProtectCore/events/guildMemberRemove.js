import { dropCaptchaSession } from '../captcha.js';

export default {
    name: 'guildMemberRemove',
    async execute(client, member) { await dropCaptchaSession(client, member.guild.id, member.id); },
};
