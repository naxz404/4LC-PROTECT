export const isEnglish = (cfg) => cfg?.language === 'en';

export function tr(cfg, french, english) {
    return isEnglish(cfg) ? english : french;
}

export function locale(cfg) {
    return isEnglish(cfg) ? 'en-US' : 'fr-CA';
}
