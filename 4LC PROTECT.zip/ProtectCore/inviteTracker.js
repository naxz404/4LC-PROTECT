import { getJoinRecords, saveJoinRecord } from './storage.js';

const snapshots = new Map();
const lastFetch = new Map();
export async function primeGuildInvites(guild) {
    try {
        const invites = await guild.invites.fetch();
        snapshots.set(guild.id, new Map(invites.map((invite) => [invite.code, invite.uses ?? 0])));
        return true;
    } catch { return false; } // ManageGuild/ManageServer requis.
}
export async function trackMemberInvite(client, member, risk) {
    const before = snapshots.get(member.guild.id);
    let code = null; let inviterId = null;
    try {
        // Pendant une vague, une lecture par arrivée saturerait l'endpoint invitations.
        const now = Date.now();
        if (now - (lastFetch.get(member.guild.id) || 0) < 1_000) throw new Error('Lecture invitations regroupée');
        lastFetch.set(member.guild.id, now);
        const invites = await member.guild.invites.fetch();
        const next = new Map(invites.map((invite) => [invite.code, invite.uses ?? 0]));
        if (before) {
            const used = invites.filter((invite) => (invite.uses ?? 0) > (before.get(invite.code) ?? 0));
            if (used.size === 1) { code = used.first().code; inviterId = used.first().inviter?.id ?? null; }
        }
        snapshots.set(member.guild.id, next);
    } catch { /* permissions absentes : attribution inconnue */ }
    saveJoinRecord(member.guild.id, { userId: member.id, code, inviterId, risk: risk.score, at: Date.now() });
    const recent = code ? getJoinRecords(member.guild.id).filter((row) => row.code === code && Date.now() - row.at < 60_000).length : 0;
    if (code && (risk.score >= 30 || recent === 4)) {
        const { buildAntiRaidEmbed, sendLog } = await import('./antiraid/logs.js');
        await sendLog(client, member.guild.id, buildAntiRaidEmbed('Arrivée à surveiller', `<@${member.id}> · invitation \`${code}\` · créateur ${inviterId ? `<@${inviterId}>` : 'inconnu'} · risque ${risk.score}/100 · ${recent} arrivée(s) par ce lien en 60 s`)).catch(() => {});
    }
    return { code, inviterId };
}
