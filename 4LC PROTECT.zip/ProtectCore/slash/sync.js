import { allowedGuilds } from '../../ServerScope.js';
import { definitions, definitionsForLanguage } from './definitions.js';
import { getGuildConfig } from '../storage.js';

// Commandes de serveur : disponibles dès leur enregistrement. On ne touche pas
// aux commandes tierces ou aux commandes globales de l'application.
export async function syncGuildCommands(guild, commands = definitions) {
    const merged = new Map((guild.client?.arrayOfSlashCommands || []).map(command => [command.name, command]));
    for (const command of commands) merged.set(command.name, command);
    commands = [...merged.values()];
    const existing = await guild.commands.fetch();
    let created = 0;
    let updated = 0;
    let removed = 0;
    const errors = [];
    for (const command of commands) {
        const previous = existing.find((entry) => entry.name === command.name && entry.type === (command.type || 1));
        try {
            if (!previous) { await guild.commands.create(command); created++; }
            else if (!previous.equals(command, true)) { await guild.commands.edit(previous.id, command); updated++; }
        } catch (error) {
            errors.push(`/${command.name}: ${error.message}`);
        }
    }
    const names = new Set(commands.map((command) => command.name));
    for (const previous of existing.values()) {
        if (previous.type !== 1 || names.has(previous.name)) continue;
        try { await guild.commands.delete(previous.id); removed++; }
        catch (error) { errors.push(`suppression /${previous.name}: ${error.message}`); }
    }
    if (errors.length) throw new Error(`Serveur ${guild.id} : ${errors.join(' | ')}`);
    return { created, updated, removed, unchanged: commands.length - created - updated };
}

export async function syncAllGuildCommands(client) {
    for (const guild of allowedGuilds(client)) {
        try {
            const result = await syncGuildCommands(guild, definitionsForLanguage(getGuildConfig(guild.id).language));
            console.log(`Commandes / de ${guild.name} (${guild.id}) : ${result.created} créées, ${result.updated} actualisées, ${result.removed} anciennes retirées, ${result.unchanged} déjà à jour.`);
        } catch (error) {
            console.error(`❌ Enregistrement des commandes / : ${error.message}. Vérifiez l'installation du bot et le scope applications.commands.`);
        }
    }
}
