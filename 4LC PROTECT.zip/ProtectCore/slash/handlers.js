import { slashProtectionAccess, accessAllowed, accessDenied, isGlobalOwner, isGuildOwner } from '../protectionAccess.js';
import { updateSecureMember } from '../secureMembers.js';
import { clearRecentMessages, clearConfirmation, deleteAfterTwoSeconds } from '../clearMessages.js';
import { ActionRowBuilder, AttachmentBuilder, ButtonBuilder, ButtonStyle, ChannelType, EmbedBuilder, MessageFlags, PermissionFlagsBits } from 'discord.js';
import { addGlobalBlacklist, getGuildConfig, saveGuildConfig, addSanction, getSanctions, listGlobalBlacklist, removeGlobalBlacklist, removeWarning, exportMemberData, getSanctionsForAudit, getJoinRecords } from '../storage.js';
import { verifySanctionProofs } from '../auditTrail.js';
import { invalidateSettings } from '../antiraid/runtime.js';
import { buildAntiRaidEmbed, sendLog } from '../antiraid/logs.js';
import { BLUE, panelPayload, setupPayload } from '../ui.js';
import { helpPayload } from '../helpEmbed.js';
import { syncTagRole } from '../tagRole.js';
import { lockChannels, lockSuccessEmbed, renewChannel, renewSuccessEmbed, unlockChannels, unlockSuccessEmbed } from '../lockdown.js';
import { aboutPayload } from '../about.js';
import { changelogPayload } from '../changelog.js';
import { tr } from '../i18n.js';
import { syncGuildCommands } from './sync.js';
import { definitionsForLanguage } from './definitions.js';
import { captureError } from '../errors/observability.js';
import { MODULES, PUNISHMENTS, durationLabel, moduleLabel, punishmentLabel } from '../antiraid/schema.js';
import { protectionEmbed, removeWhitelist, securityScan, setWhitelist, trustScore, whitelistHistoryText } from '../securityTools.js';
import { createHoneypot, disableHoneypot, syncHoneypotLanguage } from '../honeypot.js';
import { applyProtectionLevel } from '../protectionLevels.js';
import { backupAccessDeniedEmbed, backupDiff, backupSuccessEmbed, createServerBackup, listServerBackups, resolveBackup } from '../serverBackup.js';
import { disableVerificationEnvironment, enableVerificationEnvironment } from '../onboarding.js';
import { captchaSettingsPayload } from '../captchaDashboard.js';
import { applyConfiguredPresence } from '../presence.js';
import { refreshConfigPanelOnly, refreshLocalizedMessages, rememberLocalizedMessage } from '../localizedMessages.js';
import { applyProgressiveWarning } from '../warningSystem.js';
import { sendTempBanNotice } from '../tempBans.js';
import { primeAntiNukeGuild } from '../antinuke.js';
import { syncExternalAppPermissions } from '../externalAppPermissions.js';
import { healthPayload } from '../healthDashboard.js';
import { parseBadwords, syncBadwordsRule } from '../badwords.js';

const E = MessageFlags.Ephemeral;
const answer = (i, text) => i.reply({ content: text, flags: E });
const save = (i, cfg) => { saveGuildConfig(i.guildId, cfg); invalidateSettings(i.guildId); refreshConfigPanelOnly(i.guild).catch(() => {}); };
const reason = (i, cfg) => (i.options.getString('raison') || tr(cfg, 'Aucune raison donnée', 'No reason provided')).slice(0, 250);
export const SUPPORTED_SLASH_COMMANDS = new Set([
    'secure', 'unsecure', 'setup', 'config', 'health', 'settings', 'prefix', 'language', 'tag-role', 'tag-sync', 'display', 'audit', 'lock', 'unlock', 'renew', 'lock-icon', 'join-lock', 'anti-raid', 'simulation', 'raidmode', 'verification', 'jail-config', 'logs', 'filter',
    'kick', 'ban', 'tempban', 'unban', 'timeout', 'unmute', 'untimeout', 'warn', 'unwarn', 'sanctions', 'jail', 'unjail', 'slowmode', 'clear', 'report', 'userinfo', 'about', 'changelog', 'invite', 'my-sanctions', 'ping', 'help',
    'antiban', 'antibot', 'antichannel', 'antieveryone', 'antijoin', 'antilink', 'antirole', 'antispam', 'antitoken', 'antiupdate', 'antivanity', 'antiwebhook', 'logchannel', 'panic', 'protect', 'protectiontest', 'punish', 'securityscan', 'trustscore', 'whitelist', 'unwhitelist', 'captcha', 'honeypot',
    'protection-level', 'antinuke', 'backup', 'whitelist-history', 'blacklist', 'raid-history', 'appeal-config', 'phishing', 'ghost-ping', 'warning-system', 'reload-status', 'export-data', 'delete-data', 'audit-verify', 'invite-history', 'badwords',
]);
async function modTarget(i) {
    const user = i.options.getUser('membre', true);
    const member = await i.guild.members.fetch(user.id).catch(() => null);
    const actor = await i.guild.members.fetch(i.user.id);
    const bot = await i.guild.members.fetchMe();
    if (user.id === i.guild.ownerId || user.id === i.user.id || user.id === bot.id) throw Error('Cible interdite.');
    if (member && (member.roles.highest.position >= bot.roles.highest.position || (!isGlobalOwner(i.user.id) && i.user.id !== i.guild.ownerId && member.roles.highest.position >= actor.roles.highest.position))) throw Error('Hiérarchie des rôles insuffisante.');
    return { user, member };
}
function record(i, userId, type, description) {
    const cfg = getGuildConfig(i.guildId);
    addSanction(i.guildId, { userId, type, description, moderatorId: i.user.id });
    sendLog(i.client, i.guildId, buildAntiRaidEmbed(`${tr(cfg, 'Modération', 'Moderation')} · ${type}`, `<@${userId}> · ${description}\n${tr(cfg, 'Par', 'By')} <@${i.user.id}>`, BLUE)).catch(() => {});
}
function list(records, cfg) {
    let warningNumber = 0;
    const rows = records.map((r) => {
        if (r.type === 'warn') warningNumber++;
        const number = r.type === 'warn' ? ` #${warningNumber}` : '';
        return `${r.type}${number} · ${new Date(r.at).toLocaleDateString(cfg.language === 'en' ? 'en-CA' : 'fr-CA')} · ${(r.description || '').slice(0, 100)}`;
    });
    return rows.slice(-10).join('\n') || tr(cfg, 'Aucune sanction enregistrée.', 'No punishment recorded.');
}
export async function handleSlash(i) {
    if (!i.isChatInputCommand() || !i.guildId) return false;
    const name = i.commandName;
    if (!SUPPORTED_SLASH_COMMANDS.has(name)) return false;
    const publicCommands = ['ping', 'help', 'report', 'my-sanctions', 'userinfo', 'about', 'changelog', 'invite', 'export-data', 'delete-data'];
    const permission = { kick: PermissionFlagsBits.KickMembers, ban: PermissionFlagsBits.BanMembers, tempban: PermissionFlagsBits.BanMembers, unban: PermissionFlagsBits.BanMembers, timeout: PermissionFlagsBits.ModerateMembers, unmute: PermissionFlagsBits.ModerateMembers, untimeout: PermissionFlagsBits.ModerateMembers, warn: PermissionFlagsBits.ModerateMembers, unwarn: PermissionFlagsBits.ModerateMembers, sanctions: PermissionFlagsBits.ModerateMembers, jail: PermissionFlagsBits.ModerateMembers, unjail: PermissionFlagsBits.ModerateMembers, slowmode: PermissionFlagsBits.ManageChannels, clear: PermissionFlagsBits.ManageMessages };
    const cfg = getGuildConfig(i.guildId);
    const access = slashProtectionAccess(name, i.options);
    if (access && !accessAllowed(access, i.guild, i.user.id, cfg)) { await answer(i, accessDenied(access, cfg)); return true; }
    if (!access && !publicCommands.includes(name) && !isGlobalOwner(i.user.id) && !i.memberPermissions?.has(permission[name] || PermissionFlagsBits.Administrator)) return answer(i, tr(cfg, '⛔ Permissions insuffisantes.', '⛔ Insufficient permissions.'));
    try {
        if (name === 'secure' || name === 'unsecure') {
            const user = i.options.getUser('membre', name === 'unsecure');
            if (!user) { await i.reply({ content: `**Liste Secure**\n${cfg.secureUsers.map((id) => `<@${id}>`).join(', ') || 'Aucun membre.'}`.slice(0, 1950), allowedMentions: { parse: [] }, flags: E }); return true; }
            try { await updateSecureMember(i.guild, i.user.id, user.id, name === 'unsecure'); }
            catch (error) { await answer(i, error.message); return true; }
            await i.reply({ content: `✅ <@${user.id}> ${name === 'secure' ? 'ajouté à' : 'retiré de'} la liste Secure.`, allowedMentions: { parse: [] }, flags: E }); return true;
        }
        if (name === 'export-data') {
            const payload = exportMemberData(i.guildId, i.user.id);
            await i.reply({ content: tr(cfg, '📤 Vos données pour ce serveur.', '📤 Your data for this server.'), files: [new AttachmentBuilder(Buffer.from(JSON.stringify(payload, null, 2)), { name: '4lc-protect-mes-donnees.json' })], flags: E });
            return true;
        }
        if (name === 'delete-data') {
            const row = new ActionRowBuilder().addComponents(new ButtonBuilder().setCustomId(`sar:privacy:delete:${i.user.id}`).setLabel(tr(cfg, 'Confirmer la suppression', 'Confirm deletion')).setStyle(ButtonStyle.Danger));
            await i.reply({ content: tr(cfg, 'Supprimer vos sanctions et données de suivi de ce serveur ? La blacklist globale, les bannissements temporaires actifs et les preuves pseudonymisées restent conservés.', 'Delete your server sanctions and tracking data? Global blacklist, active temporary bans and pseudonymized audit proofs are retained.'), components: [row], flags: E });
            return true;
        }
        if (name === 'audit-verify') {
            const result = verifySanctionProofs(i.guildId, getSanctionsForAudit(i.guildId));
            await answer(i, `${result.valid ? '✅' : '❌'} ${result.count} entrée(s) · ${result.valid ? `tête : \`${result.head || 'aucune'}\`` : result.reason}`);
            return true;
        }
        if (name === 'invite-history') {
            const rows = getJoinRecords(i.guildId).slice(-20).reverse();
            await answer(i, rows.map((row) => `<@${row.userId}> · ${row.code ? `\`${row.code}\`` : 'invitation inconnue'} · créateur ${row.inviterId ? `<@${row.inviterId}>` : 'inconnu'} · ${row.risk}/100`).join('\n') || 'Aucune arrivée enregistrée.');
            return true;
        }
        if (name === 'setup') { await i.reply({ ...setupPayload(cfg), flags: E }); return true; }
        if (name === 'config' || name === 'settings') { await i.reply({ ...panelPayload(cfg), flags: E }); return true; }
        if (name === 'badwords') {
            const action = i.options.getString('action', true);
            const state = cfg.badwords;
            if (action === 'list') return answer(i, `${state.enabled ? '🟢' : '⚪'} ${state.words.length} mot(s) : ${state.words.map((w) => `\`${w.replace(/`/g, 'ˋ')}\``).join(', ').slice(0, 1500) || '—'}\nSalons exemptés : ${state.exemptChannels.map((id) => `<#${id}>`).join(', ') || '—'} · AutoMod : ${state.ruleId ? '✅' : '—'}`);
            const word = i.options.getString('mot'); const channel = i.options.getChannel('salon');
            if (['add', 'remove'].includes(action)) {
                if (!word) return answer(i, '❌ Indique un mot ou une expression.');
                let value; try { [value] = parseBadwords(word); } catch (error) { return answer(i, `❌ ${error.message}`); }
                if (action === 'add') {
                    if (state.words.length >= 100 && !state.words.includes(value)) return answer(i, '❌ Maximum 100 mots.');
                    state.words = [...new Set([...state.words, value])];
                } else state.words = state.words.filter((w) => w !== value);
            } else if (['exempt', 'unexempt'].includes(action)) {
                if (!channel) return answer(i, '❌ Indique un salon.');
                if (action === 'exempt') {
                    if (state.exemptChannels.length >= 50 && !state.exemptChannels.includes(channel.id)) return answer(i, '❌ Maximum 50 salons.');
                    state.exemptChannels = [...new Set([...state.exemptChannels, channel.id])];
                } else state.exemptChannels = state.exemptChannels.filter((id) => id !== channel.id);
            } else if (action === 'sanction') {
                const punishment = i.options.getString('sanction');
                if (!['none', 'timeout'].includes(punishment)) return answer(i, '❌ Choisis « Blocage seul » ou « Timeout ».');
                state.sanction = punishment; state.timeoutSeconds = i.options.getInteger('secondes') || state.timeoutSeconds;
            } else if (action === 'on') {
                if (!state.words.length) return answer(i, '❌ Ajoute un mot avant d’activer.');
                state.enabled = true;
            } else state.enabled = false;
            save(i, cfg); await i.deferReply({ flags: E });
            try { const result = await syncBadwordsRule(i.guild, cfg); await i.editReply(`✅ Mots interdits : ${state.words.length} · ${state.enabled ? 'activé' : 'désactivé'} · AutoMod ${result.active ? 'actif' : 'inactif'}.`); }
            catch (error) { await i.editReply(`⚠️ Réglages sauvegardés, mais AutoMod : ${error.message}`); }
            return true;
        }
        if (name === 'health') { await i.deferReply({ flags: E }); await i.editReply(await healthPayload(i.client, i.guild, cfg)); return true; }
        if (name === 'prefix') {
            const value = i.options.getString('valeur', true);
            if (!/^[^\s@/`]{1,3}$/.test(value)) return answer(i, tr(cfg, 'Préfixe invalide : 1 à 3 caractères sans espace, @, / ni accent grave.', 'Invalid prefix: 1 to 3 characters without spaces, @, / or backticks.'));
            cfg.prefix = value; save(i, cfg); await answer(i, tr(cfg, `✅ Préfixe du serveur : \`${value}\`.`, `✅ Server prefix: \`${value}\`.`)); return true;
        }
        if (name === 'language') {
            cfg.language = i.options.getString('langue', true); save(i, cfg);
            await answer(i, cfg.language === 'en' ? '✅ 4LC-PROTECT is now fully displayed in English on this server.' : '✅ 4LC-PROTECT est maintenant entièrement affiché en français sur ce serveur.');
            await syncGuildCommands(i.guild, definitionsForLanguage(cfg.language));
            await syncHoneypotLanguage(i.guild, cfg);
            const refreshed = await refreshLocalizedMessages(i.guild);
            await i.followUp({ content: cfg.language === 'en' ? `🔄 ${refreshed} existing help/settings panel(s) refreshed.` : `🔄 ${refreshed} panneau(x) d’aide/configuration existant(s) actualisé(s).`, flags: E });
            return true;
        }
        if (name === 'tag-role') {
            const role = i.options.getRole('role');
            if (role) {
                const bot = await i.guild.members.fetchMe();
                if (role.id === i.guildId || role.position >= bot.roles.highest.position || role.managed || role.permissions.has(PermissionFlagsBits.Administrator)) return answer(i, tr(cfg, 'Choisissez un rôle ordinaire, sans Administrateur, situé sous celui du bot.', 'Choose a regular non-Administrator role below the bot role.'));
            }
            cfg.tagRoleId = role?.id || null; save(i, cfg);
            await answer(i, role ? tr(cfg, `✅ Rôle de tag : ${role}. Utilisez /tag-sync pour mettre un membre à jour.`, `✅ Tag role: ${role}. Use /tag-sync to refresh a member.`) : tr(cfg, '✅ Rôle de tag désactivé. Les rôles déjà attribués restent en place; retirez-les manuellement si nécessaire.', '✅ Tag role disabled. Previously assigned roles remain; remove them manually if needed.')); return true;
        }
        if (name === 'tag-sync') {
            const user = i.options.getUser('membre') || i.user;
            const member = await i.guild.members.fetch(user.id).catch(() => null);
            if (!member) return answer(i, tr(cfg, 'Ce compte n’est pas dans le serveur.', 'This account is not in the server.'));
            const result = await syncTagRole(member);
            await answer(i, tr(cfg, `Synchronisation de ${user} : ${result}.`, `Sync for ${user}: ${result}.`)); return true;
        }
        if (name === 'display') {
            const type = i.options.getString('panneau', true);
            if (type === 'verification') { await i.reply(captchaSettingsPayload(cfg)); return true; }
            const sent = await i.channel.send(panelPayload(cfg));
            rememberLocalizedMessage(i.guildId, sent, 'config');
            await answer(i, tr(cfg, '✅ Panneau envoyé dans ce salon.', '✅ Panel sent in this channel.')); return true;
        }
        if (name === 'reload-status') {
            const applied = applyConfiguredPresence(i.client, { force: true });
            await answer(i, tr(cfg, `✅ Statut rechargé : **${applied.status}** · **${applied.type}** · ${applied.name || '(aucune activité)'}.`, `✅ Status reloaded: **${applied.status}** · **${applied.type}** · ${applied.name || '(no activity)'}.`)); return true;
        }
        if (name === 'ping') { await answer(i, `🏓 ${Math.max(0, Date.now() - i.createdTimestamp)} ms · WebSocket ${i.client.ws.ping} ms`); return true; }
        if (name === 'userinfo') {
            const user = i.options.getUser('utilisateur') || i.user;
            const member = await i.guild.members.fetch(user.id).catch(() => null);
            const profile = await i.client.users.fetch(user.id, { force: true }).catch(() => user);
            const tag = profile.primaryGuild?.identityEnabled ? profile.primaryGuild.tag : null;
            const embed = new EmbedBuilder().setColor(BLUE).setTitle(`${tr(cfg, 'Profil', 'Profile')} · ${user.username}`).setThumbnail(user.displayAvatarURL())
                .addFields({ name: tr(cfg, 'Identifiant', 'ID'), value: user.id, inline: true }, { name: tr(cfg, 'Compte créé', 'Account created'), value: `<t:${Math.floor(user.createdTimestamp / 1000)}:D>`, inline: true }, { name: tr(cfg, 'Arrivée', 'Joined'), value: member?.joinedTimestamp ? `<t:${Math.floor(member.joinedTimestamp / 1000)}:D>` : tr(cfg, 'Hors serveur', 'Not in server'), inline: true }, { name: tr(cfg, 'Tag affiché', 'Displayed tag'), value: tag || tr(cfg, 'Aucun', 'None'), inline: true });
            await i.reply({ embeds: [embed], flags: E }); return true;
        }
        if (name === 'about') { await i.reply({ ...aboutPayload(cfg, i.client.user.id, i.user.id), flags: E }); return true; }
        if (name === 'changelog') { await i.reply({ ...changelogPayload(cfg, i.user.id), flags: E }); return true; }
        if (name === 'invite') {
            await answer(i, `${tr(cfg, 'Serveur 4LC', '4LC-PROTECT support')} : https://discord.gg/ddJMXWYJ29`); return true;
        }
        if (name === 'help') {
            await i.reply(helpPayload(cfg, i.user, i.options.getString('commande')));
            if (!i.options.getString('commande')) rememberLocalizedMessage(i.guildId, await i.fetchReply(), 'help');
            return true;
        }
        if (name === 'protection-level') {
            await i.deferReply({ flags: E });
            const level = applyProtectionLevel(cfg, i.options.getString('niveau', true)); save(i, cfg); const result = await syncExternalAppPermissions(i.guild);
            if (cfg.antiNuke.enabled) primeAntiNukeGuild(i.guild);
            await i.editReply(`✅ ${tr(cfg, 'Niveau de protection appliqué', 'Protection level applied')} : **${level}**.${result.failed.length ? ` ⚠️ ${result.failed.slice(0, 3).join(', ')}.` : ''}`); return true;
        }
        if (name === 'antinuke') {
            cfg.antiNuke.enabled = i.options.getBoolean('activer', true); cfg.antiNuke.count = i.options.getInteger('nombre') ?? cfg.antiNuke.count; cfg.antiNuke.windowMs = (i.options.getInteger('secondes') ?? cfg.antiNuke.windowMs / 1000) * 1000; save(i, cfg);
            if (cfg.antiNuke.enabled) primeAntiNukeGuild(i.guild);
            await answer(i, `✅ Anti-Nuke ${cfg.antiNuke.enabled ? tr(cfg, 'activé', 'enabled') : tr(cfg, 'désactivé', 'disabled')} · ${cfg.antiNuke.count}/${cfg.antiNuke.windowMs / 1000}s.`); return true;
        }
        if (name === 'backup') {
            if (!isGuildOwner(i.guild, i.user.id)) { await i.reply({ embeds: [backupAccessDeniedEmbed(cfg)], flags: E }); return true; }
            const action = i.options.getString('action', true); const code = i.options.getString('code')?.trim();
            if (action === 'create') { const created = createServerBackup(i.guild, i.user.id); await i.reply({ embeds: [backupSuccessEmbed(created, cfg.prefix || '+')], flags: E }); return true; }
            if (action === 'list') { const rows = listServerBackups(i.user.id).slice(0, 15).map((item) => `\`${item.code}\` · ${item.snapshot.guildName} · <t:${Math.floor(item.createdAt / 1000)}:R>`); await answer(i, rows.join('\n') || tr(cfg, 'Aucune sauvegarde.', 'No backups.')); return true; }
            const record = resolveBackup(code, i.user.id); if (!record) return answer(i, tr(cfg, 'Sauvegarde introuvable ou appartenant à un autre propriétaire.', 'Backup not found or owned by someone else.'));
            const diff = backupDiff(i.guild, record);
            if (action === 'diff') { await answer(i, tr(cfg, `Différences avec \`${record.code}\` : ${diff.missingRoles.length} rôle(s) manquant(s), ${diff.changedRoles.length} rôle(s) modifié(s), ${diff.missingChannels.length} salon(s) et ${diff.missingEmojis.length} emoji(s) manquant(s).`, `Differences from \`${record.code}\`: ${diff.missingRoles.length} missing role(s), ${diff.changedRoles.length} changed role(s), ${diff.missingChannels.length} missing channel(s), ${diff.missingEmojis.length} missing emoji(s).`)); return true; }
            const row = new ActionRowBuilder().addComponents(new ButtonBuilder().setCustomId(`sar:backup:restore:${record.code}:${i.user.id}`).setLabel(tr(cfg, 'Confirmer la restauration', 'Confirm restoration')).setStyle(ButtonStyle.Danger));
            await i.reply({ content: tr(cfg, `⚠️ Restauration contrôlée de \`${record.code}\`. Les éléments existants ne seront pas supprimés et les anciens messages ne peuvent pas être restaurés.`, `⚠️ Controlled restore of \`${record.code}\`. Existing items will not be deleted and old messages cannot be restored.`), components: [row], flags: E }); return true;
        }
        if (name === 'blacklist') {
            if (!isGuildOwner(i.guild, i.user.id)) { await i.reply({ embeds: [backupAccessDeniedEmbed(cfg)], flags: E }); return true; }
            const action = i.options.getString('action', true); const id = i.options.getString('id');
            if (['add', 'remove'].includes(action) && !/^\d{17,20}$/.test(id || '')) return answer(i, tr(cfg, 'Identifiant Discord invalide.', 'Invalid Discord ID.'));
            if (action === 'add') { addGlobalBlacklist(id, i.options.getString('raison') || 'Compte suspect', i.user.id); await answer(i, `✅ \`${id}\` ajouté à la blacklist globale.`); return true; }
            if (action === 'remove') { const removed = removeGlobalBlacklist(id); await answer(i, removed ? `✅ \`${id}\` retiré.` : 'Identifiant absent de la blacklist.'); return true; }
            const entries = listGlobalBlacklist();
            if (action === 'export') { const file = new AttachmentBuilder(Buffer.from(JSON.stringify(entries, null, 2)), { name: '4lcprotect-blacklist.json' }); await i.reply({ content: `📤 ${entries.length} entrée(s) exportée(s).`, files: [file], flags: E }); return true; }
            const rows = entries.slice(-30).map((entry) => `• \`${entry.userId}\` — ${entry.reason}`);
            await i.reply({ embeds: [new EmbedBuilder().setColor(0x000000).setTitle('Blacklist globale').setDescription(rows.join('\n') || 'Aucune entrée.').setFooter({ text: `${entries.length} entrée(s) · 4LC-PROTECT` })], flags: E }); return true;
        }
        if (name === 'raid-history') {
            const rows = (cfg.raidHistory || []).slice(-20).reverse().map((entry) => entry.type === 'antinuke' ? `• <t:${Math.floor(entry.at / 1000)}:R> · Anti-Nuke · **${entry.actions}** actions/${entry.windowMs / 1000}s · <@${entry.executorId}>` : `• <t:${Math.floor(entry.at / 1000)}:R> · **${entry.joins}** arrivées/${entry.windowMs / 1000}s · ${entry.action}`);
            await i.reply({ embeds: [new EmbedBuilder().setColor(0x000000).setTitle('Historique des raids').setDescription(rows.join('\n') || 'Aucun raid détecté.').setFooter({ text: '4LC-PROTECT • AntiRaid' })], flags: E }); return true;
        }
        if (name === 'appeal-config') {
            const url = i.options.getString('url'); if (url && !/^https:\/\//i.test(url)) return answer(i, 'Utilisez une URL HTTPS valide.'); cfg.appealUrl = url || null; save(i, cfg); await answer(i, cfg.appealUrl ? `✅ Lien d’appel : ${cfg.appealUrl}` : '✅ Bouton d’appel désactivé.'); return true;
        }
        if (['phishing', 'ghost-ping', 'warning-system'].includes(name)) {
            const enabled = i.options.getBoolean('activer', true);
            if (name === 'phishing') cfg.phishing.enabled = enabled;
            if (name === 'ghost-ping') cfg.ghostPing.enabled = enabled;
            if (name === 'warning-system') cfg.warningSystem.enabled = enabled;
            save(i, cfg); await answer(i, `✅ ${name} : **${enabled ? 'ON' : 'OFF'}**.`); return true;
        }
        if (MODULES.includes(name)) {
            cfg.enabled[name] = i.options.getBoolean('activer', true);
            const punishment = i.options.getString('sanction');
            if (punishment && (PUNISHMENTS.includes(punishment) || punishment === 'none')) cfg.punishments[name] = punishment;
            if (name === 'antilink') cfg.antilink.type = i.options.getString('portee') ?? cfg.antilink.type;
            if (name === 'antispam') { cfg.antispam.count = i.options.getInteger('nombre') ?? cfg.antispam.count; cfg.antispam.windowMs = (i.options.getInteger('secondes') ?? cfg.antispam.windowMs / 1000) * 1000; }
            if (name === 'antitoken') cfg.antitoken.minAccountAgeMs = (i.options.getInteger('minutes') ?? cfg.antitoken.minAccountAgeMs / 60000) * 60000;
            save(i, cfg);
            if (name === 'antibot' || name === 'antiuserapps') {
                await i.deferReply({ flags: E });
                const result = await syncExternalAppPermissions(i.guild);
                await i.editReply(`✅ ${moduleLabel(name, cfg)} ${cfg.enabled[name] ? tr(cfg, 'activé', 'enabled') : tr(cfg, 'désactivé', 'disabled')}.${result.failed.length ? ` ⚠️ ${result.failed.slice(0, 3).join(', ')}.` : ''}`);
                return true;
            }
            await answer(i, `✅ ${moduleLabel(name, cfg)} ${cfg.enabled[name] ? tr(cfg, 'activé', 'enabled') : tr(cfg, 'désactivé', 'disabled')} · ${punishmentLabel(cfg.punishments[name], cfg)}${cfg.punishments[name] === 'timeout' ? ` · ${durationLabel(cfg.punishmentDurations[name], cfg)}` : ''}.`); return true;
        }
        if (name === 'antijoin') {
            cfg.autoRaid.enabled = i.options.getBoolean('activer', true); cfg.autoRaid.count = i.options.getInteger('nombre') ?? cfg.autoRaid.count; cfg.autoRaid.windowMs = (i.options.getInteger('secondes') ?? cfg.autoRaid.windowMs / 1000) * 1000; save(i, cfg);
            await answer(i, `✅ Anti-Join ${cfg.autoRaid.enabled ? tr(cfg, 'activé', 'enabled') : tr(cfg, 'désactivé', 'disabled')} · ${cfg.autoRaid.count}/${cfg.autoRaid.windowMs / 1000}s.`); return true;
        }
        if (name === 'logchannel') { const channel = i.options.getChannel('salon', true); cfg.logChannel = channel.id; save(i, cfg); await answer(i, `✅ Logs : ${channel}.`); return true; }
        if (name === 'protect') { await i.reply({ embeds: [protectionEmbed(cfg)], flags: E }); return true; }
        if (name === 'protectiontest') { await answer(i, `🧪 ${tr(cfg, 'Simulation terminée, aucune sanction appliquée', 'Simulation complete, no punishment applied')} · ${securityScan(i.guild, cfg)}/100.`); return true; }
        if (name === 'securityscan') { await answer(i, `🛡️ ${tr(cfg, 'Note de sécurité', 'Security score')} : **${securityScan(i.guild, cfg)}/100**.`); return true; }
        if (name === 'trustscore') { const user = i.options.getUser('membre') || i.user; const member = await i.guild.members.fetch(user.id).catch(() => null); await answer(i, `🔎 ${user} · **${trustScore(member)}/100**.`); return true; }
        if (name === 'punish') { const module = i.options.getString('module', true); const punishment = i.options.getString('sanction', true); cfg.punishments[module] = punishment; save(i, cfg); await answer(i, `✅ ${moduleLabel(module, cfg)} : ${punishmentLabel(punishment, cfg)}${punishment === 'timeout' ? ` · ${durationLabel(cfg.punishmentDurations[module], cfg)} ${tr(cfg, '(durée réglable uniquement dans le panneau Sanctions)', '(duration adjustable only in the Punishments panel)')}` : ''}.`); return true; }
        if (name === 'whitelist') { const user = i.options.getUser('membre', true); const module = i.options.getString('module') || 'all'; const minutes = i.options.getInteger('minutes') || 0; setWhitelist(cfg, user.id, module, minutes, i.user.id); save(i, cfg); await answer(i, `✅ ${user} · ${module}${minutes ? ` · ${minutes} min` : ''}.`); return true; }
        if (name === 'unwhitelist') { const user = i.options.getUser('membre', true); removeWhitelist(cfg, user.id, i.options.getString('module') || 'all', i.user.id); save(i, cfg); await answer(i, `✅ ${tr(cfg, 'Exemption retirée', 'Exemption removed')} · ${user}.`); return true; }
        if (name === 'whitelist-history') { await i.reply({ embeds: [new EmbedBuilder().setColor(BLUE).setTitle(tr(cfg, 'Historique de la whitelist', 'Whitelist history')).setDescription(whitelistHistoryText(cfg))], flags: E }); save(i, cfg); return true; }
        if (name === 'panic') {
            const requested = i.options.getBoolean('activer');
            if (requested === null) {
                const row = new ActionRowBuilder().addComponents(new ButtonBuilder().setCustomId('sar:panic:on').setLabel(tr(cfg, 'Activer l’urgence', 'Enable emergency')).setStyle(ButtonStyle.Danger), new ButtonBuilder().setCustomId('sar:panic:off').setLabel(tr(cfg, 'Restaurer', 'Restore')).setStyle(ButtonStyle.Success));
                await i.reply({ embeds: [new EmbedBuilder().setColor(BLUE).setTitle(tr(cfg, 'Panneau d’urgence', 'Emergency panel')).setDescription(tr(cfg, 'Active le niveau Urgence, Join-Lock et le verrouillage des salons, ou restaure les permissions sauvegardées.', 'Enables Emergency level, Join-Lock and channel lockdown, or restores saved permissions.'))], components: [row], flags: E }); return true;
            }
            await i.deferReply({ flags: E }); const enabled = requested;
            if (enabled) applyProtectionLevel(cfg, 'urgence'); else cfg.joinLock = false; save(i, cfg); await syncExternalAppPermissions(i.guild); if (enabled) primeAntiNukeGuild(i.guild);
            const result = enabled ? await lockChannels(i.guild, i.guild.channels.cache.values(), i.user.id) : await unlockChannels(i.guild, null, i.user.id);
            await i.editReply(enabled ? `🔒 ${result.locked} salon(s) verrouillé(s).` : `🔓 ${result.restored}/${result.requested} salon(s) restauré(s).`); return true;
        }
        if (name === 'captcha') {
            const enabled = i.options.getBoolean('activer', true);
            if (!enabled) { await disableVerificationEnvironment(i.guild); await answer(i, tr(cfg, '✅ CAPTCHA désactivé et restrictions Unverified retirées.', '✅ CAPTCHA disabled and Unverified restrictions removed.')); return true; }
            await i.deferReply({ flags: E });
            const result = await enableVerificationEnvironment(i.guild, { role: i.options.getRole('non_verifie'), verifiedRole: i.options.getRole('verifie') });
            await i.editReply(tr(cfg, `✅ CAPTCHA activé : ${result.role}, ${result.channel}, ${result.protectedChannels} salon(s) protégés.`, `✅ CAPTCHA enabled: ${result.role}, ${result.channel}, ${result.protectedChannels} protected channel(s).`)); return true;
        }
        if (name === 'honeypot') {
            const enabled = i.options.getBoolean('activer', true); cfg.honeypot.punishment = i.options.getString('sanction') || cfg.honeypot.punishment;
            if (!enabled) { await disableHoneypot(i.guild, cfg, false); await answer(i, tr(cfg, '✅ HoneyPot désactivé.', '✅ HoneyPot disabled.')); return true; }
            await i.deferReply({ flags: E }); const channel = await createHoneypot(i.guild, cfg, i.user.id); await i.editReply(`✅ HoneyPot : ${channel}.`); return true;
        }
        if (name === 'join-lock') { cfg.joinLock = i.options.getBoolean('activer', true); save(i, cfg); await answer(i, tr(cfg, `Join-Lock ${cfg.joinLock ? 'activé : les nouvelles arrivées seront expulsées' : 'désactivé'}.`, `Join-Lock ${cfg.joinLock ? 'enabled: new members will be kicked' : 'disabled'}.`)); return true; }
        if (name === 'simulation') { cfg.simulationMode = i.options.getBoolean('activer', true); save(i, cfg); await answer(i, tr(cfg, `🧪 Simulation ${cfg.simulationMode ? 'activée' : 'désactivée'}.`, `🧪 Simulation ${cfg.simulationMode ? 'enabled' : 'disabled'}.`)); return true; }
        if (name === 'lock-icon') { cfg.lockIcon = i.options.getBoolean('activer', true); save(i, cfg); await answer(i, tr(cfg, `Cadenas dans le nom des salons : ${cfg.lockIcon ? 'activé pour les prochains /lock' : 'désactivé'}.`, `Lock icon in channel names: ${cfg.lockIcon ? 'enabled for future /lock actions' : 'disabled'}.`)); return true; }
        if (name === 'anti-raid' || name === 'raidmode') {
            cfg.autoRaid.enabled = i.options.getBoolean('activer', true);
            cfg.autoRaid.count = i.options.getInteger('nombre') ?? cfg.autoRaid.count;
            cfg.autoRaid.windowMs = (i.options.getInteger('secondes') ?? cfg.autoRaid.windowMs / 1000) * 1000;
            cfg.raidAction = i.options.getString('action') ?? cfg.raidAction;
            save(i, cfg); await answer(i, tr(cfg, `Auto RaidMode ${cfg.autoRaid.enabled ? 'activé' : 'désactivé'} · ${cfg.autoRaid.count} arrivées en ${cfg.autoRaid.windowMs / 1000}s · ${cfg.raidAction}.`, `Auto RaidMode ${cfg.autoRaid.enabled ? 'enabled' : 'disabled'} · ${cfg.autoRaid.count} joins in ${cfg.autoRaid.windowMs / 1000}s · ${cfg.raidAction}.`)); return true;
        }
        if (name === 'verification') {
            const enabled = i.options.getBoolean('activer', true);
            if (!enabled) { await disableVerificationEnvironment(i.guild); await answer(i, tr(cfg, '✅ Vérification désactivée.', '✅ Verification disabled.')); return true; }
            await i.deferReply({ flags: E });
            const result = await enableVerificationEnvironment(i.guild, { role: i.options.getRole('non_verifie'), verifiedRole: i.options.getRole('verifie') });
            await i.editReply(tr(cfg, `✅ Vérification prête : rôle ${result.role}, salon ${result.channel}, permissions automatiques appliquées.`, `✅ Verification ready: ${result.role} role, ${result.channel} channel, automatic permissions applied.`)); return true;
        }
        if (name === 'jail-config') {
            const role = i.options.getRole('role', true); const channel = i.options.getChannel('salon', true); const bot = await i.guild.members.fetchMe();
            if (role.id === i.guildId || role.managed || role.position >= bot.roles.highest.position || role.permissions.has(PermissionFlagsBits.Administrator) || !channel.isTextBased() || channel.isDMBased()) return answer(i, tr(cfg, 'Choisissez un rôle Jail ordinaire sans Administrateur, sous celui du bot, et un salon textuel du serveur.', 'Choose a regular non-Administrator Jail role below the bot and a server text channel.'));
            cfg.jail = { roleId: role.id, channelId: channel.id }; save(i, cfg);
            await answer(i, tr(cfg, '✅ Rôle et salon mémorisés. Configurez manuellement les permissions pour isoler réellement ce rôle.', '✅ Role and channel saved. Configure channel permissions manually to fully isolate this role.')); return true;
        }
        if (name === 'logs') {
            const security = i.options.getChannel('securite'); const reports = i.options.getChannel('signalements');
            if (!security && !reports) return answer(i, tr(cfg, 'Indiquez au moins un salon.', 'Provide at least one channel.'));
            if ((security && !security.isTextBased()) || (reports && !reports.isTextBased())) return answer(i, tr(cfg, 'Choisissez des salons textuels.', 'Choose text channels.'));
            if (security) cfg.logChannel = security.id;
            if (reports) cfg.reportChannel = reports.id;
            save(i, cfg); await answer(i, tr(cfg, '✅ Salons de logs enregistrés.', '✅ Log channels saved.')); return true;
        }
        if (name === 'filter') {
            cfg.mentionLimit = i.options.getInteger('mentions', true);
            cfg.suspiciousTextFilter = i.options.getBoolean('texte_suspect', true);
            save(i, cfg); await answer(i, tr(cfg, `Filtre : maximum ${cfg.mentionLimit || 'illimité'} mentions; texte suspect ${cfg.suspiciousTextFilter ? 'activé' : 'désactivé'}.`, `Filter: maximum ${cfg.mentionLimit || 'unlimited'} mentions; suspicious text ${cfg.suspiciousTextFilter ? 'enabled' : 'disabled'}.`)); return true;
        }
        if (name === 'audit') {
            const everyone = i.guild.roles.everyone;
            const perms = ['Administrator', 'ManageGuild', 'ManageRoles', 'ManageChannels', 'BanMembers', 'MentionEveryone'];
            const risk = i.guild.roles.cache.filter((r) => r.id !== everyone.id && perms.some((p) => r.permissions.has(p)));
            const bot = await i.guild.members.fetchMe();
            const required = [
                [tr(cfg, 'Voir les logs d’audit', 'View Audit Log'), PermissionFlagsBits.ViewAuditLog], [tr(cfg, 'Gérer le serveur', 'Manage Server'), PermissionFlagsBits.ManageGuild], [tr(cfg, 'Gérer les rôles', 'Manage Roles'), PermissionFlagsBits.ManageRoles],
                [tr(cfg, 'Gérer les salons', 'Manage Channels'), PermissionFlagsBits.ManageChannels], [tr(cfg, 'Gérer les messages', 'Manage Messages'), PermissionFlagsBits.ManageMessages], [tr(cfg, 'Expulser', 'Kick Members'), PermissionFlagsBits.KickMembers],
                [tr(cfg, 'Bannir', 'Ban Members'), PermissionFlagsBits.BanMembers], [tr(cfg, 'Exclure temporairement', 'Moderate Members'), PermissionFlagsBits.ModerateMembers], [tr(cfg, 'Envoyer des messages', 'Send Messages'), PermissionFlagsBits.SendMessages], [tr(cfg, 'Intégrer des liens', 'Embed Links'), PermissionFlagsBits.EmbedLinks],
            ];
            const missing = required.filter(([, permission]) => !bot.permissions.has(permission)).map(([label]) => label);
            const warnings = [everyone.permissions.has(PermissionFlagsBits.Administrator) ? tr(cfg, '⚠️ @everyone possède Administrateur.', '⚠️ @everyone has Administrator.') : null, missing.length ? tr(cfg, `⚠️ Permissions manquantes au bot : **${missing.join(', ')}**.`, `⚠️ Missing bot permissions: **${missing.join(', ')}**.`) : null].filter(Boolean);
            await i.reply({ embeds: [new EmbedBuilder().setColor(BLUE).setTitle(tr(cfg, 'Audit des permissions', 'Permission audit')).setDescription(`${warnings.join('\n') || tr(cfg, 'Alerte générale : aucune.', 'General alerts: none.')}\n\n${tr(cfg, 'Rôles à permissions sensibles', 'Roles with sensitive permissions')} (${risk.size}) : ${risk.first(12).map((r) => r.toString()).join(', ') || tr(cfg, 'aucun', 'none')}.\n${tr(cfg, 'Vérification indicative; les permissions par salon restent à examiner manuellement.', 'Informational audit; channel-specific permissions should still be reviewed manually.')}`)], flags: E }); return true;
        }
        if (name === 'lock') {
            const selected = i.options.getChannel('salon') || i.channel;
            if (selected?.type !== ChannelType.GuildText) return answer(i, tr(cfg, 'Choisissez un salon texte.', 'Choose a text channel.'));
            await i.deferReply({ flags: E });
            const result = await lockChannels(i.guild, [selected], i.user.id, i.options.getString('raison'));
            if (!result.details[0]) { await i.editReply(tr(cfg, 'Ce salon est déjà verrouillé ou ne peut pas être modifié.', 'This channel is already locked or cannot be changed.')); return true; }
            await i.editReply({ embeds: [lockSuccessEmbed(selected, result.details[0], cfg)] }); return true;
        }
        if (name === 'unlock') {
            const selected = i.options.getChannel('salon') || i.channel;
            if (!selected || !cfg.lockSnapshot || !Object.hasOwn(cfg.lockSnapshot, selected.id)) return answer(i, tr(cfg, 'Aucun verrouillage enregistré pour ce salon.', 'No saved lock exists for this channel.'));
            await i.deferReply({ flags: E });
            const result = await unlockChannels(i.guild, selected.id, i.user.id, i.options.getString('raison'));
            if (!result.details[0]) { await i.editReply(tr(cfg, 'Impossible de restaurer les permissions de ce salon.', 'Could not restore this channel permissions.')); return true; }
            await i.editReply({ embeds: [unlockSuccessEmbed(selected, result.details[0], cfg)] }); return true;
        }
        if (name === 'renew') {
            const selected = i.options.getChannel('salon') || i.channel;
            if (selected?.type !== ChannelType.GuildText) return answer(i, tr(cfg, 'Choisissez un salon texte.', 'Choose a text channel.'));
            await i.deferReply({ flags: E });
            await renewChannel(selected, i.user.id);
            await i.editReply({ embeds: [renewSuccessEmbed(cfg)] }); return true;
        }
        if (name === 'report') {
            if (!cfg.reportChannel) return answer(i, tr(cfg, 'Le staff doit d’abord configurer /logs signalements.', 'Staff must configure /logs signalements first.'));
            const user = i.options.getUser('utilisateur');
            const url = i.options.getString('lien')?.trim();
            if (!user && !url) return answer(i, tr(cfg, 'Indiquez un membre ou un lien de message.', 'Provide a member or a message link.'));
            if (url) {
                const match = url.match(/^https:\/\/(?:canary\.|ptb\.)?(?:discord\.com|discordapp\.com)\/channels\/(\d{17,20})\/(\d{17,20})\/(\d{17,20})\/?$/);
                if (!match || match[1] !== i.guildId) return answer(i, tr(cfg, 'Fournissez un lien de message de ce serveur.', 'Provide a message link from this server.'));
                const channel = await i.guild.channels.fetch(match[2]).catch(() => null);
                if (!channel?.isTextBased() || !channel.permissionsFor(i.user)?.has(PermissionFlagsBits.ViewChannel)) return answer(i, tr(cfg, 'Lien inaccessible ou invalide.', 'Invalid or inaccessible link.'));
            }
            const reports = await i.guild.channels.fetch(cfg.reportChannel).catch(() => null);
            if (!reports?.isTextBased()) return answer(i, tr(cfg, 'Salon de signalements inaccessible.', 'Report channel is inaccessible.'));
            const body = i.options.getString('raison', true).replace(/@/g, '@\u200b').slice(0, 500);
            await reports.send({ embeds: [new EmbedBuilder().setColor(BLUE).setTitle(tr(cfg, '🚩 Signalement', '🚩 Report')).setDescription(`${body}${user ? `\n${tr(cfg, 'Membre concerné', 'Reported member')} : <@${user.id}>` : ''}${url ? `\n[${tr(cfg, 'Voir le message', 'View message')}](${url})` : ''}\n${tr(cfg, 'Signalé par', 'Reported by')} <@${i.user.id}>`)], allowedMentions: { parse: [] } });
            await answer(i, tr(cfg, '✅ Signalement transmis au staff.', '✅ Report sent to staff.')); return true;
        }
        if (name === 'my-sanctions' || name === 'sanctions') {
            const user = name === 'sanctions' ? i.options.getUser('membre', true) : i.user;
            await answer(i, tr(cfg, `Dossier de ${user.username} :\n${list(getSanctions(i.guildId, user.id), cfg)}`, `Record for ${user.username}:\n${list(getSanctions(i.guildId, user.id), cfg)}`)); return true;
        }
        if (name === 'clear') {
            await i.deferReply();
            const deleted = await clearRecentMessages(i.channel, i.options.getInteger('nombre', true), i.id, i.member, i.guild.members.me);
            await i.editReply(clearConfirmation(i.user.id, deleted, cfg));
            deleteAfterTwoSeconds(() => i.deleteReply());
            return true;
        }
        if (name === 'slowmode') {
            const channel = i.options.getChannel('salon') || i.channel;
            if (channel?.type !== ChannelType.GuildText || typeof channel.setRateLimitPerUser !== 'function') return answer(i, tr(cfg, 'Choisissez un salon texte classique.', 'Choose a regular text channel.'));
            const seconds = i.options.getInteger('secondes', true);
            await channel.setRateLimitPerUser(seconds, `Slowmode réglé par ${i.user.id}`);
            await answer(i, seconds ? tr(cfg, `✅ Mode lent de ${channel} réglé sur ${seconds} seconde(s).`, `✅ Slowmode in ${channel} set to ${seconds} second(s).`) : tr(cfg, `✅ Mode lent désactivé dans ${channel}.`, `✅ Slowmode disabled in ${channel}.`)); return true;
        }
        if (name === 'unban') {
            const id = i.options.getString('id', true);
            if (!/^\d{17,20}$/.test(id)) return answer(i, tr(cfg, 'Identifiant Discord invalide.', 'Invalid Discord ID.'));
            await i.guild.members.unban(id, `Par ${i.user.id}`);
            cfg.tempBans = cfg.tempBans.filter((b) => b.userId !== id); save(i, cfg);
            record(i, id, 'unban', tr(cfg, 'Bannissement levé', 'Ban removed')); await answer(i, tr(cfg, '✅ Bannissement levé.', '✅ Ban removed.')); return true;
        }
        if (name === 'unwarn') {
            const user = i.options.getUser('membre', true); const n = i.options.getInteger('numero', true);
            const removed = removeWarning(i.guildId, user.id, n);
            await answer(i, removed ? tr(cfg, `✅ Avertissement n°${n} retiré.`, `✅ Warning #${n} removed.`) : tr(cfg, 'Avertissement introuvable.', 'Warning not found.')); return true;
        }
        if (['kick', 'ban', 'tempban', 'timeout', 'unmute', 'untimeout', 'warn', 'jail', 'unjail'].includes(name)) {
            const { user, member } = await modTarget(i);
            if (!member && !['ban', 'tempban'].includes(name)) return answer(i, tr(cfg, 'Membre absent du serveur.', 'Member is not in the server.'));
            const why = reason(i, cfg);
            if (name === 'kick') { if (!member.kickable) return answer(i, tr(cfg, 'Expulsion impossible.', 'Unable to kick this member.')); await member.kick(why); }
            if (name === 'ban' || name === 'tempban') {
                if (member && !member.bannable) return answer(i, tr(cfg, 'Bannissement impossible.', 'Unable to ban this member.'));
                if (name === 'tempban') await sendTempBanNotice(user, i.guild, i.options.getInteger('minutes', true) * 60000, why, cfg);
                await i.guild.members.ban(user.id, { reason: why });
                if (name === 'tempban') {
                    const minutes = i.options.getInteger('minutes', true);
                    cfg.tempBans = cfg.tempBans.filter((b) => b.userId !== user.id);
                    cfg.tempBans.push({ userId: user.id, expiresAt: Date.now() + minutes * 60000 }); save(i, cfg);
                } else if (cfg.tempBans.length) { cfg.tempBans = cfg.tempBans.filter((b) => b.userId !== user.id); save(i, cfg); }
            }
            if (name === 'timeout') { if (!member.moderatable) return answer(i, tr(cfg, 'Timeout impossible.', 'Unable to timeout this member.')); await member.timeout(i.options.getInteger('minutes', true) * 60000, why); }
            if (name === 'unmute' || name === 'untimeout') { if (!member.moderatable) return answer(i, tr(cfg, 'Action impossible.', 'Action failed.')); await member.timeout(null, `By ${i.user.id}`); }
            if (['jail', 'unjail'].includes(name)) {
                const role = i.guild.roles.cache.get(cfg.jail.roleId);
                if (!role || !member.manageable) return answer(i, tr(cfg, 'Configurez /jail-config et vérifiez la hiérarchie des rôles.', 'Configure /jail-config and check the role hierarchy.'));
                if (name === 'jail') await member.roles.add(role, why);
                else await member.roles.remove(role, `Par ${i.user.id}`);
            }
            if (name === 'warn') {
                const result = await applyProgressiveWarning(i.client, member, why, i.user.id);
                await answer(i, tr(cfg, `✅ Avertissement ajouté : ${result.total} point(s). Action : ${result.action}.`, `✅ Warning added: ${result.total} point(s). Action: ${result.action}.`)); return true;
            }
            record(i, user.id, name, why); await answer(i, tr(cfg, `✅ ${name} appliqué à ${user}.`, `✅ ${name} applied to ${user}.`)); return true;
        }
        return false;
    } catch (error) {
        const id = captureError(error, `slash:${name}`, i.guildId);
        console.warn(`[${id}] Échec de /${name}.`);
        const message = tr(cfg, `Action impossible : vérifiez les permissions, la hiérarchie des rôles et les paramètres du bot. Diagnostic : ${id}`, `Action failed: check permissions, role hierarchy and bot settings. Diagnostic: ${id}`);
        if (i.deferred || i.replied) await i.editReply(message).catch(() => {});
        else await answer(i, message).catch(() => {});
        return true;
    }
}

export async function handleVerification(i) {
    if (!i.isButton() || i.customId !== 'sar:verify' || !i.guildId) return false;
    const cfg = getGuildConfig(i.guildId);
    if (!cfg.verification?.enabled || !cfg.verification.roleId) { await answer(i, tr(cfg, 'Vérification désactivée.', 'Verification is disabled.')); return true; }
    const member = await i.guild.members.fetch(i.user.id);
    if (!member.roles.cache.has(cfg.verification.roleId)) { await answer(i, tr(cfg, 'Aucun rôle Non-Vérifié à retirer. Contactez un modérateur.', 'No Unverified role to remove. Contact a moderator.')); return true; }
    try {
        if (cfg.verification.verifiedRoleId) await member.roles.add(cfg.verification.verifiedRoleId, 'Vérification par bouton');
        await member.roles.remove(cfg.verification.roleId, 'Vérification par bouton');
        await answer(i, tr(cfg, '✅ Vérification terminée.', '✅ Verification complete.'));
    } catch { await answer(i, tr(cfg, 'Impossible de modifier vos rôles : contactez le staff.', 'Unable to update your roles. Contact staff.')); }
    return true;
}
