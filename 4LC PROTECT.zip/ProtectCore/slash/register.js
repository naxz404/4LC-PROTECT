import 'dotenv/config';
import { REST, Routes } from 'discord.js';
import { definitions } from './definitions.js';

import { pathToFileURL } from 'node:url';

if (process.argv[1] && import.meta.url === pathToFileURL(process.argv[1]).href) {
const token = process.env.TOKEN;
const guildId = process.env.GUILD_ID;
if (!token || !/^\d{17,20}$/.test(guildId || '')) {
    console.error('Renseignez TOKEN et GUILD_ID dans .env avant la commande register.');
    process.exit(1);
}
const rest = new REST({ version: '10' }).setToken(token);
try {
    const app = await rest.get(Routes.oauth2CurrentApplication());
    const existing = await rest.get(Routes.applicationGuildCommands(app.id, guildId));
    for (const definition of definitions) {
        const prior = existing.find((entry) => entry.name === definition.name && entry.type === 1);
        if (prior) await rest.patch(Routes.applicationGuildCommand(app.id, guildId, prior.id), { body: definition });
        else await rest.post(Routes.applicationGuildCommands(app.id, guildId), { body: definition });
        console.log(`/${definition.name} enregistré`);
    }
    const names = new Set(definitions.map((definition) => definition.name));
    for (const prior of existing.filter((entry) => entry.type === 1 && !names.has(entry.name))) {
        await rest.delete(Routes.applicationGuildCommand(app.id, guildId, prior.id));
        console.log(`Ancienne commande /${prior.name} supprimée`);
    }
    console.log(`${definitions.length} commandes prêtes dans le serveur ${guildId}.`);
} catch (error) {
    console.error('Enregistrement échoué :', error.message);
    process.exitCode = 1;
}

}
