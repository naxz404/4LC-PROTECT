import { isAllowedGuild } from '../ServerScope.js';
import { randomInt } from 'node:crypto';
import { ActionRowBuilder, ButtonBuilder, ButtonStyle, EmbedBuilder, MessageFlags, ModalBuilder, TextInputBuilder, TextInputStyle } from 'discord.js';
import { getGuildConfig } from './storage.js';
import { tr } from './i18n.js';

const ALPHABET = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
const sessions = new Map();
const key = (guildId, userId) => `${guildId}:${userId}`;
const code = () => Array.from({ length: 5 }, () => ALPHABET[randomInt(ALPHABET.length)]).join('');

async function deleteChallenge(session, client) {
    const channel = await client.channels.fetch(session.channelId).catch(() => null);
    if (channel?.messages) await channel.messages.delete(session.messageId).catch(() => {});
}

async function failSession(session, client, reason) {
    sessions.delete(key(session.guildId, session.userId));
    await deleteChallenge(session, client);
    if (!session.kickOnFail) return;
    const guild = client.guilds.cache.get(session.guildId); const member = await guild?.members.fetch(session.userId).catch(() => null);
    if (member?.kickable) await member.kick(reason === 'timeout' ? 'CAPTCHA : délai dépassé' : 'CAPTCHA : trop de tentatives').catch(() => {});
}

setInterval(() => {
    const now = Date.now();
    for (const session of sessions.values()) if (isAllowedGuild(session.guildId) && session.expiresAt <= now) failSession(session, session.client, 'timeout').catch(() => {});
}, 15_000).unref();

function challengePayload(cfg, member, challengeCode) {
    const embed = new EmbedBuilder().setColor(0x000000).setTitle('✅ 〃 Vérification').setDescription(
        `> *${tr(cfg, `Bienvenue ${member} ! Entrez le code ci-dessous pour accéder au serveur.`, `Welcome ${member}! Enter the code below to access the server.`)}*\n\n` +
        `> ***${tr(cfg, 'Code', 'Code')} :** \`${challengeCode}\`*\n` +
        `> *${tr(cfg, `Délai : ${Math.round((cfg.verification.timeoutMs || 300_000) / 1000)} secondes · ${cfg.verification.maxAttempts || 3} essais.`, `Time limit: ${Math.round((cfg.verification.timeoutMs || 300_000) / 1000)} seconds · ${cfg.verification.maxAttempts || 3} attempts.`)}*`,
    ).setFooter({ text: '4LC-PROTECT • Vérification' });
    const row = new ActionRowBuilder().addComponents(new ButtonBuilder().setCustomId(`sar:captcha:start:${member.id}`).setLabel(tr(cfg, 'Vérifier', 'Verify')).setEmoji('✅').setStyle(ButtonStyle.Success));
    return { embeds: [embed], components: [row], allowedMentions: { users: [member.id], parse: [] } };
}

export async function startCaptchaChallenge(client, member) {
    const cfg = getGuildConfig(member.guild.id); const v = cfg.verification;
    if (!v?.enabled || !v.channelId || !v.roleId || !member.roles.cache.has(v.roleId) || (member.user.bot && v.ignoreBots !== false)) return false;
    const channel = await member.guild.channels.fetch(v.channelId).catch(() => null);
    if (!channel?.isSendable()) return false;
    const previous = sessions.get(key(member.guild.id, member.id)); if (previous) await failSession({ ...previous, kickOnFail: false }, client, 'replaced');
    const challengeCode = code(); const sent = await channel.send(challengePayload(cfg, member, challengeCode));
    sessions.set(key(member.guild.id, member.id), { client, guildId: member.guild.id, userId: member.id, channelId: channel.id, messageId: sent.id, code: challengeCode, attempts: 0, maxAttempts: v.maxAttempts || 3, expiresAt: Date.now() + (v.timeoutMs || 300_000), kickOnFail: v.kickOnFail !== false });
    return true;
}

export async function dropCaptchaSession(client, guildId, userId) {
    const session = sessions.get(key(guildId, userId)); if (!session) return;
    sessions.delete(key(guildId, userId)); await deleteChallenge(session, client);
}

function captchaModal(userId) {
    return new ModalBuilder().setCustomId(`sar:captcha:answer:${userId}`).setTitle('Vérification CAPTCHA').addComponents(new ActionRowBuilder().addComponents(new TextInputBuilder().setCustomId('answer').setLabel('Code de vérification').setPlaceholder('ABCDE').setMinLength(5).setMaxLength(5).setStyle(TextInputStyle.Short).setRequired(true)));
}

export async function handleCaptcha(i) {
    if (!i.guildId) return false;
    const cfg = getGuildConfig(i.guildId);
    if (i.isButton() && i.customId.startsWith('sar:captcha:start:')) {
        const userId = i.customId.slice('sar:captcha:start:'.length);
        if (i.user.id !== userId) { await i.reply({ content: tr(cfg, "*Ce défi n'est pas pour vous.*", '*This challenge is not for you.*'), flags: MessageFlags.Ephemeral }); return true; }
        const session = sessions.get(key(i.guildId, userId));
        if (!session || session.expiresAt <= Date.now()) { if (session) await failSession(session, i.client, 'timeout'); await i.reply({ content: tr(cfg, 'Ce défi a expiré.', 'This challenge expired.'), flags: MessageFlags.Ephemeral }); return true; }
        await i.showModal(captchaModal(userId)); return true;
    }
    if (!i.isModalSubmit() || !i.customId.startsWith('sar:captcha:answer:')) return false;
    const userId = i.customId.slice('sar:captcha:answer:'.length);
    if (i.user.id !== userId) return true;
    const session = sessions.get(key(i.guildId, userId));
    if (!session || session.expiresAt <= Date.now()) { if (session) await failSession(session, i.client, 'timeout'); await i.reply({ content: tr(cfg, 'CAPTCHA expiré.', 'CAPTCHA expired.'), flags: MessageFlags.Ephemeral }); return true; }
    const submitted = i.fields.getTextInputValue('answer').replace(/\s+/g, '').toUpperCase();
    if (submitted !== session.code) {
        session.attempts++; const remaining = session.maxAttempts - session.attempts;
        await i.reply({ content: remaining > 0 ? tr(cfg, `Code incorrect. Il reste ${remaining} essai(s).`, `Incorrect code. ${remaining} attempt(s) left.`) : tr(cfg, 'Trop de tentatives. Vérification échouée.', 'Too many attempts. Verification failed.'), flags: MessageFlags.Ephemeral });
        if (remaining <= 0) await failSession(session, i.client, 'attempts'); return true;
    }
    const member = await i.guild.members.fetch(userId); const verified = cfg.verification.verifiedRoleId ? i.guild.roles.cache.get(cfg.verification.verifiedRoleId) : null;
    if (verified) await member.roles.add(verified, 'CAPTCHA 4LC-PROTECT validé');
    await member.roles.remove(cfg.verification.roleId, 'CAPTCHA 4LC-PROTECT validé');
    sessions.delete(key(i.guildId, userId)); await deleteChallenge(session, i.client);
    await i.reply({ content: tr(cfg, '✅ CAPTCHA validé, accès accordé.', '✅ CAPTCHA passed, access granted.'), flags: MessageFlags.Ephemeral }); return true;
}
