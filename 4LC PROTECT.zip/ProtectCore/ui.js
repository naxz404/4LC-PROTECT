import { ActionRowBuilder, ButtonBuilder, ButtonStyle, ChannelSelectMenuBuilder, ChannelType, EmbedBuilder, StringSelectMenuBuilder } from 'discord.js';
import { MODULES, moduleLabel, moduleDescription } from './antiraid/schema.js';
import config, { supportUrl } from './config.js';
import { emojiText, emojiComponent } from './appEmojis.js';

export const BLUE = 0x6495ed;
const moduleOptions = (cfg) => MODULES.map((m) => ({ label: moduleLabel(m, cfg), value: m, description: moduleDescription(m, cfg).slice(0, 100), default: Boolean(cfg.enabled[m]) }));
const button = (id, label, style = ButtonStyle.Secondary, emoji = null, iconKey = null) => { const b = new ButtonBuilder().setCustomId(id).setLabel(label).setStyle(style); return emoji ? b.setEmoji(iconKey ? emojiComponent(iconKey, emoji) : emoji) : b; };
const english = (cfg) => cfg.language === 'en';

export function setupPayload(cfg) {
    const active = MODULES.filter((m) => cfg.enabled[m]);
    const embed = new EmbedBuilder().setColor(BLUE).setTitle(`${emojiText('role', '🛡️')} 4LC-PROTECT · ${english(cfg) ? 'Setup' : 'Installation'}`)
        .setDescription(english(cfg) ? 'Choose protections, then confirm.' : 'Choisissez les protections, puis confirmez.')
        .addFields({ name: `${english(cfg) ? 'Selected' : 'Sélectionnées'} · ${active.length}/${MODULES.length}`, value: active.length ? active.map((m) => moduleLabel(m, cfg)).join(' · ') : english(cfg) ? 'None' : 'Aucune' });
    const select = new StringSelectMenuBuilder().setCustomId('sar:setup:modules').setPlaceholder(english(cfg) ? 'Select modules to install' : 'Choisir les modules à installer').setMinValues(0).setMaxValues(MODULES.length).addOptions(moduleOptions(cfg));
    return { embeds: [embed], components: [new ActionRowBuilder().addComponents(select), new ActionRowBuilder().addComponents(button('sar:setup:confirm', english(cfg) ? 'Enable and confirm' : 'Activer et confirmer', ButtonStyle.Success, '✅', 'accept'), button('sar:setup:cancel', english(cfg) ? 'Cancel' : 'Annuler', ButtonStyle.Danger, '❌', 'cancel'))] };
}

export function summaryPayload(cfg) {
    const active = MODULES.filter((m) => cfg.enabled[m]);
    const en = english(cfg);
    const embed = new EmbedBuilder().setColor(BLUE).setTitle(`${emojiText('accept', '✅')} 4LC-PROTECT · ${en ? 'Setup complete' : 'Installation terminée'}`)
        .setDescription(`${active.length}/${MODULES.length} ${en ? 'protections enabled' : 'protections activées'} · Logs ${cfg.logChannel ? `<#${cfg.logChannel}>` : '—'}`)
        .addFields({ name: en ? 'Enabled' : 'Actives', value: active.length ? active.map((m) => moduleLabel(m, cfg)).join(' · ') : en ? 'None' : 'Aucune' });
    return { embeds: [embed], components: [new ActionRowBuilder().addComponents(button('sar:send', en ? 'Send panel in this channel' : 'Envoyer le panneau dans ce salon', ButtonStyle.Primary), button('sar:panel', en ? 'Configure' : 'Configurer', ButtonStyle.Secondary))] };
}

const CATEGORIES = {
    arrivals: {
        label: (en) => en ? '🚪 Arrivals' : '🚪 Arrivées',
        desc: (en) => en ? 'Anti-spam · account age · RaidMode' : 'Anti-spam · âge du compte · RaidMode',
        buttons: (en) => [button('sar:panel:spam', 'Anti-spam', ButtonStyle.Primary, '📨'), button('sar:panel:age', en ? 'Minimum age' : 'Âge minimum', ButtonStyle.Primary, '⏳'), button('sar:panel:raid', 'Auto RaidMode', ButtonStyle.Primary, '🚨', 'alert')],
    },
    verification: {
        label: (en) => en ? '✅ Verification' : '✅ Vérification',
        desc: (en) => en ? 'Captcha and HoneyPot trap channel' : 'Captcha et salon piège HoneyPot',
        buttons: () => [button('sar:panel:verification', 'Captcha', ButtonStyle.Secondary, '✅', 'verified'), button('sar:panel:honeypot', 'HoneyPot', ButtonStyle.Secondary, '🍯')],
    },
    sanctions: {
        label: (en) => en ? '⚖️ Punishments & content' : '⚖️ Sanctions & Contenu',
        desc: (en) => en ? 'Punishments · links · blocked words · Join-Lock' : 'Sanctions · liens · mots interdits · Join-Lock',
        buttons: (en) => [button('sar:panel:punish', en ? 'Punishments' : 'Sanctions', ButtonStyle.Primary, '⚖️', 'admin'), button('sar:panel:warnings', en ? 'Warn thresholds' : 'Seuils warns', ButtonStyle.Primary, '⚠️'), button('sar:panel:links', en ? 'Links' : 'Liens', ButtonStyle.Primary, '🔗'), button('sar:panel:badwords', en ? 'Blocked words' : 'Mots interdits', ButtonStyle.Primary, '📝'), button('sar:panel:join', 'Join-Lock', ButtonStyle.Danger, '🔒', 'blocked')],
    },
    other: {
        label: (en) => en ? '🏷️ Other settings' : '🏷️ Autres réglages',
        desc: (en) => en ? 'Protection level presets and server tag role' : 'Niveaux de protection prédéfinis et rôle de tag',
        buttons: (en) => [button('sar:panel:level', en ? 'Protection level' : 'Niveau', ButtonStyle.Secondary, '📊'), button('sar:panel:tag', en ? 'Tag role' : 'Rôle de Tag', ButtonStyle.Secondary, '🏷️')],
    },
};

/** Sous-page ouverte depuis le menu « Catégories » du panneau : quelques boutons ciblés + un retour. */
export function categoryPayload(cfg, key) {
    const en = english(cfg);
    const cat = CATEGORIES[key];
    if (!cat) return panelPayload(cfg);
    const embed = new EmbedBuilder().setColor(BLUE).setTitle(`${emojiText('role', '🛡️')} 4LC-PROTECT · ${cat.label(en)}`)
        .setDescription(cat.desc(en));
    const back = button('sar:panel:back', en ? '← Back to menu' : '← Retour au menu', ButtonStyle.Secondary, '↩️');
    return { embeds: [embed], components: [new ActionRowBuilder().addComponents(...cat.buttons(en), back)] };
}

export function whitelistPayload(cfg) {
    const en = english(cfg);
    const entries = (cfg.whitelistEntries || []).filter((entry) => !entry.expiresAt || entry.expiresAt > Date.now());
    const legacy = cfg.whitelistedUsers || [];
    const lines = [
        ...legacy.map((id) => `<@${id}> · ${en ? 'all protections' : 'toutes les protections'}`),
        ...entries.map((entry) => `<@${entry.userId}> · ${entry.module === 'all' ? (en ? 'all protections' : 'toutes') : moduleLabel(entry.module, cfg)}${entry.expiresAt ? ` · <t:${Math.floor(entry.expiresAt / 1000)}:R>` : ''}`),
    ];
    const embed = new EmbedBuilder().setColor(BLUE).setTitle(`${emojiText('verified', '✅')} ${en ? 'Exemptions' : 'Whitelist'}`)
        .setDescription(`${en ? 'Active exemptions' : 'Exemptions actives'} : **${lines.length}**\n${lines.slice(0, 12).join('\n') || (en ? 'None.' : 'Aucune.')}${lines.length > 12 ? `\n… +${lines.length - 12}` : ''}`)
        .addFields({ name: en ? 'Manage' : 'Gérer', value: '`/whitelist` · `/unwhitelist` · `/whitelist-history`' });
    return { embeds: [embed], components: [new ActionRowBuilder().addComponents(button('sar:panel:back', en ? 'Back' : 'Retour', ButtonStyle.Secondary, '↩️'))] };
}

export function badwordsPayload(cfg) {
    const en = english(cfg);
    const words = cfg.badwords?.words || [];
    const channels = cfg.badwords?.exemptChannels || [];
    const embed = new EmbedBuilder().setColor(BLUE).setTitle(en ? '📝 Blocked words' : '📝 Mots interdits')
        .setDescription(`${cfg.badwords?.enabled ? '🟢' : '⚪'} ${en ? 'Protection' : 'Protection'} · **${words.length}/100** ${en ? 'words' : 'mots'}\n${words.length ? words.slice(0, 16).map((w) => `\`${w.replace(/`/g, 'ˋ')}\``).join(' · ') + (words.length > 16 ? ' …' : '') : (en ? 'No words configured.' : 'Aucun mot configuré.')}\n${en ? 'Exempt channels' : 'Salons exemptés'} : ${channels.map((id) => `<#${id}>`).join(' · ') || '—'}\n${en ? 'Sanction' : 'Sanction'} : ${cfg.badwords?.sanction === 'timeout' ? `TimeMute ${cfg.badwords.timeoutSeconds || 60}s` : (en ? 'Block only' : 'Blocage seul')} · AutoMod : ${cfg.badwords?.ruleId ? '✅' : '—'}`);
    const toggle = button('sar:badwords:toggle', cfg.badwords?.enabled ? (en ? 'Disable' : 'Désactiver') : (en ? 'Enable' : 'Activer'), cfg.badwords?.enabled ? ButtonStyle.Danger : ButtonStyle.Success);
    return { embeds: [embed], components: [new ActionRowBuilder().addComponents(button('sar:badwords:edit', en ? 'Edit words' : 'Modifier les mots', ButtonStyle.Primary), toggle, button('sar:badwords:sanction', en ? 'Punishment' : 'Sanction'), button('sar:panel:back', en ? 'Back' : 'Retour')), new ActionRowBuilder().addComponents(new ChannelSelectMenuBuilder().setCustomId('sar:badwords:channel').setPlaceholder(en ? 'Add/remove an exempt channel' : 'Ajouter/retirer un salon exempté').addChannelTypes(ChannelType.GuildText))] };
}

export function panelPayload(cfg) {
    const en = english(cfg);
    const active = MODULES.filter((m) => cfg.enabled[m]).length;
    const yes = (value) => value ? '🟢' : '⚪';
    const embed = new EmbedBuilder().setColor(BLUE).setTitle(`${emojiText('role', '🛡️')} 4LC-PROTECT · ${en ? 'Settings' : 'Configuration'}`)
        .setDescription(`${en ? 'Protections' : 'Protections'} **${active}/${MODULES.length}** · ${en ? 'Level' : 'Niveau'} **${cfg.protectionLevel || 'custom'}**\n${en ? 'Choose a category for its settings.' : 'Choisissez une catégorie pour ses réglages.'}`)
        .addFields(
            { name: en ? '📍 Server' : '📍 Serveur', value: `${en ? 'Logs' : 'Logs'} ${cfg.logChannel ? `<#${cfg.logChannel}>` : '—'} · ${en ? 'Language' : 'Langue'} ${en ? 'EN' : 'FR'} · ${en ? 'Prefix' : 'Préfixe'} \`${cfg.prefix || config.prefix}\`` },
            { name: en ? '🚨 Raid response' : '🚨 Anti-raid', value: `Anti-Nuke ${yes(cfg.antiNuke.enabled)} · RaidMode ${yes(cfg.autoRaid.enabled)} · Join-Lock ${yes(cfg.joinLock)}`, inline: false },
        );
    const advanced = [
        { value: 'phishing', label: 'Anti-Phishing', enabled: cfg.phishing?.enabled !== false },
        { value: 'ghostping', label: 'Ghost Ping', enabled: cfg.ghostPing?.enabled !== false },
        { value: 'warnings', label: en ? 'Progressive warnings' : 'Avertissements', enabled: cfg.warningSystem?.enabled !== false },
    ];
    const select = new StringSelectMenuBuilder().setCustomId('sar:panel:toggle').setPlaceholder(en ? 'Toggle a protection' : 'Activer / désactiver une protection').addOptions(
        ...MODULES.map((m) => ({ label: `${cfg.enabled[m] ? '✓' : '○'} ${moduleLabel(m, cfg)}`, value: m, description: moduleDescription(m, cfg).slice(0, 100) })),
        ...advanced.map((item) => ({ label: `${item.enabled ? '✓' : '○'} ${item.label}`, value: item.value })),
    );
    const nav = new StringSelectMenuBuilder().setCustomId('sar:panel:nav').setPlaceholder(en ? 'Open settings' : 'Ouvrir les réglages').addOptions(
        ...Object.entries(CATEGORIES).map(([value, cat]) => ({ label: cat.label(en), value })),
        { label: en ? '✅ Exemptions' : '✅ Whitelist', value: 'whitelist' },
    );
    const channels = new ChannelSelectMenuBuilder().setCustomId('sar:panel:logs').setPlaceholder(en ? 'Log channel' : 'Salon de logs').addChannelTypes(ChannelType.GuildText);
    const support = new ButtonBuilder().setStyle(ButtonStyle.Link).setURL(supportUrl).setLabel(en ? 'Support' : 'Support');
    return { embeds: [embed], components: [new ActionRowBuilder().addComponents(nav), new ActionRowBuilder().addComponents(select), new ActionRowBuilder().addComponents(channels), new ActionRowBuilder().addComponents(button('sar:panel:language', en ? 'Language' : 'Langue', ButtonStyle.Secondary, '🌐'), button('sar:panel:prefix', en ? 'Prefix' : 'Préfixe', ButtonStyle.Secondary, '↪️'), button('sar:panel:recreatelogs', en ? 'Recreate logs' : 'Recréer logs', ButtonStyle.Secondary, '🧾'), button('sar:panel:send', en ? 'Send' : 'Envoyer', ButtonStyle.Secondary, '📤'), support)] };
}
