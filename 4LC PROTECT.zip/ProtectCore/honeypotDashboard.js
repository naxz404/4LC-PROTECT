import { ActionRowBuilder, ButtonStyle, ContainerBuilder, MessageFlags, PermissionFlagsBits, StringSelectMenuBuilder } from 'discord.js';
import { getGuildConfig, saveGuildConfig } from './storage.js';
import { invalidateSettings } from './antiraid/runtime.js';
import { createHoneypot, disableHoneypot } from './honeypot.js';
import { tr } from './i18n.js';

const PUNISHMENTS = [
    { value: 'softban', labelFr: 'Softban', labelEn: 'Softban', emoji: '🍯' },
    { value: 'ban', labelFr: 'Ban', labelEn: 'Ban', emoji: '⛔' },
    { value: 'kick', labelFr: 'Kick', labelEn: 'Kick', emoji: '👢' },
    { value: 'timeout', labelFr: 'Timeout', labelEn: 'Timeout', emoji: '⏱️' },
];

function punishmentLabel(value, en) {
    const p = PUNISHMENTS.find((entry) => entry.value === value);
    return p ? (en ? p.labelEn : p.labelFr) : value;
}

export function honeypotSettingsComponents(cfg) {
    const en = cfg.language === 'en';
    const h = cfg.honeypot;
    const stateLabel = h.enabled ? (en ? '⚡ Enabled' : '⚡ Activé') : (en ? '⛔ Disabled' : '⛔ Désactivé');
    const container = new ContainerBuilder().setAccentColor(0x000000);

    container.addTextDisplayComponents((text) => text.setContent('# 🍯 〃 HoneyPot'));
    container.addSeparatorComponents((separator) => separator.setDivider(true));
    container.addTextDisplayComponents((text) => text.setContent(
        `${stateLabel} · ${en ? 'Channel' : 'Salon'} ${h.channelId ? `<#${h.channelId}>` : '—'} · ${en ? 'Punishment' : 'Sanction'} **${punishmentLabel(h.punishment, en)}**`,
    ));
    container.addSeparatorComponents((separator) => separator.setDivider(true));

    container.addSectionComponents((section) => section
        .addTextDisplayComponents((text) => text.setContent(`${en ? 'Protection' : 'Protection'} · ${stateLabel}`))
        .setButtonAccessory((button) => button.setCustomId('sar:hp:toggle').setEmoji({ name: '⚡' }).setStyle(h.enabled ? ButtonStyle.Danger : ButtonStyle.Success)));
    container.addSeparatorComponents((separator) => separator.setDivider(true));

    container.addTextDisplayComponents((text) => text.setContent(`⚔️ **${en ? 'Punishment applied' : 'Sanction appliquée'}**`));
    container.addActionRowComponents((row) => row.setComponents(
        new StringSelectMenuBuilder().setCustomId('sar:hp:punishment').setPlaceholder(en ? 'Choose a punishment...' : 'Choisir une sanction...').addOptions(
            PUNISHMENTS.map((p) => ({ label: en ? p.labelEn : p.labelFr, value: p.value, emoji: p.emoji, default: p.value === h.punishment })),
        ),
    ));
    container.addSeparatorComponents((separator) => separator.setDivider(true));

    container.addSectionComponents((section) => section
        .addTextDisplayComponents((text) => text.setContent(`${en ? 'Regenerate channel' : 'Régénérer le salon'}`))
        .setButtonAccessory((button) => button.setCustomId('sar:hp:regenerate').setEmoji({ name: '🔄' }).setStyle(ButtonStyle.Secondary).setDisabled(!h.enabled)));

    return [container];
}

export function honeypotSettingsPayload(cfg) { return { components: honeypotSettingsComponents(cfg), flags: MessageFlags.Ephemeral | MessageFlags.IsComponentsV2 }; }
const refresh = (i) => i.update({ components: honeypotSettingsComponents(getGuildConfig(i.guildId)) });

export async function handleHoneypotSettingsInteraction(i) {
    if (!i.guildId || !i.customId?.startsWith('sar:hp:')) return false;
    const cfg = getGuildConfig(i.guildId);
    if (!i.memberPermissions?.has(PermissionFlagsBits.ManageGuild)) {
        await i.reply({ content: tr(cfg, '⛔ Permission Gérer le serveur requise.', '⛔ Manage Server permission required.'), flags: MessageFlags.Ephemeral });
        return true;
    }
    const id = i.customId;

    if (i.isButton() && id === 'sar:hp:toggle') {
        await i.deferUpdate();
        if (cfg.honeypot.enabled) await disableHoneypot(i.guild, cfg, true);
        else await createHoneypot(i.guild, cfg, i.user.id);
        await i.editReply({ components: honeypotSettingsComponents(getGuildConfig(i.guildId)) });
        return true;
    }
    if (i.isStringSelectMenu() && id === 'sar:hp:punishment') {
        cfg.honeypot.punishment = i.values[0];
        saveGuildConfig(i.guildId, cfg); invalidateSettings(i.guildId);
        await refresh(i);
        return true;
    }
    if (i.isButton() && id === 'sar:hp:regenerate') {
        await i.deferUpdate();
        await createHoneypot(i.guild, cfg, i.user.id);
        await i.editReply({ components: honeypotSettingsComponents(getGuildConfig(i.guildId)) });
        return true;
    }
    return false;
}
