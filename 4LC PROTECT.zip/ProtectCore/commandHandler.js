import { prefixProtectionAccess, accessAllowed, accessDenied, isGlobalOwner } from './protectionAccess.js';
import { readdirSync } from 'node:fs';
import { pathToFileURL } from 'node:url';
import { resolve } from 'node:path';
import { Collection } from 'discord.js';
import config from './config.js';
import { captureError } from './errors/observability.js';
import buildErrorEmbed from './errors/errorEmbed.js';
import { installErrorNormalizer } from './errors/errorEmbed.js';
import { getGuildConfig } from './storage.js';
import { tr } from './i18n.js';

export async function loadCommands(client) {
    client.commands = new Collection();
    const dir = resolve(import.meta.dirname, 'commands');
    for (const file of readdirSync(dir).filter((f) => f.endsWith('.js'))) {
        const mod = await import(pathToFileURL(resolve(dir, file)).href);
        const commands = Array.isArray(mod.default) ? mod.default : [mod.default];
        for (const cmd of commands) {
            if (!cmd?.name) continue;
            client.commands.set(cmd.name, cmd);
            for (const alias of cmd.aliases || []) client.commands.set(alias, cmd);
        }
    }
}

export async function dispatch(client, message) {
    if (message.author.bot || !message.guild) return;
    installErrorNormalizer(message);
    const cfg = getGuildConfig(message.guild.id);
    const prefix = cfg.prefix || config.prefix;
    if (!message.content.startsWith(prefix)) return;
    const args = message.content.slice(prefix.length).trim().split(/\s+/);
    const name = args.shift()?.toLowerCase();
    if (!name) return;
    const command = client.commands.get(name);
    if (!command) return;

    const access = prefixProtectionAccess(command.name, args);
    if (access && !accessAllowed(access, message.guild, message.author.id, cfg)) {
        return message.reply({ content: accessDenied(access, cfg), allowedMentions: { parse: [], repliedUser: false } }).catch(() => {});
    }
    if (command.ownerOnly && !config.ownerIds.includes(message.author.id)) {
        return message.reply({ embeds: [buildErrorEmbed('401 Unauthorized', tr(cfg, 'Commande réservée aux propriétaires du bot.', 'Bot owners only.'))] }).catch(() => {});
    }
    const effectivePermissions = command.name === 'clear' ? message.channel.permissionsFor(message.member) : message.member.permissions;
    if (!access && !isGlobalOwner(message.author.id) && command.permissions?.length && !effectivePermissions?.has(command.permissions)) {
        return message.reply({ embeds: [buildErrorEmbed('401 Unauthorized', tr(cfg, `Permission requise : ${command.permissions.join(', ')}`, `Required permission: ${command.permissions.join(', ')}`))] }).catch(() => {});
    }
    try {
        await command.execute(client, message, args, name);
    } catch (error) {
        const id = captureError(error, `command:${command.name}`, message.guild.id);
        message.reply({ embeds: [buildErrorEmbed('500 Internal Server Error', tr(cfg, `Une erreur est survenue (\`${id}\`).`, `An error occurred (\`${id}\`).`))] }).catch(() => {});
    }
}
