import { EmbedBuilder, ChannelType, PermissionFlagsBits } from 'discord.js';
import { getGuildConfig, saveGuildConfig } from './storage.js';
import { invalidateSettings, isModuleBypassed } from './antiraid/runtime.js';
import { buildAntiRaidEmbed, sendLog } from './antiraid/logs.js';
import { BLUE } from './ui.js';
import { tr } from './i18n.js';
import { rememberLocalizedMessage } from './localizedMessages.js';

export function honeypotWarning(cfg) {
    return new EmbedBuilder().setColor(BLUE).setTitle(tr(cfg, '🚨 N’ENVOYEZ PAS DE MESSAGE ICI', '🚨 DO NOT SEND MESSAGES HERE'))
        .setDescription(tr(cfg, 'Ce salon sert à détecter les comptes automatisés.\nTout message envoyé ici entraîne une sanction automatique.', 'This channel detects automated accounts.\nAny message sent here triggers an automatic punishment.'));
}

/** Nom du salon HoneyPot, adapté à la langue du serveur. */
export function honeypotChannelName(cfg) {
    return tr(cfg, 'pas-touche', 'dont-touch');
}

export async function createHoneypot(guild, cfg, actorId) {
    const me = await guild.members.fetchMe();
    if (!me.permissions.has(PermissionFlagsBits.ManageChannels)) throw new Error('Permission Gérer les salons manquante.');
    const old = cfg.honeypot.channelId ? await guild.channels.fetch(cfg.honeypot.channelId).catch(() => null) : null;
    if (old?.deletable) await old.delete('Régénération HoneyPot 4LC-PROTECT').catch(() => {});
    const channel = await guild.channels.create({ name: honeypotChannelName(cfg), type: ChannelType.GuildText, position: 0, reason: `HoneyPot configuré par ${actorId}` });
    cfg.honeypot.enabled = true;
    cfg.honeypot.channelId = channel.id;
    saveGuildConfig(guild.id, cfg); invalidateSettings(guild.id);
    const sent = await channel.send({ embeds: [honeypotWarning(cfg)] });
    rememberLocalizedMessage(guild.id, sent, 'honeypot');
    return channel;
}

export async function disableHoneypot(guild, cfg, removeChannel = false) {
    const channel = cfg.honeypot.channelId ? await guild.channels.fetch(cfg.honeypot.channelId).catch(() => null) : null;
    cfg.honeypot.enabled = false;
    if (removeChannel && channel?.deletable) { await channel.delete('HoneyPot désactivé'); cfg.honeypot.channelId = null; }
    saveGuildConfig(guild.id, cfg); invalidateSettings(guild.id);
}

/** Renomme le salon HoneyPot et republie son embed dans la langue courante. */
export async function syncHoneypotLanguage(guild, cfg) {
    if (!cfg.honeypot?.channelId) return false;
    const channel = await guild.channels.fetch(cfg.honeypot.channelId).catch(() => null);
    if (!channel) return false;
    const name = honeypotChannelName(cfg);
    if (channel.name !== name) await channel.setName(name, 'Langue du serveur modifiée').catch(() => {});
    return true;
}

export async function handleHoneypotMessage(message, settings) {
    if (!settings.honeypot?.enabled || message.channel.id !== settings.honeypot.channelId) return false;
    const member = message.member;
    if (!member || isModuleBypassed(message.author.id, message.guild.id, 'honeypot', message.client.user.id, message.guild.ownerId)) return false;
    if (member.permissions.has(PermissionFlagsBits.Administrator) || !member.manageable) return false;
    if (settings.honeypot.ignoredUsers.includes(message.author.id) || member.roles.cache.some((r) => settings.honeypot.ignoredRoles.includes(r.id))) return false;
    await message.delete().catch(() => {});
    const why = tr(settings, 'HoneyPot : message dans le salon piège', 'HoneyPot: message in trap channel');
    let applied = false;
    if (settings.honeypot.punishment === 'softban' && member.bannable) {
        await member.ban({ reason: why }); await message.guild.members.unban(member.id, why); applied = true;
    } else if (settings.honeypot.punishment === 'ban' && member.bannable) { await member.ban({ reason: why }); applied = true; }
    else if (settings.honeypot.punishment === 'kick' && member.kickable) { await member.kick(why); applied = true; }
    else if (settings.honeypot.punishment === 'timeout' && member.moderatable) { await member.timeout(settings.honeypot.timeoutMs, why); applied = true; }
    await sendLog(message.client, message.guild.id, buildAntiRaidEmbed('HoneyPot', `${message.author} · ${applied ? tr(settings, 'sanction appliquée', 'punishment applied') : tr(settings, 'sanction impossible', 'punishment failed')}.`));
    return true;
}
