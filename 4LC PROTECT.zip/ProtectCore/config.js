import { ownerIds } from '../Owners.js';
import 'dotenv/config';
import { readFileSync, writeFileSync, renameSync } from 'node:fs';
import rootConfig from '../config.json' with { type: 'json' };

export const presenceConfigPath = new URL('./config.json', import.meta.url);
export const legacyPresenceConfigPath = new URL('./appearance.json', import.meta.url);
const PRESENCES = ['online', 'idle', 'dnd', 'invisible'];
const ACTIVITY_TYPES = ['Playing', 'Watching', 'Listening', 'Streaming', 'Competing', 'Custom'];
const NUMERIC_ACTIVITY_TYPES = { 0: 'Playing', 1: 'Streaming', 2: 'Listening', 3: 'Watching', 5: 'Competing', 4: 'Custom' };

function readJson(url) {
    try { return JSON.parse(readFileSync(url, 'utf8')); }
    catch { return {}; }
}

export function normalizeActivityConfig(file = {}, legacy = {}) {
    const configuredActivity = Array.isArray(file.activity) ? file.activity[0] : file.activity;
    const statusObject = file.status && typeof file.status === 'object' ? file.status : {};
    const presenceObject = file.presence && typeof file.presence === 'object' ? file.presence : {};
    const presenceActivity = Array.isArray(presenceObject.activities) ? presenceObject.activities[0] || {} : {};
    const statusAsPresence = typeof file.status === 'string' && PRESENCES.includes(file.status.toLowerCase()) ? file.status.toLowerCase() : null;
    const candidates = [
        typeof configuredActivity === 'string' ? configuredActivity : configuredActivity?.name,
        configuredActivity?.state, file.activityText, file.statusText, statusObject.name, statusObject.text,
        typeof statusObject.activity === 'string' ? statusObject.activity : statusObject.activity?.name,
        presenceActivity.name, presenceActivity.state,
        typeof file.status === 'string' && !statusAsPresence ? file.status : null,
        legacy.name, 'la sécurité du serveur 🛡️',
    ];
    const name = candidates.find((value) => typeof value === 'string' && value.trim()) || '';
    const requestedType = file.activityType ?? configuredActivity?.type ?? statusObject.activityType ?? statusObject.type ?? presenceActivity.type ?? file.type ?? legacy.type;
    const requestedPresence = (typeof file.presence === 'string' ? file.presence : null) ?? statusAsPresence ?? statusObject.presence ?? statusObject.status ?? presenceObject.status ?? file.onlineStatus ?? legacy.status;
    const normalizedType = typeof requestedType === 'number' ? NUMERIC_ACTIVITY_TYPES[requestedType] : requestedType;
    const type = ACTIVITY_TYPES.find((value) => value.toLowerCase() === String(normalizedType || '').toLowerCase()) || 'Watching';
    const normalizedPresence = String(requestedPresence || '').toLowerCase();
    const url = String(configuredActivity?.url || statusObject.url || presenceActivity.url || file.activityUrl || '').trim().slice(0, 512);
    return {
        name: file.activityDisabled ? '' : name.trim().slice(0, 128),
        type,
        status: PRESENCES.includes(normalizedPresence) ? normalizedPresence : 'online',
        ...(url ? { url } : {}),
    };
}

export function writeActivityConfig(patch) {
    const next = { ...readJson(presenceConfigPath), ...patch };
    const temporary = new URL('./config.json.tmp', import.meta.url);
    writeFileSync(temporary, JSON.stringify(next, null, 2), { mode: 0o600 });
    renameSync(temporary, presenceConfigPath);
    return readActivityConfig();
}
export function readActivityConfig() {
    return normalizeActivityConfig(readJson(presenceConfigPath), readJson(legacyPresenceConfigPath).activity || {});
}

const rawPrefix = process.env.PREFIX || '+';
const config = {
    token: process.env.TOKEN || rootConfig.token || '',
    prefix: /^[^\s@/`]{1,3}$/.test(rawPrefix) ? rawPrefix : '+',
    get ownerIds() { return ownerIds(); },
    activity: readActivityConfig(),
};

export const colors = {
    prime: 0x6495ed,
    red: 0xe74c3c,
    green: 0x2ecc71,
};

export const supportUrl = 'https://discord.gg/ddJMXWYJ29';

export default config;
