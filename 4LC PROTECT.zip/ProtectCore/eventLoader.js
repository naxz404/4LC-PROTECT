import { readdirSync } from 'node:fs';
import { pathToFileURL } from 'node:url';
import { resolve } from 'node:path';
import { captureError } from './errors/observability.js';
import { recordGuildEvent } from './healthMetrics.js';
import { syncExternalAppPermissions } from './externalAppPermissions.js';

export async function loadEvents(client) {
    const dir = resolve(import.meta.dirname, 'events');
    for (const file of readdirSync(dir).filter((f) => f.endsWith('.js'))) {
        const mod = await import(pathToFileURL(resolve(dir, file)).href);
        const event = mod.default;
        if (!event?.name) continue;
        const handler = (...args) =>
            Promise.resolve()
                .then(() => {
                    const target = args.find((value) => value?.guildId || value?.guild?.id || value?.message?.guildId || value?.channels?.cache);
                    recordGuildEvent(target?.guildId || target?.guild?.id || target?.message?.guildId || (target?.channels?.cache ? target.id : null), event.name);
                    return event.execute(client, ...args);
                })
                .then(() => {
                    if (['roleCreate', 'roleUpdate', 'channelCreate', 'channelUpdate'].includes(event.name)) {
                        const guild = args.at(-1)?.guild || args.at(-1)?.roles?.cache && args.at(-1);
                        if (guild) void syncExternalAppPermissions(guild).catch((error) => captureError(error, 'external-app-permissions', guild.id));
                    }
                })
                .catch((error) => {
                    const id = captureError(error, `event:${event.name}`, args[0]?.guild?.id ?? null);
                    console.warn(`[${id}] Événement ${event.name} échoué.`);
                });
        if (event.once) client.once(event.name, handler);
        else client.on(event.name, handler);
        console.log(`Event ${event.name} chargé`);
    }
}
