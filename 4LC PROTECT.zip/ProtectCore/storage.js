// Stockage minimal sur disque, en JSON. Un fichier par serveur pour la config
// anti-raid, et un fichier unique pour le journal d'erreurs.
import { readFileSync, writeFileSync, existsSync, mkdirSync, renameSync, readdirSync, rmSync, cpSync, promises as fs } from 'node:fs';
import { dirname, resolve } from 'node:path';
import { randomBytes } from 'node:crypto';
import { DEFAULT_CONFIG } from './antiraid/schema.js';
import { appendSanctionProof } from './auditTrail.js';

// Données persistantes 4LC-PROTECT.
// IMPORTANT : le stockage est volontairement HORS de ProtectCore afin que les réglages
// survivent quand le code du bot est remplacé/mis à jour sur l'hébergeur.
// Emplacement personnalisable avec FOUR_LC_DATA_DIR.
const LEGACY_DATA_DIR = resolve(import.meta.dirname, 'data');
const DATA_DIR = resolve(process.env.FOUR_LC_DATA_DIR || resolve(import.meta.dirname, '..', '4LC-DATA'));

// Migration automatique : si une ancienne version avait déjà des réglages dans
// ProtectCore/data et que le nouveau dossier persistent n'existe pas encore, on
// recopie tout sans toucher à l'ancienne copie.
if (DATA_DIR !== LEGACY_DATA_DIR && !existsSync(DATA_DIR) && existsSync(LEGACY_DATA_DIR)) {
    try {
        cpSync(LEGACY_DATA_DIR, DATA_DIR, { recursive: true, force: false, errorOnExist: false });
        console.log(`[4LC-DATA] Anciennes données migrées vers ${DATA_DIR}`);
    } catch (error) {
        console.warn('[4LC-DATA] Migration automatique impossible :', error?.message || error);
    }
}

const GUILDS_DIR = resolve(DATA_DIR, 'guilds');
const ERRORS_FILE = resolve(DATA_DIR, 'errors.json');
const SANCTIONS_DIR = resolve(DATA_DIR, 'sanctions');
const BACKUPS_DIR = resolve(DATA_DIR, 'backups');
const INCIDENTS_DIR = resolve(DATA_DIR, 'incidents');
const GLOBAL_BLACKLIST_FILE = resolve(DATA_DIR, 'global-blacklist.json');
const AMBASSADORS_FILE = resolve(DATA_DIR, 'ambassadors.json');
const JOINS_DIR = resolve(DATA_DIR, 'joins');
const guildCache = new Map();
const bufferedWrites = new Map();
const writeChains = new Map();
const writingValues = new Map();
const GUILD_CACHE_TTL = 5_000;

function ensureDirs() {
    mkdirSync(GUILDS_DIR, { recursive: true });
    mkdirSync(SANCTIONS_DIR, { recursive: true });
    mkdirSync(BACKUPS_DIR, { recursive: true });
    mkdirSync(INCIDENTS_DIR, { recursive: true });
}

function readJson(path, fallback) {
    if (!existsSync(path)) return fallback;
    try {
        return JSON.parse(readFileSync(path, 'utf8'));
    } catch {
        return fallback;
    }
}

function writeJsonAtomic(path, value) {
    ensureDirs();
    writeFileSync(`${path}.tmp`, JSON.stringify(value, null, 2));
    renameSync(`${path}.tmp`, path);
}
function scheduleJsonWrite(path, value) {
    const previous = bufferedWrites.get(path);
    if (previous) { previous.value = structuredClone(value); return; }
    const entry = { value: structuredClone(value), timer: null };
    entry.timer = setTimeout(() => {
        bufferedWrites.delete(path);
        writingValues.set(path, entry.value);
        const prior = writeChains.get(path) || Promise.resolve();
        const next = prior.catch(() => {}).then(async () => {
            await fs.mkdir(dirname(path), { recursive: true });
            const tmp = `${path}.tmp`;
            await fs.writeFile(tmp, JSON.stringify(entry.value, null, 2));
            await fs.rename(tmp, path);
        });
        writeChains.set(path, next);
        void next.finally(() => { if (writingValues.get(path) === entry.value) writingValues.delete(path); }).catch(() => {});
        void next.catch((error) => console.error(`[Storage] Écriture différée ${path}:`, error));
    }, 1_000);
    bufferedWrites.set(path, entry);
}

function guildFile(guildId) {
    return resolve(GUILDS_DIR, `${guildId}.json`);
}

export function hasStoredGuildConfig(guildId) { return existsSync(guildFile(guildId)); }

/** Renvoie la config anti-raid d'un serveur, fusionnée avec les valeurs par défaut. */
export function getGuildConfig(guildId) {
    const cached = guildCache.get(guildId);
    if (cached && cached.until > Date.now()) return mergeDefaults(cached.value);
    const raw = readJson(guildFile(guildId), {});
    guildCache.set(guildId, { value: raw, until: Date.now() + GUILD_CACHE_TTL });
    return mergeDefaults(raw);
}

export function saveGuildConfig(guildId, cfg) {
    writeJsonAtomic(guildFile(guildId), cfg);
    guildCache.set(guildId, { value: structuredClone(cfg), until: Date.now() + GUILD_CACHE_TTL });
    return cfg;
}

function mergeDefaults(raw) {
    const merged = JSON.parse(JSON.stringify(DEFAULT_CONFIG));
    for (const key of Object.keys(merged)) {
        if (raw[key] === undefined) continue;
        if (typeof merged[key] === 'object' && merged[key] !== null && !Array.isArray(merged[key])) {
            merged[key] = { ...merged[key], ...raw[key] };
        } else {
            merged[key] = raw[key];
        }
    }
    merged.secureUsers = Array.isArray(merged.secureUsers) ? [...new Set(merged.secureUsers.filter(id => typeof id === 'string' && /^\d{17,22}$/.test(id)))] : [];
    return merged;
}

// ---- Journal d'erreurs (in-memory + persisté périodiquement) ----
let errorLog = readJson(ERRORS_FILE, []);
const MAX_ERRORS = 300;

export function pushError(entry) {
    errorLog.push(entry);
    if (errorLog.length > MAX_ERRORS) errorLog = errorLog.slice(-MAX_ERRORS);
    try {
        writeJsonAtomic(ERRORS_FILE, errorLog);
    } catch {
        /* best-effort : ne doit jamais faire planter la capture d'erreur */
    }
}

export function listErrors() {
    return errorLog.slice().reverse(); // plus récent en premier
}

export function findError(id) {
    return errorLog.find((e) => e.id === id) || null;
}

function sanctionsFile(guildId) { return resolve(SANCTIONS_DIR, `${guildId}.json`); }
export function getSanctionsForAudit(guildId) { const rows = readJson(sanctionsFile(guildId), []); return Array.isArray(rows) ? rows : []; }
export function getSanctions(guildId, userId) {
    const records = readJson(sanctionsFile(guildId), []);
    return Array.isArray(records) ? records.filter((r) => r.userId === userId) : [];
}
export function addSanction(guildId, record) {
    const records = readJson(sanctionsFile(guildId), []);
    const safe = Array.isArray(records) ? records : [];
    const saved = { ...record, at: Date.now() };
    safe.push(saved);
    writeJsonAtomic(sanctionsFile(guildId), safe.slice(-1000));
    appendSanctionProof(guildId, saved);
}
export function removeWarning(guildId, userId, index) {
    const records = readJson(sanctionsFile(guildId), []);
    const safe = Array.isArray(records) ? records : [];
    const warnings = safe.filter((r) => r.userId === userId && r.type === 'warn');
    const target = warnings[index - 1];
    if (!target) return false;
    safe.splice(safe.indexOf(target), 1);
    writeJsonAtomic(sanctionsFile(guildId), safe);
    return true;
}

function backupFile(code) { return resolve(BACKUPS_DIR, `${code}.json`); }
export function createBackupRecord(record) {
    let code;
    do { code = randomBytes(12).toString('hex'); } while (existsSync(backupFile(code)));
    const saved = { ...record, code, createdAt: Date.now() };
    writeJsonAtomic(backupFile(code), saved);
    return saved;
}
export function createPeriodicBackupRecord(record, intervalMs = 6 * 60 * 60_000) {
    ensureDirs();
    const snapshots = readdirSync(BACKUPS_DIR).filter((name) => name.endsWith('.json'))
        .map((name) => ({ name, value: readJson(resolve(BACKUPS_DIR, name), null) }))
        .filter(({ value }) => value?.automatic === true && value.sourceGuildId === record.sourceGuildId)
        .sort((a, b) => b.value.createdAt - a.value.createdAt);
    if (snapshots[0] && Date.now() - snapshots[0].value.createdAt < intervalMs) return null;
    const saved = createBackupRecord({ ...record, automatic: true });
    for (const old of snapshots.slice(27)) {
        // Conserver 28 snapshots automatiques par serveur, sans toucher aux sauvegardes manuelles.
        rmSync(resolve(BACKUPS_DIR, old.name), { force: true });
    }
    return saved;
}
export function getBackupRecord(code) {
    const normalized = String(code || '').trim();
    if (!/^[a-f0-9]{24}$/i.test(normalized)) return null;
    return readJson(backupFile(normalized.toLowerCase()), null) || readJson(backupFile(normalized.toUpperCase()), null);
}
export function listBackupRecords(ownerId) {
    ensureDirs();
    return readdirSync(BACKUPS_DIR).filter((name) => name.endsWith('.json')).map((name) => readJson(resolve(BACKUPS_DIR, name), null)).filter((item) => item?.ownerId === ownerId).sort((a, b) => b.createdAt - a.createdAt);
}

function incidentFile(guildId) { return resolve(INCIDENTS_DIR, `${guildId}.json`); }
export function addIncident(guildId, entry) {
    const rows = readJson(incidentFile(guildId), []);
    const item = { ...entry, id: randomBytes(8).toString('hex'), at: Date.now(), status: 'active' };
    writeJsonAtomic(incidentFile(guildId), [...(Array.isArray(rows) ? rows : []), item].slice(-200));
    return item;
}
export function getIncident(guildId, id) { return listIncidents(guildId).find((row) => row.id === id) || null; }
export function listIncidents(guildId) { const rows = readJson(incidentFile(guildId), []); return Array.isArray(rows) ? rows.slice().reverse() : []; }
export function updateIncident(guildId, id, changes) {
    const loaded = readJson(incidentFile(guildId), []); const rows = Array.isArray(loaded) ? loaded : [];
    const item = rows.find((row) => row.id === id);
    if (!item) return null;
    Object.assign(item, changes); writeJsonAtomic(incidentFile(guildId), rows); return item;
}

export function listGlobalBlacklist() {
    const entries = readJson(GLOBAL_BLACKLIST_FILE, []);
    return Array.isArray(entries) ? entries : [];
}
export function addGlobalBlacklist(userId, reason, actorId) {
    const entries = listGlobalBlacklist().filter((entry) => entry.userId !== userId);
    const entry = { userId, reason: String(reason || 'Compte signalé').slice(0, 250), actorId, at: Date.now() };
    entries.push(entry); writeJsonAtomic(GLOBAL_BLACKLIST_FILE, entries.slice(-5000)); return entry;
}
export function removeGlobalBlacklist(userId) {
    const entries = listGlobalBlacklist(); const next = entries.filter((entry) => entry.userId !== userId);
    writeJsonAtomic(GLOBAL_BLACKLIST_FILE, next); return next.length !== entries.length;
}
export function findGlobalBlacklist(userId) { return listGlobalBlacklist().find((entry) => entry.userId === userId) || null; }

function joinsFile(guildId) { return resolve(JOINS_DIR, `${guildId}.json`); }
export function getJoinRecords(guildId) { const path = joinsFile(guildId); const rows = bufferedWrites.get(path)?.value || writingValues.get(path) || readJson(path, []); return Array.isArray(rows) ? rows : []; }
export function saveJoinRecord(guildId, record) {
    const rows = getJoinRecords(guildId);
    rows.push(record);
    scheduleJsonWrite(joinsFile(guildId), rows.slice(-1000));
}
export function exportMemberData(guildId, userId) {
    const cfg = getGuildConfig(guildId);
    const joins = readJson(joinsFile(guildId), []);
    return {
        guildId, userId,
        sanctions: getSanctionsForAudit(guildId).filter((row) => row.userId === userId || row.moderatorId === userId),
        joins: Array.isArray(joins) ? joins.filter((row) => row.userId === userId || row.inviterId === userId) : [],
        whitelist: (cfg.whitelistEntries || []).filter((row) => row.userId === userId),
        whitelistHistory: (cfg.whitelistHistory || []).filter((row) => row.userId === userId || row.actorId === userId),
        quarantines: (cfg.jail?.quarantines || []).filter((row) => row.userId === userId),
        tempBans: (cfg.tempBans || []).filter((row) => row.userId === userId),
        raidHistory: (cfg.raidHistory || []).filter((row) => row.executorId === userId),
        incidents: listIncidents(guildId).filter((row) => row.userId === userId || row.reviewedBy === userId),
        globalBlacklist: findGlobalBlacklist(userId),
    };
}
export function deleteMemberData(guildId, userId) {
    const exported = exportMemberData(guildId, userId);
    const sanctions = readJson(sanctionsFile(guildId), []);
    if (Array.isArray(sanctions)) writeJsonAtomic(sanctionsFile(guildId), sanctions.filter((row) => row.userId !== userId && row.moderatorId !== userId));
    const joins = readJson(joinsFile(guildId), []);
    if (Array.isArray(joins)) writeJsonAtomic(joinsFile(guildId), joins.filter((row) => row.userId !== userId && row.inviterId !== userId));
    const incidents = listIncidents(guildId);
    if (incidents.length) writeJsonAtomic(incidentFile(guildId), incidents.filter((row) => row.userId !== userId && row.reviewedBy !== userId));
    const cfg = getGuildConfig(guildId);
    cfg.whitelistedUsers = (cfg.whitelistedUsers || []).filter((id) => id !== userId);
    cfg.whitelistEntries = (cfg.whitelistEntries || []).filter((row) => row.userId !== userId);
    cfg.whitelistHistory = (cfg.whitelistHistory || []).filter((row) => row.userId !== userId && row.actorId !== userId);
    if (cfg.jail?.quarantines) cfg.jail.quarantines = cfg.jail.quarantines.filter((row) => row.userId !== userId);
    if (Array.isArray(cfg.raidHistory)) cfg.raidHistory = cfg.raidHistory.filter((row) => row.executorId !== userId);
    saveGuildConfig(guildId, cfg);
    // Les entrées de blacklist globale sont conservées pour la sécurité.
    return { deletedSanctions: exported.sanctions.length, deletedJoins: exported.joins.length, globalBlacklistRetained: Boolean(exported.globalBlacklist) };
}

// ---- État adaptatif anti-spam/anti-raid (mode raid actif + récidive) ----
// Persisté légèrement pour survivre à un redémarrage ; voir adaptiveSecurity.js.
const shardKey = String(process.env.SHARD_LIST || 'single').replace(/[^0-9a-z_-]/gi, '_');
const ADAPTIVE_STATE_FILE = resolve(DATA_DIR, shardKey === 'single' ? 'adaptive-state.json' : `adaptive-state-${shardKey}.json`);
export function getAdaptiveState() { return readJson(ADAPTIVE_STATE_FILE, readJson(resolve(DATA_DIR, 'adaptive-state.json'), { raidModeUntil: {}, offences: {} })); }
export function saveAdaptiveState(state) {
    scheduleJsonWrite(ADAPTIVE_STATE_FILE, state);
}

// ---- Programme Ambassadeur ----
// { codes: { CODE: guildId }, guilds: { guildId: { code, ownerId, createdAt, referrals: [{ guildId, guildName, claimedAt, status, validatedAt, rewardDays }] } } }
function readAmbassadors() {
    const data = readJson(AMBASSADORS_FILE, { codes: {}, guilds: {} });
    if (!data.codes) data.codes = {};
    if (!data.guilds) data.guilds = {};
    return data;
}
function writeAmbassadors(data) { writeJsonAtomic(AMBASSADORS_FILE, data); }

export function getAmbassador(guildId) { return readAmbassadors().guilds[guildId] || null; }

export function ensureAmbassadorCode(guildId, ownerId) {
    const data = readAmbassadors();
    if (data.guilds[guildId]) return data.guilds[guildId];
    let code;
    do { code = `SYN-${randomBytes(3).toString('hex').toUpperCase()}`; } while (data.codes[code]);
    const record = { code, ownerId, createdAt: Date.now(), referrals: [] };
    data.guilds[guildId] = record;
    data.codes[code] = guildId;
    writeAmbassadors(data);
    return record;
}

export function findAmbassadorByCode(code) {
    const data = readAmbassadors();
    const guildId = data.codes[String(code || '').trim().toUpperCase()];
    return guildId ? { guildId, ...data.guilds[guildId] } : null;
}

export function addReferral(ambassadorGuildId, referral) {
    const data = readAmbassadors();
    const record = data.guilds[ambassadorGuildId];
    if (!record) return null;
    record.referrals.push(referral);
    writeAmbassadors(data);
    return referral;
}

export function updateReferral(ambassadorGuildId, referredGuildId, patch) {
    const data = readAmbassadors();
    const record = data.guilds[ambassadorGuildId];
    const referral = record?.referrals.find((r) => r.guildId === referredGuildId);
    if (!referral) return false;
    Object.assign(referral, patch);
    writeAmbassadors(data);
    return true;
}

export function listAmbassadors() { return readAmbassadors().guilds; }

/** Tous les guildId déjà parrainés, tous ambassadeurs confondus (anti-doublon). */
export function referredGuildIds() {
    const data = readAmbassadors();
    const set = new Set();
    for (const record of Object.values(data.guilds)) for (const r of record.referrals) set.add(r.guildId);
    return set;
}
