import { EmbedBuilder } from 'discord.js';
import { listErrors, findError } from '../errors/observability.js';
import buildErrorEmbed from '../errors/errorEmbed.js';
import { getGuildConfig } from '../storage.js';
import config from '../config.js';
import { tr } from '../i18n.js';

const PAGE_SIZE = 10;

export default {
    name: 'errors',
    description: "Consulte le journal interne d'erreurs.",
    ownerOnly: true,
    async execute(client, message, args) {
        const errors = listErrors();
        const cfg = getGuildConfig(message.guild.id);
        const prefix = cfg.prefix || config.prefix;

        // +errors ERR-XXXXXXXX -> détail d'une erreur précise
        if (args[0]?.toUpperCase().startsWith('ERR-')) {
            const entry = findError(args[0].toUpperCase());
            if (!entry) return message.reply({ embeds: [buildErrorEmbed('404 Not Found', tr(cfg, `Aucune erreur \`${args[0]}\` trouvée.`, `No error \`${args[0]}\` was found.`))] });
            const embed = new EmbedBuilder()
                .setTitle(' ')
                .setDescription(`# ❌ 〃 ${entry.id}`)
                .setColor(0x000000)
                .addFields(
                    { name: tr(cfg, 'Date', 'Date'), value: `<t:${Math.floor(entry.at / 1000)}:F>`, inline: true },
                    { name: 'Source', value: `\`${entry.source}\``, inline: true },
                    { name: tr(cfg, 'Serveur', 'Server'), value: entry.guildId ? `\`${entry.guildId}\`` : 'N/A', inline: true },
                    { name: 'Message', value: `\`\`\`${(entry.message || 'N/A').slice(0, 1000)}\`\`\`` },
                );
            if (entry.stack) embed.addFields({ name: 'Stack', value: `\`\`\`${entry.stack.slice(0, 950)}\`\`\`` });
            return message.reply({ embeds: [embed] });
        }

        const page = Math.max(1, parseInt(args[0], 10) || 1);
        const start = (page - 1) * PAGE_SIZE;
        const slice = errors.slice(start, start + PAGE_SIZE);
        if (!slice.length) return message.reply({ embeds: [buildErrorEmbed('404 Not Found', tr(cfg, 'Aucune erreur enregistrée sur cette page.', 'No errors are recorded on this page.'))] });

        const lines = slice.map((e) => `\`${e.id}\` • <t:${Math.floor(e.at / 1000)}:R> • \`${e.source}\` — ${(e.message || '').slice(0, 80)}`);
        const embed = new EmbedBuilder()
            .setTitle(' ')
            .setColor(0x000000)
            .setDescription(`# ❌ 〃 ${tr(cfg, "Journal d'erreurs", 'Error log')}\n\n${lines.join('\n')}`)
            .setFooter({ text: tr(cfg, `Page ${page} • ${prefix}errors <id> pour le détail`, `Page ${page} • ${prefix}errors <id> for details`) });
        return message.reply({ embeds: [embed] });
    },
};
