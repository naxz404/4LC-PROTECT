import { getGuildConfig } from '../storage.js';
import { setupPayload } from '../ui.js';

export default {
    name: 'setup',
    description: 'Lance l’installation interactive de 4LC-PROTECT.',
    permissions: ['Administrator'],
    async execute(client, message) {
        return message.reply(setupPayload(getGuildConfig(message.guild.id)));
    },
};
