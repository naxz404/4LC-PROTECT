import { EmbedBuilder } from 'discord.js';
import { getGuildConfig, saveGuildConfig } from '../storage.js';
import { invalidateSettings } from '../antiraid/runtime.js';
import { MODULES, PUNISHMENTS, moduleLabel, punishmentLabel } from '../antiraid/schema.js';
import buildErrorEmbed from '../errors/errorEmbed.js';
import { panelPayload, setupPayload } from '../ui.js';
import config from '../config.js';
import { tr } from '../i18n.js';
import { refreshConfigPanelOnly, rememberLocalizedMessage } from '../localizedMessages.js';

function save(guild, cfg) { saveGuildConfig(guild.id, cfg); invalidateSettings(guild.id); refreshConfigPanelOnly(guild).catch(() => {}); }

function statusEmbed(cfg) {
    const lines = MODULES.map((m) => {
        const on = cfg.enabled[m] ? '🟢' : '⚪';
        const punish = punishmentLabel(cfg.punishments[m] || 'timeout', cfg);
        return `${on} \`${m}\` — ${moduleLabel(m, cfg)} (${tr(cfg, 'sanction', 'punishment')} : ${punish})`;
    });
    return new EmbedBuilder()
        .setTitle(tr(cfg, '🛡️ 4LC-PROTECT — État de la protection', '🛡️ 4LC-PROTECT — Protection status'))
        .setColor(0x6495ed)
        .setDescription(lines.join('\n'))
        .addFields(
            { name: tr(cfg, 'Salon de logs', 'Log channel'), value: cfg.logChannel ? `<#${cfg.logChannel}>` : tr(cfg, 'Non défini', 'Not set'), inline: true },
            { name: tr(cfg, 'Membres en whitelist', 'Exempted members'), value: String(cfg.whitelistedUsers.length), inline: true },
            { name: 'Anti-spam', value: `${cfg.antispam.count} msg / ${cfg.antispam.windowMs / 1000}s → timeout ${cfg.antispam.timeoutMs / 1000}s`, inline: false },
            { name: tr(cfg, 'Anti-lien', 'Anti-link'), value: cfg.antilink.type === 'all' ? tr(cfg, 'Tous les liens', 'All links') : tr(cfg, 'Invitations Discord uniquement', 'Discord invitations only'), inline: true },
            { name: tr(cfg, 'Anti-compte récent', 'Anti-new account'), value: `< ${Math.round(cfg.antitoken.minAccountAgeMs / 60000)} min`, inline: true },
        );
}

export default {
    name: 'protect',
    aliases: ['4lcprotect', '4lc-protect'],
    description: 'Configure la protection anti-raid du serveur.',
    permissions: ['Administrator'],
    async execute(client, message, args) {
        const sub = args.shift()?.toLowerCase();
        const cfg = getGuildConfig(message.guild.id);
        const prefix = cfg.prefix || config.prefix;

        if (sub === 'setup' || sub === 'installation') return message.reply(setupPayload(cfg));
        if (sub === 'panel' || sub === 'panneau') {
            const sent = await message.reply(panelPayload(cfg));
            rememberLocalizedMessage(message.guild.id, sent, 'config');
            return sent;
        }

        if (!sub || sub === 'status') {
            return message.reply({ embeds: [statusEmbed(cfg)] });
        }

        if (sub === 'logs') {
            const channel = message.mentions.channels.first();
            if (!channel?.isTextBased() || channel.isDMBased() || !channel.isSendable()) return message.reply({ embeds: [buildErrorEmbed('400 Bad Request', tr(cfg, `Utilisation : ${prefix}protect logs #salon-textuel`, `Usage: ${prefix}protect logs #text-channel`))] });
            cfg.logChannel = channel.id;
            save(message.guild, cfg);
            return message.reply(tr(cfg, `✅ Salon de logs anti-raid défini sur ${channel}.`, `✅ Anti-raid log channel set to ${channel}.`));
        }

        if (sub === 'on' || sub === 'off') {
            const mod = args[0]?.toLowerCase();
            if (!MODULES.includes(mod)) {
                return message.reply({ embeds: [buildErrorEmbed('404 Not Found', tr(cfg, `Module inconnu. Modules disponibles : ${MODULES.join(', ')}`, `Unknown module. Available modules: ${MODULES.join(', ')}`))] });
            }
            cfg.enabled[mod] = sub === 'on';
            save(message.guild, cfg);
            return message.reply(tr(cfg, `✅ \`${mod}\` (${moduleLabel(mod, cfg)}) ${sub === 'on' ? 'activé' : 'désactivé'}.`, `✅ \`${mod}\` (${moduleLabel(mod, cfg)}) ${sub === 'on' ? 'enabled' : 'disabled'}.`));
        }

        if (sub === 'punish') {
            const mod = args[0]?.toLowerCase();
            const punishment = args[1]?.toLowerCase();
            if (!MODULES.includes(mod)) {
                return message.reply({ embeds: [buildErrorEmbed('404 Not Found', tr(cfg, `Module inconnu. Modules disponibles : ${MODULES.join(', ')}`, `Unknown module. Available modules: ${MODULES.join(', ')}`))] });
            }
            if (!PUNISHMENTS.includes(punishment) && punishment !== 'none') {
                return message.reply({ embeds: [buildErrorEmbed('400 Bad Request', tr(cfg, `Sanction invalide. Choix : ${[...PUNISHMENTS, 'none'].join(', ')}`, `Invalid punishment. Choices: ${[...PUNISHMENTS, 'none'].join(', ')}`))] });
            }
            cfg.punishments[mod] = punishment;
            save(message.guild, cfg);
            return message.reply(tr(cfg, `✅ Sanction de \`${mod}\` définie sur **${punishmentLabel(punishment, cfg)}**.`, `✅ Punishment for \`${mod}\` set to **${punishmentLabel(punishment, cfg)}**.`));
        }

        if (sub === 'whitelist') {
            const action = args.shift()?.toLowerCase();
            if (action === 'list') {
                const list = cfg.whitelistedUsers.length ? cfg.whitelistedUsers.map((id) => `<@${id}>`).join(', ') : tr(cfg, 'Aucun membre.', 'No members.');
                return message.reply(`**${tr(cfg, 'Whitelist anti-raid', 'Anti-raid exemptions')} :** ${list}`);
            }
            const target = message.mentions.users.first();
            if (!target || !['add', 'remove'].includes(action)) {
                return message.reply({ embeds: [buildErrorEmbed('400 Bad Request', tr(cfg, `Utilisation : ${prefix}protect whitelist add|remove @membre`, `Usage: ${prefix}protect whitelist add|remove @member`))] });
            }
            if (action === 'add') {
                if (!cfg.whitelistedUsers.includes(target.id)) cfg.whitelistedUsers.push(target.id);
            } else {
                cfg.whitelistedUsers = cfg.whitelistedUsers.filter((id) => id !== target.id);
            }
            save(message.guild, cfg);
            return message.reply(tr(cfg, `✅ ${target} ${action === 'add' ? 'ajouté à' : 'retiré de'} la whitelist.`, `✅ ${target} ${action === 'add' ? 'added to' : 'removed from'} the exemption list.`));
        }

        if (sub === 'externalapp' || sub === 'appexterne') {
            const action = args.shift()?.toLowerCase();
            const list = cfg.userAppsWhitelist || [];
            if (action === 'list' || action === 'liste') {
                return message.reply(`**${tr(cfg, 'Applications externes autorisées', 'Allowed external apps')} :** ${list.length ? list.map((id) => `\`${id}\``).join(', ') : tr(cfg, 'aucune', 'none')}`);
            }
            const appId = args[0];
            if (!['add', 'remove'].includes(action) || !/^\d{5,25}$/.test(appId || '')) {
                return message.reply({ embeds: [buildErrorEmbed('400 Bad Request', tr(cfg, `Utilisation : ${prefix}protect externalapp add|remove|list <id application>`, `Usage: ${prefix}protect externalapp add|remove|list <application id>`))] });
            }
            cfg.userAppsWhitelist = action === 'add' ? [...new Set([...list, appId])] : list.filter((id) => id !== appId);
            save(message.guild, cfg);
            return message.reply(tr(cfg, `✅ Application \`${appId}\` ${action === 'add' ? 'ajoutée à la liste (la permission Discord bloque toujours ses réponses publiques tant qu’Anti-Bot ou Anti-App externe est actif)' : 'retirée de la liste'}.`, `✅ Application \`${appId}\` ${action === 'add' ? 'added to the list (Discord permissions still block its public replies while Anti-Bot or Anti-External-App is enabled)' : 'removed from the list'}.`));
        }

        if (sub === 'antispam') {
            const count = parseInt(args[0], 10);
            const seconds = parseInt(args[1], 10);
            if (!Number.isInteger(count) || count < 2 || count > 100 || !Number.isInteger(seconds) || seconds < 2 || seconds > 3600) {
                return message.reply({ embeds: [buildErrorEmbed('400 Bad Request', tr(cfg, `Utilisation : ${prefix}protect antispam <2–100 messages> <2–3600 secondes>`, `Usage: ${prefix}protect antispam <2–100 messages> <2–3600 seconds>`))] });
            }
            cfg.antispam.count = count;
            cfg.antispam.windowMs = seconds * 1000;
            save(message.guild, cfg);
            return message.reply(tr(cfg, `✅ Anti-spam réglé sur ${count} messages / ${seconds}s.`, `✅ Anti-spam set to ${count} messages / ${seconds}s.`));
        }

        if (sub === 'antilink') {
            const type = args[0]?.toLowerCase();
            if (!['invite', 'all'].includes(type)) {
                return message.reply({ embeds: [buildErrorEmbed('400 Bad Request', `Utilisation : ${prefix}protect antilink invite|all`)] });
            }
            cfg.antilink.type = type;
            save(message.guild, cfg);
            return message.reply(tr(cfg, `✅ Anti-lien réglé sur \`${type}\`.`, `✅ Anti-link set to \`${type}\`.`));
        }

        if (sub === 'antitoken') {
            const minutes = parseInt(args[0], 10);
            if (!Number.isInteger(minutes) || minutes < 0 || minutes > 525600) {
                return message.reply({ embeds: [buildErrorEmbed('400 Bad Request', `Utilisation : ${prefix}protect antitoken <0–525600 minutes>`)] });
            }
            cfg.antitoken.minAccountAgeMs = minutes * 60_000;
            save(message.guild, cfg);
            return message.reply(tr(cfg, `✅ Âge minimum du compte réglé sur ${minutes} minute(s).`, `✅ Minimum account age set to ${minutes} minute(s).`));
        }

        return message.reply({
            embeds: [buildErrorEmbed('400 Bad Request', tr(cfg, `Sous-commande inconnue. Voir ${prefix}help pour la liste complète.\nModules : ${MODULES.map((m) => `\`${m}\``).join(', ')}`, `Unknown subcommand. See ${prefix}help for the complete list.\nModules: ${MODULES.map((m) => `\`${m}\``).join(', ')}`))],
        });
    },
};
