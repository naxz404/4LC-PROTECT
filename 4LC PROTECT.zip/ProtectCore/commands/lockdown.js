import { ChannelType } from 'discord.js';
import { lockChannels, lockSuccessEmbed } from '../lockdown.js';
import { getGuildConfig } from '../storage.js';
import { tr } from '../i18n.js';

export default {
    name: 'lock',
    aliases: [],
    description: "Verrouille le salon actuel et sauvegarde ses permissions.",
    permissions: ['ManageChannels'],
    async execute(client, message, args) {
        const cfg = getGuildConfig(message.guild.id);
        if (message.channel.type !== ChannelType.GuildText) return message.reply(tr(cfg, 'Cette commande doit être utilisée dans un salon texte.', 'This command must be used in a text channel.'));
        const result = await lockChannels(message.guild, [message.channel], message.author.id, args.join(' '));
        const detail = result.details[0];
        if (!detail) return message.reply(tr(cfg, 'Ce salon est déjà verrouillé ou ne peut pas être modifié.', 'This channel is already locked or cannot be changed.'));
        return message.reply({ embeds: [lockSuccessEmbed(message.channel, detail, cfg)] });
    },
};
