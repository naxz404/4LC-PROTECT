import { ChannelType } from 'discord.js';
import { renewChannel, renewSuccessEmbed } from '../lockdown.js';
import { getGuildConfig } from '../storage.js';
import { tr } from '../i18n.js';

export default {
    name: 'renew',
    description: "Recrée le salon actuel avec les mêmes paramètres et permissions.",
    permissions: ['ManageChannels'],
    async execute(_client, message) {
        const cfg = getGuildConfig(message.guild.id);
        if (message.channel.type !== ChannelType.GuildText) return message.reply(tr(cfg, 'Cette commande doit être utilisée dans un salon texte.', 'This command must be used in a text channel.'));
        const channel = await renewChannel(message.channel, message.author.id);
        return channel.send({ embeds: [renewSuccessEmbed(cfg)] });
    },
};
