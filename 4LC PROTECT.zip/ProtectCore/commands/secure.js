import { getGuildConfig } from '../storage.js';
import { updateSecureMember } from '../secureMembers.js';
import { isGuildOwner, accessDenied } from '../protectionAccess.js';
import { tr } from '../i18n.js';

export default ['secure', 'unsecure'].map((name) => ({
    name,
    async execute(_client, message, args) {
        const cfg = getGuildConfig(message.guild.id);
        if (!isGuildOwner(message.guild, message.author.id)) return message.reply(accessDenied('owner', cfg));
        if (name === 'secure' && (!args.length || ['list', 'liste'].includes(args[0]?.toLowerCase()))) {
            const list = cfg.secureUsers.map((id) => `<@${id}>`).join(', ') || tr(cfg, 'Aucun membre.', 'No members.');
            return message.reply({ content: `**Liste Secure**\n${list}`.slice(0, 1950), allowedMentions: { parse: [], repliedUser: false } });
        }
        const userId = args[0]?.replace(/^<@!?(\d+)>$/, '$1');
        try {
            await updateSecureMember(message.guild, message.author.id, userId, name === 'unsecure');
            return message.reply({ content: tr(cfg, `✅ <@${userId}> ${name === 'secure' ? 'ajouté à' : 'retiré de'} la liste Secure.`, `✅ <@${userId}> ${name === 'secure' ? 'added to' : 'removed from'} the Secure list.`), allowedMentions: { parse: [], repliedUser: false } });
        } catch (error) { return message.reply({ content: error.message, allowedMentions: { parse: [], repliedUser: false } }); }
    },
}));
