import { getGuildConfig, saveGuildConfig } from '../storage.js';
import { invalidateSettings } from '../antiraid/runtime.js';
import { MODULES } from '../antiraid/schema.js';
import { primeAntiNukeGuild } from '../antinuke.js';
import { syncExternalAppPermissions } from '../externalAppPermissions.js';
export default {
    name: 'allanti', description: 'Active toutes les protections avec leurs réglages actuels.',
    async execute(_client, message) {
        const cfg = getGuildConfig(message.guild.id);
        for (const name of MODULES) cfg.enabled[name] = true;
        cfg.autoRaid.enabled = true;
        cfg.antiNuke.enabled = true;
        cfg.phishing.enabled = true;
        cfg.ghostPing.enabled = true;
        cfg.warningSystem.enabled = true;
        cfg.antiAlt.enabled = true;
        primeAntiNukeGuild(message.guild);
        saveGuildConfig(message.guild.id, cfg);
        invalidateSettings(message.guild.id);
        const result = await syncExternalAppPermissions(message.guild).catch(error => ({ failed: [error.message] }));
        return message.reply(`✅ Toutes les protections ont été activées.${result.failed.length ? `\n⚠️ Blocage des applications partiel : ${result.failed.slice(0,3).join(', ')}` : ''}`);
    },
};
