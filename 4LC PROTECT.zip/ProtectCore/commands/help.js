import { helpPayload } from '../helpEmbed.js';
import { getGuildConfig } from '../storage.js';
import { rememberLocalizedMessage } from '../localizedMessages.js';

export default {
    name: 'help',
    description: 'Affiche les commandes disponibles.',
    async execute(client, message, args) {
        const sent = await message.reply(helpPayload(getGuildConfig(message.guild.id), message.author, args[0]));
        if (!args[0]) rememberLocalizedMessage(message.guild.id, sent, 'help');
        return sent;
    },
};
