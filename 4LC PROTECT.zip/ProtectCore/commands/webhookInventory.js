import { getGuildConfig, listIncidents } from '../storage.js';
import { tr } from '../i18n.js';

export default {
    name: 'webhooks', permissions: ['ManageWebhooks'],
    async execute(_client, message) {
        const cfg = getGuildConfig(message.guild.id);
        const hooks = await message.guild.fetchWebhooks().catch(() => null);
        if (!hooks) return message.reply(tr(cfg, 'Impossible de lire les webhooks (permission Gérer les webhooks requise pour le bot).', 'Could not fetch webhooks (bot needs Manage Webhooks).'));
        const rows = [...hooks.values()].slice(0, 35).map((hook) => `• \`${hook.id}\` **${hook.name?.slice(0, 50) || 'Sans nom'}** · <#${hook.channelId}>`);
        const changes = listIncidents(message.guild.id).filter((row) => row.type === 'webhook').slice(0, 5)
            .map((row) => `• <t:${Math.floor(row.at / 1000)}:R> · ${row.action} · <@${row.userId}> · <#${row.channelId}>`);
        return message.reply({ content: `${tr(cfg, 'Webhooks capables de publier', 'Webhooks able to post')} (${hooks.size}) :\n${rows.join('\n') || 'Aucun / None'}\n\n${tr(cfg, 'Changements récents', 'Recent changes')} :\n${changes.join('\n') || 'Aucun / None'}`.slice(0, 1900), allowedMentions: { parse: [] } });
    },
};
