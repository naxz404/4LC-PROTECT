import { unlockChannels, unlockSuccessEmbed } from '../lockdown.js';
import { getGuildConfig } from '../storage.js';
import { tr } from '../i18n.js';

export default {
    name: 'unlock',
    description: 'Restaure les salons verrouillés par le bot.',
    permissions: ['ManageChannels'],
    async execute(client, message, args) {
        const cfg = getGuildConfig(message.guild.id);
        if (!cfg.lockSnapshot || !Object.hasOwn(cfg.lockSnapshot, message.channel.id)) return message.reply(tr(cfg, 'Aucun verrouillage enregistré pour ce salon.', 'No saved lock exists for this channel.'));
        const result = await unlockChannels(message.guild, message.channel.id, message.author.id, args.join(' '));
        const detail = result.details[0];
        if (!detail) return message.reply(tr(cfg, 'Impossible de restaurer les permissions de ce salon.', 'Could not restore this channel permissions.'));
        return message.reply({ embeds: [unlockSuccessEmbed(message.channel, detail, cfg)] });
    },
};
