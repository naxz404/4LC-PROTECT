// Mesures volatiles depuis le dernier démarrage : aucune donnée membre conservée.
const events = new Map();
const rateLimits = new Map();
const responses429 = new Map();
const MAX_AGE = 60 * 60_000;

export function recordRateLimit(info, now = Date.now()) {
    const route = String(info?.route || info?.path || 'inconnu').slice(0, 160);
    const bucket = String(info?.hash || info?.bucket || 'inconnu').slice(0, 80);
    const key = `${info?.method || 'REST'} ${route}`;
    const row = rateLimits.get(key) || { count: 0, lastAt: null, bucket, retryAfter: null };
    row.count++; row.lastAt = now; row.bucket = bucket; row.retryAfter = info?.retryAfter ?? null;
    rateLimits.set(key, row);
    if (rateLimits.size > 50) rateLimits.delete(rateLimits.keys().next().value);
}
export function rateLimitMetrics() {
    const endpoints = [...rateLimits].map(([route, value]) => ({ route, ...value })).sort((a, b) => b.count - a.count);
    const errors = [...responses429].map(([route, value]) => ({ route, ...value })).sort((a, b) => b.count - a.count);
    return { count: endpoints.reduce((sum, row) => sum + row.count, 0), endpoints, responses429: errors.reduce((sum, row) => sum + row.count, 0), errors };
}
export function recordRestResponse(info, response, now = Date.now()) {
    if (response?.status !== 429) return;
    const route = `${info?.method || 'REST'} ${info?.route || info?.path || 'inconnu'}`.slice(0, 180);
    const row = responses429.get(route) || { count: 0, lastAt: null };
    row.count++; row.lastAt = now; responses429.set(route, row);
}

export function recordGuildEvent(guildId, name, now = Date.now()) {
    if (!guildId) return;
    const state = events.get(guildId) || { buckets: new Map(), lastAt: 0 };
    const minute = Math.floor(now / 60_000) * 60_000;
    const counts = state.buckets.get(minute) || {};
    counts[name] = (counts[name] || 0) + 1;
    state.buckets.set(minute, counts);
    state.lastAt = now;
    for (const start of state.buckets.keys()) if (start < minute - MAX_AGE) state.buckets.delete(start);
    events.set(guildId, state);
}

export function guildEventMetrics(guildId, now = Date.now()) {
    const state = events.get(guildId);
    if (!state) return { count: 0, lastAt: null, byName: {} };
    const byName = {};
    for (const [minute, counts] of state.buckets) {
        if (minute < now - MAX_AGE) continue;
        for (const [name, count] of Object.entries(counts)) byName[name] = (byName[name] || 0) + count;
    }
    return { count: Object.values(byName).reduce((sum, count) => sum + count, 0), lastAt: state.lastAt, byName };
}
