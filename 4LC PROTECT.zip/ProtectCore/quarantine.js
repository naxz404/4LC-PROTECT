import { ActionRowBuilder, ButtonBuilder, ButtonStyle, ChannelType, EmbedBuilder, PermissionFlagsBits } from 'discord.js';
import { getGuildConfig, saveGuildConfig } from './storage.js';
import { invalidateSettings } from './antiraid/runtime.js';
import { BLUE } from './ui.js';
import { tr } from './i18n.js';

async function ensureJail(guild, cfg) {
    const me = guild.members.me || await guild.members.fetchMe();
    if (!me.permissions.has(PermissionFlagsBits.ManageRoles) || !me.permissions.has(PermissionFlagsBits.ManageChannels)) return null;
    let role = cfg.jail.roleId ? guild.roles.cache.get(cfg.jail.roleId) : null;
    if (!role) role = guild.roles.cache.find((item) => item.name === '4LC-PROTECT Jail' && !item.managed) || await guild.roles.create({ name: '4LC-PROTECT Jail', permissions: [], color: 0x6495ed, reason: 'Quarantaine 4LC-PROTECT' });
    let channel = cfg.jail.channelId ? guild.channels.cache.get(cfg.jail.channelId) : null;
    if (!channel) channel = await guild.channels.create({
        name: '4lcprotect-jail', type: ChannelType.GuildText, reason: 'Quarantaine 4LC-PROTECT',
        permissionOverwrites: [
            { id: guild.id, deny: [PermissionFlagsBits.ViewChannel] },
            { id: role.id, allow: [PermissionFlagsBits.ViewChannel, PermissionFlagsBits.SendMessages, PermissionFlagsBits.ReadMessageHistory] },
            { id: me.id, allow: [PermissionFlagsBits.ViewChannel, PermissionFlagsBits.SendMessages, PermissionFlagsBits.ManageMessages] },
        ],
    });
    for (const item of guild.channels.cache.values()) {
        if (item.id === channel.id || item.isThread?.() || !item.permissionOverwrites?.edit) continue;
        await item.permissionOverwrites.edit(role.id, { ViewChannel: false, SendMessages: false }, { reason: 'Isolation du rôle Jail 4LC-PROTECT' }).catch(() => {});
    }
    cfg.jail.roleId = role.id; cfg.jail.channelId = channel.id; saveGuildConfig(guild.id, cfg); invalidateSettings(guild.id);
    return { role, channel };
}

export async function quarantineMember(client, member, module, reason) {
    const cfg = getGuildConfig(member.guild.id); const jail = await ensureJail(member.guild, cfg);
    if (!jail || !member.manageable || member.id === member.guild.ownerId) return { applied: false, note: 'quarantaine impossible' };
    cfg.jail.quarantines ||= [];
    const roleIds = member.roles.cache.filter((role) => role.id !== member.guild.id && !role.managed && role.editable).map((role) => role.id);
    if (roleIds.length) await member.roles.remove(roleIds, reason).catch(() => {});
    await member.roles.add(jail.role, reason);
    cfg.jail.quarantines = cfg.jail.quarantines.filter((entry) => entry.userId !== member.id);
    cfg.jail.quarantines.push({ userId: member.id, roleIds, module, reason, at: Date.now(), status: 'pending' });
    saveGuildConfig(member.guild.id, cfg); invalidateSettings(member.guild.id);
    const log = cfg.logChannel ? await member.guild.channels.fetch(cfg.logChannel).catch(() => null) : null;
    if (log?.isSendable()) {
        const embed = new EmbedBuilder().setColor(BLUE).setTitle(tr(cfg, 'Quarantaine intelligente', 'Smart quarantine')).setDescription(`${member} · **${module}**\n${reason}\n\n${tr(cfg, 'Le staff doit choisir une décision.', 'Staff must choose a decision.')}`);
        const row = new ActionRowBuilder().addComponents(
            new ButtonBuilder().setCustomId(`sar:quarantine:allow:${member.id}`).setLabel(tr(cfg, 'Autoriser', 'Allow')).setStyle(ButtonStyle.Success),
            new ButtonBuilder().setCustomId(`sar:quarantine:kick:${member.id}`).setLabel(tr(cfg, 'Expulser', 'Kick')).setStyle(ButtonStyle.Secondary),
            new ButtonBuilder().setCustomId(`sar:quarantine:ban:${member.id}`).setLabel(tr(cfg, 'Bannir', 'Ban')).setStyle(ButtonStyle.Danger),
        );
        await log.send({ embeds: [embed], components: [row] }).catch(() => {});
    }
    return { applied: true, effectivePunishment: 'jail', note: 'quarantaine' };
}

export async function resolveQuarantine(guild, userId, action, actorId) {
    const cfg = getGuildConfig(guild.id); const entry = (cfg.jail.quarantines || []).find((item) => item.userId === userId && item.status === 'pending');
    if (!entry) return { ok: false, note: 'introuvable' };
    const member = await guild.members.fetch(userId).catch(() => null); const jailRole = guild.roles.cache.get(cfg.jail.roleId);
    if (action === 'allow' && member) {
        if (jailRole) await member.roles.remove(jailRole, `Autorisé par ${actorId}`).catch(() => {});
        const roles = entry.roleIds.map((id) => guild.roles.cache.get(id)).filter((role) => role?.editable);
        if (roles.length) await member.roles.add(roles, `Quarantaine levée par ${actorId}`).catch(() => {});
    } else if (action === 'kick' && member?.kickable) await member.kick(`Décision de quarantaine par ${actorId}`);
    else if (action === 'ban' && (member?.bannable || !member)) await guild.members.ban(userId, { reason: `Décision de quarantaine par ${actorId}` });
    else return { ok: false, note: 'action impossible' };
    entry.status = action; entry.resolvedAt = Date.now(); entry.resolvedBy = actorId; saveGuildConfig(guild.id, cfg); invalidateSettings(guild.id);
    return { ok: true, action };
}
