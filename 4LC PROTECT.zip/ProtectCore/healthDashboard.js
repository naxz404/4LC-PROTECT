import { EmbedBuilder, PermissionFlagsBits } from 'discord.js';
import { listServerBackups } from './serverBackup.js';
import { guildEventMetrics, rateLimitMetrics } from './healthMetrics.js';
import { logDeliveryMetrics } from './antiraid/logs.js';

const required = [
    ['Voir le journal d’audit', 'View Audit Log', PermissionFlagsBits.ViewAuditLog],
    ['Gérer les salons', 'Manage Channels', PermissionFlagsBits.ManageChannels],
    ['Gérer les rôles', 'Manage Roles', PermissionFlagsBits.ManageRoles],
    ['Gérer les messages', 'Manage Messages', PermissionFlagsBits.ManageMessages],
    ['Bannir', 'Ban Members', PermissionFlagsBits.BanMembers],
    ['Expulser', 'Kick Members', PermissionFlagsBits.KickMembers],
    ['Modérer', 'Moderate Members', PermissionFlagsBits.ModerateMembers],
    ['Gérer les webhooks', 'Manage Webhooks', PermissionFlagsBits.ManageWebhooks],
];
const time = (value) => value ? `<t:${Math.floor(value / 1000)}:R>` : '—';

export async function healthPayload(client, guild, cfg, now = Date.now()) {
    const en = cfg.language === 'en';
    const me = guild.members.me || await guild.members.fetchMe().catch(() => null);
    const missing = me ? required.filter(([, , flag]) => !me.permissions.has(flag)).map(([fr, english]) => en ? english : fr) : [];
    const events = guildEventMetrics(guild.id, now);
    const limits = rateLimitMetrics();
    const logs = logDeliveryMetrics(guild.id);
    const channel = cfg.logChannel ? (guild.channels.cache.get(cfg.logChannel) || await guild.channels.fetch(cfg.logChannel).catch(() => null)) : null;
    const channelPermissions = channel && me ? channel.permissionsFor(me) : null;
    const channelRequired = [
        [en ? 'View Channel' : 'Voir le salon', PermissionFlagsBits.ViewChannel],
        [en ? 'Send Messages' : 'Envoyer des messages', PermissionFlagsBits.SendMessages],
        [en ? 'Embed Links' : 'Intégrer des liens', PermissionFlagsBits.EmbedLinks],
        [en ? 'Attach Files' : 'Joindre des fichiers', PermissionFlagsBits.AttachFiles],
    ];
    const channelMissing = channelPermissions ? channelRequired.filter(([, flag]) => !channelPermissions.has(flag)).map(([label]) => label) : [];
    const logReady = Boolean(channel?.isTextBased?.() && channel?.isSendable?.() && channelPermissions && !channelMissing.length);
    const backups = listServerBackups(guild.ownerId).filter((entry) => entry.sourceGuildId === guild.id);
    const externalAppsActive = cfg.enabled.antibot || cfg.enabled.antiuserapps;
    const openExternalAppRoles = externalAppsActive ? guild.roles.cache.filter((role) => role.permissions.has(PermissionFlagsBits.UseExternalApps)).map((role) => role.name).slice(0, 5) : [];
    const automatic = backups.find((entry) => entry.automatic);
    const manual = backups.filter((entry) => !entry.automatic).length;
    const lastLog = !logs.lastAt ? (en ? 'no measurement yet' : 'aucune mesure') :
        `${logs.lastSuccess ? '✅' : '❌'} ${logs.lastDurationMs === null ? '—' : `${logs.lastDurationMs} ms`} · ${time(logs.lastAt)}`;
    const embed = new EmbedBuilder().setColor(missing.length || !logReady || !automatic ? 0xf1c40f : 0x6495ed)
        .setTitle(en ? '🩺 4LC-PROTECT · Health' : '🩺 4LC-PROTECT · Diagnostic')
        .addFields(
            { name: en ? 'Permissions' : 'Permissions', value: !me ? (en ? 'Bot member unavailable' : 'Membre du bot inaccessible') : missing.length ? `⚠️ ${missing.join(' · ')}` : (en ? '✅ Required permissions present' : '✅ Permissions requises présentes') },
            { name: en ? 'Events · about 1 hour' : 'Événements · environ 1 h', value: `${events.count} ${en ? 'received' : 'reçus'} · ${en ? 'last' : 'dernier'} ${time(events.lastAt)}\n${Object.entries(events.byName).sort((a, b) => b[1] - a[1]).slice(0, 4).map(([name, count]) => `${name} ${count}`).join(' · ') || '—'}` },
            { name: 'Logs', value: `${logReady ? '✅' : '⚠️'} ${channel ? `<#${channel.id}>` : (en ? 'channel unavailable' : 'salon indisponible')}${channelMissing.length ? ` · ${en ? 'Missing' : 'Manque'} : ${channelMissing.join(', ')}` : ''}\n${en ? 'Last send' : 'Dernier envoi'} : ${lastLog} · ${en ? 'Queue' : 'File'} : ${logs.queued}` },
            { name: en ? 'Backups' : 'Sauvegardes', value: `${en ? 'Automatic' : 'Auto'} : ${automatic ? `✅ ${time(automatic.createdAt)}` : '⚠️ —'} · ${en ? 'Manual' : 'Manuelles'} : ${manual}` },
            { name: en ? 'External apps' : 'Applications externes', value: !externalAppsActive ? (en ? 'Protection disabled' : 'Protection désactivée') : openExternalAppRoles.length ? `⚠️ ${en ? 'Permission still active on' : 'Permission encore active sur'} : ${openExternalAppRoles.join(', ')}` : (en ? '✅ Public replies blocked by permissions' : '✅ Réponses publiques bloquées par permissions') },
            { name: en ? 'REST rate limits' : 'Limites REST', value: `${limits.responses429} réponses 429 · ${limits.count} attentes de limite\n${limits.errors.slice(0, 3).map((row) => `${row.route}: ${row.count} · ${en ? 'last' : 'dernier'} ${time(row.lastAt)}`).join('\n') || limits.endpoints.slice(0, 2).map((row) => `${row.route}: ${row.count} attente(s)`).join('\n') || '—'}` },
        )
        .setFooter({ text: en ? 'Events and log timings are measured since startup.' : 'Événements et délais des logs mesurés depuis le démarrage.' });
    return { embeds: [embed] };
}
