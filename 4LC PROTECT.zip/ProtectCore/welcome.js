import { ActionRowBuilder, ButtonBuilder, ButtonStyle, EmbedBuilder, StringSelectMenuBuilder } from 'discord.js';
import { supportUrl } from './config.js';
import { tr } from './i18n.js';
import { emojiText, emojiComponent } from './appEmojis.js';

export function welcomeLanguageSelect() {
    return new StringSelectMenuBuilder().setCustomId('sar:welcome:language:set').setPlaceholder('🌐 Langue / Language').addOptions(
        { label: 'Français', value: 'fr', emoji: '🇫🇷' },
        { label: 'English', value: 'en', emoji: '🇬🇧' },
    );
}

export function welcomePayload(cfg = {}) {
    const embed = new EmbedBuilder().setColor(0x6495ed).setTitle(`${emojiText('verified', '💙')} ${tr(cfg, 'Merci d’avoir ajouté 4LC-PROTECT', 'Thanks for adding 4LC-PROTECT')}`).setDescription(
        tr(cfg,
            '**4LC-PROTECT est maintenant prêt à protéger votre serveur.**\n\n' +
            'Ce salon devient votre journal de sécurité par défaut. Le rôle **Unverified** est créé automatiquement pour le CAPTCHA. Les détections anti-raid, les actions automatiques et les alertes importantes seront envoyées ici.\n\n' +
            'Commencez avec **Configurer** pour choisir les protections, puis placez le rôle de 4LC-PROTECT suffisamment haut pour gérer les membres et les rôles ciblés.\n\n' +
            'Choisissez votre langue ci-dessous 🌐',
            '**4LC-PROTECT is now ready to protect your server.**\n\n' +
            'This channel becomes your default security log. The **Unverified** role is created automatically for the CAPTCHA. Anti-raid detections, automatic actions and important alerts will be sent here.\n\n' +
            'Start with **Setup** to choose your protections, then place the 4LC-PROTECT role high enough to manage targeted members and roles.\n\n' +
            'Choose your language below 🌐',
        ),
    );
    const setup = new ButtonBuilder().setCustomId('sar:welcome:setup').setLabel(tr(cfg, 'Configurer', 'Setup')).setEmoji(emojiComponent('admin', '⚙️')).setStyle(ButtonStyle.Primary);
    const logs = new ButtonBuilder().setCustomId('sar:welcome:logs').setLabel(tr(cfg, 'Changer le salon de logs', 'Change log channel')).setEmoji(emojiComponent('role', '#️⃣')).setStyle(ButtonStyle.Secondary);
    const support = new ButtonBuilder().setStyle(ButtonStyle.Link).setURL(supportUrl).setLabel(tr(cfg, 'Serveur Support', 'Support Server')).setEmoji(emojiComponent('ticket', '💬'));
    return {
        embeds: [embed],
        components: [
            new ActionRowBuilder().addComponents(setup, logs, support),
            new ActionRowBuilder().addComponents(welcomeLanguageSelect()),
        ],
    };
}
