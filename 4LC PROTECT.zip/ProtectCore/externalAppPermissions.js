import { PermissionFlagsBits } from 'discord.js';
import { getGuildConfig, saveGuildConfig } from './storage.js';

const bit = PermissionFlagsBits.UseExternalApps;
const locks = new Map();
const active = (cfg) => Boolean(cfg.enabled.antibot || cfg.enabled.antiuserapps);
async function runLimited(jobs) {
    let next = 0;
    await Promise.all(Array.from({ length: Math.min(3, jobs.length) }, async () => {
        while (next < jobs.length) await jobs[next++]();
    }));
}
export function syncExternalAppPermissions(guild) {
    const prior = locks.get(guild.id) || Promise.resolve();
    const current = prior.catch(() => {}).then(() => synchronize(guild));
    locks.set(guild.id, current);
    void current.finally(() => { if (locks.get(guild.id) === current) locks.delete(guild.id); }).catch(() => {});
    return current;
}
async function synchronize(guild) {
    const cfg = getGuildConfig(guild.id), result = { changed: 0, restored: 0, failed: [] };
    const finish = () => ({ ...result, complete: result.failed.length === 0 });
    if (!active(cfg) && !cfg.externalAppPermissionSnapshot?.length && !cfg.externalAppOverwriteSnapshot?.length) return finish();
    const me = guild.members.me || await guild.members.fetchMe().catch(() => null);
    if (!me?.permissions.has(PermissionFlagsBits.ManageRoles)) { result.failed.push('Permission Gérer les rôles manquante'); return finish(); }
    cfg.externalAppPermissionSnapshot ||= [];
    cfg.externalAppOverwriteSnapshot ||= [];
    const jobs = [];
    if (active(cfg)) {
        let newSnapshot = false;
        for (const role of guild.roles.cache.values()) {
            if (!role.permissions.has(bit) || role.permissions.has(PermissionFlagsBits.Administrator)) continue;
            if (role.managed || (role.id !== guild.id && !role.editable)) { result.failed.push(`${role.name} : rôle non modifiable`); continue; }
            const before = role.permissions.bitfield, after = before & ~bit;
            if (!cfg.externalAppPermissionSnapshot.some((row) => row.id === role.id)) {
                cfg.externalAppPermissionSnapshot.push({ id: role.id, before: String(before), after: String(after) }); newSnapshot = true;
            }
            jobs.push(async () => { try { await role.setPermissions(after, '4LC-PROTECT : bloquer les applications externes'); result.changed++; } catch { result.failed.push(`${role.name} : modification refusée`); } });
        }
        for (const channel of guild.channels?.cache?.values?.() || []) for (const overwrite of channel.permissionOverwrites?.cache?.values?.() || []) {
            if (!overwrite.allow.has(bit)) continue;
            if (!channel.permissionOverwrites?.edit) { result.failed.push(`${channel.name} : permissions de salon non modifiables`); continue; }
            const beforeAllow = overwrite.allow.bitfield, beforeDeny = overwrite.deny.bitfield;
            const afterAllow = beforeAllow & ~bit, afterDeny = beforeDeny | bit;
            if (!cfg.externalAppOverwriteSnapshot.some((row) => row.channelId === channel.id && row.id === overwrite.id)) {
                cfg.externalAppOverwriteSnapshot.push({ channelId: channel.id, id: overwrite.id, type: overwrite.type, beforeAllow: String(beforeAllow), beforeDeny: String(beforeDeny), afterAllow: String(afterAllow), afterDeny: String(afterDeny) }); newSnapshot = true;
            }
            jobs.push(async () => { try { await channel.permissionOverwrites.edit(overwrite.id, { UseExternalApps: false }, { type: overwrite.type, reason: '4LC-PROTECT : bloquer les applications externes' }); result.changed++; } catch { result.failed.push(`${channel.name} : exception de salon non modifiable`); } });
        }
        // Une seule écriture durable, avant les appels Discord.
        if (newSnapshot) saveGuildConfig(guild.id, cfg);
        await runLimited(jobs);
    } else {
        const doneRoles = new Set(), doneOverwrites = new Set();
        for (const saved of cfg.externalAppPermissionSnapshot) jobs.push(async () => {
            const role = guild.roles.cache.get(saved.id);
            if (!role) { result.failed.push(`${saved.id} : rôle introuvable`); return; }
            if (role.permissions.bitfield === BigInt(saved.before)) { doneRoles.add(saved.id); return; }
            if (role.permissions.bitfield !== BigInt(saved.after)) { result.failed.push(`${role.name} : permissions changées depuis le blocage`); return; }
            if (role.id !== guild.id && !role.editable) { result.failed.push(`${role.name} : rôle non modifiable`); return; }
            try { await role.setPermissions(BigInt(saved.before), '4LC-PROTECT : restaurer les applications externes'); result.restored++; doneRoles.add(saved.id); }
            catch { result.failed.push(`${role.name} : restauration refusée`); }
        });
        for (const saved of cfg.externalAppOverwriteSnapshot) jobs.push(async () => {
            const key = `${saved.channelId}:${saved.id}`, channel = guild.channels?.cache?.get?.(saved.channelId);
            const overwrite = channel?.permissionOverwrites?.cache?.get?.(saved.id);
            if (!overwrite) { result.failed.push(`${saved.channelId} : exception introuvable`); return; }
            if (overwrite.allow.bitfield === BigInt(saved.beforeAllow) && overwrite.deny.bitfield === BigInt(saved.beforeDeny)) { doneOverwrites.add(key); return; }
            if (overwrite.allow.bitfield !== BigInt(saved.afterAllow) || overwrite.deny.bitfield !== BigInt(saved.afterDeny)) { result.failed.push(`${channel.name} : exception modifiée depuis le blocage`); return; }
            try { await channel.permissionOverwrites.edit(saved.id, { UseExternalApps: true }, { type: saved.type, reason: '4LC-PROTECT : restaurer les exceptions' }); result.restored++; doneOverwrites.add(key); }
            catch { result.failed.push(`${channel.name} : restauration de l'exception refusée`); }
        });
        await runLimited(jobs);
        if (doneRoles.size || doneOverwrites.size) {
            cfg.externalAppPermissionSnapshot = cfg.externalAppPermissionSnapshot.filter((row) => !doneRoles.has(row.id));
            cfg.externalAppOverwriteSnapshot = cfg.externalAppOverwriteSnapshot.filter((row) => !doneOverwrites.has(`${row.channelId}:${row.id}`));
            saveGuildConfig(guild.id, cfg);
        }
    }
    return finish();
}
