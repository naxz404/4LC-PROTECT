import { protectionDataDir } from '../DataPaths.js';
import { appendFileSync, existsSync, mkdirSync, readFileSync, writeFileSync } from 'node:fs';
import { resolve } from 'node:path';
import { createHmac, randomBytes } from 'node:crypto';

const directory = resolve(protectionDataDir, 'audit');
const secretPath = resolve(directory, 'key');
function secret() {
    if (process.env.SANCTION_AUDIT_KEY) return process.env.SANCTION_AUDIT_KEY;
    mkdirSync(directory, { recursive: true });
    if (!existsSync(secretPath)) {
        try { writeFileSync(secretPath, randomBytes(32), { flag: 'wx', mode: 0o600 }); }
        catch (error) { if (error.code !== 'EEXIST') throw error; }
    }
    return readFileSync(secretPath);
}
function digest(value) { return createHmac('sha256', secret()).update(value).digest('hex'); }
function fileFor(guildId) {
    if (!/^\d{1,20}$/.test(String(guildId))) throw Error('Identifiant de serveur invalide');
    return resolve(directory, `${guildId}.jsonl`);
}
export function appendSanctionProof(guildId, record) {
    const path = fileFor(guildId);
    mkdirSync(directory, { recursive: true });
    const lines = existsSync(path) ? readFileSync(path, 'utf8').trim().split('\n').filter(Boolean) : [];
    const previous = lines.length ? JSON.parse(lines.at(-1)).signature : 'GENESIS';
    const entry = {
        sequence: lines.length + 1,
        previous,
        at: record.at,
        subject: digest(`subject:${guildId}:${record.userId}`),
        type: record.type,
        recordHash: digest(JSON.stringify(record)),
    };
    appendFileSync(path, `${JSON.stringify({ ...entry, signature: digest(JSON.stringify(entry)) })}\n`, { mode: 0o600 });
    return entry.sequence;
}
export function verifySanctionProofs(guildId, sanctions = null) {
    const path = fileFor(guildId);
    if (!existsSync(path)) return { valid: true, count: 0, head: null };
    let previous = 'GENESIS'; let count = 0;
    const signed = [];
    for (const line of readFileSync(path, 'utf8').trim().split('\n').filter(Boolean)) {
        let row;
        try { row = JSON.parse(line); } catch { return { valid: false, count, reason: 'JSON invalide' }; }
        const { signature, ...entry } = row;
        if (entry.sequence !== ++count || entry.previous !== previous || digest(JSON.stringify(entry)) !== signature)
            return { valid: false, count, reason: `Entrée ${count} modifiée` };
        signed.push(entry);
        previous = signature;
    }
    if (Array.isArray(sanctions)) {
        for (const record of sanctions) {
            const subject = digest(`subject:${guildId}:${record.userId}`);
            const proofs = signed.filter((row) => row.subject === subject && row.at === record.at && row.type === record.type);
            if (proofs.length && !proofs.some((row) => row.recordHash === digest(JSON.stringify(record))))
                return { valid: false, count, reason: `Sanction modifiée (${record.at})` };
        }
    }
    return { valid: true, count, head: previous === 'GENESIS' ? null : previous };
}
