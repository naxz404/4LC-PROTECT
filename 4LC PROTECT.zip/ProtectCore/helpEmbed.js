import { ActionRowBuilder, ButtonBuilder, ButtonStyle, EmbedBuilder, MessageFlags, StringSelectMenuBuilder } from 'discord.js';
import config, { supportUrl } from './config.js';
import { getGuildConfig } from './storage.js';
import { isEnglish, tr } from './i18n.js';
import { emojiText, emojiComponent } from './appEmojis.js';

const HOME = '__home__';
const c = (usage, fr, en) => ({ usage, fr, en });
const categories = [
    { id: 'configuration', fr: 'Configuration', en: 'Configuration', emoji: '⚙️', icon: 'role', commands: [
        c('/secure [membre]', 'Ajouter un membre Secure ou voir la liste (propriétaire)', 'Add a Secure member or view the list (server owner)'), c('/unsecure [membre]', 'Retirer un membre Secure (propriétaire)', 'Remove a Secure member (server owner)'),
        c('/setup', 'Lancer la configuration guidée', 'Start guided setup'), c('/config', 'Ouvrir le panneau des protections', 'Open the protection panel'), c('/health', 'Vérifier le fonctionnement du bot', 'Check bot health'), c('/settings', 'Alias du panneau de configuration', 'Alias for the settings panel'),
        c('/language [langue]', 'Choisir Français ou English', 'Choose Français or English'), c('/prefix [valeur]', 'Modifier le préfixe du serveur', 'Change the server prefix'), c('/tag-role [rôle]', 'Configurer le rôle de tag', 'Configure the server tag role'),
        c('/tag-sync [membre]', 'Actualiser un rôle de tag', 'Refresh a tag role'), c('/display [panneau]', 'Envoyer la configuration ou ouvrir les réglages CAPTCHA', 'Send settings or open CAPTCHA settings'), c('/reload-status', 'Recharger le statut depuis config.json', 'Reload status from config.json'), c('/verification [rôles]', 'Régler les rôles de vérification', 'Configure verification roles'),
        c('/captcha [activer]', 'Activer le CAPTCHA et configurer ses rôles', 'Enable CAPTCHA and configure its roles'), c('/honeypot [activer]', 'Créer ou désactiver le salon piège', 'Create or disable the trap channel'), c('/badwords [action]', 'Gérer les mots interdits avec AutoMod', 'Manage blocked words with AutoMod'),
        c('/backup [action]', 'Créer, comparer ou restaurer une sauvegarde transférable', 'Create, compare or restore a transferable backup'), c('/appeal-config [url]', 'Configurer le bouton d’appel des TempBans', 'Configure the TempBan appeal button'), c('/logs [salons]', 'Choisir les journaux et signalements', 'Choose log and report channels'), c('/logchannel [salon]', 'Définir directement le journal anti-raid', 'Set the anti-raid log channel'), c('/filter [mentions]', 'Régler les filtres', 'Configure content filters'), c('/jail-config [rôle] [salon]', 'Définir la quarantaine', 'Configure quarantine'),
    ] },
    { id: 'security', fr: 'Sécurité', en: 'Security', emoji: '🛡️', icon: 'warning', commands: [
        c('/anti-raid [activer]', 'Régler les arrivées massives', 'Configure mass-join protection'), c('/raidmode [activer]', 'Alias du mode anti-raid', 'Alias for anti-raid mode'), c('/join-lock [activer]', 'Bloquer ou rouvrir les arrivées', 'Block or reopen joins'),
        c('/simulation [activer]', 'Journaliser les sanctions sans les appliquer', 'Log automatic sanctions without applying them'),
        c('/antiban [activer]', 'Protéger les bannissements', 'Protect bans'), c('/antibot [activer]', 'Expulser les bots non autorisés', 'Kick unauthorized bots'), c('/antichannel [activer]', 'Protéger les salons', 'Protect channels'),
        c('/antieveryone [activer]', 'Bloquer everyone et here', 'Block everyone and here'), c('/antijoin [activer]', 'Détecter les arrivées massives', 'Detect mass joins'), c('/antilink [activer]', 'Filtrer les liens', 'Filter links'),
        c('/antirole [activer]', 'Protéger les rôles', 'Protect roles'), c('/antispam [activer]', 'Limiter le spam', 'Limit spam'), c('/antitoken [activer]', 'Refuser les comptes trop récents', 'Reject new accounts'),
        c('/antiupdate [activer]', 'Surveiller les réglages du serveur', 'Monitor server settings'), c('/antivanity [activer]', 'Protéger la vanity URL', 'Protect the vanity URL'), c('/antiwebhook [activer]', 'Protéger les webhooks', 'Protect webhooks'),
        c('/phishing [activer]', 'Bloquer les domaines et images de phishing suspects', 'Block suspicious phishing domains and images'), c('/ghost-ping [activer]', 'Journaliser les mentions supprimées rapidement', 'Log quickly deleted mentions'), c('/warning-system [activer]', 'Activer les sanctions progressives', 'Enable progressive punishments'),
        c('/lock [salon] [raison]', 'Verrouiller un salon et sauvegarder ses permissions', 'Lock a channel and save its permissions'), c('/unlock [salon] [raison]', 'Restaurer les permissions sauvegardées', 'Restore saved channel permissions'), c('/renew [salon]', 'Recréer un salon sans son ancien historique', 'Recreate a channel without its old history'), c('/lock-icon [activer]', 'Afficher le cadenas sur les salons', 'Show a lock icon on locked channels'),
        c('/panic [activer]', 'Verrouillage de crise avec restauration', 'Emergency lock with restoration'), c('/protect', 'Afficher toutes les protections', 'Show all protections'), c('/protectiontest', 'Simuler les contrôles sans sanction', 'Simulate checks without punishment'),
        c('/protection-level [niveau]', 'Appliquer Faible, Normal, Élevé ou Urgence', 'Apply Low, Normal, High or Emergency'), c('/antinuke [activer]', 'Limiter les actions administratives rapides', 'Limit rapid administrative actions'),
        c('/punish [module] [sanction]', 'Choisir la sanction d’un module', 'Choose a module punishment'), c('/securityscan', 'Noter la sécurité sur 100', 'Score server security out of 100'), c('/trustscore [membre]', 'Estimer la confiance d’un membre', 'Estimate member trust'),
        c('/whitelist [membre]', 'Ajouter une exemption temporaire ou permanente', 'Add a temporary or permanent exemption'), c('/unwhitelist [membre]', 'Retirer une exemption', 'Remove an exemption'), c('/whitelist-history', 'Voir qui a modifié les exemptions', 'View exemption changes'), c('/blacklist [action]', 'Gérer ou exporter la blacklist globale', 'Manage or export the global blacklist'), c('/raid-history', 'Voir les raids détectés', 'View detected raids'), c('/audit', 'Vérifier les permissions sensibles', 'Audit sensitive permissions'),
    ] },
    { id: 'moderation', fr: 'Modération', en: 'Moderation', emoji: '🔨', icon: 'admin', commands: [
        c('/ban [membre] [raison]', 'Bannir un membre', 'Ban a member'), c('/tempban [membre] [minutes]', 'Bannir temporairement', 'Temporarily ban a member'), c('/unban [id]', 'Lever un bannissement', 'Remove a ban'),
        c('/kick [membre] [raison]', 'Expulser un membre', 'Kick a member'), c('/timeout [membre] [minutes]', 'Mettre un membre en pause', 'Timeout a member'), c('/unmute [membre]', 'Lever un timeout', 'Remove a timeout'),
        c('/untimeout [membre]', 'Alias pour lever un timeout', 'Alias for removing a timeout'), c('/warn [membre] [raison]', 'Ajouter un avertissement', 'Warn a member'), c('/unwarn [membre] [numéro]', 'Retirer un avertissement', 'Remove a warning'),
        c('/sanctions [membre]', 'Consulter les sanctions', 'View punishments'), c('/jail [membre]', 'Attribuer le rôle Jail', 'Give the Jail role'), c('/unjail [membre]', 'Retirer le rôle Jail', 'Remove the Jail role'),
        c('/slowmode [secondes] [salon]', 'Régler le mode lent', 'Configure slowmode'), c('/clear [nombre]', 'Supprimer des messages récents', 'Delete recent messages'), c('/report [raison]', 'Signaler un membre ou un message', 'Report a member or message'),
    ] },
    { id: 'other', fr: 'Autres commandes', en: 'Other commands', emoji: '📦', icon: 'ticket', commands: [
        c('/my-sanctions', 'Voir ses propres sanctions', 'View your own punishments'), c('/userinfo [utilisateur]', 'Voir le profil public d’un membre', 'View a member public profile'), c('/about', 'Informations sur 4LC-PROTECT', 'Information about 4LC-PROTECT'),
        c('/changelog', 'Voir les nouveautés', 'View recent changes'), c('/invite', 'Ouvrir le serveur 4LC', 'Open the 4LC server'), c('/ping', 'Voir la latence', 'View latency'), c('/help [commande]', 'Afficher cette aide', 'Show this help menu'),
        c('/export-data', 'Exporter ses données du serveur', 'Export your server data'), c('/delete-data', 'Supprimer ses données du serveur', 'Delete your server data'), c('/audit-verify', 'Vérifier les preuves signées des sanctions', 'Verify signed sanction proofs'), c('/invite-history', 'Voir les invitations utilisées', 'View used invitations'),
    ] },
];

export const helpCommandNames = categories.flatMap((category) => category.commands.map(({ usage }) => usage.split(' ')[0].slice(1)));
const allCommands = categories.flatMap((category) => category.commands.map((command) => ({ ...command, category })));
const featured = new Set([
    'secure', 'unsecure', 'setup', 'config', 'health', 'language', 'logs', 'backup',
    'protect', 'panic', 'protection-level', 'whitelist', 'unwhitelist', 'raid-history', 'audit',
    'ban', 'kick', 'timeout', 'warn', 'sanctions', 'clear', 'report', 'lock', 'unlock',
    'my-sanctions', 'userinfo', 'about', 'invite', 'help',
]);
const shown = (category) => category.commands.filter(({ usage }) => featured.has(usage.split(' ')[0].slice(1)));
const prefixCommands = new Set(['secure', 'unsecure', 'clear', 'config', 'settings', 'help', 'setup', 'protect', 'lock', 'unlock', 'renew', 'reload-status', 'antiban', 'antibot', 'antichannel', 'antieveryone', 'antijoin', 'antilink', 'antirole', 'antispam', 'antitoken', 'antiupdate', 'antivanity', 'antiwebhook', 'phishing', 'ghost-ping', 'warning-system', 'logchannel', 'panic', 'protectiontest', 'protection-level', 'antinuke', 'backup', 'blacklist', 'raid-history', 'appeal-config', 'punish', 'allanti', 'allpunish', 'securityscan', 'trustscore', 'whitelist', 'unwhitelist', 'whitelist-history', 'captcha', 'honeypot', 'ambassador']);
function label(category, cfg) { return isEnglish(cfg) ? category.en : category.fr; }
function description(command, cfg) { return isEnglish(cfg) ? command.en : command.fr; }

function footer(embed, actor) {
    if (actor?.tag && actor.displayAvatarURL) embed.setFooter({ text: actor.tag, iconURL: actor.displayAvatarURL() });
    else embed.setFooter({ text: '4LC-PROTECT' });
    return embed;
}

function homeEmbed(cfg, actor) {
    return footer(new EmbedBuilder().setColor(0x000000).setTitle(' ').setDescription(
        `# 📌 〃 ${tr(cfg, 'Aide', 'Help')}\n${tr(cfg, 'Commandes de gestion dédiées à ce serveur. Réglez les protections avec', 'Management commands dedicated to this server. Configure protections with')} \`/config\`.\n\`${cfg.prefix || config.prefix}help <${tr(cfg, 'commande', 'command')}>\``,
    ), actor);
}

const PAGE_SIZE = 12;
function categoryEmbed(cfg, actor, categoryId, page = 0) {
    const category = categories.find((entry) => entry.id === categoryId) || categories[0];
    const commands = shown(category);
    const total = Math.ceil(commands.length / PAGE_SIZE);
    const lines = commands.slice(page * PAGE_SIZE, (page + 1) * PAGE_SIZE).map((command) => `• \`${command.usage}\` — ${description(command, cfg)}`).join('\n');
    return footer(new EmbedBuilder().setColor(0x000000).setTitle(' ').setDescription(
        `# ${emojiText(category.icon, category.emoji)} 〃 ${label(category, cfg)}\n${lines}\n\n${page + 1}/${total} · \`${cfg.prefix || config.prefix}help <${tr(cfg, 'commande', 'command')}>\``,
    ), actor);
}

function commandEmbed(cfg, actor, query) {
    const name = String(query || '').trim().toLowerCase().replace(/^[/+]/, '');
    const command = allCommands.find((entry) => entry.usage.split(' ')[0].slice(1) === name);
    if (!command) return footer(new EmbedBuilder().setColor(0x000000).setTitle(' ').setDescription(`# ❌ 〃 ${tr(cfg, 'Introuvable', 'Not found')}\n\n> *${tr(cfg, 'Aucune commande nommée', 'No command named')} \`${name || '?'}\`.*`), actor);
    const prefix = cfg.prefix || config.prefix;
    return footer(new EmbedBuilder().setColor(0x000000).setTitle(' ').setDescription(
        `# 📌 〃 ${name}\n\n` +
        `> ***${tr(cfg, 'Description', 'Description')} :** ${description(command, cfg)}*\n` +
        `> ***${tr(cfg, 'Catégorie', 'Category')} :** \`${label(command.category, cfg)}\`*\n` +
        `> ***${tr(cfg, 'Usage slash', 'Slash usage')} :** \`${command.usage}\`*\n` +
        (prefixCommands.has(name) ? `> ***${tr(cfg, 'Usage préfixe', 'Prefix usage')} :** \`${prefix}${name}\`*\n` : '') +
        `> ***${tr(cfg, 'Aide', 'Help')} :** \`${prefix}help ${name}\`*`,
    ), actor);
}

function rows(cfg, actorId, selected = HOME, page = 0) {
    const select = new StringSelectMenuBuilder().setCustomId(`sar:help:${actorId || 'public'}`).setPlaceholder(tr(cfg, 'Sélectionnez une catégorie...', 'Select a category...')).addOptions(
        { label: tr(cfg, 'Accueil', 'Home'), emoji: '📌', description: tr(cfg, 'Retourner à la page d’accueil', 'Return to the home page'), value: HOME, default: selected === HOME },
        ...categories.map((category) => ({ label: label(category, cfg), emoji: emojiComponent(category.icon, category.emoji), description: `${shown(category).length} ${tr(cfg, 'commandes', 'commands')}`, value: category.id, default: selected === category.id })),
    );
    const support = new ButtonBuilder().setStyle(ButtonStyle.Link).setURL(supportUrl).setLabel(tr(cfg, 'Serveur Support', 'Support server'));
    const category = categories.find((entry) => entry.id === selected);
    const navigation = category && shown(category).length > PAGE_SIZE ? [
        new ButtonBuilder().setCustomId(`sar:help-page:${actorId || 'public'}:${selected}:${Math.max(0, page - 1)}`).setLabel('◀').setStyle(ButtonStyle.Secondary).setDisabled(page === 0),
        new ButtonBuilder().setCustomId(`sar:help-page:${actorId || 'public'}:${selected}:${Math.min(Math.ceil(shown(category).length / PAGE_SIZE) - 1, page + 1)}`).setLabel('▶').setStyle(ButtonStyle.Secondary).setDisabled((page + 1) * PAGE_SIZE >= shown(category).length),
    ] : [];
    return [new ActionRowBuilder().addComponents(select), new ActionRowBuilder().addComponents(...navigation, support)];
}

export function helpPayload(cfg = {}, actor = null, query = null, category = HOME, page = 0) {
    if (query) return { embeds: [commandEmbed(cfg, actor, query)], components: [] };
    const embed = category === HOME ? homeEmbed(cfg, actor) : categoryEmbed(cfg, actor, category, page);
    return { embeds: [embed], components: rows(cfg, actor?.id, category, page) };
}

export function helpEmbed(cfg = {}, actor = null) { return homeEmbed(cfg, actor); }

export async function handleHelpInteraction(interaction) {
    const isSelect = interaction.isStringSelectMenu() && interaction.customId.startsWith('sar:help:');
    const isPage = interaction.isButton() && interaction.customId.startsWith('sar:help-page:');
    if (!isSelect && !isPage) return false;
    const cfg = getGuildConfig(interaction.guildId);
    const [, , ownerId, category, rawPage] = isPage ? interaction.customId.split(':') : [];
    const owner = isPage ? ownerId : interaction.customId.slice('sar:help:'.length);
    if (owner !== 'public' && owner !== interaction.user.id) {
        await interaction.reply({ content: tr(cfg, 'Cette aide est réservée à son auteur.', 'This help menu belongs to its original user.'), flags: MessageFlags.Ephemeral });
        return true;
    }
    await interaction.update(helpPayload(cfg, interaction.user, null, isPage ? category : interaction.values[0], isPage ? Number(rawPage) : 0));
    return true;
}
