import { getGuildConfig } from './storage.js';
import { PermissionFlagsBits } from 'discord.js';

export function displaysGuildTag(user, guildId) {
    return user?.primaryGuild?.identityGuildId === guildId && user.primaryGuild.identityEnabled === true;
}

/** Uses Discord's actual server-tag identity, not text in a nickname or status. */
export async function syncTagRole(member, user = null) {
    const cfg = getGuildConfig(member.guild.id);
    if (!cfg.tagRoleId || member.user.bot) return 'disabled';
    const role = await member.guild.roles.fetch(cfg.tagRoleId).catch(() => null);
    if (!role) return 'missing_role';
    const bot = await member.guild.members.fetchMe();
    if (role.position >= bot.roles.highest.position || role.permissions.has(PermissionFlagsBits.Administrator)) return 'hierarchy';
    const profile = user || await member.client.users.fetch(member.id, { force: true }).catch(() => member.user);
    const hasTag = displaysGuildTag(profile, member.guild.id);
    const hasRole = member.roles.cache.has(role.id);
    if (hasTag && !hasRole) {
        try { await member.roles.add(role, 'Tag de serveur affiché'); return 'added'; } catch { return 'permission_error'; }
    }
    if (!hasTag && hasRole) {
        try { await member.roles.remove(role, 'Tag de serveur retiré'); return 'removed'; } catch { return 'permission_error'; }
    }
    return 'unchanged';
}
