import { allowedGuilds } from '../ServerScope.js';
import { getGuildConfig, saveGuildConfig } from './storage.js';
import { invalidateSettings } from './antiraid/runtime.js';
import { applyProtectionLevel } from './protectionLevels.js';
import { buildAntiRaidEmbed, sendLog } from './antiraid/logs.js';

const FIELDS = ['enabled', 'punishments', 'antispam', 'antilink', 'autoRaid', 'antiNuke', 'joinLock', 'protectionLevel'];
const pick = (cfg) => Object.fromEntries(FIELDS.map((field) => [field, structuredClone(cfg[field])]));
const DURATION = 10 * 60_000;

export function activateAutomaticEmergency(guildId, reason, now = Date.now()) {
    const cfg = getGuildConfig(guildId);
    if (cfg.automaticEmergency?.until > now) {
        cfg.automaticEmergency.until = Math.min(now + DURATION, Math.max(cfg.automaticEmergency.until, now + 60_000));
        cfg.automaticEmergency.events++;
    } else {
        const previous = pick(cfg);
        applyProtectionLevel(cfg, 'urgence');
        cfg.automaticEmergency = { previous, applied: pick(cfg), startedAt: now, until: now + DURATION, reason, events: 1, blocked: 0, damage: 0, restored: 0, failed: 0 };
    }
    saveGuildConfig(guildId, cfg); invalidateSettings(guildId);
    return cfg.automaticEmergency;
}

export function recordEmergencyResult(guildId, { blocked = 0, damage = 0, restored = 0, failed = 0 } = {}) {
    const cfg = getGuildConfig(guildId);
    if (!cfg.automaticEmergency) return;
    cfg.automaticEmergency.restored += restored;
    cfg.automaticEmergency.failed += failed;
    cfg.automaticEmergency.blocked += blocked;
    cfg.automaticEmergency.damage += damage;
    saveGuildConfig(guildId, cfg); invalidateSettings(guildId);
}

export async function finishExpiredEmergencies(client, now = Date.now()) {
    for (const guild of allowedGuilds(client)) {
        const cfg = getGuildConfig(guild.id); const state = cfg.automaticEmergency;
        if (!state || state.until > now) continue;
        const safeToRestore = JSON.stringify(pick(cfg)) === JSON.stringify(state.applied);
        if (safeToRestore) Object.assign(cfg, state.previous);
        delete cfg.automaticEmergency;
        saveGuildConfig(guild.id, cfg); invalidateSettings(guild.id);
        await sendLog(client, guild.id, buildAntiRaidEmbed('Résumé du mode urgence / Emergency summary',
            `${Math.round((now - state.startedAt) / 60_000)} min · ${state.events} détection(s) · ${state.blocked || 0} action(s) contenue(s) · ${state.damage || 0} élément(s) touché(s) · ${state.restored} restauré(s) · ${state.failed} échec(s).\n${safeToRestore ? 'Réglages précédents restaurés.' : 'Réglages modifiés pendant l’urgence : restauration automatique ignorée.'}`));
    }
}
