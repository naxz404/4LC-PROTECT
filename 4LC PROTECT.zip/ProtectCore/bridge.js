import { allowServerEvent } from '../ServerScope.js';
import { prefixProtectionAccess, accessAllowed, accessDenied } from './protectionAccess.js';
import { getGuildConfig } from './storage.js';
import { isGlobalOwner } from '../Owners.js';
import { readdirSync } from 'node:fs';
import { pathToFileURL } from 'node:url';
import { resolve } from 'node:path';
import readyEvent from './events/ready.js';
import interactionEvent from './events/interactionCreate.js';

const installed = new WeakSet();
const booted = new WeakSet();

export async function installProtectCore(client) {
    if (installed.has(client)) return;
    installed.add(client);
    const dir = resolve(import.meta.dirname, 'events');
    const skip = new Set(['ready.js', 'interactionCreate.js', 'messageCreate.js', 'guildMemberAdd.js', 'guildCreate.js']);
    for (const file of readdirSync(dir).filter((f) => f.endsWith('.js') && !skip.has(f))) {
        const mod = await import(pathToFileURL(resolve(dir, file)).href);
        const event = mod.default;
        if (!event?.name) continue;
        const handler = (...args) => Promise.resolve().then(() => allowServerEvent(client, event.name, args) ? event.execute(client, ...args) : undefined).catch((error) => {
            console.error(`[4LC-PROTECT/Core] ${event.name}:`, error);
        });
        if (event.once) client.once(event.name, handler);
        else client.on(event.name, handler);
    }
}

export async function bootProtectCore(client) {
    if (booted.has(client)) return;
    booted.add(client);
    return readyEvent.execute(client);
}

export async function handleProtectInteraction(client, interaction) {
    return interactionEvent.execute(client, interaction);
}

export async function installProtectTextCommands(client) {
    const { readdirSync } = await import('node:fs');
    const { pathToFileURL } = await import('node:url');
    const { resolve } = await import('node:path');
    const dir = resolve(import.meta.dirname, 'commands');
    const config4lc = (await import('../config.json', { with: { type: 'json' } })).default;
    for (const file of readdirSync(dir).filter((f) => f.endsWith('.js'))) {
        const mod = await import(pathToFileURL(resolve(dir, file)).href);
        const list = Array.isArray(mod.default) ? mod.default : [mod.default];
        for (const cmd of list) {
            if (!cmd?.name || cmd.name === 'help') continue;
            const wrapped = {
                name: cmd.name, aliases: cmd.aliases || [], helpname: cmd.name,
                category: 'Sécurité',
                description: cmd.description || 'Commande de sécurité 4LC-PROTECT',
                help: cmd.name,
                run: async (bot, message, args) => {
                    if (cmd.ownerOnly && !isGlobalOwner(message.author.id)) return message.reply('Commande réservée aux propriétaires du bot.');
                    const globalOwner = isGlobalOwner(message.author.id);
                    const access = prefixProtectionAccess(cmd.name, args);
                    if (access && !accessAllowed(access, message.guild, message.author.id, getGuildConfig(message.guild.id))) return message.reply(accessDenied(access, getGuildConfig(message.guild.id)));
                    if (!globalOwner && !access && cmd.permissions?.length && !message.member.permissions.has(cmd.permissions)) return message.reply(`Permission requise : ${cmd.permissions.join(', ')}`);
                    return cmd.execute(bot, message, args, cmd.name);
                },
            };
            client.commands.set(cmd.name, wrapped);
            for (const alias of cmd.aliases || []) client.commands.set(alias, wrapped);
        }
    }
}
