import { isGlobalOwner } from '../Owners.js';
import { ChannelType, EmbedBuilder, PermissionFlagsBits } from 'discord.js';
import { createBackupRecord, createPeriodicBackupRecord, getBackupRecord, listBackupRecords } from './storage.js';

const supportedChannel = (channel) => !channel.isThread?.() && [ChannelType.GuildCategory, ChannelType.GuildText, ChannelType.GuildAnnouncement, ChannelType.GuildVoice, ChannelType.GuildStageVoice, ChannelType.GuildForum].includes(channel.type);

function serializeOverwrite(overwrite, guildId) {
    return { id: overwrite.id, everyone: overwrite.id === guildId, type: overwrite.type, allow: overwrite.allow.bitfield.toString(), deny: overwrite.deny.bitfield.toString() };
}

export function snapshotGuild(guild) {
    const roles = guild.roles.cache.filter((role) => role.id !== guild.id && !role.managed).sort((a, b) => a.position - b.position).map((role) => ({
        sourceId: role.id, name: role.name, color: role.color, hoist: role.hoist, mentionable: role.mentionable, permissions: role.permissions.bitfield.toString(), position: role.position,
    }));
    const channels = guild.channels.cache.filter(supportedChannel).sort((a, b) => a.rawPosition - b.rawPosition).map((channel) => ({
        sourceId: channel.id, name: channel.name, type: channel.type, parentId: channel.parentId, position: channel.rawPosition,
        bitrate: channel.bitrate, userLimit: channel.userLimit, rtcRegion: channel.rtcRegion, videoQualityMode: channel.videoQualityMode,
        topic: 'topic' in channel ? channel.topic : null, nsfw: 'nsfw' in channel ? channel.nsfw : false, rateLimitPerUser: 'rateLimitPerUser' in channel ? channel.rateLimitPerUser : 0,
        permissionOverwrites: [...channel.permissionOverwrites.cache.values()].map((overwrite) => serializeOverwrite(overwrite, guild.id)),
    }));
    const emojis = guild.emojis.cache.map((emoji) => ({ sourceId: emoji.id, name: emoji.name, animated: emoji.animated, url: emoji.imageURL({ extension: emoji.animated ? 'gif' : 'png', size: 128 }) }));
    return { guildName: guild.name, roles, channels, emojis, everyonePermissions: guild.roles.everyone.permissions.bitfield.toString() };
}

export function createServerBackup(guild, ownerId) {
    return createBackupRecord({ ownerId, sourceGuildId: guild.id, snapshot: snapshotGuild(guild) });
}

export function createPeriodicServerBackup(guild) {
    const snapshot = snapshotGuild(guild);
    snapshot.emojis = []; // sauvegarde légère : structure, permissions et rôles seulement
    return createPeriodicBackupRecord({ ownerId: guild.ownerId, sourceGuildId: guild.id, snapshot });
}

export function backupSuccessEmbed(record, prefix = '+') {
    const snapshot = record.snapshot;
    return new EmbedBuilder().setColor(0x000000).setTitle('✅ SAUVEGARDE EFFECTUÉE AVEC SUCCÈS').setDescription(
        `> \u200b\n\n` +
        `📸 **Version** : \`#${record.code}\`\n` +
        `💬 **Salons capturés** : \`${snapshot.channels.length}\`\n` +
        `🎭 **Rôles capturés** : \`${snapshot.roles.length}\`\n` +
        `😀 **Emojis capturés** : \`${snapshot.emojis?.length || 0}\`\n\n` +
        `✨ *Pour restaurer cette sauvegarde à tout moment, tapez :*\n\`${prefix}restore ${record.code}\``,
    ).setFooter({ text: '4LC-PROTECT • AntiRaid' });
}

export function backupAccessDeniedEmbed(cfg = {}) {
    const en = cfg.language === 'en';
    return new EmbedBuilder().setColor(0x000000).setTitle(en ? '❌ 〃 Access denied' : '❌ 〃 Accès refusé').setDescription(en ? '> *Reserved for the server owner.*' : '> *Réservé au propriétaire du serveur.*').setFooter({ text: '4LC-PROTECT • AntiRaid' });
}

export function listServerBackups(ownerId) { return listBackupRecords(ownerId); }

export function backupDiff(guild, record) {
    const snapshot = record.snapshot; const currentRoles = guild.roles.cache.filter((role) => !role.managed);
    const missingRoles = snapshot.roles.filter((saved) => !currentRoles.some((role) => role.name === saved.name));
    const changedRoles = snapshot.roles.filter((saved) => currentRoles.some((role) => role.name === saved.name && role.permissions.bitfield.toString() !== saved.permissions));
    const missingChannels = snapshot.channels.filter((saved) => !guild.channels.cache.some((channel) => channel.name === saved.name && channel.type === saved.type));
    const missingEmojis = (snapshot.emojis || []).filter((saved) => !guild.emojis.cache.some((emoji) => emoji.name === saved.name));
    return { missingRoles, changedRoles, missingChannels, missingEmojis, totalSaved: snapshot.roles.length + snapshot.channels.length + (snapshot.emojis?.length || 0) };
}

function channelCreateOptions(saved, parent, code) {
    const options = { name: saved.name, type: saved.type, parent, reason: `Restauration ${code}` };
    if ([ChannelType.GuildText, ChannelType.GuildAnnouncement, ChannelType.GuildForum].includes(saved.type)) {
        options.topic = saved.topic || undefined; options.nsfw = Boolean(saved.nsfw); options.rateLimitPerUser = saved.rateLimitPerUser || 0;
    }
    if ([ChannelType.GuildVoice, ChannelType.GuildStageVoice].includes(saved.type)) { for (const key of ['bitrate','userLimit','rtcRegion','videoQualityMode']) if (saved[key] !== undefined) options[key] = saved[key]; }
    return options;
}

function mappedOverwrites(saved, guild, roleMap) {
    return saved.permissionOverwrites.map((entry) => ({
        type: entry.type, id: entry.everyone ? guild.id : entry.type === 0 ? roleMap.get(entry.id) || guild.roles.cache.get(entry.id)?.id : entry.id,
        allow: BigInt(entry.allow), deny: BigInt(entry.deny),
    })).filter((entry) => entry.id);
}

export async function restoreServerBackup(guild, record, actorId) {
    const me = guild.members.me || await guild.members.fetchMe();
    if (!me.permissions.has(PermissionFlagsBits.ManageRoles) || !me.permissions.has(PermissionFlagsBits.ManageChannels)) throw new Error('Permissions Gérer les rôles et Gérer les salons requises.');
    const failures = [];
    await guild.roles.everyone.edit({ permissions: BigInt(record.snapshot.everyonePermissions) & me.permissions.bitfield, reason: `Restauration ${record.code}` }).catch((error) => failures.push(`@everyone : ${error.message}`));
    const usedRoles = new Set();
    const usedChannels = new Set();
    const roleMap = new Map([[record.sourceGuildId, guild.id]]); let rolesCreated = 0; let rolesUpdated = 0;
    for (const saved of record.snapshot.roles) {
        try {
        const safePermissions = BigInt(saved.permissions) & me.permissions.bitfield;
        let role = guild.roles.cache.get(saved.sourceId) || guild.roles.cache.find(item => !item.managed && item.id !== guild.id && !usedRoles.has(item.id) && item.name === saved.name);
        if (role?.managed || role?.id === guild.id) role = null;
        if (!role) { role = await guild.roles.create({ name: saved.name, color: saved.color, hoist: saved.hoist, mentionable: saved.mentionable, permissions: safePermissions, reason: `Restauration ${record.code} par ${actorId}` }); rolesCreated++; }
        else if (role.editable) { await role.edit({ color: saved.color, hoist: saved.hoist, mentionable: saved.mentionable, permissions: safePermissions, reason: `Restauration ${record.code}` }); rolesUpdated++; }
        if (role.editable) await role.setPosition(Math.min(saved.position, Math.max(1, me.roles.highest.position - 1)), `Restauration ${record.code}`).catch((error) => failures.push(`position rôle ${saved.name} : ${error.message}`));
        usedRoles.add(role.id);
        roleMap.set(saved.sourceId, role.id);

        } catch (error) { failures.push(`rôle ${saved.name} : ${error.message}`); }
    }
    const channelMap = new Map(); let channelsCreated = 0; let channelsUpdated = 0;
    for (const saved of record.snapshot.channels.filter((item) => item.type === ChannelType.GuildCategory)) {
        try {
        let channel = guild.channels.cache.get(saved.sourceId) || guild.channels.cache.find(item => !usedChannels.has(item.id) && item.type === saved.type && item.name === saved.name && (saved.type === ChannelType.GuildCategory || item.parentId === (channelMap.get(saved.parentId) || null)));
        if (channel?.type !== saved.type) channel = null;
        if (!channel) { channel = await guild.channels.create({ name: saved.name, type: saved.type, reason: `Restauration ${record.code}` }); channelsCreated++; }
        await channel.setPosition(saved.position).catch((error) => failures.push(`position salon ${saved.name} : ${error.message}`));
        const overwrites = mappedOverwrites(saved, guild, roleMap);
        await channel.permissionOverwrites.set(overwrites, `Restauration ${record.code}`).catch((error) => failures.push(`permissions salon ${saved.name} : ${error.message}`));
        usedChannels.add(channel.id);
        channelMap.set(saved.sourceId, channel.id);

        } catch (error) { failures.push(`catégorie ${saved.name} : ${error.message}`); }
    }
    for (const saved of record.snapshot.channels.filter((item) => item.type !== ChannelType.GuildCategory)) {
        try {
        if (saved.parentId && !channelMap.has(saved.parentId)) { failures.push(`catégorie introuvable pour ${saved.name}`); continue; }
        let channel = guild.channels.cache.get(saved.sourceId) || guild.channels.cache.find(item => !usedChannels.has(item.id) && item.type === saved.type && item.name === saved.name && (saved.type === ChannelType.GuildCategory || item.parentId === (channelMap.get(saved.parentId) || null)));
        if (channel?.type !== saved.type) channel = null;
        if (!channel) {
            channel = await guild.channels.create(channelCreateOptions(saved, channelMap.get(saved.parentId) || null, record.code)); channelsCreated++;
        } else {
            channelsUpdated++;
            const options = channelCreateOptions(saved, channelMap.get(saved.parentId) || null, record.code);
            delete options.type;
            await channel.edit(options).catch(error => failures.push(`paramètres salon ${saved.name} : ${error.message}`));
        }
        if (typeof channel.setParent === 'function') await channel.setParent(channelMap.get(saved.parentId) || null, { lockPermissions: false, reason: `Restauration ${record.code}` }).catch((error) => failures.push(`catégorie salon ${saved.name} : ${error.message}`));
        await channel.setPosition(saved.position).catch((error) => failures.push(`position salon ${saved.name} : ${error.message}`));
        usedChannels.add(channel.id);
        channelMap.set(saved.sourceId, channel.id);
        const overwrites = mappedOverwrites(saved, guild, roleMap);
        await channel.permissionOverwrites.set(overwrites, `Restauration ${record.code}`).catch((error) => failures.push(`permissions salon ${saved.name} : ${error.message}`));

        } catch (error) { failures.push(`salon ${saved.name} : ${error.message}`); }
    }
    let emojisCreated = 0; let emojisSkipped = 0;
    if (me.permissions.has(PermissionFlagsBits.ManageGuildExpressions)) {
        for (const saved of record.snapshot.emojis || []) {
            if (guild.emojis.cache.some((emoji) => emoji.name === saved.name)) { emojisSkipped++; continue; }
            await guild.emojis.create({ attachment: saved.url, name: saved.name, reason: `Restauration ${record.code}` }).then(() => emojisCreated++).catch((error) => { emojisSkipped++; failures.push(`emoji ${saved.name} : ${error.message}`); });
        }
    } else emojisSkipped = record.snapshot.emojis?.length || 0;
    return { rolesCreated, rolesUpdated, channelsCreated, channelsUpdated, emojisCreated, emojisSkipped, failures };
}

export function resolveBackup(code, ownerId) {
    const record = getBackupRecord(code);
    if (!record || (record.ownerId !== ownerId && !isGlobalOwner(ownerId))) return null;
    return record;
}
