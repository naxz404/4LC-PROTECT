import { createHash } from 'node:crypto';

export async function hashAttachments(message) {
    const small = [...(message.attachments?.values?.() || [])].filter((item) => item.size > 0 && item.size <= 1_000_000).slice(0, 2);
    return (await Promise.all(small.map(async (item) => {
        let url; try { url = new URL(item.url); } catch { return null; }
        if (url.protocol !== 'https:' || !['cdn.discordapp.com', 'media.discordapp.net'].includes(url.hostname)) return null;
        try {
            const response = await fetch(url, { signal: AbortSignal.timeout(2_000), redirect: 'error' });
            if (!response.ok || Number(response.headers.get('content-length') || 0) > 1_000_000) { await response.body?.cancel(); return null; }
            const bytes = await response.arrayBuffer();
            if (bytes.byteLength > 1_000_000) return null;
            return createHash('sha256').update(new Uint8Array(bytes)).digest('hex');
        } catch { return null; }
    }))).filter(Boolean);
}
