import { MessageFlags } from 'discord.js';

const last = new Map();

export async function throttleInteraction(interaction) {
    if (!interaction.guildId || !interaction.user?.id) return false;
    const key = `${interaction.guildId}:${interaction.user.id}`;
    const action = interaction.customId || interaction.commandName || 'unknown';
    const now = Date.now();
    const expensive = interaction.customId?.startsWith('sar:backup:restore:') || interaction.customId?.startsWith('sar:panic:');
    const interval = expensive ? 4_000 : 1_200;
    if (last.size > 10_000) for (const [id, value] of last) if (now - value.at > 10_000) last.delete(id);
    const state = last.get(key) || { at: 0, action: '', recent: [] };
    const recent = state.recent.filter((at) => now - at < 10_000);
    if ((state.action === action && now - state.at < interval) || recent.length >= 8) {
        await interaction.reply({ content: '⏳ Patientez un instant avant une autre action. / Please wait before trying again.', flags: MessageFlags.Ephemeral }).catch(() => {});
        return true;
    }
    last.set(key, { at: now, action, recent: [...recent, now] });
    return false;
}
