# 4LC-PROTECT — moteur de protection

Ce dossier contient les protections, les panneaux, les commandes slash, les sauvegardes et les journaux de sécurité de 4LC-PROTECT. Le lancement se fait depuis index.js à la racine du bot, avec Node.js 24 minimum.

Les réglages et sauvegardes sont conservés dans 4LC-DATA. Le stockage des tickets est dans data/4lc-support et les informations SQLite dans database.sqlite3. Conserver ces éléments lors des mises à jour.

Les owners du bot et le propriétaire du serveur gèrent les réglages. Les membres Secure peuvent activer et désactiver les protections. Les actions du staff restent soumises aux permissions requises et à la hiérarchie Discord du bot.

Les logs utilisent le salon central 4lcprotect-logs. Les anciennes bannières ont été retirées. La signature est By 4LC et le lien de support discord.gg/ddJMXWYJ29.

Les sauvegardes recréent les éléments de structure pris en charge et signalent les échecs. Les messages supprimés ne peuvent pas être restaurés.
