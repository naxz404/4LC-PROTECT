import { ActionRowBuilder, ButtonBuilder, ButtonStyle, PermissionFlagsBits } from 'discord.js';
import { getIncident, updateIncident } from './storage.js';
import { buildAntiRaidEmbed, sendLog } from './antiraid/logs.js';
import { emojiComponent } from './appEmojis.js';

export function incidentButtons(id) {
    return [new ActionRowBuilder().addComponents(
        new ButtonBuilder().setCustomId(`sar:incident:why:${id}`).setLabel('Pourquoi ? / Why?').setEmoji(emojiComponent('role', '🔎')).setStyle(ButtonStyle.Secondary),
        new ButtonBuilder().setCustomId(`sar:incident:false:${id}`).setLabel('Faux positif / False positive').setEmoji(emojiComponent('warning', '⚠️')).setStyle(ButtonStyle.Secondary),
        new ButtonBuilder().setCustomId(`sar:incident:undo:${id}`).setLabel('Annuler / Undo').setEmoji(emojiComponent('cancel', '↩️')).setStyle(ButtonStyle.Danger),
    )];
}

export function announceIncident(client, guildId, incident) {
    return sendLog(client, guildId, buildAntiRaidEmbed('Sanction automatique / Automatic action',
        `<@${incident.userId}> · **${incident.action}** · ${incident.reason.slice(0, 800)}\nID : \`${incident.id}\``), 'normal', incidentButtons(incident.id));
}

export async function handleIncidentInteraction(i) {
    if (!i.isButton?.() || !i.customId?.startsWith('sar:incident:')) return false;
    if (!i.memberPermissions?.has(PermissionFlagsBits.ModerateMembers)) { await i.reply({ content: 'Permission Modérer les membres requise.', ephemeral: true }); return true; }
    const [, , action, id] = i.customId.split(':');
    const incident = getIncident(i.guildId, id);
    if (!incident) { await i.reply({ content: 'Incident introuvable ou expiré.', ephemeral: true }); return true; }
    if (action === 'why') {
        await i.reply({ content: `**${incident.reason}**\nCompte : <@${incident.userId}> · action : ${incident.action} · <t:${Math.floor(incident.at / 1000)}:F> · état : ${incident.status}.`, ephemeral: true });
    } else if (action === 'false') {
        updateIncident(i.guildId, id, { status: 'false-positive', reviewedBy: i.user.id, reviewedAt: Date.now() });
        await i.reply({ content: `Signalement enregistré pour l’incident \`${id}\`. La sanction reste active tant qu’elle n’est pas annulée.`, ephemeral: true });
    } else if (action === 'undo') {
        if (incident.action !== 'timeout' || incident.status === 'undone') { await i.reply({ content: 'Annulation automatique disponible uniquement pour un timeout actif.', ephemeral: true }); return true; }
        const member = await i.guild.members.fetch(incident.userId).catch(() => null);
        if (!member?.moderatable || !incident.expectedUntil || !member.communicationDisabledUntilTimestamp ||
            Math.abs(member.communicationDisabledUntilTimestamp - incident.expectedUntil) > 5_000) {
            await i.reply({ content: 'Le timeout a été modifié ou ne peut plus être annulé en sécurité.', ephemeral: true }); return true;
        }
        const ok = await member.timeout(null, `Annulation incident ${id} par ${i.user.id}`).then(() => true).catch(() => false);
        if (ok) updateIncident(i.guildId, id, { status: 'undone', reviewedBy: i.user.id, reviewedAt: Date.now() });
        await i.reply({ content: ok ? `Timeout annulé pour <@${incident.userId}>.` : 'Annulation impossible : permissions insuffisantes.', ephemeral: true });
    }
    return true;
}
