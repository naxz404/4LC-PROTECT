// Détection adaptative inspirée du moteur 4LC-PROTECT : fenêtres glissantes,
// seuils renforcés pendant un raid et récidive progressive.
import { getAdaptiveState, saveAdaptiveState } from './storage.js';

const joins = new Map();
const messages = new Map();
const mentionWindows = new Map();
const offences = new Map();
const raidModeUntil = new Map();

// Restauration au démarrage : seul l'état "actif" mérite d'être conservé
// entre deux redémarrages (mode raid en cours, récidive récente d'un membre).
// L'historique fin des arrivées/messages (fenêtres de quelques secondes à
// quelques minutes) est volontairement recalculé à chaud plutôt que persisté :
// il serait de toute façon obsolète après un redémarrage, et l'écrire à
// chaque message coûterait une opération disque par message reçu.
(function restoreAdaptiveState() {
    const persisted = getAdaptiveState();
    const now = Date.now();
    for (const [guildId, until] of Object.entries(persisted.raidModeUntil || {})) {
        if (until > now) raidModeUntil.set(guildId, until);
    }
    for (const [key, row] of Object.entries(persisted.offences || {})) {
        if (row && now - row.at < 30 * 60_000) offences.set(key, row);
    }
})();

// Sauvegarde regroupée (au plus une écriture par tick) pour éviter une
// écriture disque à chaque arrivée ou récidive détectée en rafale.
let saveScheduled = false;
function persistAdaptiveState() {
    if (saveScheduled) return;
    saveScheduled = true;
    setImmediate(() => {
        saveScheduled = false;
        saveAdaptiveState({
            raidModeUntil: Object.fromEntries(raidModeUntil),
            offences: Object.fromEntries(offences),
        });
    });
}

const normalize = (value) => String(value || '').toLowerCase().replace(/https?:\/\/\S+/g, '<url>').replace(/\s+/g, ' ').trim().slice(0, 500);

export function recordJoin(guildId, memberId, count, windowMs, durationMs) {
    const now = Date.now();
    const recent = (joins.get(guildId) || []).filter((entry) => now - entry.at < windowMs);
    recent.push({ at: now, memberId });
    joins.set(guildId, recent);
    const crossed = recent.length >= count && (raidModeUntil.get(guildId) || 0) <= now;
    if (recent.length >= count) {
        raidModeUntil.set(guildId, Math.max(raidModeUntil.get(guildId) || 0, now + durationMs));
        persistAdaptiveState();
    }
    return { count: recent.length, crossed, active: (raidModeUntil.get(guildId) || 0) > now, memberIds: [...new Set(recent.map((entry) => entry.memberId))] };
}

export function isAdaptiveRaidActive(guildId) { return (raidModeUntil.get(guildId) || 0) > Date.now(); }

export function adaptiveSpamLimit(guildId, normalLimit) {
    return isAdaptiveRaidActive(guildId) ? Math.max(3, Math.ceil(normalLimit * 0.6)) : normalLimit;
}

export function inspectSpamMessage(message, config) {
    const now = Date.now();
    const key = `${message.guild.id}:${message.author.id}`;
    const history = (messages.get(key) || []).filter((entry) => now - entry.at < Math.max(config.windowMs, 15_000));
    const content = normalize(message.content);
    const fingerprints = message.securityAttachmentHashes || [];
    history.push({ at: now, id: message.id, channelId: message.channel.id, content, attachments: message.attachments?.size || 0, fingerprints });
    messages.set(key, history.slice(-50));

    const window = history.filter((entry) => now - entry.at < config.windowMs);
    const limit = adaptiveSpamLimit(message.guild.id, config.count);
    const duplicateCount = content.length >= 3 ? history.filter((entry) => entry.content === content && now - entry.at < 12_000).length : 0;
    const rapid = history.slice(-4).length >= 4 && history.at(-1).at - history.at(-4).at <= 1_500;
    const crossChannelWindow = history.filter((entry) => now - entry.at < 6_000);
    const channelHopping = new Set(crossChannelWindow.map((entry) => entry.channelId)).size >= 3 && crossChannelWindow.length >= 4;
    const attachmentFlood = history.filter((entry) => now - entry.at < 8_000).reduce((sum, entry) => sum + entry.attachments, 0) >= 3;
    const sameAttachment = fingerprints.some((fingerprint) => history.filter((entry) => now - entry.at < 15_000 && entry.fingerprints.includes(fingerprint)).length >= 3);
    const reason = window.length >= limit ? `${window.length} messages/${Math.round(config.windowMs / 1000)}s`
        : duplicateCount >= 3 ? `${duplicateCount} messages identiques`
            : sameAttachment ? 'pièce jointe identique répétée' : rapid ? 'rafale très rapide' : channelHopping ? 'spam multi-salons' : attachmentFlood ? 'spam de fichiers' : null;
    return { triggered: Boolean(reason), reason, messageIds: window.filter((entry) => entry.channelId === message.channel.id).map((entry) => entry.id), limit, raidMode: isAdaptiveRaidActive(message.guild.id) };
}

export function inspectDistributedMentions(message, limit = 8, windowMs = 12_000) {
    const ids = new Set([...(message.mentions?.users?.keys?.() || []), ...(message.mentions?.roles?.keys?.() || [])]);
    if (!ids.size) return { triggered: false, count: 0 };
    const key = `${message.guild.id}:${message.author.id}`; const now = Date.now();
    const recent = (mentionWindows.get(key) || []).filter((row) => now - row.at < windowMs);
    recent.push({ at: now, id: message.id, channelId: message.channel.id, count: ids.size });
    mentionWindows.set(key, recent.slice(-30));
    const count = recent.reduce((sum, row) => sum + row.count, 0);
    return { triggered: count >= limit && recent.length >= 3, count, messageIds: recent.filter((row) => row.channelId === message.channel.id).map((row) => row.id) };
}

export function nextSpamStep(guildId, userId) {
    const key = `${guildId}:${userId}`; const now = Date.now(); const previous = offences.get(key);
    const count = previous && now - previous.at < 30 * 60_000 ? previous.count + 1 : 1;
    offences.set(key, { count, at: now });
    persistAdaptiveState();
    return Math.min(count, 4);
}

// NB : l'intervalle d'origine ne précisait aucun délai (donc ~0ms en continu).
// Corrigé à 30s, largement suffisant pour ce nettoyage de fenêtres courtes.
setInterval(() => {
    const now = Date.now();
    for (const [key, history] of messages) if (!history.length || now - history.at(-1).at > 120_000) messages.delete(key);
    for (const [key, history] of mentionWindows) if (!history.length || now - history.at(-1).at > 120_000) mentionWindows.delete(key);
    for (const [key, history] of joins) if (!history.length || now - history.at(-1).at > 120_000) joins.delete(key);
    let offencesChanged = false;
    for (const [key, row] of offences) if (now - row.at > 30 * 60_000) { offences.delete(key); offencesChanged = true; }
    let raidChanged = false;
    for (const [key, until] of raidModeUntil) if (until <= now) { raidModeUntil.delete(key); raidChanged = true; }
    if (offencesChanged || raidChanged) persistAdaptiveState();
}, 30_000).unref();
