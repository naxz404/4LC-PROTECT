import { EmbedBuilder, PermissionFlagsBits } from 'discord.js';
import { MODULES, moduleLabel, punishmentLabel } from './antiraid/schema.js';
import { BLUE } from './ui.js';
import { tr } from './i18n.js';

export function protectionEmbed(cfg) {
    const active = MODULES.filter((m) => cfg.enabled[m]);
    const inactive = MODULES.filter((m) => !cfg.enabled[m]);
    const extra = [
        ['RaidMode', cfg.autoRaid.enabled], ['CAPTCHA', cfg.verification.enabled],
        ['HoneyPot', cfg.honeypot.enabled], ['Join-Lock', cfg.joinLock], ['Anti-Nuke', cfg.antiNuke.enabled],
    ];
    return new EmbedBuilder().setColor(BLUE).setTitle(tr(cfg, '🛡️ État des protections', '🛡️ Protection status'))
        .setDescription(`**${active.length}/${MODULES.length}** ${tr(cfg, 'modules actifs', 'modules enabled')}`)
        .addFields(
            { name: tr(cfg, '🟢 Actives', '🟢 Enabled'), value: active.length ? active.map((m) => `${moduleLabel(m, cfg)} · ${punishmentLabel(cfg.punishments[m], cfg)}`).join('\n') : '—' },
            { name: tr(cfg, '⚪ Inactives', '⚪ Disabled'), value: inactive.length ? inactive.map((m) => moduleLabel(m, cfg)).join(' · ') : '—' },
            { name: tr(cfg, '🚨 Autres', '🚨 Others'), value: extra.map(([label, enabled]) => `${enabled ? '🟢' : '⚪'} ${label}`).join(' · ') },
        );
}

export function securityScan(guild, cfg) {
    const everyone = guild.roles.everyone;
    const dangerous = guild.roles.cache.filter((r) => r.id !== everyone.id && r.permissions.has(PermissionFlagsBits.Administrator)).size;
    const enabled = MODULES.filter((m) => cfg.enabled[m]).length;
    let score = 100;
    score -= Math.min(30, dangerous * 5);
    if (everyone.permissions.has(PermissionFlagsBits.Administrator)) score -= 40;
    if (!cfg.logChannel) score -= 10;
    if (!cfg.autoRaid.enabled) score -= 10;
    if (!cfg.verification.enabled) score -= 10;
    score += Math.min(10, enabled);
    return Math.max(0, Math.min(100, score));
}

export function trustScore(member) {
    if (!member) return 0;
    let score = 50;
    const ageDays = (Date.now() - member.user.createdTimestamp) / 86_400_000;
    const joinedDays = member.joinedTimestamp ? (Date.now() - member.joinedTimestamp) / 86_400_000 : 0;
    score += Math.min(25, Math.floor(ageDays / 30));
    score += Math.min(15, Math.floor(joinedDays / 14));
    if (member.user.bot) score -= 30;
    if (member.permissions?.has(PermissionFlagsBits.Administrator)) score += 10;
    return Math.max(0, Math.min(100, score));
}

function whitelistAudit(cfg, action, userId, module, actorId, expiresAt = null) {
    cfg.whitelistHistory ||= [];
    cfg.whitelistHistory.push({ action, userId, module, actorId: actorId || null, expiresAt, at: Date.now() });
    cfg.whitelistHistory = cfg.whitelistHistory.slice(-200);
}

export function pruneWhitelist(cfg) {
    const now = Date.now(); const expired = (cfg.whitelistEntries || []).filter((entry) => entry.expiresAt && entry.expiresAt <= now);
    cfg.whitelistEntries = (cfg.whitelistEntries || []).filter((entry) => !entry.expiresAt || entry.expiresAt > now);
    for (const entry of expired) whitelistAudit(cfg, 'expire', entry.userId, entry.module, null, entry.expiresAt);
    return expired.length;
}

export function setWhitelist(cfg, userId, module = 'all', durationMinutes = 0, actorId = null) {
    pruneWhitelist(cfg);
    cfg.whitelistEntries = (cfg.whitelistEntries || []).filter((entry) => !(entry.userId === userId && entry.module === module));
    const expiresAt = durationMinutes ? Date.now() + durationMinutes * 60_000 : null;
    cfg.whitelistEntries.push({ userId, module, expiresAt });
    whitelistAudit(cfg, 'add', userId, module, actorId, expiresAt);
}

export function removeWhitelist(cfg, userId, module = 'all', actorId = null) {
    pruneWhitelist(cfg);
    const before = (cfg.whitelistEntries || []).length;
    cfg.whitelistEntries = (cfg.whitelistEntries || []).filter((entry) => !(entry.userId === userId && (module === 'all' || entry.module === module)));
    if (module === 'all') cfg.whitelistedUsers = cfg.whitelistedUsers.filter((id) => id !== userId);
    if (before !== cfg.whitelistEntries.length) whitelistAudit(cfg, 'remove', userId, module, actorId);
    return before !== cfg.whitelistEntries.length;
}

export function whitelistHistoryText(cfg) {
    pruneWhitelist(cfg);
    const labels = { add: '+', remove: '−', expire: '⌛' };
    return (cfg.whitelistHistory || []).slice(-15).reverse().map((entry) => `${labels[entry.action] || '•'} <@${entry.userId}> · **${entry.module}** · ${entry.actorId ? `<@${entry.actorId}>` : 'système'} · <t:${Math.floor(entry.at / 1000)}:R>`).join('\n') || 'Aucun changement enregistré.';
}
