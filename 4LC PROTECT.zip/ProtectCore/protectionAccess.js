import { isGlobalOwner } from '../Owners.js';
import { MODULES } from './antiraid/schema.js';
import config from './config.js';

// Secure donne uniquement accès aux interrupteurs, jamais une exemption anti-raid.
export const TOGGLE_COMMANDS = new Set([...MODULES, 'antijoin', 'antinuke', 'phishing', 'ghost-ping', 'ghostping', 'warning-system', 'warningsystem', 'captcha', 'verification', 'honeypot', 'join-lock', 'anti-raid', 'raidmode', 'allanti']);
export const PANEL_COMMANDS = new Set(['config', 'settings', 'setup', 'protectstatus']);
const OWNER_COMMANDS = new Set(['allpunish', 'secure', 'unsecure', 'punish', 'whitelist', 'unwhitelist', 'protectionlevel', 'protection-level', 'panic', 'simulation', 'filter', 'jail-config', 'prefix', 'language', 'tag-role', 'display', 'lock-icon', 'logs', 'logchannel', 'appealurl', 'appeal-config', 'backup', 'restore', 'blacklist']);
export { isGlobalOwner } from '../Owners.js';
export const isGuildOwner = (guild, userId) => Boolean(userId && (guild?.ownerId === userId || isGlobalOwner(userId)));
export const isSecure = (guild, userId, cfg) => isGuildOwner(guild, userId) || Boolean(userId && Array.isArray(cfg?.secureUsers) && cfg.secureUsers.includes(userId));
export const accessAllowed = (access, guild, userId, cfg) => access === 'owner' ? isGuildOwner(guild, userId) : access === 'secure' ? isSecure(guild, userId, cfg) : true;
export const accessDenied = (access, cfg = {}) => cfg.language === 'en'
    ? (access === 'owner' ? '⛔ Only the server owner or a bot owner can change these settings or manage the Secure list.' : '⛔ Only the server owner and Secure members can enable or disable protections.')
    : (access === 'owner' ? '⛔ Seuls le propriétaire du serveur ou un owner du bot peuvent modifier ces réglages ou gérer la liste Secure.' : '⛔ Seuls le propriétaire du serveur et les membres Secure peuvent activer ou désactiver les protections.');

export function prefixProtectionAccess(name, args = []) {
    if (OWNER_COMMANDS.has(name)) return 'owner';
    if (PANEL_COMMANDS.has(name)) return 'secure';
    if (name === 'protect') {
        const sub = args[0]?.toLowerCase();
        if (!sub || ['status', 'panel', 'panneau', 'setup', 'installation'].includes(sub)) return 'secure';
        return ['on', 'off'].includes(sub) && args.length === 2 ? 'secure' : 'owner';
    }
    if (TOGGLE_COMMANDS.has(name)) return args.length <= 1 ? 'secure' : 'owner';
    return null;
}

export function slashProtectionAccess(name, options) {
    if (OWNER_COMMANDS.has(name)) return 'owner';
    if (PANEL_COMMANDS.has(name) || name === 'protect') return 'secure';
    if (TOGGLE_COMMANDS.has(name)) {
        // Toute option supplémentaire (même identique à la valeur existante) est réservée au propriétaire.
        return (options.data || []).some((option) => option.name !== 'activer') ? 'owner' : 'secure';
    }
    if (name === 'badwords') {
        const action = options.getString('action');
        return ['on', 'off', 'list'].includes(action) && (options.data || []).every((o) => o.name === 'action') ? 'secure' : 'owner';
    }
    return null;
}

const SECURE_COMPONENTS = new Set([
    'sar:panel', 'sar:send', 'sar:panel:send', 'sar:panel:refresh', 'sar:panel:nav', 'sar:panel:back',
    'sar:welcome:setup', 'sar:setup:modules', 'sar:setup:cancel', 'sar:setup:confirm',
    'sar:panel:toggle', 'sar:links:toggle', 'sar:badwords:toggle', 'sar:cp:toggle', 'sar:hp:toggle',
    'sar:panel:links', 'sar:panel:badwords', 'sar:panel:verification', 'sar:panel:honeypot',
    'sar:panel:join', 'sar:panel:join:confirm:on', 'sar:panel:join:confirm:off', 'sar:panel:level',
]);
export function componentProtectionAccess(id, values = []) {
    if (id === 'sar:level:set' && ['antinuke:on', 'antinuke:off'].includes(values[0])) return 'secure';
    return SECURE_COMPONENTS.has(id) ? 'secure' : 'owner';
}
