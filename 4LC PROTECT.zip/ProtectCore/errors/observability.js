// Adapté de Handler/v4/observability.js de 4LC-PROTECT : capture centralisée des
// erreurs avec un identifiant court, masquage du token et des webhooks, et
// interception de console.error pour ne rien laisser passer.
import { randomBytes } from 'node:crypto';
import config from '../config.js';
import { pushError, listErrors, findError } from '../storage.js';

export function clean(value) {
    let s = String(value ?? '')
        .replace(/https:\/\/(?:\w+\.)?(?:discord(?:app)?\.com)\/api(?:\/v\d+)?\/webhooks\/[^\s"'<>]+/gi, '[webhook masqué]')
        .replace(/[A-Za-z0-9_-]{20,}\.[A-Za-z0-9_-]{6,}\.[A-Za-z0-9_-]{20,}/g, '[token masqué]');
    if (config.token) s = s.split(config.token).join('[token masqué]');
    return s.slice(0, 1800);
}

/** Enregistre une erreur et renvoie son identifiant court (ex. ERR-A1B2C3D4). */
export function captureError(error, source = 'runtime', guildId = null) {
    const id = `ERR-${randomBytes(4).toString('hex').toUpperCase()}`;
    try {
        pushError({
            id,
            at: Date.now(),
            source: clean(source),
            guildId,
            message: clean(error?.message || error),
            stack: clean(error?.stack || ''),
        });
    } catch {
        console.error(`[${id}] Journal d'erreurs indisponible.`);
    }
    return id;
}

export { listErrors, findError };

let installed = false;
/** Intercepte console.error et les erreurs process non gérées pour qu'aucune
 * erreur ne passe sous le radar sans être journalisée. */
export function installErrorCapture() {
    if (installed) return;
    installed = true;
    const original = console.error.bind(console);
    let recording = false;
    console.error = (...args) => {
        const message = args.map((v) => (v instanceof Error ? v.message : typeof v === 'string' ? v : '[objet diagnostic]')).join(' ');
        if (recording) return original(clean(message));
        recording = true;
        try {
            const id = captureError(Error(message), 'console');
            original(`[${id}] ${clean(message)}`);
        } finally {
            recording = false;
        }
    };
    process.on('uncaughtException', (error) => {
        const id = captureError(error, 'uncaughtException');
        original(`[${id}] Exception non interceptée:`, clean(error?.stack || error));
    });
    process.on('unhandledRejection', (reason) => {
        const id = captureError(reason instanceof Error ? reason : Error(String(reason)), 'unhandledRejection');
        original(`[${id}] Rejet de promesse non géré:`, clean(reason?.stack || reason));
    });
}
