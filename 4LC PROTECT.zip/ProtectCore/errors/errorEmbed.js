import { EmbedBuilder } from 'discord.js';

export default function buildErrorEmbed(title, desc) {
    const heading = /^\d{3}\s/.test(String(title)) ? title : title === 'Maintenance' ? '503 Service Unavailable' : '500 Internal Server Error';
    const clean = String(desc || 'Une erreur est survenue.').split('\n')
        .map((line) => line.replace(/^\s*>\s*/, '').replace(/^\*+|\*+$/g, '').trim())
        .filter(Boolean).map((line) => `> *${line}*`).join('\n');
    return new EmbedBuilder().setTitle(' ').setDescription(`# ❌ 〃 ${heading}\n\n${clean}`).setColor(0x000000);
}

export function inferErrorCode(value) {
    const text = String(value || '').toLowerCase();
    if (/trop de|too many|attendez|wait|cooldown/.test(text)) return '429 Too Many Requests';
    if (/indisponible|hors ligne|maintenance|unavailable|offline/.test(text)) return '503 Service Unavailable';
    if (/introuvable|n.existe plus|inconnue?|not found|unknown|non configuré|not configured/.test(text)) return '404 Not Found';
    if (/interdit|forbidden|blacklist|quarantaine|non autorisé|not allowed/.test(text)) return '403 Forbidden';
    if (/permission|réservé|reserved|unauthorized|pas accès|insufficient/.test(text)) return '401 Unauthorized';
    if (/déjà|already|expirée?|expired|conflit|conflict/.test(text)) return '409 Conflict';
    if (/erreur|error|impossible|failed|diagnostic/.test(text)) return '500 Internal Server Error';
    return '400 Bad Request';
}

export function looksLikeError(value) {
    return /^(❌|⚠️|🔴|⛔)|introuvable|invalide|impossible|indisponible|permission|accès refusé|réservé|trop de|attendez|déjà|expirée?|une erreur|doit être|utilisation\s*:|unknown|invalid|failed|unavailable|insufficient|forbidden|not found|must be|usage\s*:/i.test(String(value || '').trim());
}

export function normalizeErrorPayload(payload) {
    const source = typeof payload === 'string' ? { content: payload } : payload;
    if (!source || source.embeds?.length || !looksLikeError(source.content)) return payload;
    const clean = String(source.content).replace(/^(❌|⚠️|🔴|⛔)\s*/, '').trim();
    return { ...source, content: undefined, embeds: [buildErrorEmbed(inferErrorCode(clean), clean)] };
}

export function installErrorNormalizer(target) {
    for (const method of ['reply', 'followUp', 'editReply', 'update']) {
        if (typeof target?.[method] !== 'function') continue;
        const original = target[method].bind(target);
        target[method] = (payload) => original(normalizeErrorPayload(payload));
    }
}
