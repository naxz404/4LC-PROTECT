import { addSanction, getGuildConfig, getSanctions, saveGuildConfig } from './storage.js';
import { sendTempBanNotice } from './tempBans.js';
import { buildAntiRaidEmbed, sendLog } from './antiraid/logs.js';
import { tr } from './i18n.js';
import { punishmentDuration } from './antiraid/schema.js';

export function warningPoints(guildId, userId) { return getSanctions(guildId, userId).filter((entry) => entry.type === 'warn').reduce((sum, entry) => sum + (Number(entry.points) || 1), 0); }

export async function applyProgressiveWarning(client, member, reason, moderatorId, points = 1, module = null) {
    const cfg = getGuildConfig(member.guild.id);
    addSanction(member.guild.id, { userId: member.id, type: 'warn', points, description: reason, moderatorId });
    const total = warningPoints(member.guild.id, member.id); const thresholds = cfg.warningSystem;
    if (thresholds?.enabled === false) return { total, action: 'warn' };
    let action = 'warn';
    if (total >= (thresholds.banPoints || 10) && member.bannable) { action = 'ban'; await member.ban({ reason: `Avertissements progressifs : ${total} points · ${reason}` }); }
    else if (total >= (thresholds.tempBanPoints || 7) && member.bannable) {
        action = 'tempban'; const durationMs = thresholds.tempBanMs || 86_400_000;
        await sendTempBanNotice(member.user, member.guild, durationMs, reason, cfg);
        await member.ban({ reason: `Avertissements progressifs : ${total} points · ${reason}` });
        cfg.tempBans = (cfg.tempBans || []).filter((entry) => entry.userId !== member.id); cfg.tempBans.push({ userId: member.id, expiresAt: Date.now() + durationMs, reason }); saveGuildConfig(member.guild.id, cfg);
    } else if (total >= (thresholds.kickPoints || 5) && member.kickable) { action = 'kick'; await member.kick(`Avertissements progressifs : ${total} points · ${reason}`); }
    else if (total >= (thresholds.mutePoints || 3) && member.moderatable) { action = 'timeout'; await member.timeout(module ? punishmentDuration(cfg, module, 60 * 60_000) : 60 * 60_000, `Avertissements progressifs : ${total} points · ${reason}`); }
    if (action !== 'warn') await sendLog(client, member.guild.id, buildAntiRaidEmbed(tr(cfg, 'Sanction progressive', 'Progressive punishment'), `${member.user.tag} · **${total} points**\n${tr(cfg, 'Action', 'Action')} : **${action}**\n${tr(cfg, 'Raison', 'Reason')} : ${reason}`));
    return { total, action };
}
