import { buildAntiRaidEmbed, sendLog } from './antiraid/logs.js';
import { getGuildConfig } from './storage.js';
import { tr } from './i18n.js';
import { applyProgressiveWarning } from './warningSystem.js';

const candidates = new Map();
const moderated = new Set();

export function rememberGhostPingCandidate(message) {
    if (!message.guild || message.author.bot) return;
    const users = [...(message.mentions?.users?.keys?.() || [])]; const roles = [...(message.mentions?.roles?.keys?.() || [])];
    if (!users.length && !roles.length && !message.mentions?.everyone) return;
    candidates.set(message.id, { guildId: message.guild.id, channelId: message.channel.id, authorId: message.author.id, content: String(message.content || '').slice(0, 1200), users, roles, everyone: Boolean(message.mentions?.everyone), createdAt: message.createdTimestamp || Date.now() });
    setTimeout(() => candidates.delete(message.id), 60_000).unref();
}

export function markModeratedDeletion(messageId) { moderated.add(messageId); setTimeout(() => moderated.delete(messageId), 60_000).unref(); }

export async function handleGhostPingDelete(client, message) {
    const item = candidates.get(message.id); candidates.delete(message.id);
    if (!item || moderated.delete(message.id)) return false;
    const cfg = getGuildConfig(item.guildId);
    if (cfg.ghostPing?.enabled === false || Date.now() - item.createdAt > (cfg.ghostPing?.maxAgeMs || 30_000)) return false;
    const mentions = [...item.users.map((id) => `<@${id}>`), ...item.roles.map((id) => `<@&${id}>`), ...(item.everyone ? ['@everyone/@here'] : [])].join(', ');
    let sanction = 'warn';
    const guild = client.guilds.cache.get(item.guildId);
    const member = guild ? await guild.members.fetch(item.authorId).catch(() => null) : null;
    if (member) {
        const result = await applyProgressiveWarning(client, member, 'Ghost ping : mention supprimée', client.user.id, 1, 'antieveryone').catch(() => null);
        if (result?.action) sanction = result.action;
    }
    await sendLog(client, item.guildId, buildAntiRaidEmbed(tr(cfg, 'Ghost Ping détecté', 'Ghost ping detected'), `${tr(cfg, 'Auteur', 'Author')} : <@${item.authorId}>\n${tr(cfg, 'Salon', 'Channel')} : <#${item.channelId}>\n${tr(cfg, 'Mentions', 'Mentions')} : ${mentions}\nSanction : **${sanction}**\n${tr(cfg, 'Contenu supprimé', 'Deleted content')} :\n\`\`\`${item.content.replace(/```/g, 'ʼʼʼ') || '(vide)'}\`\`\``));
    return true;
}
