import { ChannelType, EmbedBuilder, PermissionFlagsBits } from 'discord.js';
import { getGuildConfig, saveGuildConfig } from './storage.js';
import { invalidateSettings } from './antiraid/runtime.js';
import { tr } from './i18n.js';

function permissionState(overwrite, permission) {
    if (overwrite?.allow.has(permission)) return true;
    if (overwrite?.deny.has(permission)) return false;
    return null;
}

function nextCase(cfg) {
    cfg.lockCaseSequence = Math.max(0, Number(cfg.lockCaseSequence) || 0) + 1;
    return `CASE-${String(cfg.lockCaseSequence).padStart(6, '0')}`;
}

function safeReason(value, cfg) {
    return String(value || tr(cfg, 'Aucune raison fournie', 'No reason provided')).replace(/@/g, '@\u200b').slice(0, 250);
}

export function lockSuccessEmbed(channel, detail, cfg = {}) {
    return new EmbedBuilder().setTitle(' ').setColor(0x000000).setDescription(
        `# ⚡ 〃 ${tr(cfg, 'Salon verrouillé', 'Channel locked')}\n` +
        `> ***${tr(cfg, 'Salon', 'Channel')} :** ${channel}*\n` +
        `> ***${tr(cfg, 'Raison', 'Reason')} :** ${detail.reason}*\n` +
        `> ***Case :** \`${detail.caseId}\`*\n` +
        `> *${tr(cfg, "L’état précédent des permissions a été sauvegardé et sera restauré avec /unlock.", 'The previous permission state was saved and will be restored with /unlock.')}*`,
    );
}

export function unlockSuccessEmbed(channel, detail, cfg = {}) {
    return new EmbedBuilder().setTitle(' ').setColor(0x000000).setDescription(
        `# ✅ 〃 ${tr(cfg, 'Salon déverrouillé', 'Channel unlocked')}\n` +
        `> ***${tr(cfg, 'Salon', 'Channel')} :** ${channel}*\n` +
        `> ***${tr(cfg, 'Raison', 'Reason')} :** ${detail.reason}*\n` +
        `> ***${tr(cfg, 'Permissions restaurées', 'Permissions restored')} :** ${detail.permissionsRestored}*\n` +
        `> ***${tr(cfg, 'Verrouillage d’origine', 'Original lock')} :** \`${detail.originCaseId || 'N/A'}\` (${tr(cfg, 'toujours consultable', 'still recorded')})*\n` +
        `> ***Case :** \`${detail.caseId}\`*`,
    );
}

export function renewSuccessEmbed(cfg = {}) {
    return new EmbedBuilder().setTitle(' ').setColor(0x000000).setDescription(
        `# ✅ 〃 ${tr(cfg, 'Salon renouvelé', 'Channel renewed')}\n\n` +
        `> *${tr(cfg, "Le salon a été recréé avec ses paramètres et permissions. L'ancien historique a été supprimé.", 'The channel was recreated with its settings and permissions. The old history was deleted.')}*`,
    );
}

export async function renewChannel(channel, actorId) {
    if (channel?.type !== ChannelType.GuildText || typeof channel.clone !== 'function') throw new Error('Salon texte requis.');
    const clone = await channel.clone({ reason: `Renouvellement par ${actorId}` });
    try {
        await clone.setPosition(channel.rawPosition, `Renouvellement par ${actorId}`).catch(() => {});
        if (channel.parentId && typeof clone.setParent === 'function') await clone.setParent(channel.parentId, { lockPermissions: false, reason: `Renouvellement par ${actorId}` }).catch(() => {});
        await channel.delete(`Renouvellement par ${actorId}`);
        const cfg = getGuildConfig(channel.guild.id);
        if (cfg.logChannel === channel.id) cfg.logChannel = clone.id;
        if (cfg.reportChannel === channel.id) cfg.reportChannel = clone.id;
        for (const section of ['verification', 'honeypot', 'jail']) {
            if (cfg[section]?.channelId === channel.id) cfg[section].channelId = clone.id;
        }
        if (cfg.lockSnapshot?.[channel.id]) {
            cfg.lockSnapshot[clone.id] = cfg.lockSnapshot[channel.id];
            delete cfg.lockSnapshot[channel.id];
        }
        cfg.localizedMessages = (cfg.localizedMessages || []).filter((entry) => entry.channelId !== channel.id);
        saveGuildConfig(channel.guild.id, cfg);
        invalidateSettings(channel.guild.id);
        return clone;
    } catch (error) {
        await clone.delete('Annulation du renouvellement incomplet').catch(() => {});
        throw error;
    }
}

export async function lockChannels(guild, channels, actorId, reason = null) {
    const cfg = getGuildConfig(guild.id);
    const snapshot = cfg.lockSnapshot || {};
    cfg.lockHistory ||= [];
    const cleanReason = safeReason(reason, cfg);
    let locked = 0;
    const details = [];
    for (const channel of channels) {
        if (channel.type !== ChannelType.GuildText || Object.hasOwn(snapshot, channel.id)) continue;
        const overwrite = channel.permissionOverwrites.cache.get(guild.id);
        const send = permissionState(overwrite, PermissionFlagsBits.SendMessages);
        const addReactions = permissionState(overwrite, PermissionFlagsBits.AddReactions);
        try {
            await channel.permissionOverwrites.edit(guild.id, { SendMessages: false, AddReactions: false }, { reason: `Verrouillage par ${actorId}` });
        } catch (error) {
            console.warn(`Impossible de verrouiller ${channel.id}: ${error.message}`);
            continue;
        }
        const caseId = nextCase(cfg);
        snapshot[channel.id] = { send, addReactions, name: null, hadOverwrite: Boolean(overwrite), caseId, reason: cleanReason, actorId, lockedAt: Date.now() };
        cfg.lockHistory.push({ caseId, type: 'lock', channelId: channel.id, actorId, reason: cleanReason, at: Date.now() });
        cfg.lockHistory = cfg.lockHistory.slice(-100);
        cfg.lockSnapshot = snapshot;
        saveGuildConfig(guild.id, cfg);
        locked++;
        details.push({ channel, caseId, reason: cleanReason });
        if (cfg.lockIcon && !channel.name.startsWith('🔒・') && channel.name.length < 96) {
            const original = channel.name;
            try {
                await channel.setName(`🔒・${original}`, `Verrouillage par ${actorId}`);
                snapshot[channel.id].name = original;
                saveGuildConfig(guild.id, cfg);
            } catch (error) {
                console.warn(`Impossible de renommer ${channel.id}: ${error.message}`);
            }
        }
    }
    return { locked, total: Object.keys(snapshot).length, details };
}

export async function unlockChannels(guild, channelId, actorId, reason = null) {
    const cfg = getGuildConfig(guild.id);
    const snapshot = cfg.lockSnapshot || {};
    cfg.lockHistory ||= [];
    const cleanReason = safeReason(reason, cfg);
    let restored = 0;
    const details = [];
    const requested = Object.entries(snapshot).filter(([id]) => !channelId || channelId === id);
    for (const [id, state] of requested) {
        const channel = guild.channels.cache.get(id);
        if (!channel) {
            delete snapshot[id];
            cfg.lockSnapshot = Object.keys(snapshot).length ? snapshot : null;
            saveGuildConfig(guild.id, cfg);
            continue;
        }
        try {
            const values = { SendMessages: typeof state === 'object' && state !== null ? state.send : state };
            if (typeof state === 'object' && state !== null && Object.hasOwn(state, 'addReactions')) values.AddReactions = state.addReactions;
            await channel.permissionOverwrites.edit(guild.id, values, { reason: `Déverrouillage par ${actorId}` });
            if (state?.hadOverwrite === false) {
                const current = channel.permissionOverwrites.cache.get(guild.id);
                if (current && current.allow.bitfield === 0n && current.deny.bitfield === 0n) await channel.permissionOverwrites.delete(guild.id, `Déverrouillage par ${actorId}`);
            }
            if (state?.name && channel.name === `🔒・${state.name}`) await channel.setName(state.name, `Déverrouillage par ${actorId}`);
            delete snapshot[id];
            const caseId = nextCase(cfg);
            const permissionsRestored = Object.hasOwn(values, 'AddReactions') ? 2 : 1;
            const originCaseId = state?.caseId || 'N/A';
            cfg.lockHistory.push({ caseId, type: 'unlock', originCaseId, channelId: id, actorId, reason: cleanReason, at: Date.now() });
            cfg.lockHistory = cfg.lockHistory.slice(-100);
            cfg.lockSnapshot = Object.keys(snapshot).length ? snapshot : null;
            saveGuildConfig(guild.id, cfg);
            restored++;
            details.push({ channel, caseId, originCaseId, permissionsRestored, reason: cleanReason });
        } catch (error) {
            console.warn(`Impossible de déverrouiller ${id}: ${error.message}`);
        }
    }
    return { restored, requested: requested.length, remaining: Object.keys(snapshot).length, details };
}
