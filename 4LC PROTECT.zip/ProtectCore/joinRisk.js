/** Indicateurs pondérés. Un critère seul n'entraîne pas une quarantaine. */
export function scoreJoinRisk(user, now = Date.now()) {
    const age = Math.max(0, now - (user.createdTimestamp || now));
    const indicators = [];
    if (age < 60 * 60_000) indicators.push({ name: 'compte créé il y a moins d’une heure', points: 45 });
    else if (age < 24 * 60 * 60_000) indicators.push({ name: 'compte créé il y a moins d’un jour', points: 30 });
    else if (age < 7 * 24 * 60 * 60_000) indicators.push({ name: 'compte créé il y a moins de sept jours', points: 12 });
    if (!user.avatar) indicators.push({ name: 'avatar par défaut', points: 15 });
    if (/(nitro|airdrop|crypto|support|discord.?staff|free.?gift)/i.test(user.username || ''))
        indicators.push({ name: 'nom trompeur', points: 35 });
    // discriminator 0 est normal sur Discord ; il ne constitue pas un signal.
    return { score: Math.min(100, indicators.reduce((sum, row) => sum + row.points, 0)), indicators };
}
