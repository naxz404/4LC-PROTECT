import { allowedGuilds } from '../ServerScope.js';
import { ActivityType } from 'discord.js';
import { readActivityConfig } from './config.js';

let lastSignature = null;
let lastResolvedName = null;
let lastDynamicRefreshAt = 0;
const DYNAMIC_REFRESH_INTERVAL = 5 * 60_000;
const numberFormatter = new Intl.NumberFormat('fr-FR');

/**
 * Variables dynamiques utilisables dans le nom du statut, ex :
 * "{membres} Membres sur {serveurs} serveurs".
 * Si le texte ne contient aucune variable (ex: "Opérationnel"), il est
 * utilisé tel quel, sans aucun traitement.
 */
function hasDynamicVars(name) {
    return typeof name === 'string' && /\{(membres|serveurs)\}/i.test(name);
}

function resolveName(name, client) {
    if (!hasDynamicVars(name)) return name;
    const servers = allowedGuilds(client).length;
    const members = allowedGuilds(client).reduce((total, g) => total + (g.memberCount ?? 0), 0);
    return name
        .replace(/\{membres\}/gi, numberFormatter.format(members))
        .replace(/\{serveurs\}/gi, numberFormatter.format(servers));
}

export function applyConfiguredPresence(client, { force = false } = {}) {
    const configured = readActivityConfig();
    const signature = JSON.stringify(configured);
    const dynamic = hasDynamicVars(configured.name);
    // Pour un statut dynamique, on force une revérification périodique
    // (les chiffres évoluent même si le fichier de config, lui, ne change pas).
    const dueForDynamicRefresh = dynamic && Date.now() - lastDynamicRefreshAt >= DYNAMIC_REFRESH_INTERVAL;
    if (!force && !dueForDynamicRefresh && signature === lastSignature) return { ...configured, changed: false };

    const resolvedName = resolveName(configured.name, client);
    if (!force && dynamic && signature === lastSignature && resolvedName === lastResolvedName) {
        // Config inchangée et chiffres identiques : rien à renvoyer à Discord.
        lastDynamicRefreshAt = Date.now();
        return { ...configured, name: resolvedName, changed: false };
    }

    const activity = resolvedName ? (configured.type === 'Custom' ? { name: 'Custom Status', state: resolvedName, type: ActivityType.Custom } : { name: resolvedName, type: ActivityType[configured.type] ?? ActivityType.Watching }) : null;
    if (activity && configured.type === 'Streaming' && configured.url) activity.url = configured.url;
    client.user.setPresence({ status: configured.status, activities: [...(activity ? [activity] : []), ...(configured.type === 'Custom' && activity ? [] : [{ name: 'Custom Status', state: 'By 4LC | discord.gg/ddJMXWYJ29', type: ActivityType.Custom }])] });
    lastSignature = signature;
    lastResolvedName = resolvedName;
    lastDynamicRefreshAt = Date.now();
    console.log(`✅ Statut actualisé : ${configured.status} · ${configured.type} ${resolvedName || '(aucune activité)'}`);
    return { ...configured, name: resolvedName, changed: true };
}
