import { resolve } from 'node:path';
export const protectionDataDir = resolve(process.env.FOUR_LC_DATA_DIR || resolve(import.meta.dirname, '4LC-DATA'));
