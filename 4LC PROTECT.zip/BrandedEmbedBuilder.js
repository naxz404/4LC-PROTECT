import { EmbedBuilder } from 'discord.js';

export const FOUR_LC_BRAND = 'By 4LC | discord.gg/ddJMXWYJ29';

// Identité visuelle du bot : tous les embeds 4LC affichent la signature.
export class BrandedEmbedBuilder extends EmbedBuilder {
    constructor(data) {
        super(data);
        if (!this.data.footer) this.setFooter({ text: FOUR_LC_BRAND });
    }
}
