import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
const file = path.join(path.dirname(fileURLToPath(import.meta.url)), '..', 'captcha-settings.json');
const defaults = () => ({ language: 'fr', verification: { enabled: false, roleId: null, verifiedRoleId: null, channelId: null, captchaEnabled: true, timeoutMs: 300000, maxAttempts: 3, kickOnFail: true, ignoreBots: true } });
let data;
function read() {
    if (data) return data;
    try { data = JSON.parse(fs.readFileSync(file, 'utf8')); }
    catch (err) { if (err.code !== 'ENOENT') console.error('[Captcha] Lecture des réglages:', err); data = {}; }
    return data;
}
export function getGuildConfig(guildId) {
    const all = read();
    const stored = all[guildId] || {};
    return { ...defaults(), ...stored, verification: { ...defaults().verification, ...stored.verification } };
}
export function saveGuildConfig(guildId, cfg) {
    const all = read(); all[guildId] = cfg;
    const tmp = `${file}.tmp`;
    fs.writeFileSync(tmp, JSON.stringify(all, null, 2));
    fs.renameSync(tmp, file);
}
