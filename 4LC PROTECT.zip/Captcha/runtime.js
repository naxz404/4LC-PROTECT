export function invalidateSettings() { /* Configuration CAPTCHA lue directement. */ }
