export function tr(cfg, fr, en) { return cfg?.language === 'en' ? en : fr; }
