import { clearGuildCaptchaSessions } from './captcha.js';
import { ChannelType, PermissionFlagsBits } from 'discord.js';
import { getGuildConfig, saveGuildConfig } from './storage.js';
import { invalidateSettings } from './runtime.js';

const BLUE = 0x3498db;

function persist(guildId, cfg) {
    saveGuildConfig(guildId, cfg);
    invalidateSettings(guildId);
}

export async function ensureUnverifiedRole(guild) {
    const cfg = getGuildConfig(guild.id);
    let role = cfg.verification.roleId ? guild.roles.cache.get(cfg.verification.roleId) : null;
    if (!role) role = guild.roles.cache.find((item) => item.name.toLowerCase() === 'unverified' && !item.managed) || null;
    const me = guild.members.me || await guild.members.fetchMe().catch(() => null);
    if (!role && me?.permissions.has(PermissionFlagsBits.ManageRoles)) {
        role = await guild.roles.create({ name: 'Unverified', permissions: [], color: BLUE, reason: 'Rôle CAPTCHA automatique 4LC-PROTECT' }).catch(() => null);
    }
    if (role && cfg.verification.roleId !== role.id) {
        cfg.verification.roleId = role.id;
        cfg.verification.captchaEnabled = true;
        persist(guild.id, cfg);
    }
    return role;
}

export async function protectChannelForVerification(channel, cfg = getGuildConfig(channel.guild.id)) {
    if (!cfg.verification?.enabled || !cfg.verification.roleId || channel.id === cfg.verification.channelId || !channel.permissionOverwrites?.edit) return false;
    const role = channel.guild.roles.cache.get(cfg.verification.roleId);
    if (!role) return false;
    await channel.permissionOverwrites.edit(role, { ViewChannel: false, SendMessages: false, AddReactions: false, CreatePublicThreads: false, CreatePrivateThreads: false, SendMessagesInThreads: false }, { reason: 'Isolation automatique des membres non vérifiés' });
    return true;
}

async function ensureVerificationChannel(guild, cfg, role) {
    let channel = cfg.verification.channelId ? await guild.channels.fetch(cfg.verification.channelId).catch(() => null) : null;
    if (!channel?.isTextBased()) channel = guild.channels.cache.find((item) => item.type === ChannelType.GuildText && item.name === '4lc-protect-verification') || null;
    const me = guild.members.me || await guild.members.fetchMe();
    if (!channel) {
        channel = await guild.channels.create({
            name: '4lc-protect-verification', type: ChannelType.GuildText, reason: 'Salon CAPTCHA automatique 4LC-PROTECT',
            permissionOverwrites: [
                { id: guild.roles.everyone.id, deny: [PermissionFlagsBits.ViewChannel] },
                { id: role.id, allow: [PermissionFlagsBits.ViewChannel, PermissionFlagsBits.ReadMessageHistory], deny: [PermissionFlagsBits.SendMessages, PermissionFlagsBits.AddReactions, PermissionFlagsBits.CreatePublicThreads, PermissionFlagsBits.CreatePrivateThreads] },
                { id: me.id, allow: [PermissionFlagsBits.ViewChannel, PermissionFlagsBits.SendMessages, PermissionFlagsBits.EmbedLinks, PermissionFlagsBits.ReadMessageHistory, PermissionFlagsBits.ManageMessages] },
            ],
        });
    } else {
        await channel.permissionOverwrites.edit(guild.roles.everyone, { ViewChannel: false }, { reason: 'Permissions CAPTCHA 4LC-PROTECT' });
        await channel.permissionOverwrites.edit(role, { ViewChannel: true, ReadMessageHistory: true, SendMessages: false, AddReactions: false, CreatePublicThreads: false, CreatePrivateThreads: false }, { reason: 'Permissions CAPTCHA 4LC-PROTECT' });
        await channel.permissionOverwrites.edit(me, { ViewChannel: true, SendMessages: true, EmbedLinks: true, ReadMessageHistory: true, ManageMessages: true }, { reason: 'Permissions CAPTCHA 4LC-PROTECT' });
    }
    cfg.verification.channelId = channel.id;
    return channel;
}

export async function removeLegacyVerificationPanels(guild) {
    const cfg = getGuildConfig(guild.id);
    const channel = cfg.verification?.channelId ? await guild.channels.fetch(cfg.verification.channelId).catch(() => null) : null;
    if (!channel?.messages?.fetch) return 0;
    const recent = await channel.messages.fetch({ limit: 100 }).catch(() => null);
    if (!recent) return 0;
    const legacy = recent.filter((message) => message.author.id === guild.client.user.id && message.components.some((row) => row.components.some((component) => ['sar:captcha:start', 'sar:verify'].includes(component.customId))));
    let deleted = 0;
    for (const message of legacy.values()) if (await message.delete().then(() => true).catch(() => false)) deleted++;
    return deleted;
}

export async function enableVerificationEnvironment(guild, options = {}) {
    const cfg = getGuildConfig(guild.id);
    const role = options.role || (cfg.verification.roleId ? guild.roles.cache.get(cfg.verification.roleId) : null) || await ensureUnverifiedRole(guild);
    if (!role) throw Error('Rôle Unverified impossible à créer. Permission Gérer les rôles requise.');
    const me = guild.members.me || await guild.members.fetchMe();
    if (role.id === guild.id || role.managed || role.position >= me.roles.highest.position || role.permissions.has(PermissionFlagsBits.Administrator)) throw Error('Le rôle Unverified doit être ordinaire, sans Administrateur et sous le rôle du bot.');
    cfg.verification = { ...cfg.verification, enabled: true, captchaEnabled: true, roleId: role.id, verifiedRoleId: options.verifiedRole?.id ?? cfg.verification.verifiedRoleId ?? null };
    const channel = await ensureVerificationChannel(guild, cfg, role);
    persist(guild.id, cfg);
    let protectedChannels = 0;
    for (const candidate of guild.channels.cache.values()) if (await protectChannelForVerification(candidate, cfg).catch(() => false)) protectedChannels++;
    await removeLegacyVerificationPanels(guild);
    return { role, channel, protectedChannels };
}

export async function disableVerificationEnvironment(guild) {
    const cfg = getGuildConfig(guild.id);
    const role = cfg.verification.roleId ? guild.roles.cache.get(cfg.verification.roleId) : null;
    cfg.verification.enabled = false;
    persist(guild.id, cfg);
    await clearGuildCaptchaSessions(guild.client, guild.id);
    if (role) {
        await guild.members.fetch().catch(() => null);
        for (const member of role.members.values()) await member.roles.remove(role, 'CAPTCHA désactivé').catch(() => {});
        for (const channel of guild.channels.cache.values()) {
            if (!channel.permissionOverwrites?.cache?.has(role.id)) continue;
            await channel.permissionOverwrites.delete(role, 'CAPTCHA désactivé').catch(() => {});
        }
    }
    return role;
}
