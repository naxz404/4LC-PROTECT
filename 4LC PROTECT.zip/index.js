import { isAllowedGuild } from './ServerScope.js';
import { migrateProtections } from './Features/migrateProtections.js';
import db from './Events/loadDatabase.js';
import { loadDatabaseOwners } from './Owners.js';
import { BrandedEmbedBuilder } from './BrandedEmbedBuilder.js';
import Discord from "discord.js"
import { EmbedBuilder } from "discord.js";
import config from "./config.json" with { type: 'json' }
import { GiveawaysManager } from "discord-giveaways";

process.chdir(import.meta.dirname);

const FOUR_LC_BRAND = 'By 4LC | discord.gg/ddJMXWYJ29';
const originalEmbedToJSON = EmbedBuilder.prototype.toJSON;
EmbedBuilder.prototype.toJSON = function (...args) {
    const footer = this.data?.footer;
    const current = footer?.text || '';
    if (!current.includes(FOUR_LC_BRAND)) {
        const text = current ? `${current} • ${FOUR_LC_BRAND}` : FOUR_LC_BRAND;
        this.setFooter({ text: text.slice(0, 2048), ...(footer?.icon_url ? { iconURL: footer.icon_url } : {}) });
    }
    return originalEmbedToJSON.apply(this, args);
};

const bot = new Discord.Client({
	intents: 3276799,
	partials: [
		Discord.Partials.Channel,
		Discord.Partials.Message,
		Discord.Partials.User,
		Discord.Partials.GuildMember,
		Discord.Partials.Reaction,
		Discord.Partials.ThreadMember,
		Discord.Partials.GuildScheduledEvent
	]
});

bot.commands = new Discord.Collection();
bot.slashCommands = new Discord.Collection();
bot.setMaxListeners(70);

class ServerGiveawaysManager extends GiveawaysManager {
    initialize() { return this.initialization ||= this._init(); }
    async getAllGiveaways() { return (await super.getAllGiveaways()).filter(g => isAllowedGuild(g.guildId)); }
    _handleRawPacket(packet) { if (isAllowedGuild(packet.d?.guild_id)) return super._handleRawPacket(packet); }
}
bot.giveawaysManager = new ServerGiveawaysManager(bot, {
	storage: './giveaways.json',
	updateCountdownEvery: 5000,
	default: {
		botsCanWin: false,
		embedColor: config.color,
		reaction: "🎉"
	}
}, false);
bot.giveawaysManager.on('giveawayEnded', async (giveaway, winners) => {
    if (!isAllowedGuild(giveaway.guildId)) return;
	const channel = await bot.channels.fetch(giveaway.channelId);
	const message = await channel.messages.fetch(giveaway.messageId);

	setTimeout(async () => {
		const reaction = message.reactions.cache.get("🎉");
		let participantsCount = 0;
		if (reaction) {
			const users = await reaction.users.fetch();
			participantsCount = users.filter(u => !u.bot).size;
		}
		const embed = new BrandedEmbedBuilder()
			.setTitle(giveaway.prize)
			.setDescription(
				`Fin: <t:${Math.floor(giveaway.endAt / 1000)}:R> <t:${Math.floor(giveaway.endAt / 1000)}:F>\n` +
				`Organisé par: ${giveaway.hostedBy?.id || giveaway.hostedBy}\n` +
				`Participants: ${participantsCount}\n` +
				`Gagnant(s): ${winners.map(w => `<@${w.id}>`).join(', ') || "Aucun"}\n`
			)
			.setColor(config.color)
            .setFooter({ text: FOUR_LC_BRAND });
		await message.edit({ embeds: [embed], components: [] });
	}, 1000);
}
);
await loadDatabaseOwners(db);
await migrateProtections();
await (await import('./Handler/Commands.js')).default(bot);
await (await import('./Handler/slashCommands.js')).default(bot);
await (await import('./Handler/Events.js')).default(bot);
await (await import('./ProtectCore/bridge.js')).installProtectCore(bot);
const anticrashHandler = (await import('./Handler/anticrash.js')).default;
anticrashHandler(bot);

bot.login(process.env.TOKEN || config.token)
	.then(() => {
		console.log(`[INFO] > ${bot.user.tag} est connecté`);
		console.log('[4LC-PROTECT] Bot prêt pour le serveur configuré.');
	})
	.catch((e) => {
		console.log('\x1b[31m[!] — Please configure a valid bot token or allow all the intents\x1b[0m');
	});

