import './Environment.js';
import rootConfig from './config.json' with { type: 'json' };
const databaseOwners = new Set();
export function isIdentityOwner(userId) {
    return Boolean(userId && [...(rootConfig.owners || []), ...(process.env.OWNER_IDS || '').split(',').map(id => id.trim())].includes(userId));
}
export function ownerIds() {
    return [...new Set([...(rootConfig.owners || []), ...(process.env.OWNER_IDS || '').split(',').map(id => id.trim()), ...databaseOwners])].filter(id => /^\d{17,22}$/.test(id));
}
export function isGlobalOwner(userId) { return Boolean(userId && ownerIds().includes(userId)); }
export function setDatabaseOwner(userId, enabled) { if (enabled) databaseOwners.add(userId); else databaseOwners.delete(userId); }
export async function loadDatabaseOwners(db) {
    await new Promise((resolve, reject) => db.run('CREATE TABLE IF NOT EXISTS owner (id TEXT PRIMARY KEY)', err => err ? reject(err) : resolve()));
    const rows = await new Promise((resolve, reject) => db.all('SELECT id FROM owner', [], (err, rows) => err ? reject(err) : resolve(rows)));
    databaseOwners.clear();
    for (const row of rows) databaseOwners.add(row.id);
}
