import { test, after, mock } from 'node:test';
import assert from 'node:assert/strict';
import { mkdtempSync, rmSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import { Collection } from 'discord.js';
const dir = mkdtempSync(join(tmpdir(), '4lc-scope-'));
process.env.FOUR_LC_DATA_DIR = dir;
after(() => rmSync(dir, { recursive: true, force: true }));
const { createServerScope, initializeServerScope, allowServerEvent, allowedGuilds, eventGuildId } = await import('../ServerScope.js');
const A = '111111111111111111', B = '222222222222222222', ROOT = '333333333333333333', OWNER = '444444444444444444';
const client = (...ids) => ({ guilds: { cache: new Collection(ids.map(id => [id, { id }])) } });
test('explicit server is enforced for every guild, without guessing from joined guilds', () => {
 const s = createServerScope({ config: { guildId: A } });
 assert.equal(s.initialize(client(B)), A);
 assert.equal(s.allows(B), false);
 assert.deepEqual(s.guilds(client(A, B)).map(g => g.id), [A]);
 assert.throws(() => createServerScope({ env: { GUILD_ID: 'bad' } }), /identifiant/);
});
test('automatic single-server binding survives restarts and refuses a second server', () => {
 const file = join(dir, 'binding.json');
 const s = createServerScope({ file });
 assert.equal(s.initialize(client()), null);
 assert.equal(s.initialize(client(A, B)), null);
 assert.equal(s.initialize(client(A)), A);
 const restarted = createServerScope({ file });
 assert.equal(restarted.initialize(client(B)), A);
 assert.equal(restarted.allows(B), false);
});
test('event routing denies other servers and DMs while keeping target audit and reactions', () => {
 const c = client(A, B);
 initializeServerScope(client(A));
 for (const name of ['messageCreate', 'interactionCreate', 'guildMemberAdd', 'presenceUpdate', 'webhooksUpdate']) {
  assert.equal(allowServerEvent(c, name, [{ guildId: B }]), false);
  assert.equal(allowServerEvent(c, name, [{ guildId: A }]), true);
 }
 assert.equal(allowServerEvent(c, 'interactionCreate', [{ guildId: null }]), false);
 assert.equal(allowServerEvent(c, 'guildAuditLogEntryCreate', [{}, { id: B }]), false);
 assert.equal(allowServerEvent(c, 'guildAuditLogEntryCreate', [{}, { id: A }]), true);
 assert.equal(eventGuildId('messageReactionAdd', [{ message: { guildId: A } }]), A);
 assert.equal(allowServerEvent(c, 'guildCreate', [{ id: B }]), false);
 assert.deepEqual(allowedGuilds(c).map(g => g.id), [A]);
});
const writes = [];
mock.module(new URL('../Events/loadDatabase.js', import.meta.url).href, { exports: { default: { run: (sql, params, cb) => { writes.push({ sql, params }); cb(null); } } } });
const { isGlobalOwner, isIdentityOwner, setDatabaseOwner } = await import('../Owners.js');
const { command: owner } = await import('../Commands/Paramètres/owner.js');
const { command: unowner } = await import('../Commands/Paramètres/unowner.js');
const { command: name } = await import('../Commands/Gestions/name.js');
const { command: avatar } = await import('../Commands/Gestions/avatar.js');
test('owner mention grants bot permissions immediately and unowner revokes them', async () => {
 setDatabaseOwner(ROOT, true);
 const replies = [];
 const bot = { users: { fetch: async id => ({ id, bot: false }) } };
 const message = { author: { id: ROOT }, reply: async content => replies.push(content) };
 await owner.run(bot, message, [`<@${OWNER}>`]);
 assert.equal(isGlobalOwner(OWNER), true);
 assert.match(replies[0].content, /owner du bot/);
 assert.equal(writes[0].params[0], OWNER);
 await unowner.run(bot, message, [OWNER]);
 assert.equal(isGlobalOwner(OWNER), false);
});
test('database owners and public users cannot change bot identity', async () => {
 setDatabaseOwner(OWNER, true);
 const edits = [], replies = [];
 const bot = { user: { setUsername: async v => edits.push(v), setAvatar: async v => edits.push(v) } };
 for (const id of [OWNER, B]) {
  const message = { author: { id }, reply: async content => replies.push(content) };
  await name.run(bot, message, ['Changed']);
  await avatar.run(bot, message, ['https://example.com/avatar.png']);
 }
 assert.deepEqual(edits, []);
 assert.equal(isIdentityOwner(OWNER), false);
 assert.equal(replies.length, 4);
});
test('configured owners can change identity without Discord administrator permissions', async () => {
 const previous = process.env.OWNER_IDS;
 process.env.OWNER_IDS = ROOT;
 try {
  const edits = [];
  const bot = { user: { setUsername: async v => edits.push(v), setAvatar: async v => edits.push(v) } };
  const message = { author: { id: ROOT }, reply: async () => {} };
  await name.run(bot, message, ['4LC-PROTECT']);
  await avatar.run(bot, message, ['https://example.com/avatar.png']);
  assert.deepEqual(edits, ['4LC-PROTECT', 'https://example.com/avatar.png']);
 } finally { if (previous === undefined) delete process.env.OWNER_IDS; else process.env.OWNER_IDS = previous; }
});
test('temporary-ban background processing never acts on another joined server', async () => {
 const { getGuildConfig, saveGuildConfig } = await import('../ProtectCore/storage.js');
 const { processExpiredBans } = await import('../ProtectCore/tempBans.js');
 const actions = [];
 const guild = id => ({ id, bans: { fetch: async user => ({ user }) }, members: { unban: async user => actions.push([id, user]) } });
 const c = { guilds: { cache: new Collection([[A, guild(A)], [B, guild(B)]]) } };
 for (const id of [A, B]) { const cfg = getGuildConfig(id); cfg.tempBans = [{ userId: OWNER, expiresAt: 1 }]; saveGuildConfig(id, cfg); }
 await processExpiredBans(c, 2);
 assert.deepEqual(actions, [[A, OWNER]]);
 assert.equal(getGuildConfig(B).tempBans.length, 1);
 assert.equal(getGuildConfig(A).tempBans.length, 0);
});
