import { test, after, mock } from 'node:test';
import assert from 'node:assert/strict';
import { mkdtempSync, rmSync, readdirSync, readFileSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import { EventEmitter } from 'node:events';
import { pathToFileURL } from 'node:url';
import { Collection, PermissionsBitField, ChannelType, PermissionFlagsBits as P } from 'discord.js';
const root = new URL('../', import.meta.url).pathname, cwd = process.cwd(), dir = mkdtempSync(join(tmpdir(), '4lc-review-'));
process.env.FOUR_LC_DATA_DIR = join(dir,'security');
process.chdir(dir);
after(() => { process.chdir(cwd); rmSync(dir,{ recursive: true, force: true }); });
const writes=[];
mock.module(new URL('../Events/loadDatabase.js', import.meta.url).href,{ exports:{ default:{ get:(_s,_p,cb)=>cb(null,null), all:(_s,_p,cb)=>cb(null,[]), run:(sql,args,cb)=>{writes.push({sql,args}); (typeof args==='function'?args:cb)?.(null); } } } });
const { getGuildConfig, saveGuildConfig } = await import('../ProtectCore/storage.js');
const { setDatabaseOwner } = await import('../Owners.js');
const OWNER='111111111111111111', USER='222222222222222222', GUILD='333333333333333333', BOT='444444444444444444';
function fakeGuild() {
 let seq=500000000000000000n;
 const g={id:GUILD,name:'Test',ownerId:OWNER,verificationLevel:2};
 const perms=new PermissionsBitField(P.Administrator);
 g.roles={cache:new Collection(),create:async o=>{const role={...o,id:String(++seq),managed:false,editable:true,position:1,permissions:new PermissionsBitField(o.permissions),edit:async o=>Object.assign(role,o),setPosition:async n=>{role.position=n;}};g.roles.cache.set(role.id,role);return role;}};
 g.roles.everyone={id:GUILD,name:'@everyone',permissions:new PermissionsBitField(),edit:async()=>{}};g.roles.cache.set(GUILD,g.roles.everyone);
 g.members={me:{id:BOT,permissions:perms,roles:{highest:{position:100}}},fetchMe:async()=>g.members.me,cache:new Collection(),fetch:async id=>g.members.cache.get(id)};
 g.channels={cache:new Collection(),fetch:async id=>g.channels.cache.get(id),create:async o=>{
  const c={...o,id:String(++seq),parentId:o.parent||null,rawPosition:0,guild:g,guildId:g.id,manageable:true,isTextBased:()=>o.type!==ChannelType.GuildCategory,isSendable:()=>true,isDMBased:()=>false,setName:async n=>{c.name=n;},setParent:async n=>{c.parentId=n;},setPosition:async n=>{c.rawPosition=n;},edit:async o=>Object.assign(c,o),send:async()=>({id:String(++seq)}),permissionOverwrites:{cache:new Collection(),set:async es=>{c.overwrites=es;}}};g.channels.cache.set(c.id,c);return c;
 }};
 g.emojis={cache:new Collection()};g.setVerificationLevel=async n=>{g.verificationLevel=n;};
 g.client={user:{id:BOT},guilds:{cache:new Collection([[g.id,g]])},channels:{cache:g.channels.cache}};return g;
}
test('every source module imports and all command/event handlers load from another working directory',async()=>{
 const failures=[];
 async function walk(path){for(const e of readdirSync(path,{withFileTypes:true})){const file=join(path,e.name);if(e.isDirectory()){if(!['node_modules','tests','4LC-DATA'].includes(e.name))await walk(file);}else if(e.name.endsWith('.js')&&e.name!=='index.js'){try{await import(pathToFileURL(file).href);}catch(error){failures.push(`${file}: ${error.message}`);}}}}
 await walk(root);assert.deepEqual(failures,[]);
 const bot=new EventEmitter();bot.commands=new Collection();bot.slashCommands=new Collection();
 await (await import('../Handler/Commands.js')).default(bot);
 await (await import('../Handler/slashCommands.js')).default(bot);
 await (await import('../Handler/Events.js')).default(bot);
 for(const name of ['secure','unsecure','allanti','allpunish','nick','help','lock','unlock','lockdown','unlockdown','setowner','unowner'])assert.equal(typeof bot.commands.get(name)?.run,'function',name);
 assert.equal(bot.commands.get('lockdown').category,'Modérations');
 assert.equal(bot.slashCommands.has('member'),true);assert.equal(bot.slashCommands.has('config'),true);
 assert.equal(bot.listenerCount('clientReady'),1);assert.equal(bot.listenerCount('messageCreate'),1);
 assert.equal(bot.eventNames().includes(undefined),false);
 const native=bot.arrayOfSlashCommands.find(c=>c.name==='member');assert.equal(native.run,undefined);
});
test('guild prefixes and both bot mention formats route commands',async()=>{
 const {handleCommands}=await import('../Events/messageCreate.js');const cfg=getGuildConfig(GUILD);cfg.prefix='!';saveGuildConfig(GUILD,cfg);
 const called=[];const bot={user:{id:BOT},commands:new Collection([['ping',{run:async(_b,_m,args,config)=>called.push({args,prefix:config.prefix})}]])};
 const msg={guild:{id:GUILD},reply:async()=>{},content:'!ping test'};
 await handleCommands(msg,bot,{prefix:'+'});await handleCommands({...msg,content:`<@!${BOT}> ping`},bot,{prefix:'+'});await handleCommands({...msg,content:'+ping'},bot,{prefix:'+'});
 assert.deepEqual(called,[{args:['test'],prefix:'!'},{args:[],prefix:'!'}]);
});
test('central journal creation is deduplicated and security cache points to it',async()=>{
 const g=fakeGuild();const {ensureCentralLogChannel}=await import('../Features/centralLogs.js');const {getSettings,invalidateSettings}=await import('../ProtectCore/antiraid/runtime.js');
 const cfg=getGuildConfig(g.id);cfg.logChannel=null;saveGuildConfig(g.id,cfg);invalidateSettings(g.id);getSettings(g.id);
 const channels=await Promise.all(Array.from({length:8},()=>ensureCentralLogChannel(g)));
 assert.equal(new Set(channels.map(c=>c.id)).size,1);assert.equal(g.channels.cache.size,1);assert.equal(getSettings(g.id).logChannel,channels[0].id);
});
test('temporary raid verification persists and restores the previous level',async()=>{
 const g=fakeGuild();const {raiseRaidVerification,restoreRaidVerification}=await import('../ProtectCore/raidResponse.js');
 await raiseRaidVerification(g,60000);assert.equal(g.verificationLevel,4);const cfg=getGuildConfig(g.id);assert.equal(cfg.raidVerification.previous,2);cfg.raidVerification.until=Date.now()-1;saveGuildConfig(g.id,cfg);
 await restoreRaidVerification(g);assert.equal(g.verificationLevel,2);assert.equal(getGuildConfig(g.id).raidVerification,null);
});
test('restoration keeps duplicate roles and channel names distinct, and assigns their categories',async()=>{
 const g=fakeGuild();const {restoreServerBackup}=await import('../ProtectCore/serverBackup.js');
 const role=id=>({sourceId:id,name:'Membre',color:0,hoist:false,mentionable:false,permissions:'0',position:1});
 const channel=(id,name,type,parentId=null)=>({sourceId:id,name,type,parentId,position:1,permissionOverwrites:[],topic:null});
 const record={code:'test',sourceGuildId:GUILD,snapshot:{everyonePermissions:'0',roles:[role('r1'),role('r2')],channels:[channel('c1','Groupe A',ChannelType.GuildCategory),channel('c2','Groupe B',ChannelType.GuildCategory),channel('c3','général',ChannelType.GuildText,'c1'),channel('c4','général',ChannelType.GuildText,'c2')],emojis:[]}};
 const first=await restoreServerBackup(g,record,OWNER);assert.equal(first.rolesCreated,2);assert.equal(first.channelsCreated,4);
 const text=g.channels.cache.filter(c=>c.type===ChannelType.GuildText);assert.equal(text.size,2);assert.equal(new Set(text.map(c=>c.parentId)).size,2);
 const second=await restoreServerBackup(g,record,OWNER);assert.equal(second.rolesCreated,0);assert.equal(second.channelsCreated,0);assert.equal(g.channels.cache.size,4);
});
test('slash language synchronization keeps native member and ticket commands',async()=>{
 const g=fakeGuild();const {syncGuildCommands}=await import('../ProtectCore/slash/sync.js');const commands=[];
 g.client.arrayOfSlashCommands=[{name:'member',description:'Member'}];g.commands={fetch:async()=>new Collection(),create:async c=>commands.push(c),delete:async()=>{},edit:async()=>{}};
 await syncGuildCommands(g,[{name:'config',description:'Configuration'}]);assert.deepEqual(commands.map(c=>c.name),['member','config']);
});
test('custom presence is valid and does not produce two custom activities',async()=>{
 const {normalizeActivityConfig}=await import('../ProtectCore/config.js');const {applyConfiguredPresence}=await import('../ProtectCore/presence.js');assert.equal(normalizeActivityConfig({activityType:'Custom',status:'By 4LC'}).type,'Custom');let presence;
 applyConfiguredPresence({user:{setPresence:p=>{presence=p;}},guilds:{cache:new Collection()}},{force:true});
 assert.equal(presence.activities.filter(a=>a.type===4).length,1);assert.ok(presence.activities.find(a=>a.type===4).state);
});
test('ordinary staff cannot grant global ownership',async()=>{
 const {command}=await import('../Commands/Paramètres/setowner.js');const before=writes.length;let reply;
 await command.run({users:{fetch:async id=>({id,bot:false})}},{author:{id:USER},reply:async p=>{reply=p;}},[OWNER]);assert.equal(writes.length,before);assert.match(reply,/owners/);
 setDatabaseOwner(OWNER,true);await command.run({users:{fetch:async id=>({id,bot:false})}},{author:{id:OWNER},reply:async p=>{reply=p;}},[USER]);assert.equal(writes.length,before+1);setDatabaseOwner(OWNER,false);setDatabaseOwner(USER,false);
});
test('staff panel checks action permissions and hierarchy before attempting a ban',async()=>{
 const {handleStaffInteraction}=await import('../Features/staffPanel.js');const g=fakeGuild();let bans=0;g.members.ban=async()=>{bans++;};
 const actor={id:USER,guild:g,permissions:new PermissionsBitField(P.ManageGuild),roles:{highest:{position:5}}};
 const target={id:'666666666666666666',guild:g,roles:{highest:{position:10}}};g.members.cache.set(target.id,target);
 const outputs=[];const interaction={guild:g,client:g.client,member:actor,user:{id:USER,tag:'Staff'},customId:`staffmmodal:ban:${target.id}`,isButton:()=>false,isModalSubmit:()=>true,fields:{getTextInputValue:()=> 'Raison'},reply:async p=>outputs.push(p),deferReply:async()=>{},editReply:async p=>outputs.push(p)};
 await handleStaffInteraction(interaction);assert.equal(bans,0);assert.match(outputs.at(-1).content,/Permission/);
 actor.permissions.add(P.BanMembers);await handleStaffInteraction(interaction);assert.equal(bans,0);assert.match(outputs.at(-1).content,/Cible interdite/);
});
test('failed backup items are reported without preventing the remaining restoration',async()=>{
 const g=fakeGuild();const {restoreServerBackup}=await import('../ProtectCore/serverBackup.js');const create=g.roles.create;g.roles.create=async o=>{if(o.name==='Échec')throw Error('Permission refusée');return create(o);};
 const snapshot={everyonePermissions:'0',roles:[{sourceId:'r1',name:'Échec',permissions:'0',position:1},{sourceId:'r2',name:'Réussi',permissions:'0',position:2}],channels:[],emojis:[]};
 const result=await restoreServerBackup(g,{snapshot,sourceGuildId:GUILD,code:'test'},OWNER);assert.equal(result.rolesCreated,1);assert.equal(result.failures.length,1);assert.match(result.failures[0],/Échec/);
});
test('failed full unlock keeps the saved permission snapshot for retry',async()=>{
 const g=fakeGuild();const c=await g.channels.create({name:'test',type:ChannelType.GuildText});c.permissionOverwrites.set=async()=>{throw Error('Échec');};
 const cfg=getGuildConfig(GUILD);cfg.fullLockdown={active:true,snapshots:{[c.id]:{exists:false}}};saveGuildConfig(GUILD,cfg);
 const {fullUnlockdown}=await import('../Features/serverSecurity.js');await fullUnlockdown(g,OWNER);assert.equal(getGuildConfig(GUILD).fullLockdown.active,true);assert.ok(getGuildConfig(GUILD).fullLockdown.snapshots[c.id]);
 c.permissionOverwrites.set=async()=>{};await fullUnlockdown(g,OWNER);assert.equal(getGuildConfig(GUILD).fullLockdown.active,false);
});
test('allanti is restricted to Secure/owners while default punishment changes require an owner',async()=>{
 const {prefixProtectionAccess}=await import('../ProtectCore/protectionAccess.js');assert.equal(prefixProtectionAccess('allanti',[]),'secure');assert.equal(prefixProtectionAccess('allpunish',[]),'owner');
 const {default:definition}=await import('../ProtectCore/commands/allanti.js');const {MODULES}=await import('../ProtectCore/antiraid/schema.js');const g=fakeGuild();await definition.execute(g.client,{guild:g,reply:async()=>{}});
 const cfg=getGuildConfig(GUILD);for(const name of MODULES)assert.equal(cfg.enabled[name],true,name);assert.equal(cfg.autoRaid.enabled,true);assert.equal(cfg.antiNuke.enabled,true);
});
test('bot and external webhook messages still pass through the protection engine',async()=>{
 const {default:engine}=await import('../ProtectCore/events/messageCreate.js');const {default:handler}=await import('../Events/messageCreate.js');const original=engine.execute;let checks=0;
 engine.execute=async()=>{checks++;return false;};
 try {await handler.execute({guild:{id:GUILD},author:{id:USER,bot:true},webhookId:'external'}, {commands:new Collection()}, {prefix:'+'});assert.equal(checks,1);}
 finally {engine.execute=original;}
});
