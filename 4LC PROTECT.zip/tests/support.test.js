import { test, after, mock } from 'node:test';
import assert from 'node:assert/strict';
import { mkdtempSync, rmSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import { Collection, PermissionsBitField, PermissionFlagsBits as P, ChannelType } from 'discord.js';
const cwd=process.cwd(),dir=mkdtempSync(join(tmpdir(),'4lc-support-test-'));
const OWNER='11111111111111111',USER='22222222222222222',GUILD='33333333333333333',BOT='44444444444444444';
process.chdir(dir);
process.env.FOUR_LC_DATA_DIR=join(dir,'security');
mock.module(new URL('../Events/loadDatabase.js',import.meta.url).href,{exports:{default:{get:(_sql,_args,cb)=>cb(null,{category:'55555555555555555'}),all:(_sql,_args,cb)=>cb(null,[]),run:(_sql,_args,cb)=>cb?.(null)}}});
after(()=>{process.chdir(cwd);rmSync(dir,{recursive:true,force:true});});
const {settings,update,serial}=await import('../ProtectModules/Handler/v4/store.js');
const {TicketRecords,updateConfig,defaultCategory,getConfig}=await import('../ProtectModules/Handler/tickets/schema.js');
const {showTicketForm,handleAdvancedTickets,ticketMessage,ticketsTick,offerRating}=await import('../ProtectModules/Handler/v4/tickets.js');
const {openTicket,closeTicket,buildPanelPayload}=await import('../ProtectModules/Handler/tickets/engine.js');
let seq=50000000000000000n;
const newId=()=>String(++seq);
function permissions(values=[]) {return new PermissionsBitField(values);}
function guild(id=GUILD) {
 const g={id,name:'Serveur test',ownerId:OWNER,verificationLevel:0,memberCount:20};
 g.roles={cache:new Collection(),fetch:async()=>g.roles.cache};
 g.roles.everyone={id,name:'@everyone',managed:false,permissions:permissions(),rawPosition:0,color:0,hoist:false,mentionable:false,setPermissions:async(bits)=>{g.roles.everyone.permissions=permissions(bits);return g.roles.everyone;}};g.roles.cache.set(id,g.roles.everyone);
 g.roles.create=async opts=>{const r={...opts,id:newId(),rawPosition:1,managed:false,editable:true,permissions:permissions(opts.permissions),edit:async opts=>{Object.assign(r,opts);r.permissions=permissions(opts.permissions);return r;},setPosition:async pos=>{r.rawPosition=pos;return r;}};g.roles.cache.set(r.id,r);return r;};
 g.channels={cache:new Collection(),fetch:async id=>id?g.channels.cache.get(id):g.channels.cache,create:async opts=>channel(g,newId(),opts)};
 const me={id:BOT,user:{id:BOT,username:'bot',bot:true},permissions:permissions(['Administrator']),roles:{highest:{position:100,comparePositionTo:()=>1},cache:new Collection()}};
 const user={id:USER,user:{id:USER,username:'membre',tag:'membre',bot:false,send:async()=>{}},displayName:'Membre',roles:{cache:new Collection(),highest:{comparePositionTo:()=>1}},permissions:permissions(),voice:{channelId:null},guild:g,moderatable:true,kickable:true,bannable:true};
 user.roles.add=async ids=>{for(const id of Array.isArray(ids)?ids:[ids])user.roles.cache.set(id,g.roles.cache.get(id));};
 user.roles.remove=async ids=>{for(const id of Array.isArray(ids)?ids:[ids])user.roles.cache.delete(id);};
 user.voice.setChannel=async c=>{for(const ch of g.channels.cache.values())ch.members.delete(USER);user.voice.channelId=c.id;c.members.set(USER,user);};
 g.members={me,cache:new Collection([[BOT,me],[USER,user]]),fetchMe:async()=>me,fetch:async input=>g.members.cache.get(typeof input==='string'?input:input.user)};
 g.setVerificationLevel=async n=>{g.verificationLevel=n;};g.edit=async opts=>{Object.assign(g,opts);return g;};return g;
}
function channel(g,id,opts={}) {
 const c={id,guild:g,type:opts.type??ChannelType.GuildText,name:opts.name||'test',parentId:opts.parent||null,rawPosition:0,members:new Collection(),sent:[],isThread:()=>false,isTextBased:()=>true,isSendable:()=>true,isDMBased:()=>false};
 const cache=new Collection();
 c.permissionOverwrites={cache,set:async entries=>{cache.clear();for(const e of entries)cache.set(e.id,{...e,allow:permissions(e.allow||[]),deny:permissions(e.deny||[])});return c;},edit:async(id,patch,options={})=>{const old=cache.get(id)||{id,type:options.type||0,allow:permissions(),deny:permissions()};for(const [key,value]of Object.entries(patch)){assert.ok(P[key],`Invalid permission ${key}`);old.allow.remove(P[key]);old.deny.remove(P[key]);if(value===true)old.allow.add(P[key]);if(value===false)old.deny.add(P[key]);}cache.set(id,old);return c;},delete:async id=>cache.delete(id)};
 for(const e of opts.permissionOverwrites||[])cache.set(e.id,{...e,allow:permissions(e.allow||[]),deny:permissions(e.deny||[])});
 c.edit=async opts=>{if(opts.permissionOverwrites)await c.permissionOverwrites.set(opts.permissionOverwrites);if('parent'in opts)c.parentId=opts.parent;return c;};c.setPosition=async n=>{c.rawPosition=n;return c;};c.setName=async n=>{c.name=n;return c;};c.setUserLimit=async n=>{c.userLimit=n;return c;};c.delete=async()=>{g.channels.cache.delete(id);};
 c.send=async p=>{c.sent.push(p);return{id:newId()};};c.messages={fetch:async()=>new Collection(),edit:async()=>{},delete:async()=>{}};
 g.channels.cache.set(id,c);return c;
}
function client(g) {return{dataDir:join(dir,'backups'),prefix:'+',user:{id:BOT,username:'bot',bot:true},guilds:{cache:new Collection([[g.id,g]])},channels:{cache:g.channels.cache,fetch:g.channels.fetch},users:{fetch:async id=>g.members.cache.get(id)?.user},enabledModules:new Set(['Base','ModerationAvancee','Tickets'])};}
function interaction(g,customId,more={}) {
 const i={guild:g,guildId:g?.id,user:{id:USER},customId,channelId:null,replied:false,deferred:false,outputs:[],inGuild:()=>!!g,isButton:()=>true,isStringSelectMenu:()=>false,isModalSubmit:()=>false,isMessageComponent:()=>true,isRepliable:()=>true,
 reply:async p=>{assert.equal(i.replied||i.deferred,false,'double initial response');i.replied=true;i.outputs.push(p);},deferReply:async()=>{assert.equal(i.deferred||i.replied,false);i.deferred=true;},deferUpdate:async()=>{i.deferred=true;},editReply:async p=>{assert.ok(i.deferred||i.replied);i.outputs.push(p);},update:async p=>{i.replied=true;i.outputs.push(p);},showModal:async p=>{i.replied=true;i.modal=p;}};return Object.assign(i,more);
}
test('ticket form is user-bound and category-bound',async()=>{
 const g=guild(newId());update(g.id,s=>{s.tickets.form=['Sujet ?'];});const i=interaction(g,'tk_open:cat');assert.equal(await showTicketForm(i,'cat'),true);const modal=i.modal.toJSON();
 const forged=interaction(g,modal.custom_id,{user:{id:OWNER},isModalSubmit:()=>true,isButton:()=>false});await handleAdvancedTickets(client(g),forged);assert.match(JSON.stringify(forged.outputs),/expiré/);
});
test('ticket opening stores answers and concurrent openings create only one ticket',async()=>{
 const g=guild(newId()),c=client(g);await updateConfig(g.id,{$set:{categories:[defaultCategory('cat')]}});
 const i=interaction(g,'form',{isModalSubmit:()=>true,isButton:()=>false});const j=interaction(g,'form',{isModalSubmit:()=>true,isButton:()=>false});
 await Promise.all([openTicket(c,i,'cat',[{question:'Sujet',answer:'Bonjour'}]),openTicket(c,j,'cat',[])]);
 const all=await TicketRecords.find({guildId:g.id}).lean();assert.equal(all.length,1);assert.ok(settings(g.id).tickets.records[all[0].channelId]);assert.match(JSON.stringify(g.channels.cache.get(all[0].channelId).sent),/Bonjour/);
});
test('ticket priority rejects non-staff and rating cannot be replayed',async()=>{
 const g=guild(newId()),c=client(g),ch=channel(g,newId());await TicketRecords.create({guildId:g.id,channelId:ch.id,userId:USER,categoryId:'cat',number:1,closedAt:null});
 update(g.id,s=>{s.tickets.rating=true;s.tickets.records[ch.id]={userId:USER,priority:'normal'};});
 const i=interaction(g,'ta:priority',{channelId:ch.id,isButton:()=>false,isStringSelectMenu:()=>true,values:['high']});await handleAdvancedTickets(c,i);assert.equal(settings(g.id).tickets.records[ch.id].priority,'normal');
 let dm;g.members.cache.get(USER).user.send=async p=>{dm=p;};await TicketRecords.updateOne({channelId:ch.id},{$set:{closedAt:Date.now()}});await offerRating(c,g,{channelId:ch.id,userId:USER,number:1});
 const customId=dm.components[0].toJSON().components[4].custom_id;await handleAdvancedTickets(c,interaction(null,customId));assert.equal(settings(g.id).tickets.records[ch.id].rating.value,5);
 const again=interaction(null,customId);await handleAdvancedTickets(c,again);assert.match(JSON.stringify(again.outputs),/déjà/);
});
test('ticket reminders fire once and inactivity uses the existing close/transcript flow',async()=>{
 const g=guild(newId()),c=client(g),ch=channel(g,newId());await updateConfig(g.id,{$set:{categories:[defaultCategory('cat')]}});
 await TicketRecords.create({guildId:g.id,channelId:ch.id,userId:USER,categoryId:'cat',number:1,closedAt:null,extraMemberIds:[],createdAt:Date.now()});
 update(g.id,s=>{s.tickets.reminderMs=1000;s.tickets.records[ch.id]={userId:USER,priority:'normal',lastActivity:Date.now()-5000,waitingSince:Date.now()-5000,reminded:false};});
 await ticketsTick(c,g);await ticketsTick(c,g);assert.equal(ch.sent.length,1);assert.equal(settings(g.id).tickets.records[ch.id].reminded,true);
 update(g.id,s=>{s.tickets.closeMs=1000;});await ticketsTick(c,g);const r=await TicketRecords.findOne({channelId:ch.id}).lean();assert.ok(r.closedAt);assert.match(ch.name,/-ferme$/);
});
test('a staff response clears the pending ticket reminder',async()=>{
 const g=guild(newId()),c=client(g),ch=channel(g,newId());g.members.cache.get(USER).permissions=permissions(['ManageGuild']);
 await TicketRecords.create({guildId:g.id,channelId:ch.id,userId:OWNER,categoryId:'cat',number:1,closedAt:null});
 update(g.id,s=>{s.tickets.records[ch.id]={userId:OWNER,lastActivity:1,waitingSince:1,reminded:true};});
 await ticketMessage(c,{guild:g,channel:ch,author:{id:USER,bot:false}});assert.equal(settings(g.id).tickets.records[ch.id].waitingSince,null);assert.equal(settings(g.id).tickets.records[ch.id].reminded,false);
});
test('five labelled ticket options survive persistence and serialize correctly',async()=>{
 const g=guild(newId());
 await updateConfig(g.id,{$set:{type:'select',categories:['Staff','Animations','Abus','Community','Couronnes'].map((label,n)=>({...defaultCategory(`option${n+1}`),label}))}});
 const cfg=await getConfig(g.id);
 const panel=buildPanelPayload(g,cfg);
 const options=panel.components[0].toJSON().components[0].options;
 assert.equal(options.length,5);assert.equal(options[4].label,'Couronnes');
 const {buildTicketsPayload}=await import('../ProtectModules/Handler/tickets/dashboard.js');
 for(const c of buildTicketsPayload(client(g),g,cfg))c.toJSON();
});
test('captcha dashboard serializes and challenge checks owner, wrong code and correct code',async()=>{
 const {updateConfig:getUpdate,getConfig:getCaptcha}=await import('../ProtectModules/Handler/captcha/schema.js');
 const {startChallenge,handleChallengeInteraction}=await import('../ProtectModules/Handler/captcha/engine.js');
 const {buildCaptchaContainer}=await import('../ProtectModules/Handler/captcha/dashboard.js');
 const g=guild(newId()),c=client(g),ch=channel(g,newId()),role=await g.roles.create({name:'Vérifié',permissions:[]});
 const m=g.members.cache.get(USER);
 m.roles.add=async r=>m.roles.cache.set(r.id,r);
 await getUpdate(g.id,{$set:{enabled:true,channelId:ch.id,roleId:role.id,maxAttempts:3}});
 for(const p of buildCaptchaContainer(c,g,await getCaptcha(g.id)))p.toJSON();
 await startChallenge(c,m);
 const json=JSON.stringify(ch.sent[0].components.map(p=>p.toJSON()));
 const code=/Code :\*\* \\?`([A-Z2-9]{5})/.exec(json)?.[1];
 assert.ok(code,json);
 const other=interaction(g,`cp_verify:${USER}`,{user:{id:OWNER}});
 await handleChallengeInteraction(c,other);assert.match(JSON.stringify(other.outputs),/pas pour vous/);
 const wrong=interaction(g,`cp_modal:${USER}`,{isButton:()=>false,isModalSubmit:()=>true,fields:{getTextInputValue:()=> 'wrong'},isFromMessage:()=>false});
 await handleChallengeInteraction(c,wrong);assert.equal(m.roles.cache.has(role.id),false);assert.match(JSON.stringify(wrong.outputs),/incorrect/);
 const correct=interaction(g,`cp_modal:${USER}`,{isButton:()=>false,isModalSubmit:()=>true,fields:{getTextInputValue:()=>code},isFromMessage:()=>false});
 await handleChallengeInteraction(c,correct);assert.equal(m.roles.cache.has(role.id),true);
});
const legacyConfigs=new Map();
mock.module(new URL('../Captcha/storage.js',import.meta.url).href,{namedExports:{getGuildConfig:id=>structuredClone(legacyConfigs.get(id)||{verification:{enabled:false}}),saveGuildConfig:(id,cfg)=>legacyConfigs.set(id,structuredClone(cfg))}});
const { initializeGuild, runModule, handleSupportInteraction, startMemberChallenge }=await import('../ProtectModules/integration.js');
test('integration seeds the five configured motifs once and keeps guild edits',async()=>{
 const g=guild(newId());await initializeGuild(g);
 const cfg=await getConfig(g.id);assert.equal(cfg.categories.length,5);assert.equal(cfg.categories[4].label,'Couronnes');assert.equal(cfg.categories[4].categoryId,'55555555555555555');
 await updateConfig(g.id,{$set:{'embed.title':'Modifié'}});await initializeGuild(g);assert.equal((await getConfig(g.id)).embed.title,'Modifié');
});
test('command adapter protects configuration and renders the imported dashboard',async()=>{
 const {command}=await import('../Commands/Contact/ticket.js');const g=guild(newId()),c=client(g);let answer;
 const m={guild:g,author:{id:USER,tag:'test'},member:g.members.cache.get(USER),reply:async data=>{answer=data}};
 await command.run(c,m,[]);assert.match(answer.content,/Permission/);
 m.member.permissions=permissions(['ManageGuild']);await command.run(c,m,[]);assert.ok(answer.components.length);for(const p of answer.components)p.toJSON();
});
test('legacy captcha migration keeps Unverified restrictions and awards a separate verified role',async()=>{
 const g=guild(newId()),c=client(g),ch=channel(g,newId());g.client=c;
 const oldRole=await g.roles.create({name:'Unverified',permissions:[]});
 legacyConfigs.set(g.id,{verification:{enabled:true,roleId:oldRole.id,channelId:ch.id,timeoutMs:300000,maxAttempts:3,kickOnFail:false,ignoreBots:true}});
 const member=g.members.cache.get(USER);
 member.roles.add=async r=>{const role=typeof r==='string'?g.roles.cache.get(r):r;member.roles.cache.set(role.id,role);};
 await startMemberChallenge(c,member);
 const {getConfig:getCaptcha}=await import('../ProtectModules/Handler/captcha/schema.js');
 const cfg=await getCaptcha(g.id);assert.notEqual(cfg.roleId,oldRole.id);assert.ok(member.roles.cache.has(oldRole.id));
 const json=JSON.stringify(ch.sent[0].components.map(x=>x.toJSON()));const code=/Code :\*\* \\?`([A-Z2-9]{5})/.exec(json)[1];
 const i=interaction(g,`cp_modal:${USER}`,{isButton:()=>false,isModalSubmit:()=>true,isFromMessage:()=>false,fields:{getTextInputValue:()=>code}});
 await handleSupportInteraction(c,i);assert.ok(member.roles.cache.has(cfg.roleId));assert.equal(member.roles.cache.has(oldRole.id),false);
});
