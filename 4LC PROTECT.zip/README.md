# 4LC-PROTECT

Bot Discord de protection et de gestion pour **un seul serveur par installation**. Le code peut être publié sur GitHub.

Installation : Node.js 24 minimum, puis `npm install`. Copier `config.example.json` vers `config.json` et renseigner `token`, `owners` (IDs des administrateurs initiaux) et `guildId` (ID du serveur). On peut aussi copier `.env.example` vers `.env` et renseigner `TOKEN`, `OWNER_IDS` (IDs séparés par des virgules) et `GUILD_ID`. Lancer `npm start`.

Sans ID configuré, le bot mémorise le serveur uniquement s’il est présent sur exactement un serveur. S’il en voit plusieurs, il attend un ID explicite. Les événements, commandes et tâches automatiques restent limités au serveur choisi. Les commandes slash sont enregistrées sur ce serveur ; les anciennes commandes globales de cette application sont retirées.

`+owner @membre` et `+setowner @membre` rendent le membre **owner du bot**, avec accès immédiat aux commandes et panneaux sur le serveur configuré, sans permission Discord supplémentaire pour l’utilisateur. `+owner` affiche la liste et `+unowner @membre` retire un owner ajouté par commande. Les changements de nom, d’avatar et la commande de départ du serveur sont réservés aux owners de `config.json` ou `OWNER_IDS`. Les permissions et la hiérarchie du bot imposées par Discord restent nécessaires.

`+secure @membre` permet d’activer ou désactiver les protections. `+secure` affiche la liste et `+unsecure @membre` retire cet accès. Les réglages restent réservés aux owners du bot ou au propriétaire du serveur.

Pour GitHub : ne pas publier `config.json`, `.env`, `database.sqlite3`, `4LC-DATA/` ni les données de membres. Ces fichiers sont exclus par `.gitignore`. Les exemples fournis ne contiennent aucun token ni ID personnel. Le statut Public Bot dans le portail Discord est indépendant de la visibilité du code et de la restriction au serveur.

Mise à jour : conserver sa configuration et ses fichiers de données avant de remplacer le code. Renseigner le nouvel ID de serveur et redémarrer. Tests locaux : `npm test`.

Support : https://discord.gg/ddJMXWYJ29
