import db from '../Events/loadDatabase.js';
import { getGuildConfig, hasStoredGuildConfig, saveGuildConfig } from '../ProtectCore/storage.js';
import { invalidateSettings } from '../ProtectCore/antiraid/runtime.js';
const names = ['antispam','antilink','antieveryone','antibot','antitoken','antichannel','antirole','antiban','antiwebhook','antiupdate','antivanity'];
const all = (sql, params=[]) => new Promise((resolve,reject) => db.all(sql,params,(err,rows)=>err?reject(err):resolve(rows||[])));
export async function migrateProtections() {
    const rows = await all('SELECT * FROM antiraid');
    for (const row of rows) {
        const stored = hasStoredGuildConfig(row.guild);
        const cfg = getGuildConfig(row.guild);
        if (!stored) {
            for (const name of names) cfg.enabled[name] = Boolean(row[name]);
            cfg.antilink.type = row.type === 'all' ? 'all' : 'invite';
            cfg.antispam.count = Math.max(2, Number(row.nombremessage) || 5);
            cfg.antispam.windowMs = Math.max(1000, (Number(row.sous) || 10) * (Number(row.sous) >= 1000 ? 1 : 1000));
            cfg.antispam.timeoutMs = Math.max(1000, Number(row.timeout) || 60000);
            for (const entry of await all('SELECT module,punition FROM punish WHERE guild = ?', [row.guild])) {
                if (names.includes(entry.module) && ['timeout','ban','kick','derank','jail','none'].includes(entry.punition)) cfg.punishments[entry.module] = entry.punition;
            }
            const raid = (await all('SELECT * FROM raidmode WHERE guild = ?', [row.guild]))[0];
            if (raid) { cfg.autoRaid.enabled = Boolean(raid.enabled); cfg.autoRaid.count = raid.count || 8; cfg.autoRaid.windowMs = raid.window_ms || 10000; cfg.autoRaid.durationMs = raid.duration_ms || 600000; cfg.raidAction = raid.action === 'ban' ? 'ban' : 'kick'; }
        }
        if (!cfg.legacyProtectionMigrated) { cfg.legacyProtectionMigrated = true; saveGuildConfig(row.guild,cfg); invalidateSettings(row.guild); }
        // The single core now owns the protection toggles; legacy listeners stay inactive.
        await new Promise((resolve,reject) => db.run(`UPDATE antiraid SET ${names.map(name => `${name}=0`).join(',')} WHERE guild=?`,[row.guild],err=>err?reject(err):resolve()));
    }
}
