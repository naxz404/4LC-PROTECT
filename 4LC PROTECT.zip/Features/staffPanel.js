import { isGlobalOwner } from '../Owners.js';
import { lockChannels, renewChannel, renewSuccessEmbed } from '../ProtectCore/lockdown.js';
import { getGuildConfig } from '../ProtectCore/storage.js';
import { ActionRowBuilder, ButtonBuilder, ButtonStyle, EmbedBuilder, ModalBuilder, TextInputBuilder, TextInputStyle, MessageFlags, PermissionFlagsBits } from 'discord.js';
import db from '../Events/loadDatabase.js';
import { canManage } from './serverSecurity.js';
import { applyProgressiveWarning } from '../ProtectCore/warningSystem.js';
import { getSanctions } from '../ProtectCore/storage.js';
import { quarantineMember } from '../ProtectCore/quarantine.js';

const E = MessageFlags.Ephemeral;
const footer = 'By 4LC | discord.gg/ddJMXWYJ29';

export function staffPanelPayload() {
  const embed = new EmbedBuilder().setColor(0x6495ed).setTitle('🛡️ Panel Staff · 4LC-PROTECT').setDescription('Gestion rapide du serveur. Choisis une action ci-dessous.').setFooter({ text: footer });
  const row1 = new ActionRowBuilder().addComponents(
    new ButtonBuilder().setCustomId('staff:ban').setLabel('Ban').setStyle(ButtonStyle.Danger),
    new ButtonBuilder().setCustomId('staff:kick').setLabel('Kick').setStyle(ButtonStyle.Danger),
    new ButtonBuilder().setCustomId('staff:timeout').setLabel('Timeout').setStyle(ButtonStyle.Secondary),
    new ButtonBuilder().setCustomId('staff:warn').setLabel('Warn').setStyle(ButtonStyle.Secondary),
  );
  const row2 = new ActionRowBuilder().addComponents(
    new ButtonBuilder().setCustomId('staff:role').setLabel('Role').setStyle(ButtonStyle.Primary),
    new ButtonBuilder().setCustomId('staff:nick').setLabel('Nick').setStyle(ButtonStyle.Primary),
    new ButtonBuilder().setCustomId('staff:lock').setLabel('Lock').setStyle(ButtonStyle.Secondary),
    new ButtonBuilder().setCustomId('staff:renew').setLabel('Renew').setStyle(ButtonStyle.Secondary),
  );
  return { embeds: [embed], components: [row1, row2] };
}

export function memberPanelPayload(member) {
  const id = member.id;
  const embed = new EmbedBuilder()
    .setColor(0x6495ed)
    .setTitle(`👤 Gestion membre · ${member.user.username}`)
    .setThumbnail(member.user.displayAvatarURL())
    .setDescription(`Membre : <@${id}>\nID : \`${id}\`\nCompte créé : <t:${Math.floor(member.user.createdTimestamp/1000)}:R>\nArrivé : ${member.joinedTimestamp ? `<t:${Math.floor(member.joinedTimestamp/1000)}:R>` : '—'}`)
    .setFooter({ text: footer });
  const row1 = new ActionRowBuilder().addComponents(
    new ButtonBuilder().setCustomId(`staffm:warn:${id}`).setLabel('Warn').setStyle(ButtonStyle.Secondary),
    new ButtonBuilder().setCustomId(`staffm:timeout:${id}`).setLabel('Timeout').setStyle(ButtonStyle.Secondary),
    new ButtonBuilder().setCustomId(`staffm:kick:${id}`).setLabel('Kick').setStyle(ButtonStyle.Danger),
    new ButtonBuilder().setCustomId(`staffm:ban:${id}`).setLabel('Ban').setStyle(ButtonStyle.Danger),
    new ButtonBuilder().setCustomId(`staffm:quarantine:${id}`).setLabel('Quarantine').setStyle(ButtonStyle.Danger),
  );
  const row2 = new ActionRowBuilder().addComponents(
    new ButtonBuilder().setCustomId(`staffm:role:${id}`).setLabel('Role').setStyle(ButtonStyle.Primary),
    new ButtonBuilder().setCustomId(`staffm:nick:${id}`).setLabel('Nick').setStyle(ButtonStyle.Primary),
    new ButtonBuilder().setCustomId(`staffm:history:${id}`).setLabel('History').setStyle(ButtonStyle.Secondary),
    new ButtonBuilder().setCustomId(`staffm:lock:${id}`).setLabel('Lock').setStyle(ButtonStyle.Secondary),
    new ButtonBuilder().setCustomId(`staffm:renew:${id}`).setLabel('Renew').setStyle(ButtonStyle.Secondary),
  );
  return { embeds: [embed], components: [row1, row2] };
}

function input(id, label, required = true, style = TextInputStyle.Short, placeholder = '') {
  return new ActionRowBuilder().addComponents(new TextInputBuilder().setCustomId(id).setLabel(label).setRequired(required).setStyle(style).setPlaceholder(placeholder));
}
function actionModal(action, targetId = null) {
  const modal = new ModalBuilder().setCustomId(targetId ? `staffmmodal:${action}:${targetId}` : `staffmodal:${action}`).setTitle(`4LC Staff · ${action.toUpperCase()}`);
  if (!targetId && ['ban','kick','warn'].includes(action)) modal.addComponents(input('user','ID du membre'));
  if (!targetId && action === 'timeout') modal.addComponents(input('user','ID du membre'));
  if (!targetId && action === 'role') modal.addComponents(input('user','ID du membre'));
  if (!targetId && action === 'nick') modal.addComponents(input('user','ID du membre'));
  if (['ban','kick','warn'].includes(action)) modal.addComponents(input('reason','Raison', true, TextInputStyle.Paragraph));
  if (action === 'timeout') modal.addComponents(input('minutes','Durée en minutes', true, TextInputStyle.Short, '30'), input('reason','Raison', false, TextInputStyle.Paragraph));
  if (action === 'role') modal.addComponents(input('role','ID du rôle'), input('mode','add ou remove', true, TextInputStyle.Short, 'add'));
  if (action === 'nick') modal.addComponents(input('nick','Nouveau pseudo (vide = reset)', false));
  return modal;
}

async function deny(i) { return i.reply({ content: '⛔ Permission insuffisante.', flags: E }).catch(() => {}); }
async function writeLegacyWarn(guildId, userId, reason) {
  return new Promise(resolve => db.run('INSERT INTO sanctions (userId, raison, date, guild) VALUES (?, ?, ?, ?)', [userId, reason, new Date().toISOString(), guildId], () => resolve()));
}
async function historyText(guildId, userId) {
  const json = getSanctions(guildId, userId).slice(-12).reverse();
  const legacy = await new Promise(resolve => db.all('SELECT raison,date FROM sanctions WHERE guild=? AND userId=? ORDER BY id DESC LIMIT 12', [guildId,userId], (e,r)=>resolve(e?[]:r||[])));
  const lines = [];
  for (const row of json) lines.push(`• **${row.type || 'sanction'}** · ${row.description || row.reason || 'Sans raison'}${row.at ? ` · <t:${Math.floor(row.at/1000)}:R>` : ''}`);
  if (!lines.length) for (const row of legacy) lines.push(`• **warn** · ${row.raison || 'Sans raison'}${row.date ? ` · ${row.date}` : ''}`);
  return lines.slice(0,12).join('\n') || 'Aucune sanction enregistrée.';
}

export async function handleStaffInteraction(i) {
  if (!/^(staff:|staffmodal:|staffm:|staffmmodal:)/.test(i.customId || '')) return false;
  try { return await runStaffInteraction(i); }
  catch (error) {
    console.error('[4LC-PROTECT] Panel staff:', error);
    const payload = { content: 'Action impossible. Vérifie les permissions et la hiérarchie du bot.' };
    if (i.deferred || i.replied) await i.editReply(payload).catch(() => {});
    else await i.reply({ ...payload, flags: E }).catch(() => {});
    return true;
  }
}
const actionPermissions = { ban: PermissionFlagsBits.BanMembers, kick: PermissionFlagsBits.KickMembers, timeout: PermissionFlagsBits.ModerateMembers, warn: PermissionFlagsBits.ModerateMembers, quarantine: PermissionFlagsBits.ModerateMembers, history: PermissionFlagsBits.ModerateMembers, role: PermissionFlagsBits.ManageRoles, nick: PermissionFlagsBits.ManageNicknames, lock: PermissionFlagsBits.ManageChannels, renew: PermissionFlagsBits.ManageChannels };
export function canOpenStaff(member) { return Object.values(actionPermissions).some(permission => canManage(member, permission)); }
function targetAllowed(i, member, userId, action) {
  if (userId === i.guild.ownerId || userId === i.client.user.id) return false;
  if (['ban','kick','timeout','warn','quarantine'].includes(action) && userId === i.user.id) return false;
  if (member && !isGlobalOwner(i.user.id) && i.user.id !== i.guild.ownerId && userId !== i.user.id && member.roles.highest.position >= i.member.roles.highest.position) return false;
  return true;
}
async function runStaffInteraction(i) {
  const isStaff = i.customId?.startsWith('staff:') || i.customId?.startsWith('staffmodal:');
  const isMember = i.customId?.startsWith('staffm:') || i.customId?.startsWith('staffmmodal:');
  if (!isStaff && !isMember) return false;
  const requestedAction = i.customId.split(':')[1];
  if (!i.guild || !actionPermissions[requestedAction] || !canManage(i.member, actionPermissions[requestedAction])) { await deny(i); return true; }

  if (i.isButton()) {
    const parts = i.customId.split(':');
    const action = parts[1];
    const targetId = parts[2] || null;
    if (['ban','kick','timeout','warn','role','nick'].includes(action)) { await i.showModal(actionModal(action, targetId)); return true; }
    if (action === 'quarantine' && targetId) {
      await i.deferReply({ flags: E });
      const member = await i.guild.members.fetch(targetId).catch(()=>null);
      if (!member || !targetAllowed(i, member, targetId, action)) return i.editReply({content:'Cible introuvable ou interdite.'}), true;
      const result = await quarantineMember(i.client, member, 'panel-member', `Quarantaine par ${i.user.tag}`).catch(()=>null);
      await i.editReply({content: result?.applied ? `🔒 <@${targetId}> placé en quarantaine.` : 'Impossible de placer ce membre en quarantaine.',flags:E}); return true;
    }
    if (action === 'history' && targetId) {
      await i.deferReply({ flags: E });
      const text = await historyText(i.guild.id,targetId);
      await i.editReply({embeds:[new EmbedBuilder().setColor(0x6495ed).setTitle(`📋 Historique · ${targetId}`).setDescription(text).setFooter({text:footer})],flags:E}); return true;
    }
    if (action === 'lock') {
      if (!i.channel?.permissionOverwrites?.edit) return i.reply({ content: 'Salon incompatible.', flags: E }), true;
      await i.deferReply({ flags: E });
      const result = await lockChannels(i.guild, [i.channel], i.user.id, 'Panel staff');
      await i.editReply({ content: result.locked ? '🔒 Salon verrouillé.' : 'Salon déjà verrouillé ou action impossible.' }); return true;
    }
    if (action === 'renew') {
      if (!i.channel?.clone) return i.reply({ content: 'Salon incompatible.', flags: E }), true;
      await i.reply({ content: 'Recréation du salon en cours…', flags: E });
      const clone = await renewChannel(i.channel, i.user.id);
      await clone.send({ embeds: [renewSuccessEmbed(getGuildConfig(i.guild.id))] }); return true;
    }
  }

  if (i.isModalSubmit()) {
    const parts = i.customId.split(':');
    const action = parts[1];
    const targetId = parts[2] || null;
    const userId = targetId || i.fields.getTextInputValue('user').trim();
    if (!/^\d{17,22}$/.test(userId)) return i.reply({ content: 'Identifiant invalide.', flags: E }), true;
    await i.deferReply({ flags: E });
    const member = await i.guild.members.fetch(userId).catch(() => null);
    if (!targetAllowed(i, member, userId, action)) return i.editReply({ content: 'Cible interdite ou rôle du modérateur insuffisant.' }), true;
    if (!member && action !== 'ban') { await i.editReply({ content: 'Membre introuvable.', flags: E }); return true; }
    if (action === 'ban') { const reason=i.fields.getTextInputValue('reason').slice(0,400); await i.guild.members.ban(userId,{reason:`${reason} · ${i.user.tag}`}); await i.editReply({content:`✅ <@${userId}> banni.`,flags:E}); return true; }
    if (action === 'kick') { const reason=i.fields.getTextInputValue('reason').slice(0,400); if(!member.kickable) return i.editReply({content:'Impossible de kick ce membre.',flags:E}),true; await member.kick(`${reason} · ${i.user.tag}`); await i.editReply({content:`✅ ${userId} expulsé.`,flags:E}); return true; }
    if (action === 'timeout') { const mins=Number(i.fields.getTextInputValue('minutes')); if(!Number.isInteger(mins)||mins<1||mins>40320) return i.editReply({content:'Indique une durée entière entre 1 et 40320 minutes.'}),true; const reason=i.fields.getTextInputValue('reason').slice(0,400)||'Panel staff'; if(!member.moderatable) return i.editReply({content:'Impossible de timeout ce membre.',flags:E}),true; await member.timeout(mins*60000,`${reason} · ${i.user.tag}`); await i.editReply({content:`✅ <@${userId}> timeout ${mins} min.`,flags:E}); return true; }
    if (action === 'warn') {
      const reason=i.fields.getTextInputValue('reason').slice(0,400); await writeLegacyWarn(i.guild.id,userId,reason);
      const progressive = await applyProgressiveWarning(i.client, member, reason, i.user.id, 1).catch(()=>null);
      await i.editReply({content:`⚠️ <@${userId}> warn : ${reason}${progressive && progressive.action !== 'warn' ? ` · Auto: **${progressive.action}** (${progressive.total})` : ` · Total: **${progressive?.total || 1}**`}`,flags:E}); return true;
    }
    if (action === 'role') { const roleId=i.fields.getTextInputValue('role').trim(); const mode=i.fields.getTextInputValue('mode').trim().toLowerCase(); const role=i.guild.roles.cache.get(roleId); if(!['add','remove'].includes(mode)||!role||!role.editable||role.managed||role.id===i.guild.id||(!isGlobalOwner(i.user.id)&&i.user.id!==i.guild.ownerId&&(role.position>=i.member.roles.highest.position||(role.permissions.bitfield & ~i.member.permissions.bitfield)!==0n))) return i.editReply({content:'Rôle introuvable ou non gérable.',flags:E}),true; if(mode==='remove') await member.roles.remove(role); else await member.roles.add(role); await i.editReply({content:`✅ Rôle ${mode==='remove'?'retiré':'ajouté'} pour <@${userId}>.`,flags:E}); return true; }
    if (action === 'nick') { const nick=i.fields.getTextInputValue('nick').trim(); if(nick.length>32) return i.editReply({content:'Le surnom doit contenir au maximum 32 caractères.'}),true; if(!member.manageable) return i.editReply({content:'Pseudo non modifiable.',flags:E}),true; await member.setNickname(nick||null,`Panel staff par ${i.user.tag}`); await i.editReply({content:'✅ Pseudo modifié.',flags:E}); return true; }
  }
  return true;
}
