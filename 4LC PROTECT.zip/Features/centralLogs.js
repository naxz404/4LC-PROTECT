import { invalidateSettings } from '../ProtectCore/antiraid/runtime.js';
import { ChannelType, PermissionFlagsBits } from 'discord.js';
import db from '../Events/loadDatabase.js';
import { getGuildConfig, saveGuildConfig } from '../ProtectCore/storage.js';

export const CENTRAL_LOG_NAME = '4lcprotect-logs';
const pending = new Map();
const bound = new Map();
const LOG_KEYS = ['📁・mod-logs','📁・boost-logs','📁・message-logs','📁・raid-logs','📁・role-logs','📁・voice-logs','📁・ticket-logs'];

function dbRun(sql, params=[]) { return new Promise((resolve,reject)=>db.run(sql, params, err=>err?reject(err):resolve())); }

export async function bindCentralLogs(guild, channel) {
  if (bound.get(guild.id) === channel.id && getGuildConfig(guild.id).logChannel === channel.id) return channel;
  const mapping = Object.fromEntries(LOG_KEYS.map(k => [k, channel.id]));
  await dbRun('INSERT OR REPLACE INTO logs (guild, channels) VALUES (?, ?)', [guild.id, JSON.stringify(mapping)]).catch(()=>{});
  const cfg = getGuildConfig(guild.id);
  const previous = cfg.logChannel;
  cfg.logChannel = channel.id;
  if (!cfg.reportChannel || cfg.reportChannel === previous) cfg.reportChannel = channel.id;
  saveGuildConfig(guild.id, cfg);
  invalidateSettings(guild.id);
  bound.set(guild.id, channel.id);
  return channel;
}

export async function ensureCentralLogChannel(guild, options = {}) {
  if (!guild) return null;
  if (!options.recreate && pending.has(guild.id)) return pending.get(guild.id);
  const previous = pending.get(guild.id) || Promise.resolve();
  const task = previous.catch(() => {}).then(() => createCentralLogChannel(guild, options));
  pending.set(guild.id, task);
  try { return await task; } finally { if (pending.get(guild.id) === task) pending.delete(guild.id); }
}
async function createCentralLogChannel(guild, { recreate=false } = {}) {
  if (!guild) return null;
  const cfg = getGuildConfig(guild.id);
  const previous = cfg.logChannel ? guild.channels.cache.get(cfg.logChannel) : null;
  let channel = !recreate && cfg.logChannel ? previous : null;
  if (!channel || !channel.isTextBased()) {
    channel = !recreate ? guild.channels.cache.find(c => c.type === ChannelType.GuildText && c.name.toLowerCase() === CENTRAL_LOG_NAME) : null;
  }
  if (!channel || recreate) {
    const me = guild.members.me || await guild.members.fetchMe().catch(() => null);
    if (!me) return null;
    channel = await guild.channels.create({
      name: CENTRAL_LOG_NAME,
      type: ChannelType.GuildText,
      topic: '4LC-PROTECT · Tous les logs : modération, anti-raid, tickets, messages, rôles, vocaux et sécurité.',
      permissionOverwrites: [
        { id: guild.id, deny: [PermissionFlagsBits.ViewChannel] },
        { id: me.id, allow: [PermissionFlagsBits.ViewChannel, PermissionFlagsBits.SendMessages, PermissionFlagsBits.EmbedLinks, PermissionFlagsBits.ReadMessageHistory] },
      ],
      reason: '4LC-PROTECT · Salon de logs central',
    }).catch(() => null);
  }
  if (channel) {
    if (channel.name !== CENTRAL_LOG_NAME && channel.manageable !== false) {
      await channel.setName(CENTRAL_LOG_NAME, '4LC-PROTECT · Nom du salon central').catch(() => {});
    }
    await bindCentralLogs(guild, channel);
    if (recreate && previous && previous.id !== channel.id && previous.deletable) await previous.delete('4LC-PROTECT · Salon logs recréé').catch(() => {});
  }
  return channel;
}
