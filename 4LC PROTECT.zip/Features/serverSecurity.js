import { PermissionFlagsBits } from 'discord.js';
import { getGuildConfig, saveGuildConfig, saveJoinRecord } from '../ProtectCore/storage.js';
import { scoreJoinRisk } from '../ProtectCore/joinRisk.js';
import { quarantineMember, resolveQuarantine } from '../ProtectCore/quarantine.js';
import { isGlobalOwner } from '../ProtectCore/protectionAccess.js';

const joinBursts = new Map();
const LOCK_PERMS = [
  PermissionFlagsBits.SendMessages,
  PermissionFlagsBits.AddReactions,
  PermissionFlagsBits.CreatePublicThreads,
  PermissionFlagsBits.CreatePrivateThreads,
  PermissionFlagsBits.SendMessagesInThreads,
  PermissionFlagsBits.Connect,
  PermissionFlagsBits.Speak,
];

export function canManage(member, permission = PermissionFlagsBits.ManageGuild) {
  return Boolean(member && (isGlobalOwner(member.id || member.user?.id) || member.permissions?.has?.(permission) || member.id === member.guild.ownerId));
}

export async function runAntiAlt(member) {
  if (!member?.guild || member.user.bot) return { checked: false };
  const cfg = getGuildConfig(member.guild.id);
  const settings = cfg.antiAlt || { enabled: false };
  if (!settings.enabled) return { checked: false };
  if ((isGlobalOwner(member.id) || member.id === member.guild.ownerId) || cfg.whitelistedUsers?.includes(member.id)) return { checked: false, exempt: true };

  const now = Date.now();
  const base = scoreJoinRisk(member.user, now);
  const windowMs = Math.max(5_000, Number(settings.burstWindowMs) || 15_000);
  const burstCount = Math.max(3, Number(settings.burstCount) || 5);
  const recent = (joinBursts.get(member.guild.id) || []).filter((ts) => now - ts <= windowMs);
  recent.push(now); joinBursts.set(member.guild.id, recent);

  let score = base.score;
  const indicators = [...base.indicators];
  if (recent.length >= burstCount) {
    const points = Math.max(10, Number(settings.burstPoints) || 30);
    score = Math.min(100, score + points);
    indicators.push({ name: `arrivée pendant une vague (${recent.length}/${Math.round(windowMs / 1000)}s)`, points });
  }
  const threshold = Math.max(20, Math.min(100, Number(settings.threshold) || 45));
  saveJoinRecord(member.guild.id, { userId: member.id, at: now, antiAltScore: score, antiAltIndicators: indicators.map(i => i.name) });
  if (score < threshold) return { checked: true, score, threshold, indicators, quarantined: false };

  const reason = `Anti-alt · score ${score}/100 · ${indicators.map((i) => i.name).join(', ') || 'signaux cumulés'}`;
  const result = await quarantineMember(member.guild.client, member, 'anti-alt', reason);
  return { checked: true, score, threshold, indicators, quarantined: result.applied };
}

export async function quarantineTarget(member, actorId, reason = 'Quarantaine manuelle') {
  return quarantineMember(member.guild.client, member, 'manual', `${reason} · par ${actorId}`);
}

export async function unquarantineTarget(guild, userId, actorId) {
  return resolveQuarantine(guild, userId, 'allow', actorId);
}

export async function fullLockdown(guild, actorId, reason = 'Lockdown manuel') {
  const cfg = getGuildConfig(guild.id);
  if (cfg.fullLockdown?.active) return { ok: false, already: true, count: 0 };
  const snapshots = {};
  let count = 0;
  for (const channel of guild.channels.cache.values()) {
    if (channel.isThread?.() || !channel.permissionOverwrites?.edit) continue;
    const everyone = channel.permissionOverwrites.cache.get(guild.id);
    snapshots[channel.id] = everyone ? { exists: true, allow: everyone.allow.bitfield.toString(), deny: everyone.deny.bitfield.toString() } : { exists: false };
    const patch = {};
    if (channel.isTextBased?.()) {
      patch.SendMessages = false; patch.AddReactions = false; patch.CreatePublicThreads = false; patch.CreatePrivateThreads = false; patch.SendMessagesInThreads = false;
    }
    if (channel.isVoiceBased?.()) { patch.Connect = false; patch.Speak = false; }
    if (!Object.keys(patch).length) continue;
    const ok = await channel.permissionOverwrites.edit(guild.id, patch, { reason: `Lockdown 4LC par ${actorId}: ${reason}` }).then(() => true).catch(() => false);
    if (ok) count++;
  }
  cfg.fullLockdown = { active: true, actorId, reason: String(reason).slice(0, 250), at: Date.now(), snapshots };
  saveGuildConfig(guild.id, cfg);
  return { ok: true, count };
}

export async function fullUnlockdown(guild, actorId) {
  const cfg = getGuildConfig(guild.id);
  const state = cfg.fullLockdown;
  if (!state?.active) return { ok: false, inactive: true, count: 0 };
  let count = 0;
  const remaining = {};
  for (const [channelId, saved] of Object.entries(state.snapshots || {})) {
    const channel = guild.channels.cache.get(channelId);
    if (!channel?.permissionOverwrites) continue;
    try {
      const others = channel.permissionOverwrites.cache.filter((o) => o.id !== guild.id).map((o) => ({ id: o.id, type: o.type, allow: o.allow.bitfield, deny: o.deny.bitfield }));
      if (saved.exists) others.push({ id: guild.id, type: 0, allow: BigInt(saved.allow), deny: BigInt(saved.deny) });
      await channel.permissionOverwrites.set(others, `Unlockdown 4LC par ${actorId}`);
      count++;
    } catch { remaining[channelId] = saved; }
  }
  cfg.fullLockdown = { active: Object.keys(remaining).length > 0, restoredAt: Date.now(), restoredBy: actorId, snapshots: remaining };
  saveGuildConfig(guild.id, cfg);
  return { ok: true, count };
}
