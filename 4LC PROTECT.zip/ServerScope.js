import './Environment.js';
import config from './config.json' with { type: 'json' };
import { protectionDataDir } from './DataPaths.js';
import { existsSync, readFileSync, mkdirSync, writeFileSync } from 'node:fs';
import { dirname, join } from 'node:path';

// Each installation operates on one server. Never guess when several servers exist.
export function createServerScope({ config = {}, env = {}, file } = {}) {
    const valid = id => /^\d{17,22}$/.test(id || '');
    const explicit = env.GUILD_ID || config.guildId;
    if (explicit && !valid(explicit)) throw new Error('GUILD_ID / guildId doit être un identifiant Discord valide.');
    let target = explicit || null;
    if (!target && file && existsSync(file)) {
        target = JSON.parse(readFileSync(file, 'utf8')).guildId;
        if (!valid(target)) throw new Error('Identifiant de serveur enregistré invalide. Renseigne guildId.');
    }
    return {
        initialize(client) {
            if (!target && client.guilds.cache.size === 1) {
                target = [...client.guilds.cache.values()][0].id;
                if (file) { mkdirSync(dirname(file), { recursive: true }); writeFileSync(file, JSON.stringify({ guildId: target }, null, 2)); }
            }
            return target;
        },
        allows(id) { return Boolean(target && id === target); },
        guilds(client) { return [...client.guilds.cache.values()].filter(g => g.id === target); },
        get guildId() { return target; }
    };
}
const scope = createServerScope({ config, env: process.env, file: join(protectionDataDir, 'server.json') });
export const initializeServerScope = client => scope.initialize(client);
export const isAllowedGuild = id => scope.allows(id);
export const allowedGuilds = client => scope.guilds(client);
export function eventGuildId(name, args) {
    if (name === 'guildAuditLogEntryCreate') return args[1]?.id;
    if (['guildCreate', 'guildDelete', 'guildUpdate', 'guildUnavailable', 'guildAvailable'].includes(name)) return args[0]?.id;
    for (const item of args) {
        const id = item?.guildId || item?.guild?.id || item?.message?.guildId || item?.message?.guild?.id;
        if (id) return id;
    }
    return null;
}
export function allowServerEvent(client, name, args) {
    if (name === 'guildCreate' || name === 'guildAvailable') initializeServerScope(client);
    const id = eventGuildId(name, args);
    if (id) return isAllowedGuild(id);
    // Guild-bound events and DMs cannot bypass server scope.
    if (/^(guild|channel|role|message|interaction|voice|thread|invite|autoModeration|stage)/.test(name)) return false;
    return true;
}
