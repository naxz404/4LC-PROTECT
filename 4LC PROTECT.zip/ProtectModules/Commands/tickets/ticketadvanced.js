import {advancedTicketCommand} from '../../Handler/v4/tickets.js';
export default advancedTicketCommand;
