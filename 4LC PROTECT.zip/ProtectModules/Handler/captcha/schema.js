import { Schema, model } from "../jsonDb.js";
import { applyBotScope, uniqueBotGuildIndex } from "../mongoScope.js";
const MIN = 60 * 1000;
export function defaultConfig(guildId) {
    return {
        guildId,
        enabled: false,
        channelId: null,
        roleId: null,
        timeout: 5 * MIN,
        maxAttempts: 3,
        kickOnFail: false,
        ignoreBots: true,
    };
}
const captchaSchema = new Schema({
    guildId: { type: String, required: true, index: true },
    enabled: { type: Boolean, default: false },
    channelId: { type: String, default: null },
    roleId: { type: String, default: null },
    timeout: { type: Number, default: 5 * MIN },
    maxAttempts: { type: Number, default: 3 },
    kickOnFail: { type: Boolean, default: false },
    ignoreBots: { type: Boolean, default: true },
}, { timestamps: true });
applyBotScope(captchaSchema);
uniqueBotGuildIndex(captchaSchema);
export const Captcha = model("Captcha", captchaSchema, "captcha");
function asBoolean(value, fallback) {
    return typeof value === "boolean" ? value : fallback;
}
function asStringOrNull(value, fallback) {
    if (value === null)
        return null;
    return typeof value === "string" ? value : fallback;
}
function asNumber(value, fallback) {
    return typeof value === "number" && Number.isFinite(value) ? value : fallback;
}
export function normalizeConfig(raw) {
    const guildId = typeof raw?.guildId === "string" ? raw.guildId : "";
    const defaults = defaultConfig(guildId);
    const maxAttempts = Math.floor(asNumber(raw?.maxAttempts, defaults.maxAttempts));
    const timeout = Math.floor(asNumber(raw?.timeout, defaults.timeout));
    return {
        guildId,
        enabled: asBoolean(raw?.enabled, defaults.enabled),
        channelId: asStringOrNull(raw?.channelId, defaults.channelId),
        roleId: asStringOrNull(raw?.roleId, defaults.roleId),
        timeout: timeout > 0 ? timeout : defaults.timeout,
        maxAttempts: maxAttempts >= 1 ? maxAttempts : defaults.maxAttempts,
        kickOnFail: asBoolean(raw?.kickOnFail, defaults.kickOnFail),
        ignoreBots: asBoolean(raw?.ignoreBots, defaults.ignoreBots),
    };
}
const CONFIG_CACHE_TTL = 5_000;
const cache = new Map();
export function invalidateConfig(guildId) {
    cache.delete(guildId);
}
export async function getConfig(guildId) {
    const hit = cache.get(guildId);
    if (hit && Date.now() - hit.ts < CONFIG_CACHE_TTL)
        return hit.config;
    const raw = await Captcha.findOne({ guildId }).lean();
    const config = normalizeConfig(raw ?? { guildId });
    cache.set(guildId, { config, ts: Date.now() });
    return config;
}
export async function updateConfig(guildId, update) {
    await Captcha.findOneAndUpdate({ guildId }, update, { upsert: true });
    invalidateConfig(guildId);
    return getConfig(guildId);
}
