import { isGlobalOwner } from '../../../Owners.js';
import { BrandedEmbedBuilder as EmbedBuilder } from '../../../BrandedEmbedBuilder.js';
import { ActionRowBuilder, ButtonStyle, ChannelSelectMenuBuilder, ChannelType, ContainerBuilder, MessageFlags, ModalBuilder, RoleSelectMenuBuilder, TextInputBuilder, TextInputStyle, } from "discord.js";
import { colors } from "../../Handler/config.js";
import { appEmojiComponent, appEmojiHeading, appEmojiText } from "../appEmojis.js";
import formatTime from "../formatTime.js";
import parseTime from "../parseTime.js";
import { handleChallengeInteraction } from "./engine.js";
import { getConfig, updateConfig } from "./schema.js";
export const COMPONENTS_V2_FLAGS = MessageFlags.IsComponentsV2;
const CONTAINER_ACCENT = 0x000000;
const MIN_TIMEOUT = 30 * 1000;
const MAX_TIMEOUT = 24 * 60 * 60 * 1000;
const MIN_ATTEMPTS = 1;
const MAX_ATTEMPTS = 10;
function compactDuration(ms) {
    if (ms % 3_600_000 === 0)
        return `${ms / 3_600_000}h`;
    if (ms % 60_000 === 0)
        return `${ms / 60_000}m`;
    if (ms % 1000 === 0)
        return `${ms / 1000}s`;
    return `${ms}ms`;
}
function onOff(enabled) {
    return enabled ? `${appEmojiText("power")} Activé` : `${appEmojiText("power")} Désactivé`;
}
function yesNo(value) {
    return value ? `${appEmojiText("check")} Oui` : `${appEmojiText("cancel")} Non`;
}
function channelMention(channelId) {
    return channelId ? `<#${channelId}>` : "Aucun";
}
function roleMention(roleId) {
    return roleId ? `<@&${roleId}>` : "Aucun";
}
export function buildCaptchaEmbed(name, title, desc, color = colors.prime) {
    const embed = new EmbedBuilder().setTitle(" ").setDescription(`${appEmojiHeading(name, title)}\n${desc}`);
    if (color)
        embed.setColor(0x000000);
    return embed;
}
async function requireManageGuild(interaction) {
    if (isGlobalOwner(interaction.user.id)) return true;
    const member = interaction.member;
    const memberPermissions = member && typeof member.permissions === "object" && member.permissions !== null ? member.permissions : null;
    if (!member || !memberPermissions || !memberPermissions.has("ManageGuild")) {
        if (interaction.isRepliable()) {
            await interaction.reply({
                content: "> *Cette action nécessite la permission **Gérer le serveur**.*",
                flags: MessageFlags.Ephemeral,
            });
        }
        return false;
    }
    return true;
}
export function buildCaptchaContainer(_client, _guild, config) {
    const container = new ContainerBuilder().setAccentColor(CONTAINER_ACCENT);
    container.addTextDisplayComponents((t) => t.setContent(`# ${appEmojiText("check")} 〃 Captcha`));
    container.addSeparatorComponents((s) => s.setSpacing(1));
    container.addTextDisplayComponents((t) => t.setContent(`> *À l'arrivée, un code est envoyé dans le salon de vérification. Le rôle est donné après succès.*\n\n` +
        `> **État :** ${onOff(config.enabled)}\n` +
        `> ${appEmojiText("file")} **Salon :** ${channelMention(config.channelId)}\n` +
        `> ${appEmojiText("people")} **Rôle :** ${roleMention(config.roleId)}\n` +
        `> ${appEmojiText("cog")} **Délai :** \`${formatTime(config.timeout)}\`\n` +
        `> ${appEmojiText("cog")} **Essais :** \`${config.maxAttempts}\`\n` +
        `> ${appEmojiText("cancel")} **Expulsion :** ${yesNo(config.kickOnFail)}\n` +
        `> ${appEmojiText("people")} **Ignorer les bots :** ${yesNo(config.ignoreBots)}`));
    container.addSeparatorComponents((s) => s.setDivider(true));
    container.addSectionComponents((sectionBuilder) => sectionBuilder
        .addTextDisplayComponents((t) => t.setContent(`**Activation**\n> ${onOff(config.enabled)}`))
        .setButtonAccessory((btn) => btn
        .setCustomId("cp_toggle")
        .setEmoji(appEmojiComponent("power"))
        .setStyle(config.enabled ? ButtonStyle.Danger : ButtonStyle.Success)));
    container.addSeparatorComponents((s) => s.setDivider(true));
    container.addTextDisplayComponents((t) => t.setContent(`${appEmojiText("file")} **Salon de vérification**`));
    container.addActionRowComponents((row) => row.setComponents(new ChannelSelectMenuBuilder()
        .setCustomId("cp_channel")
        .setPlaceholder("Choisir le salon...")
        .setMaxValues(1)
        .setChannelTypes(ChannelType.GuildText, ChannelType.GuildAnnouncement)));
    container.addSectionComponents((sectionBuilder) => sectionBuilder
        .addTextDisplayComponents((t) => t.setContent("**Retirer le salon**"))
        .setButtonAccessory((btn) => btn.setCustomId("cp_channel_clear").setEmoji(appEmojiComponent("cancel")).setStyle(ButtonStyle.Danger).setDisabled(!config.channelId)));
    container.addSeparatorComponents((s) => s.setDivider(true));
    container.addTextDisplayComponents((t) => t.setContent(`${appEmojiText("people")} **Rôle vérifié**`));
    container.addActionRowComponents((row) => row.setComponents(new RoleSelectMenuBuilder().setCustomId("cp_role").setPlaceholder("Choisir le rôle...").setMaxValues(1)));
    container.addSectionComponents((sectionBuilder) => sectionBuilder
        .addTextDisplayComponents((t) => t.setContent("**Retirer le rôle**"))
        .setButtonAccessory((btn) => btn.setCustomId("cp_role_clear").setEmoji(appEmojiComponent("cancel")).setStyle(ButtonStyle.Danger).setDisabled(!config.roleId)));
    container.addSeparatorComponents((s) => s.setDivider(true));
    container.addSectionComponents((sectionBuilder) => sectionBuilder
        .addTextDisplayComponents((t) => t.setContent(`**Délai**\n> \`${formatTime(config.timeout)}\``))
        .setButtonAccessory((btn) => btn.setCustomId("cp_timeout").setEmoji(appEmojiComponent("cog")).setStyle(ButtonStyle.Secondary)));
    container.addSectionComponents((sectionBuilder) => sectionBuilder
        .addTextDisplayComponents((t) => t.setContent(`**Essais**\n> \`${config.maxAttempts}\``))
        .setButtonAccessory((btn) => btn.setCustomId("cp_attempts").setEmoji(appEmojiComponent("cog")).setStyle(ButtonStyle.Secondary)));
    container.addSectionComponents((sectionBuilder) => sectionBuilder
        .addTextDisplayComponents((t) => t.setContent(`**Expulsion en cas d'échec**\n> ${config.kickOnFail ? `Le membre est expulsé ${appEmojiText("check")}` : `Le membre reste sans le rôle ${appEmojiText("cancel")}`}`))
        .setButtonAccessory((btn) => btn
        .setCustomId("cp_kick")
        .setEmoji(appEmojiComponent("power"))
        .setStyle(config.kickOnFail ? ButtonStyle.Success : ButtonStyle.Danger)));
    container.addSectionComponents((sectionBuilder) => sectionBuilder
        .addTextDisplayComponents((t) => t.setContent(`**Ignorer les bots**\n> ${config.ignoreBots ? `Les bots ne déclenchent pas le captcha ${appEmojiText("check")}` : `Les bots déclenchent le captcha ${appEmojiText("cancel")}`}`))
        .setButtonAccessory((btn) => btn
        .setCustomId("cp_bots")
        .setEmoji(appEmojiComponent("power"))
        .setStyle(config.ignoreBots ? ButtonStyle.Success : ButtonStyle.Danger)));
    return [container];
}
function buildTimeoutModal(config) {
    const input = new TextInputBuilder()
        .setCustomId("timeout")
        .setLabel("Délai (30s, 5m, 1h…)")
        .setStyle(TextInputStyle.Short)
        .setRequired(true)
        .setMaxLength(16)
        .setPlaceholder("5m")
        .setValue(compactDuration(config.timeout));
    return new ModalBuilder()
        .setCustomId("cp_modal_timeout")
        .setTitle("Délai du captcha")
        .addComponents(new ActionRowBuilder().addComponents(input));
}
function buildAttemptsModal(config) {
    const input = new TextInputBuilder()
        .setCustomId("attempts")
        .setLabel(`Nombre d'essais (${MIN_ATTEMPTS}–${MAX_ATTEMPTS})`)
        .setStyle(TextInputStyle.Short)
        .setRequired(true)
        .setMaxLength(2)
        .setPlaceholder("3")
        .setValue(String(config.maxAttempts));
    return new ModalBuilder()
        .setCustomId("cp_modal_attempts")
        .setTitle("Essais du captcha")
        .addComponents(new ActionRowBuilder().addComponents(input));
}
async function refreshPanel(client, interaction, guild) {
    const config = await getConfig(guild.id);
    await interaction.update({
        components: buildCaptchaContainer(client, guild, config),
        flags: COMPONENTS_V2_FLAGS,
    });
}
export function clampTimeout(ms) {
    return Math.min(MAX_TIMEOUT, Math.max(MIN_TIMEOUT, Math.floor(ms)));
}
export function clampAttempts(n) {
    return Math.min(MAX_ATTEMPTS, Math.max(MIN_ATTEMPTS, Math.floor(n)));
}
export async function handleCaptchaInteraction(client, interaction) {
    if (!interaction.isMessageComponent() && !interaction.isModalSubmit())
        return false;
    const customId = interaction.customId;
    if (!customId.startsWith("cp_"))
        return false;
    if (!interaction.inGuild())
        return false;
    if (customId.startsWith("cp_verify:") || customId.startsWith("cp_modal:")) {
        return handleChallengeInteraction(client, interaction);
    }
    if (!(await requireManageGuild(interaction)))
        return true;
    const guild = interaction.guild;
    if (!guild)
        return false;
    if (interaction.isButton() && customId === "cp_timeout") {
        const config = await getConfig(guild.id);
        await interaction.showModal(buildTimeoutModal(config));
        return true;
    }
    if (interaction.isButton() && customId === "cp_attempts") {
        const config = await getConfig(guild.id);
        await interaction.showModal(buildAttemptsModal(config));
        return true;
    }
    if (interaction.isModalSubmit()) {
        if (!interaction.isFromMessage())
            return false;
        if (customId === "cp_modal_timeout") {
            const parsed = parseTime(interaction.fields.getTextInputValue("timeout"));
            if (parsed === null || parsed <= 0) {
                await interaction.reply({
                    content: "> *Durée invalide. Exemples : `30s`, `5m`, `1h`.*",
                    flags: MessageFlags.Ephemeral,
                });
                return true;
            }
            await updateConfig(guild.id, { $set: { timeout: clampTimeout(parsed) } });
            await refreshPanel(client, interaction, guild);
            return true;
        }
        if (customId === "cp_modal_attempts") {
            const raw = Number(interaction.fields.getTextInputValue("attempts").trim());
            if (!Number.isInteger(raw) || raw < MIN_ATTEMPTS || raw > MAX_ATTEMPTS) {
                await interaction.reply({
                    content: `> *Nombre d'essais invalide. Utilisez un entier entre **${MIN_ATTEMPTS}** et **${MAX_ATTEMPTS}**.*`,
                    flags: MessageFlags.Ephemeral,
                });
                return true;
            }
            await updateConfig(guild.id, { $set: { maxAttempts: clampAttempts(raw) } });
            await refreshPanel(client, interaction, guild);
            return true;
        }
        return false;
    }
    if (!interaction.isMessageComponent())
        return false;
    if (customId === "cp_toggle") {
        const config = await getConfig(guild.id);
        await updateConfig(guild.id, { $set: { enabled: !config.enabled } });
        await refreshPanel(client, interaction, guild);
        return true;
    }
    if (customId === "cp_channel_clear") {
        await updateConfig(guild.id, { $set: { channelId: null } });
        await refreshPanel(client, interaction, guild);
        return true;
    }
    if (customId === "cp_channel" && interaction.isChannelSelectMenu()) {
        const channelId = interaction.values[0];
        const channel = guild.channels.cache.get(channelId) ?? (await guild.channels.fetch(channelId).catch(() => null));
        if (!channel || !channel.isTextBased() || channel.isDMBased()) {
            await interaction.reply({ content: "> *Le salon doit être un salon textuel du serveur.*", flags: MessageFlags.Ephemeral });
            return true;
        }
        await updateConfig(guild.id, { $set: { channelId } });
        await refreshPanel(client, interaction, guild);
        return true;
    }
    if (customId === "cp_role_clear") {
        await updateConfig(guild.id, { $set: { roleId: null } });
        await refreshPanel(client, interaction, guild);
        return true;
    }
    if (customId === "cp_role" && interaction.isRoleSelectMenu()) {
        const roleId = interaction.values[0];
        if (roleId === guild.id) {
            await interaction.reply({ content: "> *Le rôle @everyone ne peut pas être utilisé.*", flags: MessageFlags.Ephemeral });
            return true;
        }
        await updateConfig(guild.id, { $set: { roleId } });
        await refreshPanel(client, interaction, guild);
        return true;
    }
    if (customId === "cp_kick") {
        const config = await getConfig(guild.id);
        await updateConfig(guild.id, { $set: { kickOnFail: !config.kickOnFail } });
        await refreshPanel(client, interaction, guild);
        return true;
    }
    if (customId === "cp_bots") {
        const config = await getConfig(guild.id);
        await updateConfig(guild.id, { $set: { ignoreBots: !config.ignoreBots } });
        await refreshPanel(client, interaction, guild);
        return true;
    }
    return false;
}
