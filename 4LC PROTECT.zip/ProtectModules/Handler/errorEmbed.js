import { BrandedEmbedBuilder as EmbedBuilder } from '../../BrandedEmbedBuilder.js';
import {  } from "discord.js";
import { appEmojiHeading } from "./appEmojis.js";
export default function buildErrorEmbed(title, desc) {
    const heading = /^\d{3}\s/.test(String(title)) ? title : title === "Maintenance" ? "503 Service Unavailable" : "500 Internal Server Error";
    const clean = String(desc || 'Une erreur est survenue.').split('\n')
        .map((line) => line.replace(/^\s*>\s*/, '').replace(/^\*+|\*+$/g, '').trim())
        .filter(Boolean)
        .map((line) => `> *${line}*`)
        .join('\n');
    const error = new EmbedBuilder()
        .setTitle(" ")
        .setDescription(`${appEmojiHeading("cancel", heading)}\n\n${clean}`)
        .setColor(0x000000);
    return error;
}

export function inferErrorCode(value) {
    const text = String(value || '').toLowerCase();
    if (/trop de|attendez encore|attendez 10|cooldown/.test(text)) return '429 Too Many Requests';
    if (/injoignable|indisponible|hors ligne|maintenance|secret de connexion|heartbeat/.test(text)) return '503 Service Unavailable';
    if (/introuvable|n.existe plus|inconnue?|non configuré/.test(text)) return '404 Not Found';
    if (/blacklist|quarantaine|accès (refusé|suspendu)|réservée? (au|à)|non autorisé/.test(text)) return '403 Forbidden';
    if (/permission|pas accès/.test(text)) return '401 Unauthorized';
    if (/déjà|fermé|expirée?|reste conservée|état incompatible/.test(text)) return '409 Conflict';
    if (/erreur|impossible|diagnostic/.test(text)) return '500 Internal Server Error';
    return '400 Bad Request';
}

export function looksLikeError(value) {
    return /^(❌|⚠️|🔴)|introuvable|invalide|impossible|indisponible|injoignable|permission|accès refusé|accès suspendu|blacklist|quarantaine|réservée?|trop de|attendez|déjà fermé|expirée?|une erreur|doit être|utilisation\s*:|exemples?\s*:/i.test(String(value || '').trim());
}

export function normalizeErrorPayload(payload) {
    const source = typeof payload === 'string' ? { content: payload } : payload;
    if (!source || source.embeds?.length || !looksLikeError(source.content)) return payload;
    const clean = String(source.content).replace(/^(❌|⚠️|🔴)\s*/, '').trim();
    return { ...source, content: undefined, embeds: [buildErrorEmbed(inferErrorCode(clean), clean)] };
}

export function installErrorNormalizer(target) {
    for (const method of ['reply', 'followUp', 'editReply', 'update']) {
        if (typeof target?.[method] !== 'function') continue;
        const original = target[method].bind(target);
        target[method] = (payload) => original(normalizeErrorPayload(payload));
    }
}
