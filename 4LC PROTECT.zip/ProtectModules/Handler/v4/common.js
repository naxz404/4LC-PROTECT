import { isGlobalOwner } from '../../../Owners.js';
import { BrandedEmbedBuilder as EmbedBuilder } from '../../../BrandedEmbedBuilder.js';
import { MessageFlags } from 'discord.js';
import { captureError } from './observability.js';
import { iconForTitle } from '../embedTheme.js';
export function black(title, body) {
    const text = String(body || '—').trim();
    const compact = !text.includes('\n') && text.length <= 180 ? `> *${text}*` : text;
    return new EmbedBuilder().setColor(0x000000).setTitle(' ').setDescription(`# \`${iconForTitle(title)}\` 〃 ${String(title).slice(0,220)}\n\n${compact}`.slice(0,4000));
}
export function payload(title, body) { return { embeds: [black(title, body)], allowedMentions: { parse: [] } }; }
export async function reply(target, title, body) {
    const p = payload(title, body);
    if (target.deferred || target.replied) return target.editReply(p);
    return target.reply(target.user ? { ...p, flags: MessageFlags.Ephemeral } : p);
}
export function fail(text) { const e = Error(text); e.userMessage = text; throw e; }
export const idOf = v => /^(?:<[@#]!?&?)?(\d{17,22})>?$/.exec(v || '')?.[1];
export function integer(v, min, max) { const n=Number(v); if (!/^\d+$/.test(String(v)) || !Number.isSafeInteger(n) || n<min || n>max) fail(`Nombre attendu entre ${min} et ${max}.`); return n; }
export function time(v, min=1000, max=365*86400000) {
    const m=/^(\d+)(s|m|h|d)$/.exec(v || ''); const n=m ? Number(m[1])*{s:1000,m:60000,h:3600000,d:86400000}[m[2]] : NaN;
    if (!Number.isSafeInteger(n)||n<min||n>max) fail(`Durée attendue (10s, 5m, 1h, 7d), entre ${min/1000} et ${max/1000} secondes.`); return n;
}
export function command(spec, run) {
    return { permissions: ['ManageGuild'], aliases: [], category: 'utils', slashRegister: false, ...spec,
        async execute(client,m,args=[]) {
            try {
                if (!m.guild) fail('Cette commande doit être utilisée dans un serveur.');
                if (!isGlobalOwner(m.author.id) && !m.member?.permissions?.has(spec.permissions || ['ManageGuild'])) fail('Permissions insuffisantes.');
                return await run(client,m,args);
            } catch(e) { const ref=e.userMessage ? null : captureError(e, spec.name, m.guild?.id); return reply(m,'Action impossible',e.userMessage || `Vérifie les permissions du bot. Diagnostic : ${ref}`); }
        } };
}
