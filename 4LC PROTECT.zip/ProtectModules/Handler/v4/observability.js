import { randomBytes } from 'node:crypto';
import config from '../config.js';
import { state, change } from './store.js';
export function clean(value) {
    let s=String(value ?? '').replace(/https:\/\/(?:\w+\.)?(?:discord(?:app)?\.com)\/api(?:\/v\d+)?\/webhooks\/[^\s"'<>]+/gi,'[webhook masqué]')
        .replace(/[A-Za-z0-9_-]{20,}\.[A-Za-z0-9_-]{6,}\.[A-Za-z0-9_-]{20,}/g,'[token masqué]');
    if (config.token) s=s.split(config.token).join('[token masqué]'); return s.slice(0,1800);
}
export function captureError(error, source='runtime', guildId=null) {
    const id=`ERR-${randomBytes(4).toString('hex').toUpperCase()}`;
    try { change(s => { s.errors.push({ id, at: Date.now(), source: clean(source), guildId, message: clean(error?.message || error), stack: clean(error?.stack || '') }); s.errors=s.errors.slice(-300); }); } catch { console.error(`[${id}] Journal indisponible.`); }
    return id;
}
export function audit(userId, action, detail='', guildId=null) {
    change(s => { s.audit.push({ at: Date.now(), userId, action, detail: clean(detail), guildId }); s.audit=s.audit.slice(-2000); });
}
export const MAINTENANCE_ALWAYS_AVAILABLE = new Set(['help', 'contact']);
export function maintenanceReason(userId, commandName, component=false, category=null) {
    if(config.ownerId.includes(userId)) return null;
    const m=state().maintenance;
    if (!m || (m.until && m.until<=Date.now())) return null;
    // L'aide et le contact avec le support doivent rester accessibles même
    // lorsque la maintenance cible toutes les commandes. Cela inclut les
    // boutons, menus et formulaires rattachés à +contact.
    if (MAINTENANCE_ALWAYS_AVAILABLE.has(commandName)) return null;
    if (m.commands?.includes('all')) return m.reason || 'INDISPONIBLE';
    if (m.commands?.includes(commandName) || (category && m.categories?.includes(category)) || (component && m.commands?.includes('interactions'))) return m.reason || 'INDISPONIBLE';
    return null;
}
export function componentCommand(id='') {
    if (/^(tk_|ta:)/.test(id)) return 'ticket';
    if (id.startsWith('rr:')) return 'rolespanel';
    if (id.startsWith('tv:')) return 'tempvoice';
    if (id.startsWith('backup:')) return 'backup';
    if (id.startsWith('cp_')) return 'captcha';
    if (id.startsWith('contact_')) return 'contact';
    return 'interactions';
}
let installed=false;
export function installErrorCapture() {
    if(installed)return;installed=true;
    const original=console.error.bind(console);let recording=false;
    console.error=(...args)=>{
        const message=args.map(v=>v instanceof Error?v.message:typeof v==='string'?v:'[objet diagnostic]').join(' ');
        if(recording)return original(clean(message));
        recording=true;
        try {const id=captureError(Error(message),'console');original(`[${id}] ${clean(message)}`);}finally{recording=false;}
    };
}
