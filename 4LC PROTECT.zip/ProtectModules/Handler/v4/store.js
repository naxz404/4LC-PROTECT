import { existsSync, mkdirSync, readFileSync, writeFileSync, renameSync } from 'node:fs';
import { join } from 'node:path';
import config from '../config.js';
const file = join(config.dataDir, 'features-v4.json');
let cache;
export function state() {
    if (!cache){try{cache=existsSync(file)?JSON.parse(readFileSync(file,'utf8')):{guilds:{},errors:[],audit:[],maintenance:null};}catch(error){try{renameSync(file,`${file}.corrupt-${Date.now()}`);}catch{}console.error('[V4] Stockage endommagé sauvegardé à part :',error.message);cache={guilds:{},errors:[],audit:[],maintenance:null};}}
    cache.guilds||={};cache.errors||=[];cache.audit||=[];
    return cache;
}
export function change(fn) {
    const next = structuredClone(state()); const result = fn(next);
    mkdirSync(config.dataDir, { recursive: true });
    writeFileSync(`${file}.tmp`, JSON.stringify(next, null, 2), { mode: 0o600 });
    renameSync(`${file}.tmp`, file); cache = next; return result;
}
export function defaults() {
    return { raid: { enabled: false, count: 10, windowMs: 10000, durationMs: 600000, level: 3, active: null, alert: null },
        autoBackup: { enabled: false, intervalMs: 86400000, keep: 7, last: 0 }, panic: null, verification: null, whitelist: {},
        warnings: { enabled: false, expirationMs: 0, rules: [], processed: {} },
        tickets: { form: [], reminderMs: 0, closeMs: 0, rating: false, records: {} },
        securityPlus: { intelligentRaid: true, progressiveSpam: true, phishing: true, suspiciousAccounts: true, joinBurstCount: 8, joinWindowMs: 10000, temporaryWhitelist: {} },
        supervision: { enabled: false, responsibleId: null, commands: ['ban','kick','timeout','mute','tempban','tempmute','purge'], pending: {} },
        setupAssistant: { completed: [], lastCheckAt: 0 },
        rolePanels: {}, voice: { triggers: {}, rooms: {} }, permissions: {} };
}
export function settings(id) {
    const raw = state().guilds[id] || {}, d = defaults();
    return Object.fromEntries(Object.entries(d).map(([k,v]) => [k, v && typeof v === 'object' ? { ...v, ...raw[k] } : raw[k] ?? v]));
}
export function update(id, fn) { return change(s => { s.guilds[id] = settings(id); return fn(s.guilds[id]); }); }
const locks = new Map();
export async function serial(key, fn) {
    const old = locks.get(key) || Promise.resolve();
    const task = old.catch(() => {}).then(fn); locks.set(key, task);
    try { return await task; } finally { if (locks.get(key) === task) locks.delete(key); }
}
