import { isGlobalOwner } from '../../../Owners.js';
import { randomBytes } from 'node:crypto';
import { ActionRowBuilder, ButtonBuilder, ButtonStyle, StringSelectMenuBuilder, ModalBuilder, TextInputBuilder, TextInputStyle, MessageFlags } from 'discord.js';
import { settings, update, serial } from './store.js';
import { command, reply, payload, time, fail } from './common.js';
import { captureError } from './observability.js';
import { TicketRecords, getConfig } from '../tickets/schema.js';
const forms=new Map();
const PRIORITIES=['low','normal','high'];
export async function showTicketForm(interaction,categoryId) {
 const questions=settings(interaction.guild.id).tickets.form;if(!questions.length) return false;
 for(const [id,v] of forms) if(v.until<Date.now()) forms.delete(id);
 if(forms.size>=10000) fail('Trop de formulaires ouverts, réessaie dans quelques minutes.');
 const id=randomBytes(8).toString('hex');forms.set(id,{guildId:interaction.guild.id,userId:interaction.user.id,categoryId,questions,until:Date.now()+600000});
 await interaction.showModal(new ModalBuilder().setCustomId(`ta:form:${id}`).setTitle('Ouvrir un ticket').addComponents(questions.map((q,n)=>new ActionRowBuilder().addComponents(new TextInputBuilder().setCustomId(`q${n}`).setLabel(q).setStyle(TextInputStyle.Paragraph).setMaxLength(700).setRequired(true)))));
 return true;
}
export async function ticketOpened(client,guild,channel,record,answers) {
 update(guild.id,s=>{s.tickets.records[channel.id]={userId:record.userId,priority:'normal',lastActivity:Date.now(),waitingSince:Date.now(),reminded:false,rating:null,createdAt:Date.now()};});
 const text=(answers||[]).map(a=>`**${a.question}**\n${a.answer}`).join('\n\n');
 await channel.send({...payload('Suivi du ticket',text||'Priorité : normale. Le staff peut la modifier ci-dessous.'),components:[new ActionRowBuilder().addComponents(new StringSelectMenuBuilder().setCustomId('ta:priority').setPlaceholder('Priorité du ticket • staff').addOptions([{label:'Basse',value:'low'},{label:'Normale',value:'normal'},{label:'Haute',value:'high'}]))]}).catch(e=>captureError(e,'ticket-form-message',guild.id));
}
async function staff(guild,record,userId) {
 const member=await guild.members.fetch(userId).catch(()=>null);if(!member) return false;
 const cfg=await getConfig(guild.id),category=cfg.categories.find(c=>c.id===record.categoryId);
 return isGlobalOwner(member.id) || member.permissions.has('ManageGuild')||!!category?.staffRoleIds.some(id=>member.roles.cache.has(id));
}
export async function ticketMessage(client,m) {
 if(!m.guild||m.author.bot) return;
 await serial(`ticket-life:${m.channel.id}`,async()=>{
  const data=settings(m.guild.id).tickets.records[m.channel.id];
  if(!data) return;
  const record=await TicketRecords.findOne({channelId:m.channel.id,guildId:m.guild.id,closedAt:null}).lean();if(!record) return;
  const isStaff=await staff(m.guild,record,m.author.id);
  update(m.guild.id,s=>{const r=s.tickets.records[m.channel.id];r.lastActivity=Date.now();if(isStaff){r.waitingSince=null;r.reminded=false;}else if(m.author.id===record.userId&&!r.waitingSince){r.waitingSince=Date.now();r.reminded=false;}});
 });
}
export async function offerRating(client,guild,record) {
 const cfg=settings(guild.id).tickets;if(!cfg.rating) return;
 const token=randomBytes(8).toString('hex');
 update(guild.id,s=>{s.tickets.records[record.channelId] ||= {userId:record.userId,priority:'normal'};s.tickets.records[record.channelId].rating={token,expires:Date.now()+7*86400000,value:null};});
 const user=await client.users.fetch(record.userId).catch(()=>null);if(!user)return;
 await user.send({...payload('Évaluation du support',`Ton ticket #${record.number} sur **${guild.name}** est fermé. Quelle note donnes-tu au support ?`),components:[new ActionRowBuilder().addComponents(...[1,2,3,4,5].map(n=>new ButtonBuilder().setCustomId(`ta:rating:${guild.id}:${record.channelId}:${token}:${n}`).setLabel(`${n}/5`).setStyle(ButtonStyle.Secondary)))]}).catch(e=>captureError(e,'ticket-rating-dm',guild.id));
}
export async function handleAdvancedTickets(client,i) {
 if(!i.customId?.startsWith('ta:')) return false;
 try {
  const [,op,...parts]=i.customId.split(':');
  if(op==='form'&&i.isModalSubmit()) {
   const form=forms.get(parts[0]);if(!form||form.guildId!==i.guildId||form.userId!==i.user.id||form.until<Date.now()) fail('Formulaire expiré. Rouvre un ticket depuis le panneau.');
   forms.delete(parts[0]);const answers=form.questions.map((question,n)=>({question,answer:i.fields.getTextInputValue(`q${n}`).trim()}));
   const {openTicket}=await import('../tickets/engine.js');
   await openTicket(client,i,form.categoryId,answers);return true;
  }
  if(op==='rating'&&i.isButton()) {
   const [guildId,channelId,token,n]=parts;const r=settings(guildId).tickets.records[channelId];
   if(!r||r.userId!==i.user.id||r.rating?.token!==token||r.rating.expires<Date.now()||r.rating.value!=null||!/^[1-5]$/.test(n)) fail('Évaluation expirée, déjà envoyée ou réservée au créateur du ticket.');
   const record=await TicketRecords.findOne({guildId,channelId}).lean();if(!record?.closedAt) fail('Le ticket est actuellement ouvert.');
   // No await between the final read and write: simultaneous clicks cannot vote twice.
   if(settings(guildId).tickets.records[channelId].rating.value!=null) fail('Note déjà enregistrée.');
   update(guildId,s=>{s.tickets.records[channelId].rating.value=Number(n);});
   await i.update({...payload('Merci !',`Ta note de ${n}/5 a été enregistrée.`),components:[]});
   const {sendTicketsLog}=await import('../tickets/engine.js');await sendTicketsLog(client,guildId,`Évaluation du ticket #${record.number} : ${n}/5`);return true;
  }
  if(op==='priority'&&i.isStringSelectMenu()) {
   await i.deferReply({flags:MessageFlags.Ephemeral});
   if(!i.guild) fail('Ticket introuvable.');const record=await TicketRecords.findOne({guildId:i.guild.id,channelId:i.channelId,closedAt:null}).lean();
   if(!record||!await staff(i.guild,record,i.user.id)) fail('Seul le staff de ce ticket peut changer la priorité.');
   const priority=i.values[0];if(!PRIORITIES.includes(priority)) fail('Priorité invalide.');
   update(i.guild.id,s=>{s.tickets.records[i.channelId] ||= {userId:record.userId,lastActivity:Date.now(),waitingSince:Date.now()};s.tickets.records[i.channelId].priority=priority;});
   const {sendTicketsLog}=await import('../tickets/engine.js');await sendTicketsLog(client,i.guild.id,`Priorité ticket #${record.number} : ${priority} • ${i.user.id}`);
   await reply(i,'Priorité modifiée',priority);return true;
  }
  fail('Interaction de ticket invalide.');
 }catch(e){const ref=e.userMessage?null:captureError(e,'ticket-advanced',i.guildId);await reply(i,'Action impossible',e.userMessage||`Diagnostic : ${ref}`);}
 return true;
}
export const advancedTicketCommand=command({name:'ticketadvanced',aliases:['ticketplus'],category:'tickets',description:'Formulaires, priorités, rappels, fermeture automatique et notes de support.',usage:'form question | question / form off / reminder 30m|off / autoclose 2d|off / rating on|off / status',handleInteraction:handleAdvancedTickets},async(client,m,a)=>{
 const [op,value]=a;
 if(op==='form') {const questions=value==='off'?[]:a.slice(1).join(' ').split('|').map(x=>x.trim());if(questions.length>5||questions.some(q=>!q||q.length>45)) fail('1 à 5 questions, 45 caractères maximum par question, séparées par |.');update(m.guild.id,s=>{s.tickets.form=questions;});}
 else if(['reminder','autoclose'].includes(op)) {const ms=value==='off'?0:time(value,60000,90*86400000);update(m.guild.id,s=>{s.tickets[op==='reminder'?'reminderMs':'closeMs']=ms;});}
 else if(op==='rating') {if(!['on','off'].includes(value)) fail('Utilise rating on ou off.');update(m.guild.id,s=>{s.tickets.rating=value==='on';});}
 else if(a.length&&!['status','help'].includes(op)) fail('Utilise +ticketadvanced help.');
 const s=settings(m.guild.id).tickets;
 const notes=Object.values(s.records).map(r=>r.rating?.value).filter(n=>n!=null);
 return reply(m,'Tickets avancés',`> *Formulaires, rappels et fermeture automatique des tickets.*\n\n**Configuration actuelle**\n> **Questions** · ${s.form.join(' / ')||'Aucune'}\n> **Rappel au staff** · ${s.reminderMs?s.reminderMs/60000+' minutes':'Désactivé'}\n> **Fermeture automatique** · ${s.closeMs?s.closeMs/60000+' minutes':'Désactivée'}\n> **Évaluation** · ${s.rating?'Activée':'Désactivée'}\n> **Avis reçus** · ${notes.length}${notes.length?' — moyenne '+(notes.reduce((a,b)=>a+b,0)/notes.length).toFixed(1)+'/5':''}\n\n**Commandes rapides**\n> \`+ticketadvanced form Sujet ? | Décris ta demande\`\n> \`+ticketadvanced reminder 30m\`\n> \`+ticketadvanced autoclose 2d\`\n> \`+ticketadvanced rating on\`\n\n-# La priorité se règle directement depuis le menu du ticket.`);
});
export async function ticketsTick(client,guild) {
 const cfg=settings(guild.id).tickets;
 if(!cfg.closeMs&&!cfg.reminderMs) return;
 const all=await TicketRecords.find({guildId:guild.id,closedAt:null}).lean();
 for(const base of all) await serial(`ticket-life:${base.channelId}`,async()=>{
  let channel;try{channel=await guild.channels.fetch(base.channelId);}catch(e){if(e.code===10003){await TicketRecords.updateOne({channelId:base.channelId},{$set:{closedAt:Date.now()}});return;}throw e;}
  if(!channel) return;
  if(!settings(guild.id).tickets.records[base.channelId]) {update(guild.id,s=>{s.tickets.records[base.channelId]={userId:base.userId,priority:'normal',lastActivity:Date.now(),waitingSince:Date.now(),reminded:false};});return;}
  let r=settings(guild.id).tickets.records[base.channelId];
  // Reconcile the latest human message after downtime before deciding inactivity.
  const recent=await channel.messages.fetch({limit:30});
  const last=recent.filter(m=>!m.author.bot).sort((a,b)=>b.createdTimestamp-a.createdTimestamp).first();
  if(last&&last.createdTimestamp>r.lastActivity) {
   const isStaff=await staff(guild,base,last.author.id);
   update(guild.id,s=>{const item=s.tickets.records[base.channelId];item.lastActivity=last.createdTimestamp;if(isStaff){item.waitingSince=null;item.reminded=false;}else if(last.author.id===base.userId&&!item.waitingSince){item.waitingSince=last.createdTimestamp;item.reminded=false;}});r=settings(guild.id).tickets.records[base.channelId];
  }
  if(cfg.closeMs&&Date.now()-r.lastActivity>=cfg.closeMs) {
   const {closeTicket}=await import('../tickets/engine.js');
   await closeTicket(client,{guild,channel,user:client.user,automatic:true,inGuild:()=>true,isRepliable:()=>false,isMessageComponent:()=>false});
  }else if(cfg.reminderMs&&r.waitingSince&&!r.reminded&&Date.now()-r.waitingSince>=cfg.reminderMs) {
   const category=(await getConfig(guild.id)).categories.find(c=>c.id===base.categoryId);const roles=category?.staffRoleIds||[];
   await channel.send({...payload('Ticket en attente',`Priorité : ${r.priority}\nLa demande attend une réponse du staff. ${roles.map(id=>`<@&${id}>`).join(' ')}`),allowedMentions:{parse:[],roles}});
   update(guild.id,s=>{s.tickets.records[base.channelId].reminded=true;});
  }
 });
}
