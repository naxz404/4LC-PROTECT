// Remplacement local de mongoose : mêmes méthodes (find, findOne, findOneAndUpdate,
// create, updateOne, deleteOne, aggregate...) mais stockage dans des fichiers JSON
// sous data/db/<collection>.json au lieu d'une vraie base MongoDB.
import { readFileSync, writeFileSync, existsSync, mkdirSync, renameSync } from "node:fs";
import { dirname, resolve } from "node:path";
import { randomUUID } from "node:crypto";

const DB_DIR = resolve(process.cwd(), "data", "4lc-support", "db");
const stores = new Map();

function filePath(name) {
    return resolve(DB_DIR, `${name}.json`);
}
function loadStore(name) {
    if (stores.has(name)) return stores.get(name);
    const fp = filePath(name);
    let docs = [];
    if (existsSync(fp)) {
        try {
            const parsed = JSON.parse(readFileSync(fp, "utf8"));
            if (!Array.isArray(parsed)) throw new Error("Collection JSON invalide");
            docs = parsed;
        }
        catch (error) {
            throw new Error(`Stockage JSON illisible : ${name}. Restaurez le fichier avant de redémarrer.`, { cause: error });
        }
    }
    stores.set(name, docs);
    return docs;
}
function saveStore(name) {
    const fp = filePath(name);
    mkdirSync(dirname(fp), { recursive: true });
    writeFileSync(`${fp}.tmp`, JSON.stringify(stores.get(name) ?? [], null, 2));
    renameSync(`${fp}.tmp`, fp);
}
function clone(v) {
    return v === undefined ? v : JSON.parse(JSON.stringify(v));
}
function getPath(obj, path) {
    if (obj == null) return undefined;
    return path.split(".").reduce((o, k) => (o == null ? undefined : o[k]), obj);
}
function setPath(obj, path, value) {
    const parts = path.split(".");
    let cur = obj;
    for (let i = 0; i < parts.length - 1; i++) {
        const k = parts[i];
        if (typeof cur[k] !== "object" || cur[k] === null) cur[k] = {};
        cur = cur[k];
    }
    cur[parts[parts.length - 1]] = value;
}
function unsetPath(obj, path) {
    const parts = path.split(".");
    let cur = obj;
    for (let i = 0; i < parts.length - 1; i++) {
        cur = cur?.[parts[i]];
        if (cur == null) return;
    }
    delete cur[parts[parts.length - 1]];
}
function deepEqual(a, b) {
    return JSON.stringify(a) === JSON.stringify(b);
}
function matchOperator(actual, op, val) {
    const values = Array.isArray(actual) ? actual : [actual];
    switch (op) {
        case "$gt": return actual > val;
        case "$gte": return actual >= val;
        case "$lt": return actual < val;
        case "$lte": return actual <= val;
        case "$ne": return Array.isArray(actual) ? !actual.some((item) => deepEqual(item, val)) : !deepEqual(actual, val);
        case "$eq": return Array.isArray(actual) ? actual.some((item) => deepEqual(item, val)) : deepEqual(actual, val);
        case "$in": return Array.isArray(val) && values.some((item) => val.some((candidate) => deepEqual(item, candidate)));
        case "$nin": return Array.isArray(val) && values.every((item) => !val.some((candidate) => deepEqual(item, candidate)));
        case "$exists": return (actual !== undefined) === !!val;
        default: return true;
    }
}
function matchValue(actual, expected) {
    if (expected && typeof expected === "object" && !Array.isArray(expected)) {
        return Object.entries(expected).every(([op, val]) => matchOperator(actual, op, val));
    }
    if (Array.isArray(actual) && !Array.isArray(expected)) {
        return actual.some((item) => deepEqual(item, expected));
    }
    return deepEqual(actual, expected);
}
function matchesFilter(doc, filter) {
    if (!filter) return true;
    return Object.entries(filter).every(([key, expected]) => {
        if (key === "$or") return Array.isArray(expected) && expected.some((branch) => matchesFilter(doc, branch));
        if (key === "$and") return Array.isArray(expected) && expected.every((branch) => matchesFilter(doc, branch));
        if (key === "$nor") return Array.isArray(expected) && expected.every((branch) => !matchesFilter(doc, branch));
        if (key === "$not") return !matchesFilter(doc, expected);
        return matchValue(getPath(doc, key), expected);
    });
}
function ensureVirtualId(doc) {
    if (doc && typeof doc === "object") {
        if (doc._id == null) doc._id = randomUUID();
        if (doc.id == null) doc.id = doc._id;
    }
    return doc;
}
function applyUpdate(doc, update) {
    const opKeys = Object.keys(update).filter((k) => k.startsWith("$"));
    if (opKeys.length === 0) {
        Object.assign(doc, clone(update));
        return doc;
    }
    for (const op of opKeys) {
        const fields = update[op];
        if (op === "$set") {
            for (const [k, v] of Object.entries(fields)) setPath(doc, k, clone(v));
        }
        else if (op === "$unset") {
            for (const k of Object.keys(fields)) unsetPath(doc, k);
        }
        else if (op === "$inc") {
            for (const [k, v] of Object.entries(fields)) setPath(doc, k, (getPath(doc, k) ?? 0) + v);
        }
        else if (op === "$push") {
            for (const [k, v] of Object.entries(fields)) {
                const arr = getPath(doc, k) ?? [];
                if (v && typeof v === "object" && Array.isArray(v.$each)) arr.push(...clone(v.$each));
                else arr.push(clone(v));
                setPath(doc, k, arr);
            }
        }
        else if (op === "$pull") {
            for (const [k, v] of Object.entries(fields)) {
                const arr = getPath(doc, k) ?? [];
                setPath(doc, k, arr.filter((item) => !matchValue(item, v)));
            }
        }
        else if (op === "$addToSet") {
            for (const [k, v] of Object.entries(fields)) {
                const arr = getPath(doc, k) ?? [];
                const values = v && typeof v === "object" && !Array.isArray(v) && Array.isArray(v.$each) ? v.$each : [v];
                for (const item of values) {
                    const already = arr.some((existing) => JSON.stringify(existing) === JSON.stringify(item));
                    if (!already) arr.push(clone(item));
                }
                setPath(doc, k, arr);
            }
        }
        else if (op === "$pullAll") {
            for (const [k, v] of Object.entries(fields)) {
                const arr = getPath(doc, k) ?? [];
                const toRemove = Array.isArray(v) ? v : [v];
                setPath(doc, k, arr.filter((item) => !toRemove.some((r) => JSON.stringify(r) === JSON.stringify(item))));
            }
        }
        // $setOnInsert géré séparément au moment de l'insertion, le reste est ignoré.
    }
    return doc;
}
function sortDocs(docs, spec) {
    const entries = Object.entries(spec || {});
    if (!entries.length) return docs;
    return [...docs].sort((a, b) => {
        for (const [key, dir] of entries) {
            const av = getPath(a, key);
            const bv = getPath(b, key);
            if (av < bv) return dir < 0 ? 1 : -1;
            if (av > bv) return dir < 0 ? -1 : 1;
        }
        return 0;
    });
}
function extractEquality(filter) {
    const out = {};
    for (const [k, v] of Object.entries(filter || {})) {
        if (k.startsWith("$")) continue;
        if (v !== null && typeof v === "object" && !Array.isArray(v)) continue;
        out[k] = clone(v);
    }
    return out;
}
function evalExpr(expr, doc) {
    if (Array.isArray(expr)) return expr.map((e) => evalExpr(e, doc));
    if (expr && typeof expr === "object") {
        const entry = Object.entries(expr)[0];
        if (!entry) return expr;
        const [op, val] = entry;
        const args = evalExpr(val, doc);
        switch (op) {
            case "$add": return args.reduce((a, b) => a + b, 0);
            case "$subtract": return args[0] - args[1];
            case "$multiply": return args.reduce((a, b) => a * b, 1);
            case "$divide": return args[0] / args[1];
            case "$max": return Math.max(...args);
            case "$min": return Math.min(...args);
            default: return undefined;
        }
    }
    if (typeof expr === "string" && expr.startsWith("$")) return getPath(doc, expr.slice(1));
    return expr;
}

class Query {
    constructor(run) {
        this._run = run;
        this._sort = null;
        this._limit = null;
        this._skip = null;
    }
    lean() { return this; }
    select() { return this; }
    populate() { return this; }
    sort(spec) { this._sort = spec; return this; }
    limit(n) { this._limit = n; return this; }
    skip(n) { this._skip = n; return this; }
    _resolve() {
        let result = this._run();
        if (Array.isArray(result)) {
            if (this._sort) result = sortDocs(result, this._sort);
            if (this._skip) result = result.slice(this._skip);
            if (this._limit != null) result = result.slice(0, this._limit);
        }
        return result;
    }
    then(onFulfilled, onRejected) {
        return Promise.resolve().then(() => this._resolve()).then(onFulfilled, onRejected);
    }
    catch(onRejected) { return this.then(undefined, onRejected); }
    exec() { return this.then(); }
}

export class Schema {
    constructor(definition = {}, options = {}) {
        this.paths = { ...definition };
        this.options = options;
        this._pres = {};
    }
    add(definition) { Object.assign(this.paths, definition); return this; }
    pre(hook, fn) { (this._pres[hook] ??= []).push(fn); return this; }
    index() { return this; }
    set() { return this; }
    virtual() { return { get() { return this; }, set() { return this; } }; }
}
// Compat avec les schémas écrits pour mongoose qui référencent Schema.Types.* comme marqueur de type.
Schema.Types = {
    Mixed: "Mixed",
    ObjectId: "ObjectId",
    String,
    Number,
    Boolean,
    Date,
    Array,
    Map,
    Decimal128: "Decimal128",
};

function resolveDefault(def) {
    if (def == null || typeof def !== "object") return undefined;
    const d = def.default;
    if (typeof d === "function") return d();
    return clone(d);
}
function applyDefaults(doc, schema) {
    for (const [key, def] of Object.entries(schema?.paths ?? {})) {
        if (doc[key] === undefined) {
            const value = resolveDefault(def);
            if (value !== undefined) doc[key] = value;
        }
    }
    return doc;
}
function applyTimestamps(doc, schema, { create = false } = {}) {
    if (!schema?.options?.timestamps) return doc;
    const now = Date.now();
    if (create && doc.createdAt === undefined) doc.createdAt = now;
    doc.updatedAt = now;
    return doc;
}
function runHooksSync(schema, hookName, ctx, arg) {
    const hooks = schema?._pres?.[hookName];
    if (!hooks) return;
    for (const fn of hooks) fn.call(ctx, arg);
}

export function model(name, schema, collectionName) {
    const collName = collectionName || name.toLowerCase();
    const allDocs = () => loadStore(collName);
    const persist = () => saveStore(collName);
    const makeCtx = (ref) => ({
        getFilter: () => ref.value,
        setQuery: (f) => { ref.value = f; },
    });
    const withHook = (hookName, filter) => {
        const ref = { value: { ...filter } };
        runHooksSync(schema, hookName, makeCtx(ref));
        return ref.value;
    };
    const Model = {
        modelName: name,
        schema,
        find(filter = {}) {
            const f = withHook("find", filter);
            return new Query(() => allDocs().filter((d) => matchesFilter(d, f)).map(clone));
        },
        findOne(filter = {}) {
            const f = withHook("findOne", filter);
            return new Query(() => {
                const found = allDocs().find((d) => matchesFilter(d, f));
                return found ? clone(found) : null;
            });
        },
        findById(id) {
            return Model.findOne({ _id: id });
        },
        async countDocuments(filter = {}) {
            const f = withHook("countDocuments", filter);
            return allDocs().filter((d) => matchesFilter(d, f)).length;
        },
        async exists(filter = {}) {
            const f = withHook("exists", filter);
            const found = allDocs().some((d) => matchesFilter(d, f));
            return found ? { _id: "exists" } : null;
        },
        async create(input) {
            const items = Array.isArray(input) ? input : [input];
            const created = [];
            for (const item of items) {
                const doc = clone(item) ?? {};
                applyDefaults(doc, schema);
                applyTimestamps(doc, schema, { create: true });
                ensureVirtualId(doc);
                runHooksSync(schema, "save", { get: (k) => doc[k], set: (k, v) => { doc[k] = v; } });
                allDocs().push(doc);
                created.push(clone(doc));
            }
            persist();
            return Array.isArray(input) ? created : created[0];
        },
        findOneAndUpdate(filter = {}, update = {}, options = {}) {
            const f = withHook("findOneAndUpdate", filter);
            return new Query(() => {
                const docs = allDocs();
                const idx = docs.findIndex((d) => matchesFilter(d, f));
                if (idx === -1) {
                    if (!options.upsert) return null;
                    const doc = { ...extractEquality(f) };
                    applyDefaults(doc, schema);
                    applyTimestamps(doc, schema, { create: true });
                    if (update.$setOnInsert) Object.assign(doc, clone(update.$setOnInsert));
                    applyUpdate(doc, update);
                    applyTimestamps(doc, schema, { create: true });
                    ensureVirtualId(doc);
                    docs.push(doc);
                    persist();
                    return options.new === false ? null : clone(doc);
                }
                const doc = docs[idx];
                const before = options.new === false ? clone(doc) : null;
                applyUpdate(doc, update);
                applyTimestamps(doc, schema);
                persist();
                return options.new === false ? before : clone(doc);
            });
        },
        findByIdAndUpdate(id, update, options) {
            return Model.findOneAndUpdate({ _id: id }, update, options);
        },
        async updateOne(filter = {}, update = {}, options = {}) {
            const f = withHook("updateOne", filter);
            const docs = allDocs();
            const idx = docs.findIndex((d) => matchesFilter(d, f));
            if (idx === -1) {
                if (options.upsert) {
                    const doc = { ...extractEquality(f) };
                    applyDefaults(doc, schema);
                    applyTimestamps(doc, schema, { create: true });
                    if (update.$setOnInsert) Object.assign(doc, clone(update.$setOnInsert));
                    applyUpdate(doc, update);
                    applyTimestamps(doc, schema, { create: true });
                    ensureVirtualId(doc);
                    docs.push(doc);
                    persist();
                    return { matchedCount: 0, modifiedCount: 0, upsertedCount: 1 };
                }
                return { matchedCount: 0, modifiedCount: 0, upsertedCount: 0 };
            }
            applyUpdate(docs[idx], update);
            applyTimestamps(docs[idx], schema);
            persist();
            return { matchedCount: 1, modifiedCount: 1, upsertedCount: 0 };
        },
        async updateMany(filter = {}, update = {}) {
            const f = withHook("updateMany", filter);
            const docs = allDocs().filter((d) => matchesFilter(d, f));
            for (const d of docs) { applyUpdate(d, update); applyTimestamps(d, schema); }
            persist();
            return { matchedCount: docs.length, modifiedCount: docs.length };
        },
        async deleteOne(filter = {}) {
            const f = withHook("deleteOne", filter);
            const docs = allDocs();
            const idx = docs.findIndex((d) => matchesFilter(d, f));
            if (idx === -1) return { deletedCount: 0 };
            docs.splice(idx, 1);
            persist();
            return { deletedCount: 1 };
        },
        async deleteMany(filter = {}) {
            const f = withHook("deleteMany", filter);
            const docs = allDocs();
            const before = docs.length;
            const kept = docs.filter((d) => !matchesFilter(d, f));
            stores.set(collName, kept);
            persist();
            return { deletedCount: before - kept.length };
        },
        async aggregate(pipeline = []) {
            let docs = allDocs()
                .filter((doc) => schema?._botScopeId == null || doc.botId === schema._botScopeId)
                .map(clone);
            for (const stage of pipeline) {
                const entry = Object.entries(stage)[0];
                if (!entry) continue;
                const [op, arg] = entry;
                if (op === "$match") docs = docs.filter((d) => matchesFilter(d, arg));
                else if (op === "$addFields") {
                    docs = docs.map((d) => {
                        const copy = clone(d);
                        for (const [k, expr] of Object.entries(arg)) copy[k] = evalExpr(expr, copy);
                        return copy;
                    });
                }
                else if (op === "$sort") docs = sortDocs(docs, arg);
                else if (op === "$limit") docs = docs.slice(0, arg);
                else if (op === "$skip") docs = docs.slice(arg);
                else if (op === "$count") docs = [{ [arg]: docs.length }];
                else if (op === "$project") {
                    docs = docs.map((d) => {
                        const copy = {};
                        for (const k of Object.keys(arg)) copy[k] = getPath(d, k);
                        return copy;
                    });
                }
            }
            return docs;
        },
    };
    return Model;
}

export default { Schema, model };
