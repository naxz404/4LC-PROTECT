import { Schema, model } from "../jsonDb.js";
import { applyBotScope, uniqueBotGuildIndex } from "../mongoScope.js";
export const MAX_CATEGORIES = 25;
export const MAX_CHANNEL_NAME_LENGTH = 90;
export const MAX_OPEN_TEXT_LENGTH = 2000;
export const MAX_PATTERN_LENGTH = 90;
export const TICKET_BUTTON_KEYS = ["rename", "addmember", "removemember"];
export const TICKET_BUTTON_LABELS = {
    rename: "Renommer",
    addmember: "Ajouter un membre",
    removemember: "Retirer un membre",
};
export function emptyEmbed() {
    return {
        title: "",
        description: "",
        color: null,
        imageUrl: null,
        thumbnailUrl: null,
        footer: "",
    };
}
export function defaultCategory(id) {
    return {
        id,
        label: "",
        categoryId: null,
        emoji: "🎫",
        channelNamePattern: "{ticketNumber}-{memberDisplayName}",
        openText: "",
        openEmbed: emptyEmbed(),
        staffRoleIds: [],
        mentionRoleIds: [],
    };
}
export function defaultConfig(guildId) {
    return {
        guildId,
        type: "button",
        claimEnabled: true,
        enabledButtons: [...TICKET_BUTTON_KEYS],
        requiredRoleIds: [],
        blacklistRoleIds: [],
        logsChannelId: null,
        embed: emptyEmbed(),
        categories: [],
        panelChannelId: null,
        panelMessageId: null,
        counter: 0,
    };
}
const embedSchema = new Schema({
    title: { type: String, default: "" },
    description: { type: String, default: "" },
    color: { type: String, default: null },
    imageUrl: { type: String, default: null },
    thumbnailUrl: { type: String, default: null },
    footer: { type: String, default: "" },
}, { _id: false });
const categorySchema = new Schema({
    label: { type: String, default: "" },
    id: { type: String, required: true },
    categoryId: { type: String, default: null },
    emoji: { type: String, default: "🎫" },
    channelNamePattern: { type: String, default: "{ticketNumber}-{memberDisplayName}" },
    openText: { type: String, default: "" },
    openEmbed: { type: embedSchema, default: () => ({}) },
    staffRoleIds: { type: [String], default: [] },
    mentionRoleIds: { type: [String], default: [] },
}, { _id: false });
const ticketsSchema = new Schema({
    guildId: { type: String, required: true, index: true },
    type: { type: String, enum: ["button", "select"], default: "button" },
    claimEnabled: { type: Boolean, default: true },
    enabledButtons: { type: [String], enum: TICKET_BUTTON_KEYS, default: () => [...TICKET_BUTTON_KEYS] },
    requiredRoleIds: { type: [String], default: [] },
    blacklistRoleIds: { type: [String], default: [] },
    logsChannelId: { type: String, default: null },
    embed: { type: embedSchema, default: () => ({}) },
    categories: { type: [categorySchema], default: [] },
    panelChannelId: { type: String, default: null },
    panelMessageId: { type: String, default: null },
    counter: { type: Number, default: 0 },
}, { timestamps: true });
applyBotScope(ticketsSchema);
uniqueBotGuildIndex(ticketsSchema);
export const Tickets = model("Tickets", ticketsSchema, "tickets");
const ticketRecordSchema = new Schema({
    guildId: { type: String, required: true, index: true },
    channelId: { type: String, required: true, unique: true, index: true },
    messageId: { type: String, default: null },
    userId: { type: String, required: true, index: true },
    categoryId: { type: String, required: true },
    number: { type: Number, required: true },
    claimedBy: { type: String, default: null },
    closedAt: { type: Number, default: null },
    createdAt: { type: Number, required: true },
    extraMemberIds: { type: [String], default: [] },
}, { timestamps: true });
applyBotScope(ticketRecordSchema);
export const TicketRecords = model("TicketRecords", ticketRecordSchema, "tickets_records");
function asBoolean(value, fallback) {
    return typeof value === "boolean" ? value : fallback;
}
function asString(value, fallback) {
    return typeof value === "string" ? value : fallback;
}
function asStringOrNull(value, fallback) {
    if (value === null)
        return null;
    return typeof value === "string" ? value : fallback;
}
function asStringArray(value) {
    if (!Array.isArray(value))
        return [];
    return [...new Set(value.filter((item) => typeof item === "string"))].slice(0, 25);
}
function asTicketButtonArray(value, fallback) {
    if (!Array.isArray(value))
        return fallback;
    const allowed = new Set(TICKET_BUTTON_KEYS);
    const filtered = value.filter((item) => typeof item === "string" && allowed.has(item));
    return [...new Set(filtered)];
}
function clampText(value, max) {
    return value.trim().slice(0, max);
}
export function clampPattern(value) {
    return clampText(value, MAX_PATTERN_LENGTH);
}
export function clampOpenText(value) {
    return clampText(value, MAX_OPEN_TEXT_LENGTH);
}
export function isValidHexColor(value) {
    return /^#[0-9a-fA-F]{6}$/.test(value.trim());
}
export function normalizeEmoji(value) {
    const trimmed = value.trim();
    if (!trimmed || trimmed.length > 16)
        return null;
    const stripped = trimmed.replace(/[\uFE0F\u200D]/g, "");
    for (const char of stripped) {
        if (!/\p{Extended_Pictographic}|\p{Emoji_Modifier}|\p{Emoji_Component}/u.test(char))
            return null;
    }
    return trimmed;
}
function normalizeEmbed(raw) {
    const color = asStringOrNull(raw?.color, null);
    return {
        title: asString(raw?.title, "").slice(0, 256),
        description: asString(raw?.description, "").slice(0, 4000),
        color: color && isValidHexColor(color) ? color.toLowerCase() : null,
        imageUrl: asStringOrNull(raw?.imageUrl, null),
        thumbnailUrl: asStringOrNull(raw?.thumbnailUrl, null),
        footer: asString(raw?.footer, "").slice(0, 256),
    };
}
function normalizeCategories(raw) {
    if (!Array.isArray(raw))
        return [];
    const seen = new Set();
    const out = [];
    for (const entry of raw) {
        if (!entry || typeof entry !== "object")
            continue;
        const record = entry;
        const id = typeof record.id === "string" ? record.id.slice(0, 32) : "";
        if (!id || seen.has(id))
            continue;
        seen.add(id);
        const rawOpenEmbed = typeof record.openEmbed === "object" && record.openEmbed !== null
            ? record.openEmbed
            : {};
        const openEmbed = normalizeEmbed(rawOpenEmbed);
        const legacyTitle = asString(record.embedTitle, "").trim();
        const legacyColor = asStringOrNull(record.embedColor, null);
        const legacyImage = asStringOrNull(record.embedImageUrl, null);
        const legacyThumb = asStringOrNull(record.embedThumbnailUrl, null);
        const legacyFooter = asString(record.embedFooter, "").trim();
        if (legacyTitle && !openEmbed.title)
            openEmbed.title = legacyTitle.slice(0, 256);
        if (legacyColor && isValidHexColor(legacyColor) && !openEmbed.color)
            openEmbed.color = legacyColor.toLowerCase();
        if (legacyImage && !openEmbed.imageUrl)
            openEmbed.imageUrl = legacyImage;
        if (legacyThumb && !openEmbed.thumbnailUrl)
            openEmbed.thumbnailUrl = legacyThumb;
        if (legacyFooter && !openEmbed.footer)
            openEmbed.footer = legacyFooter.slice(0, 200);
        const legacyOpenText = clampOpenText(asString(record.openText, ""));
        if (!openEmbed.description && legacyOpenText)
            openEmbed.description = legacyOpenText.slice(0, 4000);
        out.push({
            id,
            label: asString(record.label, "").slice(0, 80),
            categoryId: asStringOrNull(record.categoryId, null),
            emoji: normalizeEmoji(asString(record.emoji, "🎫")) ?? "🎫",
            channelNamePattern: clampPattern(asString(record.channelNamePattern, "{ticketNumber}")) || "{ticketNumber}",
            openText: legacyOpenText,
            openEmbed,
            staffRoleIds: asStringArray(record.staffRoleIds).slice(0, 10),
            mentionRoleIds: asStringArray(record.mentionRoleIds).slice(0, 10),
        });
    }
    return out.slice(0, MAX_CATEGORIES);
}
export function normalizeConfig(raw) {
    const guildId = typeof raw?.guildId === "string" ? raw.guildId : "";
    const defaults = defaultConfig(guildId);
    const rawRecord = (raw ?? {});
    const rawEmbed = (typeof rawRecord.embed === "object" && rawRecord.embed !== null ? rawRecord.embed : {});
    const type = rawRecord.type === "select" ? "select" : "button";
    return {
        guildId,
        type,
        claimEnabled: asBoolean(rawRecord.claimEnabled, defaults.claimEnabled),
        enabledButtons: asTicketButtonArray(rawRecord.enabledButtons, defaults.enabledButtons),
        requiredRoleIds: asStringArray(rawRecord.requiredRoleIds).slice(0, 1),
        blacklistRoleIds: asStringArray(rawRecord.blacklistRoleIds).slice(0, 10),
        logsChannelId: asStringOrNull(rawRecord.logsChannelId, defaults.logsChannelId),
        embed: normalizeEmbed(rawEmbed),
        categories: normalizeCategories(rawRecord.categories),
        panelChannelId: asStringOrNull(rawRecord.panelChannelId, defaults.panelChannelId),
        panelMessageId: asStringOrNull(rawRecord.panelMessageId, defaults.panelMessageId),
        counter: typeof rawRecord.counter === "number" && Number.isFinite(rawRecord.counter) && rawRecord.counter > 0
            ? Math.floor(rawRecord.counter)
            : defaults.counter,
    };
}
const CONFIG_CACHE_TTL = 5_000;
const cache = new Map();
export function invalidateConfig(guildId) {
    cache.delete(guildId);
}
export async function getConfig(guildId) {
    const hit = cache.get(guildId);
    if (hit && Date.now() - hit.ts < CONFIG_CACHE_TTL)
        return hit.config;
    const raw = await Tickets.findOne({ guildId }).lean();
    const config = normalizeConfig(raw ?? { guildId });
    cache.set(guildId, { config, ts: Date.now() });
    return config;
}
export async function updateConfig(guildId, update) {
    await Tickets.findOneAndUpdate({ guildId }, update, { upsert: true });
    invalidateConfig(guildId);
    return getConfig(guildId);
}
export async function nextTicketNumber(guildId) {
    invalidateConfig(guildId);
    const doc = await Tickets.findOneAndUpdate({ guildId }, { $inc: { counter: 1 } }, { upsert: true, new: true });
    return typeof doc?.counter === "number" && doc.counter > 0 ? Math.floor(doc.counter) : 1;
}
export function generateCategoryId() {
    return `c${Date.now().toString(36)}${Math.random().toString(36).slice(2, 8)}`;
}
