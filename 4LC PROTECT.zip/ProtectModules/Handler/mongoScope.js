import config from "../Handler/config.js";
const QUERY_METHODS = [
    "countDocuments",
    "deleteMany",
    "deleteOne",
    "exists",
    "find",
    "findOne",
    "findOneAndDelete",
    "findOneAndReplace",
    "findOneAndUpdate",
    "replaceOne",
    "updateMany",
    "updateOne",
];
function injectBotId() {
    const filter = this.getFilter();
    if (filter.botId == null) {
        this.setQuery({ ...filter, botId: config.botId });
    }
}
export function applyBotScope(schema) {
    schema.add({
        botId: { type: String, required: true, index: true, default: () => config.botId },
    });
    // Utilisé par le moteur JSON pour appliquer aussi la portée aux agrégations.
    schema._botScopeId = config.botId;
    for (const method of QUERY_METHODS) {
        schema.pre(method, injectBotId);
    }
    schema.pre("save", function () {
        if (!this.get("botId"))
            this.set("botId", config.botId);
    });
    schema.pre("insertMany", function (docs) {
        const list = Array.isArray(docs) ? docs : [docs];
        for (const doc of list) {
            if (!doc || typeof doc !== "object")
                continue;
            const record = doc;
            if (record.botId == null)
                record.botId = config.botId;
        }
    });
}
export function uniqueBotGuildIndex(schema) {
    schema.index({ botId: 1, guildId: 1 }, { unique: true });
}
export function uniqueBotGuildUserIndex(schema) {
    schema.index({ botId: 1, guildId: 1, userId: 1 }, { unique: true });
}
