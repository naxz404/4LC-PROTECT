import { APP_EMOJI_KEYS } from "./botConfig.js";
import { botRuntime } from "../Handler/config.js";
export { APP_EMOJI_KEYS };
export const APP_EMOJI_FALLBACK = {
    cancel: "❌",
    add: "➕",
    settings: "⚙️",
    power: "⚡",
    pin: "📌",
    people: "👥",
    loop: "🔄",
    file: "📁",
    cog: "⚙️",
    check: "✅",
};
function currentMap() {
    return botRuntime.raw.application_emojis ?? {};
}
export function appEmojiId(name) {
    const id = currentMap()[name];
    return id || null;
}
export function appEmoji(name) {
    const id = appEmojiId(name);
    return id ? { id } : undefined;
}
export function appEmojiTag(name) {
    const id = appEmojiId(name);
    return id ? `<:${name}:${id}>` : null;
}
/** Button / select accessory: `{ id }` when known, else unicode (icon-only components need an emoji). */
export function appEmojiOrFallback(name) {
    return appEmoji(name) ?? APP_EMOJI_FALLBACK[name];
}
/** Components V2 accessories want `{ id }` or `{ name }`, not a bare unicode string. */
export function appEmojiComponent(name) {
    const emoji = appEmojiOrFallback(name);
    return typeof emoji === "string" ? { name: emoji } : emoji;
}
export function appEmojiText(name) {
    return appEmojiTag(name) ?? APP_EMOJI_FALLBACK[name];
}
export function appEmojiHeading(name, title) {
    const tag = appEmojiTag(name);
    if (tag)
        return `# ${tag} 〃 ${title}`;
    return `# \`${APP_EMOJI_FALLBACK[name]}\` 〃 ${title}`;
}
