import { resolve } from 'node:path';
import config from '../../config.json' with { type: 'json' };
export const colors = { red: '#E82C20', yel: '#F4E00B', orng: '#F47C0B', prime: config.color || '#6495ed' };
const settings = {
    token: config.token || '', prefix: config.prefix || '+', colors,
    ownerId: (config.owners || []).filter(Boolean), botId: '4lc-protect',
    dataDir: resolve(process.cwd(), 'data', '4lc-support'),
};
export const botRuntime = { ...settings, name: '4LC-PROTECT', raw: { application_emojis: config.application_emojis || {}, urlsupport: config.support } };
export default settings;
