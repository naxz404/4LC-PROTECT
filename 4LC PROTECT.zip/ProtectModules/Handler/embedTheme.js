import { BrandedEmbedBuilder as EmbedBuilder } from '../../BrandedEmbedBuilder.js';
import {  } from 'discord.js';

const THEME_INSTALLED = Symbol.for('4lcprotect.blackEmbedTheme');

function styledTitle(value) {
    const title = String(value ?? '').trim();
    if (!title || title.includes('〃')) return title;
    const customEmoji = title.match(/^(<a?:[^:>]+:\d+>)\s*(.*)$/u);
    if (customEmoji) return `${customEmoji[1]} 〃 ${customEmoji[2]}`.trim();
    const unicodeEmoji = title.match(/^([\p{Extended_Pictographic}\u00A9\u00AE\u203C-\u3299][\uFE0F\u200D\p{Extended_Pictographic}]*)\s*(.*)$/u);
    if (unicodeEmoji) return `${unicodeEmoji[1]} 〃 ${unicodeEmoji[2]}`.trim();
    return `〃 ${title}`;
}

function iconForTitle(value) {
    const title = String(value || '').toLowerCase();
    if (/erreur|impossible|forbidden|unauthorized|not found|bad request|maintenance|indisponible|refus/.test(title)) return '❌';
    if (/config|paramètre|réglage|préfixe|supervision/.test(title)) return '⚙️';
    if (/ticket|note|rapport|journal|log|historique|dossier|cas/.test(title)) return '📝';
    if (/anti|raid|protection|sécurité|whitelist|blacklist|verrou/.test(title)) return '🛡️';
    if (/modération|sanction|ban|kick|mute|timeout|avertissement/.test(title)) return '🔨';
    if (/aéroport|arrivée|départ|bienvenue|membre|utilisateur|staff/.test(title)) return '👥';
    if (/giveaway|concours|tirage/.test(title)) return '➕';
    if (/invitation|classement|niveau|rank|xp/.test(title)) return '👤';
    if (/sauvegarde|backup|restauration/.test(title)) return '📁';
    if (/succès|terminé|activé|validé|confirmation/.test(title)) return '✅';
    return '⚙️';
}

function markdownHeading(value) {
    const raw = String(value || '').trim().replace(/^#+\s*/, '');
    if (!raw) return '';
    if (raw.includes('〃')) {
        const [left, ...right] = raw.split('〃');
        return `# ${left.trim()} 〃 ${right.join('〃').trim()}`;
    }
    return `# \`${iconForTitle(raw)}\` 〃 ${raw}`;
}

function compactBody(value) {
    const body = String(value || '').trim();
    if (!body || body.startsWith('# ')) return body;
    if (!body.includes('\n') && body.length <= 180 && !body.startsWith('>')) return `> *${body.replace(/^\*|\*$/g, '')}*`;
    return body;
}

export function installBlackEmbedTheme() {
    if (EmbedBuilder.prototype[THEME_INSTALLED]) return;
    const originalToJSON = EmbedBuilder.prototype.toJSON;
    Object.defineProperty(EmbedBuilder.prototype, THEME_INSTALLED, { value: true });
    EmbedBuilder.prototype.toJSON = function toBlackThemeJSON() {
        const json = originalToJSON.call(this);
        const title = String(json.title || '').trim();
        const description = compactBody(json.description);
        const hasMarkdownHeading = description.startsWith('# ');
        const themedDescription = title && !hasMarkdownHeading
            ? `${markdownHeading(styledTitle(title))}${description ? `\n\n${description}` : ''}`.slice(0, 4096)
            : description;
        return {
            ...json,
            color: 0x000000,
            ...(title && !hasMarkdownHeading ? { title: undefined } : {}),
            ...(themedDescription ? { description: themedDescription } : {}),
        };
    };
}

export { styledTitle, iconForTitle, markdownHeading };
