export const KNOWN_MODULE_KEYS = [
    "Base",
    "Moderation",
    "Utilities",
    "Giveaway",
    "Levels",
    "Rules",
    "Tickets",
    "Aeroport",
    "Logs",
    "StaffList",
    "Beta",
    "Captcha",
    "Partenariat",
    "ModerationAvancee",
    "Douane",
    "Message-Horaire",
    "InformationPanel",
    "Invitations",
    "FactoryPremium",
    "FactoryManager",
];
export const APP_EMOJI_KEYS = [
    "cancel",
    "add",
    "settings",
    "power",
    "pin",
    "people",
    "loop",
    "file",
    "cog",
    "check",
];
export const DEFAULT_SUPPORT_URL = "https://discord.gg/ddJMXWYJ29";
// Aucun accès développeur implicite : seuls les owners explicitement configurés
// dans la configuration de l'instance sont autorisés.
export const DEFAULT_DEVELOPER_IDS = [];
const SNOWFLAKE_RE = /^\d{17,22}$/;
function normalizeSupportUrl(value) {
    const trimmed = value.trim();
    if (!trimmed)
        return DEFAULT_SUPPORT_URL;
    if (/^https?:\/\//i.test(trimmed))
        return trimmed;
    if (trimmed.startsWith("discord.gg/"))
        return `https://${trimmed}`;
    return trimmed;
}
export function resolveSupportUrl(config) {
    const fromConfig = config?.urlsupport?.trim() || config?.guildsupport?.trim();
    return fromConfig ? normalizeSupportUrl(fromConfig) : DEFAULT_SUPPORT_URL;
}
export function parseApplicationEmojis(value) {
    if (value === null || typeof value !== "object" || Array.isArray(value))
        return undefined;
    const record = value;
    const out = {};
    for (const key of APP_EMOJI_KEYS) {
        const id = record[key];
        if (typeof id === "string" && SNOWFLAKE_RE.test(id.trim()))
            out[key] = id.trim();
    }
    return Object.keys(out).length > 0 ? out : undefined;
}
/** Incoming valid IDs win; missing incoming keys keep existing. Absent/empty incoming keeps existing as-is. */
export function mergeApplicationEmojis(existing, incoming) {
    const fromExisting = parseApplicationEmojis(existing) ?? {};
    if (incoming === undefined || incoming === null) {
        return Object.keys(fromExisting).length > 0 ? fromExisting : undefined;
    }
    const fromIncoming = parseApplicationEmojis(incoming) ?? {};
    const merged = { ...fromExisting, ...fromIncoming };
    return Object.keys(merged).length > 0 ? merged : undefined;
}
export function isBotConfig(value) {
    if (value === null || typeof value !== "object")
        return false;
    const record = value;
    return typeof record.bot_id === "string" && record.bot_id.length > 0;
}
export function asBotConfig(value) {
    if (!isBotConfig(value))
        return null;
    const record = value;
    const application_emojis = parseApplicationEmojis(record.application_emojis);
    if (application_emojis)
        return { ...record, application_emojis };
    const { application_emojis: _ignored, ...rest } = record;
    return rest;
}
export function parseHexColor(value, fallback = "#5865f2") {
    if (typeof value !== "string")
        return fallback;
    const trimmed = value.trim();
    if (/^#[0-9a-fA-F]{6}$/.test(trimmed))
        return trimmed;
    if (/^[0-9a-fA-F]{6}$/.test(trimmed))
        return `#${trimmed}`;
    return fallback;
}
export function defaultMaxMemory(config) {
    const raw = config?.max_memory;
    if (typeof raw === "number" && Number.isFinite(raw) && raw > 0)
        return Math.floor(raw);
    if (typeof raw === "string" && /^\d+$/.test(raw))
        return Number(raw);
    return 200;
}
