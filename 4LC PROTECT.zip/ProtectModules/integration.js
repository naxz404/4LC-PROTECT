import { allowedGuilds } from '../ServerScope.js';
import { isGlobalOwner } from '../Owners.js';
import { MessageFlags, PermissionFlagsBits } from 'discord.js';
import config from '../config.json' with { type: 'json' };
import db from '../Events/loadDatabase.js';
import { getGuildConfig, saveGuildConfig } from '../Captcha/storage.js';
import { enableVerificationEnvironment, disableVerificationEnvironment } from '../Captcha/onboarding.js';
import { Tickets, defaultCategory, updateConfig as updateTickets } from './Handler/tickets/schema.js';
import { Captcha, getConfig as getCaptcha, updateConfig as updateCaptcha } from './Handler/captcha/schema.js';
import { startChallenge, handleMemberLeave } from './Handler/captcha/engine.js';
import { handleCaptchaInteraction } from './Handler/captcha/dashboard.js';
import { handleTicketActionInteraction } from './Handler/tickets/engine.js';
import { handleTicketsInteraction } from './Handler/tickets/dashboard.js';
import { handleAdvancedTickets, ticketsTick, ticketMessage } from './Handler/v4/tickets.js';
import { serial } from './Handler/v4/store.js';
export { handleMemberLeave, ticketMessage };
const readOldCategory = guildId => new Promise(resolve => db.get('SELECT category FROM ticket WHERE guild = ?', [guildId], (error, row) => resolve(error ? null : row?.category)));

export async function initializeGuild(guild) {
    return serial(`support-init:${guild.id}`, async () => {
        if (!await Tickets.findOne({ guildId: guild.id }).lean()) {
            const parent = await readOldCategory(guild.id);
            const categories = [];
            const emojis = ['👮', '🎉', '🚨', '🏢', '👑'];
            for (let n = 1; n <= 5; n++) {
                const text = config[`option${n}`]?.trim();
                if (!text) continue;
                categories.push({ ...defaultCategory(`option${n}`), label: text.replace(/^\S+\s/u, ''), emoji: emojis[n - 1], categoryId: parent || null });
            }
            await updateTickets(guild.id, { $set: { type: 'select', categories, embed: { title: config.titre || 'Support', description: config.description || 'Choisissez le motif de votre demande.', color: config.color || '#6495ed', footer: `${config.tfooter || 'Support'} • By 4LC` } } });
        }
        if (!await Captcha.findOne({ guildId: guild.id }).lean()) {
            const old = getGuildConfig(guild.id);
            const v = old.verification;
            if (v.enabled) {
                let role = v.verifiedRoleId ? guild.roles.cache.get(v.verifiedRoleId) : null;
                if (!role) {
                    role = await guild.roles.create({ name: 'Vérifié', permissions: [], reason: 'Migration du captcha vers le système 4LC-PROTECT' });
                    v.verifiedRoleId = role.id;
                    saveGuildConfig(guild.id, old);
                }
                // The old Unverified restrictions remain until each member passes the new challenge.
                await updateCaptcha(guild.id, { $set: { enabled: true, channelId: v.channelId, roleId: role.id, timeout: v.timeoutMs, maxAttempts: v.maxAttempts, kickOnFail: v.kickOnFail, ignoreBots: v.ignoreBots } });
            }
        }
    });
}

async function syncLegacyEnvironment(guild) {
    const old = getGuildConfig(guild.id);
    if (!old.verification.roleId) return;
    const cfg = await getCaptcha(guild.id);
    if (!cfg.enabled) {
        if (old.verification.enabled) await disableVerificationEnvironment(guild);
        return;
    }
    if (cfg.roleId === old.verification.roleId) throw Error('Choisissez un rôle Vérifié différent du rôle Unverified.');
    const changed = !old.verification.enabled || old.verification.channelId !== cfg.channelId;
    old.verification.channelId = cfg.channelId;
    old.verification.verifiedRoleId = cfg.roleId;
    saveGuildConfig(guild.id, old);
    if (changed && cfg.channelId) await enableVerificationEnvironment(guild);
}

export async function startMemberChallenge(client, member) {
    await initializeGuild(member.guild);
    const cfg = await getCaptcha(member.guild.id);
    if (!cfg.enabled || (member.user.bot && cfg.ignoreBots)) return;
    const old = getGuildConfig(member.guild.id).verification;
    if (old.roleId && member.roles.cache.has(cfg.roleId) && member.roles.cache.has(old.roleId)) {
        await member.roles.remove(old.roleId, 'Vérification déjà réussie');
    }
    if (old.enabled && old.roleId && !member.roles.cache.has(cfg.roleId)) {
        await member.roles.add(old.roleId, 'Vérification requise');
    }
    await startChallenge(client, member);
}

export async function runModule(definition, client, message, args = []) {
    if (!message.guild || (!isGlobalOwner(message.author.id) && !message.member?.permissions.has(PermissionFlagsBits.ManageGuild))) {
        return message.reply({ content: 'Permission « Gérer le serveur » requise.' });
    }
    try {
        await initializeGuild(message.guild);
        const result = await definition.execute(client, message, args);
        if (definition.name === 'captcha') await syncLegacyEnvironment(message.guild);
        return result;
    } catch (error) {
        console.error('[Support] Commande :', error);
        return message.reply({ content: 'Configuration impossible. Vérifiez les permissions du bot et les journaux.' });
    }
}

export async function handleSupportInteraction(client, interaction) {
    const id = interaction.customId || '';
    if (!/^(tk_|ta:|cp_|sar:cp:|sar:captcha:)/.test(id)) return false;
    try {
        if (id.startsWith('sar:')) {
            await interaction.reply({ content: 'Ce panneau a été remplacé. Utilisez +captcha pour la configuration. Pour un ancien défi, contactez le staff.', flags: MessageFlags.Ephemeral });
            return true;
        }
        if (await handleAdvancedTickets(client, interaction)) return true;
        if (id.startsWith('cp_')) {
            const handled = await handleCaptchaInteraction(client, interaction);
            if (interaction.guild) {
                if (id.startsWith('cp_modal:')) {
                    const cfg = await getCaptcha(interaction.guild.id);
                    const member = await interaction.guild.members.fetch(interaction.user.id).catch(() => null);
                    const old = getGuildConfig(interaction.guild.id).verification;
                    if (member?.roles.cache.has(cfg.roleId) && old.roleId && member.roles.cache.has(old.roleId)) {
                        await member.roles.remove(old.roleId, 'Captcha réussi');
                    }
                } else if (!id.startsWith('cp_verify:')) await syncLegacyEnvironment(interaction.guild);
            }
            return handled;
        }
        if (await handleTicketActionInteraction(client, interaction)) return true;
        return await handleTicketsInteraction(client, interaction);
    } catch (error) {
        console.error('[Support] Interaction :', error);
        const data = { content: 'Action impossible. Vérifiez les permissions du bot et les journaux.' };
        if (interaction.deferred || interaction.replied) await interaction.followUp({ ...data, flags: MessageFlags.Ephemeral }).catch(() => {});
        else await interaction.reply({ ...data, flags: MessageFlags.Ephemeral }).catch(() => {});
        return true;
    }
}
let timer;
export async function startSupport(client) {
    for (const guild of allowedGuilds(client)) {
        try {
            await initializeGuild(guild);
            const old = getGuildConfig(guild.id).verification;
            if (old.enabled && old.roleId) {
                await guild.members.fetch();
                const role = guild.roles.cache.get(old.roleId);
                for (const member of role?.members.values() || []) await startMemberChallenge(client, member);
            }
        } catch (error) { console.error('[Support] Reprise :', error); }
    }
    if (timer) return;
    let running = false;
    timer = setInterval(async () => {
        if (running) return;
        running = true;
        try {
            for (const guild of allowedGuilds(client)) await ticketsTick(client, guild).catch(console.error);
        } finally { running = false; }
    }, 60_000);
    timer.unref();
}
