import fs from 'node:fs';
import path from 'node:path';

const DATA_DIR = path.resolve('./4LC-DATA');
const DATA_FILE = path.join(DATA_DIR, 'reactionRoles.json');

function ensure() {
  fs.mkdirSync(DATA_DIR, { recursive: true });
  if (!fs.existsSync(DATA_FILE)) fs.writeFileSync(DATA_FILE, '{}', 'utf8');
}

export function loadReactionRoles() {
  ensure();
  try {
    const raw = JSON.parse(fs.readFileSync(DATA_FILE, 'utf8') || '{}');
    return raw && typeof raw === 'object' ? raw : {};
  } catch (error) {
    console.error('[ReactionRole] Fichier invalide, réinitialisation:', error);
    fs.writeFileSync(DATA_FILE, '{}', 'utf8');
    return {};
  }
}

export function saveReactionRoles(data) {
  ensure();
  const temp = `${DATA_FILE}.tmp`;
  fs.writeFileSync(temp, JSON.stringify(data, null, 2), 'utf8');
  fs.renameSync(temp, DATA_FILE);
}

export function reactionKey(emoji) {
  if (emoji?.id) return `custom:${emoji.id}`;
  return `unicode:${emoji?.name || emoji}`;
}

export function inputReactionKey(input) {
  const custom = String(input).match(/^<a?:[^:>]+:(\d+)>$/);
  if (custom) return `custom:${custom[1]}`;
  return `unicode:${String(input).trim()}`;
}
