import { isGlobalOwner } from '../../Owners.js';
import { PermissionFlagsBits } from 'discord.js';
import db from '../../Events/loadDatabase.js';
import config from '../../config.json' with { type: 'json' };
import { settings } from '../../Antiraid/raidMode.js';
import { resetGuild } from '../../Antiraid/raidLogic.js';

export const command = {
    name: 'raidmode',
    helpname: 'raidmode [on/off] [nombre] [secondes] [kick/ban] [minutes]',
    help: 'raidmode [on/off] [nombre] [secondes] [kick/ban] [minutes]',
    description: 'Configure la détection automatique des arrivées massives',
    run: async (_bot, message, args) => {
        if (!message.guild || !(isGlobalOwner(message.author.id) || message.member?.permissions.has(PermissionFlagsBits.ManageGuild))) {
            return message.reply('Permission « Gérer le serveur » requise.');
        }
        const current = await settings(message.guild.id);
        if (!args.length) return message.reply(`Auto RaidMode : **${current.enabled ? 'activé' : 'désactivé'}**. Seuil : ${current.count} arrivées en ${current.window_ms / 1000} s. Action : ${current.action}. Durée : ${current.duration_ms / 60000} min.\nExemple : \`${config.prefix}raidmode on 8 10 kick 10\``);
        const [mode, countText, secondsText, actionText, minutesText] = args;
        if (!['on', 'off'].includes(mode)) return message.reply('Utilisation : raidmode on/off [nombre 3-100] [secondes 2-60] [kick/ban] [minutes 1-60]');
        const count = countText === undefined ? current.count : Number(countText);
        const seconds = secondsText === undefined ? current.window_ms / 1000 : Number(secondsText);
        const action = actionText ?? current.action;
        const minutes = minutesText === undefined ? current.duration_ms / 60000 : Number(minutesText);
        if (!Number.isInteger(count) || count < 3 || count > 100 || !Number.isInteger(seconds) || seconds < 2 || seconds > 60 || !['kick', 'ban'].includes(action) || !Number.isInteger(minutes) || minutes < 1 || minutes > 60) {
            return message.reply('Valeurs invalides : nombre 3-100, secondes 2-60, action kick/ban, minutes 1-60.');
        }
        db.run(`INSERT INTO raidmode (guild, enabled, count, window_ms, duration_ms, action) VALUES (?, ?, ?, ?, ?, ?)
            ON CONFLICT(guild) DO UPDATE SET enabled=excluded.enabled, count=excluded.count, window_ms=excluded.window_ms,
            duration_ms=excluded.duration_ms, action=excluded.action`, [message.guild.id, Number(mode === 'on'), count, seconds * 1000, minutes * 60000, action], err => {
            if (err) return message.reply('Erreur lors de la sauvegarde.').catch(() => {});
            resetGuild(message.guild.id);
            message.reply(`Auto RaidMode ${mode === 'on' ? 'activé' : 'désactivé'} : ${count} arrivées/${seconds} s, ${action}, ${minutes} min.`).catch(() => {});
        });
    }
};
