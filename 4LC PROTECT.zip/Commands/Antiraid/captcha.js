import definition from '../../ProtectModules/Commands/captcha/captcha.js';
import { runModule } from '../../ProtectModules/integration.js';
export const command = {
    name: 'captcha', aliases: ['verify', 'verification'],
    description: definition.description,
    helpname: 'captcha [on|off|salon|role|timeout|attempts|kick|bots|reset]', help: 'captcha [on|off|salon|role|timeout|attempts|kick|bots|reset]',
    run: (client, message, args) => runModule(definition, client, message, args),
};
