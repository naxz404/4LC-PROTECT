import { isGlobalOwner } from '../../Owners.js';
import { PermissionFlagsBits } from 'discord.js';
import db from '../../Events/loadDatabase.js';
import config from '../../config.json' with { type: 'json' };
export const command = {
    name: 'antitoken', helpname: 'antitoken on/off', help: 'antitoken on/off',
    description: 'Expulse les comptes de moins de sept jours',
    run: async (_bot, message, args) => {
        if (!(isGlobalOwner(message.author.id) || message.member?.permissions.has(PermissionFlagsBits.ManageGuild))) return message.reply('Permission « Gérer le serveur » requise.');
        if (!['on', 'off'].includes(args[0])) return message.reply('Utilisation : antitoken on/off');
        const enabled = Number(args[0] === 'on');
        db.run('INSERT INTO antiraid (guild, antitoken) VALUES (?, ?) ON CONFLICT(guild) DO UPDATE SET antitoken = excluded.antitoken', [message.guild.id, enabled], err => {
            message.reply(err ? 'Erreur de sauvegarde.' : `Anti-compte récent ${enabled ? 'activé' : 'désactivé'}.`).catch(() => {});
        });
    }
};
