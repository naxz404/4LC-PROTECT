import { command as setowner } from './setowner.js';
import { isGlobalOwner, ownerIds } from '../../Owners.js';
export const command = { name: 'owner', help: 'owner [@membre]', description: 'Afficher les owners du bot.', async run(bot, message, args = []) {
    if (!isGlobalOwner(message.author.id)) return message.reply('Commande réservée aux owners du bot.');
    if (args.length) return setowner.run(bot, message, args);
    return message.reply({ content: `**Owners de 4LC-PROTECT**\n${ownerIds().map(id => `<@${id}> · ${id}`).join('\n') || 'Aucun owner.'}`.slice(0,1950), allowedMentions: { parse: [] } });
} };
