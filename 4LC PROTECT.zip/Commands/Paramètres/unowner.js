import db from '../../Events/loadDatabase.js';
import { isGlobalOwner, setDatabaseOwner } from '../../Owners.js';
export const command = {
    name: 'unowner', help: 'unowner @membre', description: 'Gérer les owners du bot.',
    async run(bot, message, args) {
        if (!isGlobalOwner(message.author.id)) return message.reply('Commande réservée aux owners du bot.');
        const id = args[0]?.replace(/^<@!?(\d+)>$/, '$1');
        if (!/^\d{17,22}$/.test(id || '')) return message.reply('Mentionne un membre ou indique son identifiant Discord.');
        const user = await bot.users.fetch(id).catch(() => null);
        if (!user || user.bot) return message.reply('Choisis un utilisateur humain valide.');
        await new Promise((resolve, reject) => db.run('DELETE FROM owner WHERE id = ?', [id], error => error ? reject(error) : resolve()));
        setDatabaseOwner(id, false);
        if (isGlobalOwner(id)) return message.reply('Cet utilisateur reste owner via config.json ou OWNER_IDS. Retire aussi son identifiant de cette configuration.');
        return message.reply({ content: `✅ <@${id}> retiré de la liste des owners ajoutés par commande.`, allowedMentions: { parse: [] } });
    }
};
