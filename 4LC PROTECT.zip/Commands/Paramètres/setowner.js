import db from '../../Events/loadDatabase.js';
import { isGlobalOwner, setDatabaseOwner } from '../../Owners.js';
export const command = {
    name: 'setowner', help: 'setowner @membre', description: 'Gérer les owners du bot.',
    async run(bot, message, args) {
        if (!isGlobalOwner(message.author.id)) return message.reply('Commande réservée aux owners du bot.');
        const id = args[0]?.replace(/^<@!?(\d+)>$/, '$1');
        if (!/^\d{17,22}$/.test(id || '')) return message.reply('Mentionne un membre ou indique son identifiant Discord.');
        const user = await bot.users.fetch(id).catch(() => null);
        if (!user || user.bot) return message.reply('Choisis un utilisateur humain valide.');
        await new Promise((resolve, reject) => db.run('INSERT OR IGNORE INTO owner (id) VALUES (?)', [id], error => error ? reject(error) : resolve()));
        setDatabaseOwner(id, true);
        return message.reply({ content: `✅ <@${id}> est maintenant owner du bot : accès aux commandes et panneaux du serveur configuré.`, allowedMentions: { parse: [] } });
    }
};
