import { getGuildConfig, saveGuildConfig } from '../../ProtectCore/storage.js';
import { canManage } from '../../Features/serverSecurity.js';
import { PermissionFlagsBits } from 'discord.js';
export const command = {
  name: 'warnconfig', aliases: ['warnings'], help: 'warnconfig <timeout> <kick> <ban>', helpname: 'warnconfig 3 5 7',
  description: 'Configure les sanctions progressives.',
  run: async (_bot, message, args) => {
    if (!canManage(message.member, PermissionFlagsBits.ManageGuild)) return message.reply('⛔ Permission insuffisante.');
    const cfg=getGuildConfig(message.guild.id);
    if (!args.length) return message.reply(`⚠️ Seuils actuels : timeout **${cfg.warningSystem.mutePoints}**, kick **${cfg.warningSystem.kickPoints}**, ban **${cfg.warningSystem.banPoints}**.\nExemple : \`+warnconfig 3 5 7\``);
    const [t,k,b]=args.slice(0,3).map(Number);
    if (![t,k,b].every(Number.isInteger) || t<1 || k<=t || b<=k || b>100) return message.reply('Utilise 3 nombres croissants, ex. `+warnconfig 3 5 7`.');
    cfg.warningSystem={...cfg.warningSystem,enabled:true,mutePoints:t,kickPoints:k,tempBanPoints:999,banPoints:b}; saveGuildConfig(message.guild.id,cfg);
    return message.reply(`✅ Auto-sanction : **${t} warns = timeout · ${k} = kick · ${b} = ban**.`);
  }
};
