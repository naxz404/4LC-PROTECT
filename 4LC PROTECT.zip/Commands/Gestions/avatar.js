import { isIdentityOwner } from '../../Owners.js';
export const command = {
    name: 'avatar', help: 'avatar <url>', description: "Modifier la photo de profil du bot (owner de configuration).",
    async run(bot, message, args) {
        if (!isIdentityOwner(message.author.id)) return message.reply('Les changements d’identité du bot sont réservés aux owners de config.json ou OWNER_IDS.');
        if (!args.length) return message.reply('Utilisation : avatar <url>');
        try { await bot.user.setAvatar(args[0]); return message.reply('La photo de profil du bot a été changée.'); }
        catch (error) { console.error('[4LC-PROTECT] avatar:', error); return message.reply('Discord a refusé le changement. Vérifie la valeur et les limites de fréquence.'); }
    }
};
