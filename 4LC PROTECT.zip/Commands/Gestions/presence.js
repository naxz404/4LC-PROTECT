import { isGlobalOwner } from '../../Owners.js';
import { writeActivityConfig, readActivityConfig } from '../../ProtectCore/config.js';
import { applyConfiguredPresence } from '../../ProtectCore/presence.js';
export const command = { name: 'presence', description: 'Modifier le statut global du bot.', help: 'presence', async run(bot, message, args) {
        if (!isGlobalOwner(message.author.id)) return message.reply('Commande réservée aux owners du bot.');
        const presence = args[0]?.toLowerCase();
        if (!['online','idle','dnd','invisible'].includes(presence)) return message.reply('Utilisation : presence online|idle|dnd|invisible');
        writeActivityConfig({ presence });
        applyConfiguredPresence(bot, { force: true });
        return message.reply('✅ Statut enregistré et actualisé.');
} };
