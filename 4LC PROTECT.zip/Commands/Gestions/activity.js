import { isGlobalOwner } from '../../Owners.js';
import { writeActivityConfig, readActivityConfig } from '../../ProtectCore/config.js';
import { applyConfiguredPresence } from '../../ProtectCore/presence.js';
export const command = { name: 'activity', description: 'Modifier le statut global du bot.', help: 'activity', async run(bot, message, args) {
        if (!isGlobalOwner(message.author.id)) return message.reply('Commande réservée aux owners du bot.');
        const type = { listen: 'Listening', play: 'Playing', stream: 'Streaming', watch: 'Watching', compet: 'Competing', custom: 'Custom' }[args[0]?.toLowerCase()];
        if (['stop','off'].includes(args[0]?.toLowerCase())) writeActivityConfig({ activityDisabled: true });
        else {
            const name = args.slice(1).join(' ').trim();
            if (!type || !name || name.length > 128) return message.reply('Utilisation : activity play|watch|listen|stream|compet|custom texte (128 caractères maximum), ou activity stop.');
            const previous = readActivityConfig();
            if (type === 'Streaming' && !previous.url) return message.reply('Renseigne activityUrl dans ProtectCore/config.json pour le mode streaming.');
            writeActivityConfig({ activityDisabled: false, activity: { name, type, ...(previous.url ? { url: previous.url } : {}) }, activityType: type });
        }
        applyConfiguredPresence(bot, { force: true });
        return message.reply('✅ Activité enregistrée et actualisée.');
} };
