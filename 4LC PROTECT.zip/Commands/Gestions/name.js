import { isIdentityOwner } from '../../Owners.js';
export const command = {
    name: 'name', help: 'name <texte>', description: "Modifier le nom du bot (owner de configuration).",
    async run(bot, message, args) {
        if (!isIdentityOwner(message.author.id)) return message.reply('Les changements d’identité du bot sont réservés aux owners de config.json ou OWNER_IDS.');
        if (!args.length) return message.reply('Utilisation : name <texte>');
        try { await bot.user.setUsername(args.join(' ')); return message.reply('Le nom du bot a été changé.'); }
        catch (error) { console.error('[4LC-PROTECT] name:', error); return message.reply('Discord a refusé le changement. Vérifie la valeur et les limites de fréquence.'); }
    }
};
