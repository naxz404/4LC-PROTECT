import { isGlobalOwner } from '../../Owners.js';
import { BrandedEmbedBuilder } from '../../BrandedEmbedBuilder.js';
import config from '../../config.json' with { type: 'json' };
import db from '../../Events/loadDatabase.js';
import { loadReactionRoles, saveReactionRoles, inputReactionKey } from '../../reactionRoleStore.js';

const waitForText = async (message, prompt, timeout = 120000) => {
  const q = await message.channel.send(prompt);
  try {
    const collected = await message.channel.awaitMessages({
      filter: (m) => m.author.id === message.author.id,
      max: 1,
      time: timeout,
      errors: ['time'],
    });
    const answer = collected.first();
    await q.delete().catch(() => {});
    return answer;
  } catch {
    await q.delete().catch(() => {});
    return null;
  }
};

async function hasAccess(message) {
  if (isGlobalOwner(message.author.id)) return true;
  if (message.guild.ownerId === message.author.id) return true;
  const row = await new Promise((resolve) => db.get('SELECT id FROM owner WHERE id = ?', [message.author.id], (err, r) => resolve(err ? null : r)));
  return !!row;
}

function parseRole(guild, text) {
  const id = text.match(/<@&(\d+)>/)?.[1] || text.match(/^\d{17,20}$/)?.[0];
  return id ? guild.roles.cache.get(id) : null;
}

export const command = {
  name: 'reactionrole',
  aliases: ['rr', 'rolereaction'],
  helpname: 'reactionrole [list/delete <messageId>]',
  description: 'Crée et gère les rôles par réaction du serveur.',
  help: 'reactionrole\nreactionrole list\nreactionrole delete <messageId>',
  run: async (bot, message, args) => {
    if (!(await hasAccess(message))) return message.reply('Cette commande est réservée à la gestion du serveur.');

    const data = loadReactionRoles();
    data[message.guild.id] ||= {};

    if ((args[0] || '').toLowerCase() === 'list') {
      const entries = Object.entries(data[message.guild.id]);
      const embed = new BrandedEmbedBuilder()
        .setColor(config.color)
        .setTitle('🎭 Rôles par réaction')
        .setDescription(entries.length
          ? entries.map(([id, item]) => `• **${item.title || 'Embed'}** — <#${item.channelId}> — \`${id}\` — ${Object.keys(item.roles || {}).length} rôle(s)`).join('\n')
          : 'Aucun rôle par réaction configuré.');
      return message.reply({ embeds: [embed], allowedMentions: { repliedUser: false } });
    }

    if ((args[0] || '').toLowerCase() === 'delete') {
      const messageId = args[1];
      if (!messageId || !data[message.guild.id][messageId]) return message.reply('Utilisation : `+reactionrole delete <messageId>`');
      delete data[message.guild.id][messageId];
      saveReactionRoles(data);
      return message.reply('Le rôle par réaction a été supprimé de la configuration.');
    }

    const channelAnswer = await waitForText(message, 'Dans quel salon envoyer l’embed ? Mentionne le salon (`#salon`) ou écris `ici`.');
    if (!channelAnswer) return message.reply('Création annulée : délai dépassé.');
    const channelId = channelAnswer.content.toLowerCase() === 'ici' ? message.channel.id : channelAnswer.mentions.channels.first()?.id;
    const channel = message.guild.channels.cache.get(channelId);
    await channelAnswer.delete().catch(() => {});
    if (!channel?.isTextBased?.()) return message.reply('Salon invalide.');

    const titleAnswer = await waitForText(message, 'Quel titre veux-tu pour l’embed ?');
    if (!titleAnswer) return message.reply('Création annulée.');
    const title = titleAnswer.content.slice(0, 256);
    await titleAnswer.delete().catch(() => {});

    const descAnswer = await waitForText(message, 'Quelle description veux-tu ? Écris `aucune` si tu n’en veux pas.');
    if (!descAnswer) return message.reply('Création annulée.');
    const description = descAnswer.content.toLowerCase() === 'aucune' ? '' : descAnswer.content.slice(0, 3500);
    await descAnswer.delete().catch(() => {});

    const mappings = [];
    for (let i = 1; i <= 10; i++) {
      const answer = await waitForText(message, `Rôle ${i}/10 : envoie \`emoji @role\` (ex: \`✅ @Membre\`) ou écris \`fini\`.`);
      if (!answer) return message.reply('Création annulée : délai dépassé.');
      const content = answer.content.trim();
      if (content.toLowerCase() === 'fini') {
        await answer.delete().catch(() => {});
        break;
      }
      const parts = content.split(/\s+/);
      const emoji = parts.shift();
      const role = parseRole(message.guild, parts.join(' '));
      await answer.delete().catch(() => {});
      if (!emoji || !role) {
        i--;
        await message.channel.send('Emoji ou rôle invalide. Recommence avec `emoji @role`.').then((m) => setTimeout(() => m.delete().catch(() => {}), 3000));
        continue;
      }
      if (role.managed || role.id === message.guild.id) {
        i--;
        await message.channel.send('Ce rôle ne peut pas être géré par le bot.').then((m) => setTimeout(() => m.delete().catch(() => {}), 3000));
        continue;
      }
      const me = message.guild.members.me;
      if (!me || role.position >= me.roles.highest.position) {
        i--;
        await message.channel.send(`Le rôle ${role} doit être placé sous le rôle de 4LC-PROTECT.`).then((m) => setTimeout(() => m.delete().catch(() => {}), 4000));
        continue;
      }
      const key = inputReactionKey(emoji);
      if (mappings.some((m) => m.key === key)) {
        i--;
        await message.channel.send('Cet emoji est déjà utilisé dans cet embed.').then((m) => setTimeout(() => m.delete().catch(() => {}), 3000));
        continue;
      }
      mappings.push({ emoji, key, roleId: role.id });
    }

    if (!mappings.length) return message.reply('Création annulée : aucun rôle ajouté.');

    const roleLines = mappings.map((m) => `${m.emoji}  →  <@&${m.roleId}>`).join('\n');
    const embed = new BrandedEmbedBuilder()
      .setColor(config.color)
      .setTitle(title)
      .setDescription(`${description ? `${description}\n\n` : ''}**Choisis tes rôles :**\n${roleLines}`);

    const sent = await channel.send({ embeds: [embed] });
    const roles = {};
    for (const mapping of mappings) {
      try {
        await sent.react(mapping.emoji);
        roles[mapping.key] = { roleId: mapping.roleId, emoji: mapping.emoji };
      } catch (error) {
        console.error('[ReactionRole] Impossible d’ajouter la réaction', mapping.emoji, error);
      }
    }

    if (!Object.keys(roles).length) {
      await sent.delete().catch(() => {});
      return message.reply('Aucune réaction n’a pu être ajoutée. Vérifie les emojis et les permissions du bot.');
    }

    data[message.guild.id][sent.id] = {
      channelId: channel.id,
      title,
      roles,
      createdBy: message.author.id,
      createdAt: Date.now(),
    };
    saveReactionRoles(data);

    return message.reply(`Rôle par réaction créé dans ${channel} avec **${Object.keys(roles).length} rôle(s)**.`);
  },
};
