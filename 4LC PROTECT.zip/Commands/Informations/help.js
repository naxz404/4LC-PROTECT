import { ActionRowBuilder, StringSelectMenuBuilder } from 'discord.js';
import { BrandedEmbedBuilder } from '../../BrandedEmbedBuilder.js';
import { getGuildConfig } from '../../ProtectCore/storage.js';
const hidden = new Set(['antiban','antibot','antiuserapps','antichannel','antieveryone','antijoin','antilink','antirole','antispam','antitoken','antiupdate','antivanity','antiwebhook']);
export const command = {
    name: 'help', helpname: 'help [commande]', help: 'help [commande]', description: 'Afficher les commandes de 4LC-PROTECT.',
    async run(bot, message, args, config) {
        const cfg = getGuildConfig(message.guild.id);
        const prefix = cfg.prefix || config.prefix;
        const en = cfg.language === 'en';
        const embed = () => new BrandedEmbedBuilder().setColor(config.color).setTitle('🛡️ 4LC-PROTECT');
        if (args[0]) {
            const cmd = bot.commands.get(args[0].toLowerCase());
            if (!cmd) return message.reply(en ? 'Unknown command.' : 'Commande inconnue.');
            return message.reply({ embeds: [embed().setDescription(cmd.description || '—').addFields({ name: en ? 'Usage' : 'Utilisation', value: `\`${prefix}${cmd.help || cmd.helpname || cmd.name}\`` })] });
        }
        const groups = new Map();
        for (const cmd of new Set(bot.commands.values())) {
            if (hidden.has(cmd.name)) continue;
            const category = cmd.category || (en ? 'Other' : 'Autres');
            if (!groups.has(category)) groups.set(category, []);
            groups.get(category).push(`\`${prefix}${cmd.helpname || cmd.name}\` · ${(cmd.description || '—').slice(0,120)}`);
        }
        const pages = [];
        for (const [name, lines] of groups) {
            let body = '';
            for (const line of lines) {
                if (body.length + line.length > 3600) { pages.push({ name, body }); body = ''; }
                body += line + '\n';
            }
            if (body) pages.push({ name, body });
        }
        const menu = new StringSelectMenuBuilder().setCustomId(`4lc_help:${message.author.id}`).setPlaceholder(en ? 'Choose a category' : 'Choisir une catégorie').addOptions(pages.slice(0,25).map((page,index) => ({ label: page.name.slice(0,100), value: String(index) })));
        const rows = [new ActionRowBuilder().addComponents(menu)];
        const sent = await message.reply({ embeds: [embed().setDescription(`${en ? 'Prefix' : 'Préfixe'} : \`${prefix}\`\n\n${en ? 'Settings' : 'Configuration'} : \`/config\`\n${en ? 'Command details' : 'Détails d’une commande'} : \`${prefix}help commande\``)], components: rows });
        const collector = sent.createMessageComponentCollector({ filter: i => i.user.id === message.author.id && i.customId === `4lc_help:${message.author.id}`, time: 120000 });
        collector.on('collect', i => { const page = pages[Number(i.values[0])]; if (page) void i.update({ embeds: [embed().setTitle(`4LC-PROTECT · ${page.name}`).setDescription(page.body)], components: rows }).catch(() => {}); });
        collector.on('end', () => void sent.edit({ components: [] }).catch(() => {}));
        return sent;
    },
};
