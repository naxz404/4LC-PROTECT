import definition from '../../ProtectModules/Commands/tickets/ticket.js';
import { runModule } from '../../ProtectModules/integration.js';
export const command = {
    name: 'ticket', aliases: ['tickets'],
    description: definition.description,
    helpname: 'ticket [panel]', help: 'ticket [panel]',
    run: (client, message, args) => runModule(definition, client, message, args),
};
