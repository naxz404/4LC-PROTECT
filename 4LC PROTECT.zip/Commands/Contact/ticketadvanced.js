import definition from '../../ProtectModules/Commands/tickets/ticketadvanced.js';
import { runModule } from '../../ProtectModules/integration.js';
export const command = {
    name: 'ticketadvanced', aliases: ['ticketplus'],
    description: definition.description,
    helpname: 'ticketadvanced [form|reminder|autoclose|rating|status]', help: 'ticketadvanced [form|reminder|autoclose|rating|status]',
    run: (client, message, args) => runModule(definition, client, message, args),
};
