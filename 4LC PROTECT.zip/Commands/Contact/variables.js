import definition from '../../ProtectModules/Commands/tickets/variables.js';
import { runModule } from '../../ProtectModules/integration.js';
export const command = {
    name: 'variables', aliases: ['variable', 'vars'],
    description: definition.description,
    helpname: 'variables [ticket]', help: 'variables [ticket]',
    run: (client, message, args) => runModule(definition, client, message, args),
};
