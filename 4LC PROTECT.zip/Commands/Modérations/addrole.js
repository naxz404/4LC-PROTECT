import { isGlobalOwner } from '../../Owners.js';
import { BrandedEmbedBuilder } from '../../BrandedEmbedBuilder.js';
import db from '../../Events/loadDatabase.js';
import sendLog from '../../Events/sendlog.js';

const MAX_MEMBERS = 10;
const MAX_ROLES = 10;

async function checkPerm(message, commandName, config) {
    if (isGlobalOwner(message.author.id)) return true;
    const one = (sql, params) => new Promise((resolve, reject) => db.get(sql, params, (err, row) => err ? reject(err) : resolve(row)));
    const all = (sql, params) => new Promise((resolve, reject) => db.all(sql, params, (err, rows) => err ? reject(err) : resolve(rows || [])));
    try {
        const pub = await one('SELECT statut FROM public WHERE guild = ? AND statut = ?', [message.guild.id, 'on']);
        if (pub && await one('SELECT command FROM cmdperm WHERE perm = ? AND command = ? AND guild = ?', ['public', commandName, message.guild.id])) return true;
        if (await one('SELECT id FROM whitelist WHERE id = ?', [message.author.id])) return true;
        if (await one('SELECT id FROM owner WHERE id = ?', [message.author.id])) return true;
        const roleIds = message.member.roles.cache.map((r) => r.id);
        if (!roleIds.length) return false;
        const perms = (await all(`SELECT perm FROM permissions WHERE id IN (${roleIds.map(() => '?').join(',')}) AND guild = ?`, [...roleIds, message.guild.id])).map((r) => r.perm);
        if (!perms.length) return false;
        const commands = (await all(`SELECT command FROM cmdperm WHERE perm IN (${perms.map(() => '?').join(',')}) AND guild = ?`, [...perms, message.guild.id])).map((r) => r.command);
        return commands.includes(commandName);
    } catch (error) {
        console.error('[addrole] permission:', error);
        return false;
    }
}

function cleanToken(token) {
    return token.replace(/^<@!?/, '').replace(/^<@&/, '').replace(/>$/, '');
}

async function resolveTargets(message, args) {
    const members = new Map(message.mentions.members.map((m) => [m.id, m]));
    const roles = new Map(message.mentions.roles.map((r) => [r.id, r]));

    for (const raw of args) {
        if (members.size >= MAX_MEMBERS && roles.size >= MAX_ROLES) break;
        if (/^<@&\d+>$/.test(raw) || /^<@!?\d+>$/.test(raw)) continue;
        const token = cleanToken(raw);

        if (/^\d{16,22}$/.test(token)) {
            if (members.size < MAX_MEMBERS) {
                const member = message.guild.members.cache.get(token) || await message.guild.members.fetch(token).catch(() => null);
                if (member) { members.set(member.id, member); continue; }
            }
            if (roles.size < MAX_ROLES) {
                const role = message.guild.roles.cache.get(token);
                if (role) { roles.set(role.id, role); continue; }
            }
        }

        const normalized = raw.toLowerCase();
        if (members.size < MAX_MEMBERS) {
            const member = message.guild.members.cache.find((m) =>
                m.user.username.toLowerCase() === normalized ||
                m.displayName.toLowerCase() === normalized ||
                m.user.globalName?.toLowerCase() === normalized
            );
            if (member) { members.set(member.id, member); continue; }
        }
        if (roles.size < MAX_ROLES) {
            const role = message.guild.roles.cache.find((r) => r.name.toLowerCase() === normalized);
            if (role) roles.set(role.id, role);
        }
    }
    return { members: [...members.values()].slice(0, MAX_MEMBERS), roles: [...roles.values()].slice(0, MAX_ROLES) };
}

export const command = {
    name: 'addrole',
    helpname: 'addrole <membre(s)> <rôle(s)>',
    description: 'Ajoute jusqu’à 10 rôles à jusqu’à 10 membres en une commande.',
    help: 'addrole <@membre/id/nom ...> <@role/id/nom ...>',
    run: async (bot, message, args, config) => {
        if (!(await checkPerm(message, command.name, config))) {
            const embed = new BrandedEmbedBuilder().setDescription("Vous n'avez pas la permission d'utiliser cette commande").setColor(config.color);
            return message.reply({ embeds: [embed], allowedMentions: { repliedUser: true } }).then((m) => setTimeout(() => m.delete().catch(() => {}), 2000));
        }
        if (!args.length) return message.reply(`Utilisation : \`${config.prefix}addrole @membre1 @membre2 @role1 @role2\``);

        const { members, roles } = await resolveTargets(message, args);
        if (!members.length || !roles.length) {
            return message.reply('Je dois trouver au moins **1 membre** et **1 rôle**. Utilise de préférence des mentions ou des IDs.');
        }
        if (message.mentions.members.size > MAX_MEMBERS || message.mentions.roles.size > MAX_ROLES) {
            return message.reply(`Maximum **${MAX_MEMBERS} membres** et **${MAX_ROLES} rôles** par commande.`);
        }

        const me = await message.guild.members.fetchMe();
        const allowedRoles = roles.filter((role) =>
            role.id !== message.guild.id && !role.managed &&
            role.position < me.roles.highest.position &&
            (message.author.id === message.guild.ownerId || role.position < message.member.roles.highest.position)
        );
        const rejectedRoles = roles.filter((role) => !allowedRoles.includes(role));
        if (!allowedRoles.length) return message.reply('Aucun des rôles indiqués ne peut être attribué à cause de la hiérarchie ou parce qu’il est géré par Discord.');

        const success = [];
        const failures = [];
        for (const member of members) {
            if (member.id === message.guild.ownerId || member.id === me.id) { failures.push(`<@${member.id}>`); continue; }
            try {
                await member.roles.add(allowedRoles, `+addrole par ${message.author.tag}`);
                success.push(member);
            } catch (error) {
                console.error('[addrole] bulk add:', error);
                failures.push(`<@${member.id}>`);
            }
        }

        const roleText = allowedRoles.map((r) => `<@&${r.id}>`).join(', ');
        const embed = new BrandedEmbedBuilder()
            .setColor(config.color)
            .setTitle('Rôles ajoutés')
            .setDescription(`**Membres :** ${success.map((m) => `<@${m.id}>`).join(', ') || 'Aucun'}\n**Rôles :** ${roleText}${rejectedRoles.length ? `\n**Rôles ignorés :** ${rejectedRoles.map((r) => `<@&${r.id}>`).join(', ')}` : ''}${failures.length ? `\n**Échecs :** ${failures.join(', ')}` : ''}`)
            .setFooter({ text: 'By 4LC' })
            .setTimestamp();
        await message.reply({ embeds: [embed], allowedMentions: { repliedUser: false } });

        const log = new BrandedEmbedBuilder()
            .setColor(config.color)
            .setDescription(`<@${message.author.id}> a ajouté ${allowedRoles.length} rôle(s) à ${success.length} membre(s).\n${roleText}`)
            .setTimestamp();
        sendLog(message.guild, log, 'rolelog');
    },
};
