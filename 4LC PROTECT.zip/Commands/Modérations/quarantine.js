import { PermissionFlagsBits } from 'discord.js';
import { canManage, quarantineTarget } from '../../Features/serverSecurity.js';
export const command={name:'quarantine',helpname:'quarantine <membre> [raison]',description:'Place un membre en quarantaine',help:'quarantine <membre> [raison]',run:async(bot,message,args)=>{
 if(!canManage(message.member,PermissionFlagsBits.ModerateMembers)) return message.reply('⛔ Permission insuffisante.');
 const m=message.mentions.members.first()||await message.guild.members.fetch(args[0]).catch(()=>null); if(!m)return message.reply('Membre introuvable.');
 const r=await quarantineTarget(m,message.author.id,args.slice(1).join(' ')||'Quarantaine manuelle'); return message.reply(r.applied?`🔒 ${m} placé en quarantaine.`:'Impossible de placer ce membre en quarantaine.');
}};
