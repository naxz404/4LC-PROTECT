import { isGlobalOwner } from '../../Owners.js';
import { BrandedEmbedBuilder } from '../../BrandedEmbedBuilder.js';
import * as Discord from "discord.js";
import db from "../../Events/loadDatabase.js";
import { EmbedBuilder } from "discord.js";
import config from "../../config.json" with { type: 'json' }
import sendLog from "../../Events/sendlog.js";

export const command = {
	name: 'renew',
	helpname: 'renew [salon]',
	description: 'Permet de recréer un salon',
	help: 'renew [salon]',
	run: async (bot, message, args, config) => {
		const checkPerm = async (message, commandName) => {
			if (isGlobalOwner(message.author.id)) {
				return true;
			}

			const publicStatut = await new Promise((resolve, reject) => {
				db.get('SELECT statut FROM public WHERE guild = ? AND statut = ?', [message.guild.id, 'on'], (err, row) => {
					if (err) reject(err);
					resolve(!!row);
				});
			});

			if (publicStatut) {

				const checkPublicCmd = await new Promise((resolve, reject) => {
					db.get(
						'SELECT command FROM cmdperm WHERE perm = ? AND command = ? AND guild = ?',
						['public', commandName, message.guild.id],
						(err, row) => {
							if (err) reject(err);
							resolve(!!row);
						}
					);
				});

				if (checkPublicCmd) {
					return true;
				}
			}

			try {
				const checkUserWl = await new Promise((resolve, reject) => {
					db.get('SELECT id FROM whitelist WHERE id = ?', [message.author.id], (err, row) => {
						if (err) reject(err);
						resolve(!!row);
					});
				});

				if (checkUserWl) {
					return true;
				}

				const checkDbOwner = await new Promise((resolve, reject) => {
					db.get('SELECT id FROM owner WHERE id = ?', [message.author.id], (err, row) => {
						if (err) reject(err);
						resolve(!!row);
					});
				});

				if (checkDbOwner) {
					return true;
				}

				const roles = message.member.roles.cache.map(role => role.id);

				const permissions = await new Promise((resolve, reject) => {
					db.all('SELECT perm FROM permissions WHERE id IN (' + roles.map(() => '?').join(',') + ') AND guild = ?', [...roles, message.guild.id], (err, rows) => {
						if (err) reject(err);
						resolve(rows.map(row => row.perm));
					});
				});

				if (permissions.length === 0) {
					return false;
				}

				const checkCmdPermLevel = await new Promise((resolve, reject) => {
					db.all('SELECT command FROM cmdperm WHERE perm IN (' + permissions.map(() => '?').join(',') + ') AND guild = ?', [...permissions, message.guild.id], (err, rows) => {
						if (err) reject(err);
						resolve(rows.map(row => row.command));
					});
				});

				return checkCmdPermLevel.includes(commandName);
			} catch (error) {
				console.error('Erreur lors de la vérification des permissions:', error);
				return false;
			}
		};

		if (!(await checkPerm(message, command.name))) {
			const noacces = new BrandedEmbedBuilder()
				.setDescription("Vous n'avez pas la permission d'utiliser cette commande")
				.setColor(config.color);
			return message.reply({ embeds: [noacces], allowedMentions: { repliedUser: true } }).then(m => setTimeout(() => m.delete().catch(() => { }), 2000));
		}



		const channel = message.mentions.channels.first() || message.guild.channels.cache.get(args[0]) || message.channel;

		// Sauvegarde avant suppression pour garantir la restauration fidèle.
		const oldPosition = channel.rawPosition ?? channel.position;
		const oldParentId = channel.parentId;
		const oldPermissionOverwrites = channel.permissionOverwrites.cache.map((overwrite) => ({
			id: overwrite.id,
			type: overwrite.type,
			allow: overwrite.allow.bitfield,
			deny: overwrite.deny.bitfield,
		}));

		try {
			await message.delete().catch(() => {});

			const clone = await channel.clone({
				reason: `Renew demandé par ${message.author.tag}`,
				permissionOverwrites: oldPermissionOverwrites,
			});

			if (oldParentId && clone.parentId !== oldParentId) {
				await clone.setParent(oldParentId, { lockPermissions: false }).catch(() => {});
			}

			await clone.setPosition(oldPosition).catch(() => {});
			await channel.delete(`Renew demandé par ${message.author.tag}`);

			await clone.send('Salon recréé avec succès avec ses anciennes permissions');

			const embed = new BrandedEmbedBuilder()
				.setColor(config.color)
				.setDescription(`<@${message.author.id}> a recréé <#${clone.id}> avec ses anciennes permissions`)
				.setTimestamp();

			sendLog(message.guild, embed, 'modlog');
		} catch (error) {
			console.error('Erreur lors du renew du salon:', error);
			if (message.channel && message.channel.isTextBased()) {
				await message.channel.send('Impossible de recréer ce salon. Vérifie les permissions du bot.').catch(() => {});
			}
		}

	},
}