import { BrandedEmbedBuilder } from '../../BrandedEmbedBuilder.js';
import { PermissionFlagsBits } from 'discord.js';
import { getGuildConfig, saveGuildConfig } from '../../ProtectCore/storage.js';
import { canManage } from '../../Features/serverSecurity.js';
export const command = { name:'antialt', helpname:'antialt <on/off/status>', description:'Configure l’Anti-alt intelligent', help:'antialt <on/off/status>', run:async(bot,message,args,config)=>{
  if(!canManage(message.member,PermissionFlagsBits.ManageGuild)) return message.reply('⛔ Permission insuffisante.');
  const cfg=getGuildConfig(message.guild.id); cfg.antiAlt ||= {enabled:true,threshold:45,burstCount:5,burstWindowMs:15000,burstPoints:30};
  const a=(args[0]||'status').toLowerCase(); if(['on','off'].includes(a)){cfg.antiAlt.enabled=a==='on'; saveGuildConfig(message.guild.id,cfg);}
  const e=new BrandedEmbedBuilder().setColor(config.color).setTitle('🕵️ Anti-alt').setDescription(`État : **${cfg.antiAlt.enabled?'ON':'OFF'}**\nSeuil : **${cfg.antiAlt.threshold}/100**\nVague : **${cfg.antiAlt.burstCount} arrivées / ${cfg.antiAlt.burstWindowMs/1000}s**\nAction au seuil : **Quarantaine**`);
  return message.reply({embeds:[e]});
}};
