import { PermissionFlagsBits } from 'discord.js';
import { canManage, unquarantineTarget } from '../../Features/serverSecurity.js';
export const command={name:'unquarantine',helpname:'unquarantine <membre>',description:'Retire un membre de quarantaine et restaure ses rôles',help:'unquarantine <membre>',run:async(bot,message,args)=>{
 if(!canManage(message.member,PermissionFlagsBits.ModerateMembers)) return message.reply('⛔ Permission insuffisante.'); const id=message.mentions.users.first()?.id||args[0]; if(!id)return message.reply('Membre requis.');
 const r=await unquarantineTarget(message.guild,id,message.author.id); return message.reply(r.ok?`✅ <@${id}> est sorti de quarantaine et ses anciens rôles ont été restaurés.`:'Aucune quarantaine active trouvée.');
}};
