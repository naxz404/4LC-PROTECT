import { PermissionFlagsBits } from 'discord.js';
import { canManage, fullLockdown } from '../../Features/serverSecurity.js';
export const command={name:'lockdown',helpname:'lockdown [raison]',description:'Verrouille rapidement tout le serveur',help:'lockdown [raison]',run:async(bot,message,args)=>{
 if(!canManage(message.member,PermissionFlagsBits.ManageGuild)) return message.reply('⛔ Permission insuffisante.'); await message.reply('🔒 Lockdown en cours…'); const r=await fullLockdown(message.guild,message.author.id,args.join(' ')||'Lockdown manuel'); return message.channel.send(r.already?'⚠️ Le serveur est déjà en lockdown.':`✅ Lockdown activé sur **${r.count} salons**. Les anciennes permissions ont été sauvegardées.`);
}};
