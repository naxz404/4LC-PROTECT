import { PermissionFlagsBits } from 'discord.js';
import { isGlobalOwner } from '../../Owners.js';
import sendLog from '../../Events/sendlog.js';
import { BrandedEmbedBuilder } from '../../BrandedEmbedBuilder.js';
export const command = {
    name: 'nick', aliases: ['nickname'], helpname: 'nick @membre nouveau pseudo', help: 'nick @membre nouveau pseudo | reset', description: 'Modifier le surnom d’un membre.',
    async run(_bot, message, args, config) {
        const owner = isGlobalOwner(message.author.id);
        if (!owner && message.author.id !== message.guild.ownerId && !message.member?.permissions.has(PermissionFlagsBits.ManageNicknames)) return message.reply('Permission Gérer les surnoms requise.');
        const id = args[0]?.replace(/^<@!?(\d+)>$/, '$1');
        if (!/^\d{17,22}$/.test(id || '')) return message.reply(`Utilisation : ${config.prefix}nick @membre nouveau pseudo | reset`);
        const member = await message.guild.members.fetch(id).catch(() => null);
        if (!member) return message.reply('Membre introuvable.');
        if (!member.manageable || (!owner && message.author.id !== message.guild.ownerId && member.roles.highest.position >= message.member.roles.highest.position)) return message.reply('Le rôle du bot et celui du modérateur doivent être au-dessus de la cible.');
        const value = args.slice(1).join(' ').trim();
        if (!value || value.length > 32) return message.reply('Indique un surnom de 1 à 32 caractères, ou reset.');
        const nick = ['reset', 'off'].includes(value.toLowerCase()) ? null : value;
        await member.setNickname(nick, `4LC-PROTECT · par ${message.author.id}`);
        await sendLog(message.guild, new BrandedEmbedBuilder().setColor(config.color).setDescription(`Surnom de <@${id}> ${nick ? `modifié : **${nick}**` : 'réinitialisé'} par <@${message.author.id}>.`));
        return message.reply({ content: '✅ Surnom modifié.', allowedMentions: { parse: [] } });
    },
};
