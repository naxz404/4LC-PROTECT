import { PermissionFlagsBits } from 'discord.js';
import { canManage, fullUnlockdown } from '../../Features/serverSecurity.js';
export const command={name:'unlockdown',helpname:'unlockdown',description:'Restaure les permissions avant le lockdown',help:'unlockdown',run:async(bot,message)=>{
 if(!canManage(message.member,PermissionFlagsBits.ManageGuild)) return message.reply('⛔ Permission insuffisante.'); await message.reply('🔓 Restauration des permissions…'); const r=await fullUnlockdown(message.guild,message.author.id); return message.channel.send(r.inactive?'⚠️ Aucun lockdown actif.':`✅ Lockdown retiré. Permissions restaurées sur **${r.count} salons**.`);
}};
