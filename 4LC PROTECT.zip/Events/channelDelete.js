import { getGuildConfig } from '../ProtectCore/storage.js';
import { BrandedEmbedBuilder } from '../BrandedEmbedBuilder.js';
import { AuditLogEvent, EmbedBuilder } from 'discord.js';
import sendLog from './sendlog.js';
import db from './loadDatabase.js';
import config from '../config.json' with { type: 'json' };
import { findEntry, punishExecutor, isTrusted } from '../Antiraid/audit.js';

export default {
    name: 'channelDelete',
    async execute(channel) {
        if (!channel?.guild) return;
        const guild = channel.guild;
        db.get('SELECT antichannel FROM antiraid WHERE guild = ?', [guild.id], async (err, settings) => {
            if (getGuildConfig(guild.id).enabled.antichannel || getGuildConfig(guild.id).antiNuke.enabled || err || !settings?.antichannel) return;
            const entry = await findEntry(guild, AuditLogEvent.ChannelDelete, channel.id);
            if (!entry || await isTrusted(guild, entry.executor)) return;
            await punishExecutor(guild, entry.executor, 'antichannel', entry.id);
            try {
                // clone() préserve le type, la catégorie, les permissions et les paramètres du salon.
                const restored = await channel.clone({ reason: '4LC-PROTECT : restauration du salon' });
                await restored.setPosition(channel.rawPosition).catch(() => {});
                db.get('SELECT channels FROM logs WHERE guild = ?', [guild.id], (logErr, row) => {
                    if (logErr || !row?.channels) return;
                    let channels; try { channels = JSON.parse(row.channels); } catch { return; }
                    for (const [name, id] of Object.entries(channels)) if (id === channel.id) channels[name] = restored.id;
                    db.run('UPDATE logs SET channels = ? WHERE guild = ?', [JSON.stringify(channels), guild.id]);
                });
                sendLog(guild, new BrandedEmbedBuilder().setColor(config.color)
                    .setDescription(`<@${entry.executor.id}> a supprimé \`${channel.name}\` ; salon recréé : <#${restored.id}>.`).setTimestamp(), 'raidlog');
            } catch (error) { console.error('[AntiChannel] Restauration impossible:', error); }
        });
    }
};
