import protectionJoin from '../ProtectCore/events/guildCreate.js';
import { ensureCentralLogChannel } from '../Features/centralLogs.js';
export default { name: 'guildCreate', async execute(guild, bot) { await bot.giveawaysManager?.initialize(); await ensureCentralLogChannel(guild); await protectionJoin.execute(bot, guild); } };
