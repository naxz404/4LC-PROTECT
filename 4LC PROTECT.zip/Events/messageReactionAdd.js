import { loadReactionRoles, reactionKey } from '../reactionRoleStore.js';

export default {
  name: 'messageReactionAdd',
  async execute(reaction, user) {
    if (user.bot) return;
    try {
      if (reaction.partial) await reaction.fetch();
      if (reaction.message.partial) await reaction.message.fetch();
      const guild = reaction.message.guild;
      if (!guild) return;
      const data = loadReactionRoles();
      const setup = data[guild.id]?.[reaction.message.id];
      if (!setup) return;
      const mapping = setup.roles?.[reactionKey(reaction.emoji)];
      if (!mapping) return;
      const member = await guild.members.fetch(user.id).catch(() => null);
      const role = guild.roles.cache.get(mapping.roleId);
      if (!member || !role || role.managed) return;
      if (role.position >= guild.members.me.roles.highest.position) return;
      await member.roles.add(role, '4LC-PROTECT • Rôle par réaction');
    } catch (error) {
      console.error('[ReactionRole] Ajout rôle:', error);
    }
  },
};
