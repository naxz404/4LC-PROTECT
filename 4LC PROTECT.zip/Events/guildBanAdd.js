import { getGuildConfig } from '../ProtectCore/storage.js';
import { BrandedEmbedBuilder } from '../BrandedEmbedBuilder.js';
import { EmbedBuilder, AuditLogEvent } from 'discord.js';
import sendLog from "./sendlog.js";
import config from "../config.json" with { type: 'json' };
import db from "./loadDatabase.js";
import { findEntry, punishExecutor, isTrusted } from "../Antiraid/audit.js";

export default {
	name: 'guildBanAdd',
	async execute(ban) {
		const { guild, user } = ban;
		let executor = null;
		const auditEntry = await findEntry(guild, AuditLogEvent.MemberBanAdd, user.id);
		if (auditEntry) {
			executor = auditEntry.executor;
			db.get('SELECT antiban FROM antiraid WHERE guild = ?', [guild.id], async (err, row) => {
				if (getGuildConfig(guild.id).enabled.antiban || getGuildConfig(guild.id).antiNuke.enabled || err || !row?.antiban || executor.id === guild.client.user.id) return;
				if (await isTrusted(guild, executor)) return;
				await punishExecutor(guild, executor, 'antiban', auditEntry.id);
				await guild.bans.remove(user.id, '4LC-PROTECT : bannissement non autorisé').catch(console.error);
			});
		}

		try {
			const fetchedLogs = await guild.fetchAuditLogs({
				limit: 1,
				type: AuditLogEvent.MemberBanAdd,
			});
			const banLog = fetchedLogs.entries.find(entry =>
				entry.target.id === user.id &&
				Date.now() - entry.createdTimestamp < 5000
			);
			if (banLog) executor = banLog.executor;
		} catch (e) { }

		const embed = new BrandedEmbedBuilder()
			.setColor(config.color)
			.setDescription(
				`<@${user.id}> a été banni du serveur` +
				(executor ? ` par <@${executor.id}>` : '')
			)
			.setTimestamp();
		sendLog(guild, embed, 'modlog');
	}
};