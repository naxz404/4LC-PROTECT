import { allowedGuilds, initializeServerScope } from '../ServerScope.js';
import { applyConfiguredPresence } from '../ProtectCore/presence.js';
import { syncAllGuildCommands } from '../ProtectCore/slash/sync.js';
import { bootProtectCore } from '../ProtectCore/bridge.js';
import { startSupport } from '../ProtectModules/integration.js';
import { ActivityType } from "discord.js";
import { resumeVerification } from "../Antiraid/raidMode.js";
import { ensureCentralLogChannel } from '../Features/centralLogs.js';

export default {
	name: 'clientReady', once: true,
	async execute(bot) {
		const target = initializeServerScope(bot);
        if (!target) console.warn('[4LC-PROTECT] Renseigne guildId ou GUILD_ID : aucun serveur unique ne peut être choisi.');
        await bot.application.commands.set([]);
        if (target) await bot.giveawaysManager?.initialize();
		await resumeVerification(bot);
        await startSupport(bot);
        await bootProtectCore(bot);
        for (const guild of allowedGuilds(bot)) await ensureCentralLogChannel(guild).catch(error => console.error('[4LC Logs] Initialisation:', error));

        applyConfiguredPresence(bot, { force: true });
        setInterval(() => { try { applyConfiguredPresence(bot); } catch (error) { console.error('[4LC-PROTECT] Statut:', error); } }, 60_000).unref();
        await syncAllGuildCommands(bot);
    }
};
