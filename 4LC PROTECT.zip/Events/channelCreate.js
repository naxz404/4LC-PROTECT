import { getGuildConfig } from '../ProtectCore/storage.js';
import { protectChannelForVerification } from '../Captcha/onboarding.js';
import { BrandedEmbedBuilder } from '../BrandedEmbedBuilder.js';
import { AuditLogEvent, EmbedBuilder } from 'discord.js';
import sendLog from './sendlog.js';
import db from './loadDatabase.js';
import config from '../config.json' with { type: 'json' };
import { findEntry, punishExecutor, isTrusted } from '../Antiraid/audit.js';
export default {
    name: 'channelCreate',
    async execute(channel) {
        if (!channel?.guild) return;
        await protectChannelForVerification(channel).catch(console.error);
        db.get('SELECT antichannel FROM antiraid WHERE guild = ?', [channel.guild.id], async (err, row) => {
            if (getGuildConfig(channel.guild.id).enabled.antichannel || getGuildConfig(channel.guild.id).antiNuke.enabled || err || !row?.antichannel) return;
            const entry = await findEntry(channel.guild, AuditLogEvent.ChannelCreate, channel.id);
            if (!entry || await isTrusted(channel.guild, entry.executor)) return;
            await punishExecutor(channel.guild, entry.executor, 'antichannel', entry.id);
            await channel.delete('4LC-PROTECT : création non autorisée').catch(console.error);
            sendLog(channel.guild, new BrandedEmbedBuilder().setColor(config.color)
                .setDescription(`<@${entry.executor.id}> a créé un salon non autorisé : \`${channel.name}\`.`).setTimestamp(), 'raidlog');
        });
    }
};
