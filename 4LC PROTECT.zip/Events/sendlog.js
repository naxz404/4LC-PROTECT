import { ensureCentralLogChannel } from '../Features/centralLogs.js';

async function sendLog(guild, embed, _type = 'modlog') {
  if (!guild) return;
  const logChannel = await ensureCentralLogChannel(guild).catch(() => null);
  if (!logChannel) return;
  if (!embed.data?.footer) embed.setFooter({ text: 'By 4LC | discord.gg/ddJMXWYJ29' });
  else if (!String(embed.data.footer.text || '').includes('discord.gg/ddJMXWYJ29')) embed.setFooter({ text: `${embed.data.footer.text} | By 4LC | discord.gg/ddJMXWYJ29` });
  await logChannel.send({ embeds: [embed] }).catch(() => {});
}
export default sendLog;
