import protectionMessage from '../ProtectCore/events/messageCreate.js';
import { getGuildConfig } from '../ProtectCore/storage.js';
import { ticketMessage } from '../ProtectModules/integration.js';
import { BrandedEmbedBuilder } from '../BrandedEmbedBuilder.js';
import config from "../config.json" with { type: 'json' }
import { EmbedBuilder } from "discord.js";
import db from "./loadDatabase.js";
const spamMap = new Map();

export default {
	name: 'messageCreate',
	async execute(message, bot, config) {
		if (!message.guild) return;
		if (await protectionMessage.execute(bot, message)) return;
		if (message.author?.bot || message.webhookId) return;
		await ticketMessage(bot, message).catch(error => console.error('[Tickets] Activité :', error));
		await handleCommands(message, bot, config);
	},
};

export const handleCommands = async (message, bot, rootConfig) => {
	const config = { ...rootConfig, prefix: getGuildConfig(message.guild.id).prefix || rootConfig.prefix };
	if (!config.prefix) config.prefix = '+';
	const prefixPing = () => message.reply({
		content: `Mon préfixe est \`${config.prefix}\`.`,
		allowedMentions: { repliedUser: false }
	});

	if (new RegExp(`^<@!?${bot.user.id}>`).test(message.content)) {
		const args = message.content.replace(new RegExp(`^<@!?${bot.user.id}>`), '').trim().split(/ +/);
		const commandName = args.shift()?.toLowerCase();

		if (!commandName) return prefixPing();

		const commandFile = bot.commands.get(commandName);
		if (!commandFile) return prefixPing();

		await commandFile.run(bot, message, args, config);
	} else if (message.content.startsWith(config.prefix)) {
		const args = message.content.slice(config.prefix.length).trim().split(/ +/);
		const commandName = args.shift()?.toLowerCase();

		const commandFile = bot.commands.get(commandName);
		if (!commandFile) return;

		await commandFile.run(bot, message, args, config);
	}
};
