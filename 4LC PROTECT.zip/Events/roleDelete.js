import { getGuildConfig } from '../ProtectCore/storage.js';
import { BrandedEmbedBuilder } from '../BrandedEmbedBuilder.js';
import { AuditLogEvent, EmbedBuilder } from 'discord.js';
import db from './loadDatabase.js';
import sendLog from './sendlog.js';
import config from '../config.json' with { type: 'json' };
import { findEntry, punishExecutor, isTrusted } from '../Antiraid/audit.js';
export default {
    name: 'roleDelete',
    async execute(role) {
        if (!role?.guild || role.managed || role.id === role.guild.id) return;
        const guild = role.guild;
        db.get('SELECT antirole FROM antiraid WHERE guild = ?', [guild.id], async (err, settings) => {
            if (getGuildConfig(guild.id).enabled.antirole || getGuildConfig(guild.id).antiNuke.enabled || err || !settings?.antirole) return;
            const entry = await findEntry(guild, AuditLogEvent.RoleDelete, role.id);
            if (!entry || await isTrusted(guild, entry.executor)) return;
            await punishExecutor(guild, entry.executor, 'antirole', entry.id);
            try {
                const replacement = await guild.roles.create({ name: role.name, color: role.color, hoist: role.hoist, mentionable: role.mentionable, permissions: role.permissions.bitfield, reason: '4LC-PROTECT : restauration du rôle' });
                await replacement.setPosition(role.position).catch(() => {});
                sendLog(guild, new BrandedEmbedBuilder().setColor(config.color)
                    .setDescription(`<@${entry.executor.id}> a supprimé le rôle \`${role.name}\` ; rôle recréé : <@&${replacement.id}>. Vérifiez les attributions des membres.`).setTimestamp(), 'raidlog');
            } catch (error) { console.error('[AntiRole] Restauration impossible:', error); }
        });
    }
};
