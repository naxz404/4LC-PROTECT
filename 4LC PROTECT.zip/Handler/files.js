import { readdirSync } from 'node:fs';
import { resolve } from 'node:path';
import { pathToFileURL } from 'node:url';
export function moduleFiles(directory) {
    return readdirSync(directory, { withFileTypes: true }).flatMap(entry => {
        const path = resolve(directory, entry.name);
        return entry.isDirectory() ? moduleFiles(path) : entry.isFile() && entry.name.endsWith('.js') ? [pathToFileURL(path)] : [];
    });
}
