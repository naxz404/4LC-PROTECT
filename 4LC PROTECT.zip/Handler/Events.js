import { allowServerEvent } from '../ServerScope.js';
import config from '../config.json' with { type: 'json' };
import { moduleFiles } from './files.js';
export default async bot => {
    for (const url of moduleFiles(new URL('../Events/', import.meta.url).pathname)) {
        const event = (await import(url.href)).default;
        if (!event?.name || typeof event.execute !== 'function') continue;
        const handler = (...args) => Promise.resolve().then(() => allowServerEvent(bot, event.name, args) ? event.execute(...args, bot, config) : undefined).catch(error => console.error(`[4LC-PROTECT] ${event.name}:`, error));
        if (event.once) bot.once(event.name, handler);
        else bot.on(event.name, handler);
    }
};
