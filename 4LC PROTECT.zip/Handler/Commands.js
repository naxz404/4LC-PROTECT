import { moduleFiles } from './files.js';
export default async bot => {
    for (const url of moduleFiles(new URL('../Commands/', import.meta.url).pathname)) {
        const props = (await import(url.href)).command;
        if (!props?.name || typeof props.run !== 'function') continue;
        props.category ||= decodeURIComponent(url.pathname.split('/').at(-2));
        bot.commands.set(props.name.toLowerCase(), props);
        for (const alias of props.aliases || []) bot.commands.set(alias.toLowerCase(), props);
    }
    const { installProtectTextCommands } = await import('../ProtectCore/bridge.js');
    await installProtectTextCommands(bot);
};
